# DEVXPE Child

DEVXPE temasının alt (child) teması. Küçük stil/JS özelleştirmelerini, üst temayı
güncellemenin güvenliğini bozmadan yapmayı sağlar.

## Child tema nedir?

Child tema, üst temanın **tüm şablonlarını ve işleyişini** miras alan ince bir
sarmalayıcıdır. Üst temada tanımlı her şey (header, footer, sayfalar, panel)
aynen çalışır; child'da yalnızca **senin eklediğin** değişiklikler bulunur.

Kurallar:

- `get_template_directory()` → **üst tema** (`devxpe`) — şablonlar buradan gelir.
- `get_stylesheet_directory()` → **bu child tema** — kendi dosyaların buradan gelir.

## Nereye özelleştirme yazarım?

| Ne yapmak istiyorum | Nereye |
|---|---|
| CSS eklemek / değiştirmek | `style.css` (üst stilden sonra yüklenir, kazanır) |
| Küçük JS eklemek | `functions.php` içinde `wp_enqueue_script` |
| PHP mantığı (küçük) | `functions.php` |

`style.css` içindeki `/* Özelleştirmelerinizi buraya yazın. */` satırının altına
kendi CSS kurallarını ekle. Sass/derleme adımı yok; düz CSS yeterli.

## Güncelleme güvenliği

Üst tema (`devxpe`) güncellendiğinde **bu klasör korunur**; WordPress üst temayı
ayrı bir klasörde günceller. Bu yüzden küçük özelleştirmeler burada güvenle durur.

## Ne zaman child KULLANILIR?

- Üst temanın CSS'ini ezmek/eklemek,
- Birkaç satır JS eklemek,
- Üst temanın davranışına küçük PHP kancaları (`add_filter`/`add_action`) eklemek.

## Ne zaman child KULLANILMAZ?

- **Şablon dosyasını override etmek** gerekiyorsa (ör. `header.php`'yi kopyalayıp
  değiştirmek). Override edilen dosya artık güncellenmez; üst tema güncellemesiyle
  gelen düzeltmeler child'daki eski kopya yüzünden kaybolabilir. Bu durumda
  değişiklik üst temaya yapılmalı ya da override bilinçli yönetilmeli.
- Büyük/yapısal değişiklikler gerekiyorsa (child bunu saklamaz, borç oluşturur).

## Template alanı neden önemli?

`style.css` başlığındaki `Template: devxpe` satırı, WordPress'e bu temanın
**hangi üst temanın child'ı** olduğunu söyler. Değer, üst temanın **klasör adıyla
birebir** aynı olmak zorundadır (`wp-content/themes/devxpe/`). Yanlış yazılırsa
child etkinleşmez veya üst tema bulunamaz.

## Sürümleme

`style.css` içindeki `Version` **child temasına aittir**, üst temanın sürümünü
takip etmez. Üst temanın güncelleme kanalı bu dosyayı etkilemez.

## Zip üretimi (paketleme)

Child tema **kendi başına** paketlenir; üst tema paketine (`devxpetema.zip`)
**dahil edilmez** ve yayın kanalına **girmez**.

- Panel: `prod/panel/` → **"Child Tema"** bölümü → **"Child Zip Üret"**.
- Çıktı: `prod/child/devxpe-child.zip` (düz zip; kök klasör yok).
- GitHub'a push **yapılmaz**; `update.json`'a yazılmaz → otomatik güncellenmez.

## Müşteriye kurulum

1. Görünüm → Temalar → **Yeni Ekle** → **Tema Yükle**.
2. `devxpe-child.zip` dosyasını seç ve yükle.
3. **Etkinleştir**.

Üst tema (`devxpe`) **kurulu ve etkin** olmalıdır; child, `Template: devxpe`
satırıyla üst temaya bağlanır.

## Güncelleme ilişkisi

- Üst tema güncellenince child **bozulmaz**; WordPress üst temayı ayrı klasörde
  günceller, child dosyalarına dokunmaz.
- Child sürümü **bağımsızdır** (ör. 1.0.0); üst temanın sürümünü takip etmez.
- Child `update.json`'a **girmez** → panelden **otomatik güncellenmez**. Yeni bir
  child sürümü gerekiyorsa zip yeniden üretilip müşteriye **elle** verilir.
