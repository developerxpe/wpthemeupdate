<?php
/**
 * DEVXPE Child tema.
 *
 * Üst tema (devxpe) şablonlarını ve stilini miras alır; buraya yalnızca küçük
 * stil/JS özelleştirmeleri eklenir. Üst temayı GÜNCELLEMEK child'ı bozmaz.
 *
 * - get_template_directory()    → üst tema (devxpe)
 * - get_stylesheet_directory()  → bu child tema
 *
 * @package Devxpe_Child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Üst tema stilinden SONRA child `style.css`'ini yükler.
 *
 * `devxpe-theme-style` bağımlılığı, üst tema stilinin sırası değişse bile
 * child stilin daima sonra yüklenmesini garanti eder; böylece child
 * özelleştirmeleri üst tema kurallarını geçersiz kılabilir.
 *
 * @return void
 */
function devxpe_child_stil() {
	$child_style = get_stylesheet_directory() . '/style.css';

	wp_enqueue_style(
		'devxpe-child-style',
		get_stylesheet_uri(),
		array( 'devxpe-theme-style' ),
		filemtime( $child_style )
	);
}
add_action( 'wp_enqueue_scripts', 'devxpe_child_stil', 20 );
