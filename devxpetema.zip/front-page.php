<?php
/**
 * Anasayfa (front page) şablonu.
 *
 * Bölümler (hero, slider, hizmetler vb.) 'devxpe_content_top' kancasından
 * çağrılan template-parts/home-sections.php içinde render edilir; paneldeki
 * "Gösterileceği Yer" ayarına göre anasayfada/tüm sayfalarda/seçili
 * sayfalarda görünür.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
get_footer();
