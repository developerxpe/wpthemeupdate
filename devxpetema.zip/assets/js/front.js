/**
 * DEVXPE tema on yuz betigi.
 *
 * Panelden uretilen dinamik ayarlar (window.dxpFormMsgs / window.dxpFormConfig)
 * bu dosyadan ONCE inline olarak basılır; burada yalnızca statik davranış var.
 *
 * @package Devxpe_Theme
 */

/* ── akordeon ── */
(function(){const rm=window.matchMedia&&window.matchMedia("(prefers-reduced-motion: reduce)").matches;function setOpen(d,p,open){if(!p){d.open=open;return;}if(p.getAnimations){p.getAnimations().forEach(function(a){a.cancel();});}let h;if(open){d.open=true;h=p.scrollHeight;if(rm){return;}p.animate([{height:"0px"},{height:h+"px"}],{duration:200,easing:"ease-out"});return;}h=p.scrollHeight;if(rm){d.open=false;return;}const a=p.animate([{height:h+"px"},{height:"0px"}],{duration:200,easing:"ease-out"});a.onfinish=function(){d.open=false;};}document.addEventListener("click",function(e){const s=e.target.closest?e.target.closest("summary.dxp-acc-btn"):null;if(!s){return;}const d=s.parentElement;if(!d||!d.classList.contains("dxp-acc")){return;}e.preventDefault();setOpen(d,d.querySelector(".dxp-acc-panel"),!d.open);});})();

/* ── dogrulama ── */
(function () {
	const msgs = window.dxpFormMsgs || {};
	const cfg  = window.dxpFormConfig || {};

	/* Eski önbellekteki sayfalarda ayar gelmezse doğrulama açık kabul edilir. */
	if ( 'undefined' === typeof cfg.enable ) { cfg.enable = true; }

	function digits( v ) { return String( v || '' ).replace( /\D/g, '' ); }

	/*
	 * Telefon alanındaki ülke kodu (varsa) ve ulusal rakam sayısı.
	 *
	 * Ulusal rakamlar: seçili ülkenin kodu (+44 / 0044) ve baştaki ulusal 0
	 * sayılmaz. Başka bir ülke kodu elle yazıldıysa null döner (karışmayız).
	 */
	function ccValue( el ) {
		const wrap = el.closest ? el.closest( '.dxp-tel-wrap' ) : null;
		const ccEl = wrap ? wrap.querySelector( '.dxp-cc' ) : null;
		return ccEl ? ccEl.value : '';
	}

	function nationalDigits( val, cc ) {
		const d   = digits( val );
		const raw = String( val ).replace( /[^0-9+]/g, '' );

		if ( ! cc ) { return d; }

		const code = digits( cc );

		if ( 0 === raw.indexOf( '+' ) ) {
			return ( 0 === raw.indexOf( '+' + code ) ) ? d.slice( code.length ) : null;
		}
		if ( 0 === raw.indexOf( '00' + code ) ) {
			return d.slice( 2 + code.length );
		}
		if ( '0' === d.charAt( 0 ) ) {
			return d.slice( 1 );
		}

		return d;
	}

	/*
	 * Telefonun geçerli rakam aralığı: yanındaki ülke seçicisi varsa o ülkenin
	 * uzunluğu (yerleşik tablo), yoksa paneldeki genel min/max.
	 */
	function phoneRange( el ) {
		let lo = parseInt( cfg.phoneMin, 10 ) || 7;
		let hi = parseInt( cfg.phoneMax, 10 ) || 20;
		const cc = ccValue( el );

		if ( cc && cfg.phoneLengths && cfg.phoneLengths[ cc ] ) {
			const r = cfg.phoneLengths[ cc ];
			lo = parseInt( r[ 0 ], 10 ) || lo;
			hi = parseInt( r[ 1 ], 10 ) || hi;
		}

		return { min: lo, max: hi };
	}

	function ruleOf( el ) {
		const r = el.getAttribute( 'data-dxp-rule' );
		if ( r ) { return r; }
		const t = ( el.getAttribute( 'type' ) || '' ).toLowerCase();
		if ( t === 'email' ) { return 'email'; }
		if ( t === 'tel' ) { return 'phone'; }
		return '';
	}

	function isRequired( el ) {
		return el.hasAttribute( 'required' ) || el.getAttribute( 'data-required' ) === '1';
	}

	/* Kapalı adımdaki alanlar doğrulanmaz. */
	function visible( el ) {
		return !!( el.offsetParent || el.getClientRects().length );
	}

	function fields( root ) {
		return Array.prototype.filter.call( root.querySelectorAll( 'input, select, textarea' ), function ( el ) {
			if ( el.type === 'hidden' || el.disabled || ! el.name || el.name === 'website' ) { return false; }
			return visible( el );
		} );
	}

	function holderOf( el ) {
		return el.closest( '.dxp-field, .dxp-qfield, .dxp-consent' ) || el.parentNode;
	}

	function noteOf( el ) {
		const holder = holderOf( el );
		let note   = holder.querySelector( '.dxp-field-error' );
		if ( ! note ) {
			note = document.createElement( 'small' );
			note.className = 'dxp-field-error';
			note.id = 'dxp-note-' + ( el.id || el.name );
			holder.appendChild( note );
			el.setAttribute( 'aria-describedby', note.id );
		}
		return note;
	}

	/* '' dönerse geçerli; aksi hâlde mesaj anahtarı döner. */
	function check( el ) {
		if ( el.type === 'checkbox' ) {
			return ( isRequired( el ) && ! el.checked ) ? 'required' : '';
		}
		if ( el.type === 'file' ) {
			return ( isRequired( el ) && ( ! el.files || ! el.files.length ) ) ? 'required' : '';
		}

		const val = ( el.value || '' ).trim();

		if ( ! val ) { return isRequired( el ) ? 'required' : ''; }

		const rule = ruleOf( el );

		if ( rule === 'email' ) {
			if ( ! /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test( val ) ) { return 'email'; }

			/* Kabul edilen uzantı listesi doluysa alan adı eşleşmeli. */
			if ( cfg.emailTlds && cfg.emailTlds.length ) {
				const dom = val.split( '@' ).pop().toLowerCase();
				let ok  = false;
				cfg.emailTlds.forEach( function ( t ) {
					if ( dom === t || dom.slice( -1 * ( t.length + 1 ) ) === '.' + t ) { ok = true; }
				} );
				if ( ! ok ) { return 'tld'; }
			}
		}

		if ( rule === 'phone' ) {
			if ( ! /^\+?[0-9\s().-]+$/.test( val ) ) { return 'phone'; }

			const rng = phoneRange( el );
			const nd  = nationalDigits( val, ccValue( el ) );

			/* Başka bir ülke kodu yazılmışsa (nd null) uzunluğa karışmayız. */
			if ( null !== nd && ( nd.length < rng.min || nd.length > rng.max ) ) { return 'phone'; }
		}

		/*
		 * Uzunluk: tek satırlık alanlarda genel ayar (Metin — En Az/Çok Karakter),
		 * textarea'da yalnızca alana özel data-dxp-min/max verilmişse uygulanır.
		 */
		const minAttr = el.getAttribute( 'data-dxp-min' );
		const maxAttr = el.getAttribute( 'data-dxp-max' );
		const single  = ( 'INPUT' === el.tagName && [ 'text', 'email', 'tel', 'url' ].indexOf( el.type ) > -1 );
		let min     = null;
		let max     = null;

		if ( null !== minAttr ) { min = parseInt( minAttr, 10 ); }
		else if ( null !== el.getAttribute( 'minlength' ) ) { min = parseInt( el.getAttribute( 'minlength' ), 10 ); }
		else if ( single && cfg.textMin ) { min = parseInt( cfg.textMin, 10 ); }

		if ( null !== maxAttr ) { max = parseInt( maxAttr, 10 ); }
		else if ( null !== el.getAttribute( 'maxlength' ) ) { max = parseInt( el.getAttribute( 'maxlength' ), 10 ); }
		else if ( single && cfg.textMax ) { max = parseInt( cfg.textMax, 10 ); }

		if ( min && val.length < min ) { return 'min'; }
		if ( max && val.length > max ) { return 'max'; }

		return '';
	}

	function mark( el, key ) {
		const note = noteOf( el );
		note.textContent = key
			? ( el.getAttribute( 'data-dxp-msg-' + key ) || el.getAttribute( 'data-dxp-msg' ) || msgs[ key ] || msgs.invalid )
			: '';
		note.hidden = ! key;
		if ( key ) { el.setAttribute( 'aria-invalid', 'true' ); } else { el.removeAttribute( 'aria-invalid' ); }
		const holder = holderOf( el );
		if ( holder && holder.classList ) { holder.classList.toggle( 'is-invalid', !! key ); }
	}

	window.dxpFormValidate = function ( form, scope ) {
		/* Doğrulama panelden kapatıldıysa yalnızca sunucu kontrolü kalır. */
		if ( ! cfg.enable ) { return true; }

		const bad = [];
		fields( scope || form ).forEach( function ( el ) {
			const key = check( el );
			mark( el, key );
			if ( key ) { bad.push( el ); }
		} );
		if ( ! bad.length ) { return true; }
		if ( bad[0].focus ) { bad[0].focus(); }
		if ( bad[0].scrollIntoView ) { bad[0].scrollIntoView( { block: 'center', behavior: 'smooth' } ); }
		return false;
	};

	/*
	 * Adım geçişi kontrolü (teklif formu).
	 *
	 * NEDEN AYRI: `dxpFormValidate` paneldeki "Doğrulama" ayarına bağlıdır
	 * (kapatılınca daima true döner). Kullanıcı "adımları doldurmadan
	 * geçilmesin" dediği için bu kontrol panelden BAĞIMSIZ çalışır.
	 *
	 * Kurallar (step = 1..4):
	 *   1 → hizmet seçilmiş olmalı
	 *   2 → en az bir alan doldurulmuş olmalı
	 *   3 → ad + e-posta + telefon dolu ve geçerli olmalı
	 *   4 → gizlilik onayı işaretli olmalı
	 * Hata varsa alanı işaretler, ilkini odaklar ve false döner.
	 */
	window.dxpStepValidate = function ( form, step ) {
		const root = form.querySelector( '.dxp-qstep[data-step="' + step + '"]' );
		if ( ! root ) { return true; }

		/* 1. adımda alan yok; seçili hizmet butonu/`service` değeri kontrol edilir. */
		if ( 1 === step ) {
			const svc = form.querySelector( '[name="service"]' );
			if ( svc && svc.value ) { return true; }
			const pe = root.querySelector( '.dxp-field-error' );
			if ( pe ) { pe.hidden = false; }
			return false;
		}

		const bad = [];
		const fail = function ( el ) {
			mark( el, 'required' );
			bad.push( el );
		};

		if ( 2 === step ) {
			/* En az bir alan dolu olmalı (hepsi boşsa devam edilmez). */
			const list = fields( root );
			const filled = list.some( function ( el ) {
				return ( 'checkbox' === el.type ) ? el.checked : !! ( el.value || '' ).trim();
			} );
			if ( list.length && ! filled ) { fail( list[0] ); }
		} else if ( 3 === step ) {
			/* İletişim adımı: ad, e-posta ve telefon şart. */
			[ 'name', 'email', 'phone' ].forEach( function ( name ) {
				const el = root.querySelector( '[name="' + name + '"]' );
				if ( ! el ) { return; }
				if ( ! ( el.value || '' ).trim() ) { fail( el ); return; }
				const key = check( el );
				if ( key ) { mark( el, key ); bad.push( el ); }
			} );
		} else if ( 4 === step ) {
			const ck = root.querySelector( '[name="consent"]' );
			if ( ck && ! ck.checked ) { fail( ck ); }
		}

		if ( ! bad.length ) { return true; }
		if ( bad[0].focus ) { bad[0].focus(); }
		if ( bad[0].scrollIntoView ) { bad[0].scrollIntoView( { block: 'center', behavior: 'smooth' } ); }
		return false;
	};

	/* Kullanıcı düzeltince not hemen silinsin. */
	function clearIfFixed( e ) {
		const el = e.target;
		if ( ! el || ! el.getAttribute || el.getAttribute( 'aria-invalid' ) !== 'true' ) { return; }
		if ( ! check( el ) ) { mark( el, '' ); }
	}
	document.addEventListener( 'input', clearIfFixed, true );
	document.addEventListener( 'change', clearIfFixed, true );

	/*
	 * Sadece sayı girişi: telefon/sayı alanlarına harf ve izinsiz simge
	 * yazılmasını engeller (yazarken temizlenir). Telefonda + ve ayraçlar kalır.
	 */
	if ( cfg.numbersOnly ) {
		document.addEventListener( 'input', function ( e ) {
			const el = e.target;
			if ( ! el || 'INPUT' !== el.tagName ) { return; }

			const rule = ruleOf( el );
			if ( 'phone' !== rule && 'number' !== el.type ) { return; }

			const strip = ( 'phone' === rule ) ? /[^0-9+\s().-]/g : /[^0-9.,-]/g;
			let clean = el.value.replace( strip, '' );

			/* Telefon: seçili ülkenin rakam sınırı aşılırsa fazlası yazılmaz. */
			if ( 'phone' === rule ) {
				const cc    = ccValue( el );
				const maxD  = phoneRange( el ).max;
				let nd    = nationalDigits( clean, cc );
				let guard = 0;

				/* Sondan kırparak sınıra indir (ayraçlar da gidebilir). */
				while ( null !== nd && nd.length > maxD && clean.length && guard++ < 40 ) {
					clean = clean.slice( 0, -1 );
					nd    = nationalDigits( clean, cc );
				}
			}

			if ( clean !== el.value ) { el.value = clean; }
		}, true );
	}

	/* Uzun metin sayaçları: "12 / 500" */
	function refreshCount( el ) {		if ( ! el || ( 'TEXTAREA' !== el.tagName && 'INPUT' !== el.tagName ) ) { return; }

		let box = el.parentNode;
		while ( box && box !== document.body ) {
			const count = box.querySelector ? box.querySelector( '.dxp-count' ) : null;
			if ( count ) {
				const max = parseInt( count.getAttribute( 'data-max' ), 10 ) || 0;
				count.textContent = el.value.length + ( max ? ' / ' + max : '' );
				count.classList.toggle( 'is-full', !! max && el.value.length >= max );
				return;
			}
			box = box.parentNode;
		}
	}

	document.addEventListener( 'input', function ( e ) {
		refreshCount( e.target );
	}, true );

	/* Ülke değişince: numarayı yeni ülkenin sınırına göre kırp, hatayı tazele. */
	document.addEventListener( 'change', function ( e ) {
		const el = e.target;
		if ( ! el || ! el.classList || ! el.classList.contains( 'dxp-cc' ) ) { return; }

		const wrap  = el.closest( '.dxp-tel-wrap' );
		const phone = wrap ? wrap.querySelector( 'input' ) : null;
		if ( ! phone ) { return; }

		const cc    = el.value;
		const maxD  = phoneRange( phone ).max;
		let value = phone.value.replace( /[^0-9+\s().-]/g, '' );
		let nd    = nationalDigits( value, cc );
		let guard = 0;

		while ( null !== nd && nd.length > maxD && value.length && guard++ < 40 ) {
			value = value.slice( 0, -1 );
			nd    = nationalDigits( value, cc );
		}
		phone.value = value;

		if ( phone.getAttribute( 'aria-invalid' ) === 'true' ) {
			mark( phone, check( phone ) );
		}
	}, true );

	/* Açılışta dolu gelen alanlar için bir kez güncelle. */
	document.addEventListener( 'DOMContentLoaded', function () {
		Array.prototype.forEach.call( document.querySelectorAll( '.dxp-count' ), function ( count ) {
			const box   = count.parentNode;
			const field = box ? box.querySelector( 'textarea, input' ) : null;
			if ( field ) { refreshCount( field ); }
		} );
	} );
})();

/* ── popup ── */
(function(){const t=document.querySelector(".dxp-float--top");if(t){const f=function(){t.classList.toggle("is-visible",window.scrollY>320);};window.addEventListener("scroll",f,{passive:true});f();t.addEventListener("click",function(){window.scrollTo({top:0,behavior:"smooth"});});}const p=document.getElementById("dxp-popup");if(!p){return;}const K="dxp_popup_hide",fr=p.getAttribute("data-frequency")||"always";function day(){const d=new Date();return d.getFullYear()+"-"+d.getMonth()+"-"+d.getDate();}function seen(){try{if(fr==="session"){return sessionStorage.getItem(K)==="1";}if(fr==="day"){return localStorage.getItem(K)===day();}if(fr==="once"){return localStorage.getItem(K)==="1";}}catch(e){}return false;}function mark(){try{if(fr==="session"){sessionStorage.setItem(K,"1");}else if(fr==="day"){localStorage.setItem(K,day());}else if(fr==="once"){localStorage.setItem(K,"1");}}catch(e){}}function show(){p.classList.add("is-open");const x=p.querySelector(".dxp-popup-x");if(x){x.focus();}}function hide(){p.classList.remove("is-open");mark();}document.addEventListener("click",function(e){if(!e.target.closest){return;}if(e.target.closest("[data-dxp-popup-close]")||e.target===p){hide();return;}const el=e.target.closest("a,[data-dxp-popup]");if(el&&(el.hasAttribute("data-dxp-popup")||(el.getAttribute("href")||"").indexOf("#duyuru")>-1)){e.preventDefault();show();}});document.addEventListener("keydown",function(e){if(e.key==="Escape"&&p.classList.contains("is-open")){hide();}});if(p.getAttribute("data-auto")==="1"&&!seen()){const dl=parseInt(p.getAttribute("data-delay")||"0",10);setTimeout(show,dl>0?dl*1000:0);}})();

/* ── menu ── */
document.addEventListener('DOMContentLoaded', function () {
	const btn   = document.getElementById( 'dxp-burger-btn' );
	const nav   = document.getElementById( 'dxp-mobile-nav' );
	if ( ! btn || ! nav ) return;

	const ov    = document.getElementById( 'dxp-menu-overlay' );
	const close = document.getElementById( 'dxp-burger-close' );

	/*
	 * Header yüksekliğini CSS'e değişken olarak ver: off-canvas/dropdown panelin
	 * üst boşluğu header'ın altında kalmasın. Header boyu üst barda değişebilir.
	 */
	const header = document.querySelector( '.dxp-header' );
	function syncHeaderHeight() {
		if ( header ) {
			document.documentElement.style.setProperty( '--dxp-header-h', header.offsetHeight + 'px' );
		}
	}
	syncHeaderHeight();
	window.addEventListener( 'resize', syncHeaderHeight );

	/*
	 * Kaydırma çubuğu genişliğini CSS'e değişken olarak ver.
	 *
	 * NEDEN: Menü açılınca `html { overflow:hidden }` klasik kaydırma çubuğunu
	 * kaldırır ve içerik o kadar GENİŞLER (ölçüm: +15px). CSS, menü açıkken
	 * gövdeye bu genişlik kadar sağ boşluk vererek genişlemeyi engeller.
	 * Mobilde (overlay çubuk) değer 0 olur; zararsız.
	 */
	function syncScrollbarWidth() {
		const gen = window.innerWidth - document.documentElement.clientWidth;
		document.documentElement.style.setProperty( '--dxp-scrollbar-w', ( gen > 0 ? gen : 0 ) + 'px' );
	}
	syncScrollbarWidth();
	window.addEventListener( 'resize', syncScrollbarWidth );

	function setOpen( open ) {
		if ( open ) syncHeaderHeight();
		nav.classList.toggle( 'open', open );
		btn.classList.toggle( 'open', open );
		btn.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
		if ( ov ) ov.classList.toggle( 'open', open );

		/*
		 * Kaydırma kilidi ve header'ı üste taşıma TÜM stillerde uygulanır
		 * (dropdown dâhil; artık o da ekranı kaplayan bir panel).
		 *
		 * Kilit <html> üzerinde: overflow:hidden kaydırma konumunu korur
		 * (sayfa ortasında açılsa da zıplama olmaz) ve sticky header'ı bozmaz.
		 * body'ye verilirse body kaydırma kapsayıcısı olur, sticky header
		 * ekran dışına kayar; bu yüzden html kullanılır. Header 1060 ile
		 * overlay (1040) ve panel (1050) üstüne çıkar; hamburger tıklanır kalır.
		 */
		document.documentElement.classList.toggle( 'dxp-menu-open', open );
	}

	btn.addEventListener( 'click', function () { setOpen( ! nav.classList.contains( 'open' ) ); } );
	if ( close ) close.addEventListener( 'click', function () { setOpen( false ); } );
	if ( ov ) ov.addEventListener( 'click', function () { setOpen( false ); } );

	document.addEventListener( 'keydown', function ( e ) { if ( 'Escape' === e.key ) setOpen( false ); } );

	/* Hamburger görünmez olduysa (kırılma noktası aşıldı) menüyü kapat. */
	window.addEventListener( 'resize', function () { if ( ! btn.offsetParent ) setOpen( false ); } );
});

