<?php
/**
 * Varsayılan (index) şablonu — son çare şablon.
 *
 * Normalde blog sayfası `home.php`, arşivler `archive.php`, arama `search.php`
 * ile çizilir. Bu dosya yalnızca hiçbiri uymadığında devreye girer ve aynı
 * ortak ızgarayı kullanır.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

if ( is_search() ) {
	/* translators: %s: arama sorgusu. */
	$dxp_index_title = sprintf( __( '"%s" için arama sonuçları', 'devxpe-theme' ), get_search_query() );
	$dxp_index_eyebrow = __( 'Arama', 'devxpe-theme' );
} else {
	$dxp_index_title   = __( 'Blog', 'devxpe-theme' );
	$dxp_index_eyebrow = __( 'İçerik', 'devxpe-theme' );
}

get_template_part(
	'template-parts/archive-grid',
	null,
	array(
		'eyebrow'     => $dxp_index_eyebrow,
		'title'       => $dxp_index_title,
		'description' => is_archive() ? get_the_archive_description() : '',
	)
);

get_footer();
