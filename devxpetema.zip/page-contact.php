<?php
/**
 * "İletişim" sayfa düzeni.
 *
 * WordPress "Şablon" listesinde görünmez. Sayfa düzenleyicisindeki
 * "Sayfa Şablonu ve İçeriği" kutusundan "İletişim" seçilince yüklenir
 * (bkz. devxpe_page_pick_template()).
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$dxp_title = (string) get_post_meta( get_the_ID(), '_dxp_hero_title', true );
if ( '' === $dxp_title ) {
	$dxp_title = get_the_title();
}

$dxp_phone  = (string) devxpe_theme_get( 'phone' );
$dxp_wa     = (string) devxpe_theme_get( 'whatsapp' );
$dxp_email  = (string) devxpe_theme_get( 'email' );
$dxp_addr   = (string) devxpe_theme_get( 'address' );
$dxp_hours  = (string) devxpe_theme_get( 'working_hours' );
$dxp_tel    = $dxp_phone ? preg_replace( '/\s+/', '', $dxp_phone ) : '';

$dxp_wa_num = $dxp_wa ? preg_replace( '/[^0-9]/', '', $dxp_wa ) : '';
$dxp_wa_url = $dxp_wa_num ? 'https://wa.me/' . $dxp_wa_num . '?text=' . rawurlencode( __( 'Merhaba, ücretsiz bir teklif almak istiyorum.', 'devxpe-theme' ) ) : '';

$dxp_form_args = devxpe_quote_form_args();

/* İletişim kartları sütunu (metabox). 0 = tema varsayılanı (tek sütun). */
$dxp_cols = (int) get_post_meta( get_the_ID(), '_dxp_contact_cols', true );

/*
 * Sayfa widget'larla mı kurulmuş? (kayıtlı widget listesi doluysa)
 * Doluysa: şablonun yerleşik bloğu ve eski 2 KOLON bölünmesi devre dışı kalır;
 * her şey widget akışından gelir.
 */
$dxp_pw_var = (bool) DEVXPE_Page_Widgets::veri( get_the_ID() );
?>
<section class="dxp-band dxp-band--paper dxp-page-band">
	<div class="dxp-band-inner">
		<?php get_template_part( 'template-parts/breadcrumbs' ); ?>
		<div class="dxp-contact-grid<?php echo $dxp_pw_var ? ' dxp-contact-grid--widgets' : ''; ?>">
		<?php
		while ( have_posts() ) :
			the_post();

			if ( ! $dxp_pw_var ) :
				?>
			<article id="post-<?php the_ID(); ?>" <?php post_class( 'dxp-contact-info' ); ?>>
				<?php if ( ! DEVXPE_Page_Widgets::icerir( get_the_ID(), 'manset' ) ) : ?>
				<div class="dxp-eyebrow"><?php esc_html_e( 'İletişim', 'devxpe-theme' ); ?></div>
				<h1 class="dxp-page-title dxp-page-title--xl"><?php echo esc_html( $dxp_title ); ?></h1>
				<?php endif; ?>

				<?php if ( ! DEVXPE_Page_Widgets::icerir( get_the_ID(), 'icerik' ) && get_the_content() ) : ?>
				<div class="dxp-page-content"><?php the_content(); ?></div>
				<?php endif; ?>

				<?php
				/* İletişim kartları: panelden (İkon + başlık + değer + bağlantı). */
				/* Önce sayfaya özel kartlar (metabox), yoksa panel varsayılanı. */
				$dxp_cards = get_post_meta( get_the_ID(), '_dxp_contact_cards', true );
				if ( ! is_array( $dxp_cards ) || ! $dxp_cards ) {
					$dxp_cards = devxpe_theme_get( 'contact_cards' );
				}
				$dxp_cards = is_array( $dxp_cards ) ? array_values(
					array_filter(
						$dxp_cards,
						function ( $r ) {
							return is_array( $r ) && ( ! empty( $r['title'] ) || ! empty( $r['text'] ) );
						}
					)
				) : array();

				if ( ! $dxp_cards ) {
					if ( $dxp_phone ) {
						$dxp_cards[] = array( 'icon' => 'phone', 'title' => __( 'Ara', 'devxpe-theme' ), 'text' => $dxp_phone, 'url' => 'tel:' . $dxp_tel );
					}
					if ( $dxp_wa_url ) {
						$dxp_cards[] = array( 'icon' => 'message-circle', 'title' => 'WhatsApp', 'text' => $dxp_wa, 'url' => $dxp_wa_url );
					}
					if ( $dxp_email ) {
						$dxp_cards[] = array( 'icon' => 'mail', 'title' => __( 'E-posta', 'devxpe-theme' ), 'text' => $dxp_email, 'url' => 'mailto:' . $dxp_email );
					}
					if ( $dxp_addr ) {
						$dxp_cards[] = array( 'icon' => 'map-pin', 'title' => __( 'Hizmet bölgesi', 'devxpe-theme' ), 'text' => $dxp_addr, 'url' => '' );
					}
				}
				?>
				<?php if ( $dxp_cards && ! DEVXPE_Page_Widgets::icerir( get_the_ID(), 'iletisim_kart' ) ) : ?>
				<ul class="dxp-contact-list"<?php echo $dxp_cols ? ' style="display:grid;grid-template-columns:repeat(' . absint( $dxp_cols ) . ',minmax(0,1fr))"' : ''; ?>>
					<?php foreach ( $dxp_cards as $dxp_card ) : ?>
					<li>
						<?php if ( ! empty( $dxp_card['url'] ) ) : ?>
						<a href="<?php echo esc_url( $dxp_card['url'] ); ?>">
						<?php else : ?>
						<span>
						<?php endif; ?>
							<span class="dxp-contact-card">
								<span class="dxp-contact-ic"><?php echo devxpe_lucide( isset( $dxp_card['icon'] ) ? $dxp_card['icon'] : '' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
								<span class="dxp-contact-body">
									<?php if ( ! empty( $dxp_card['title'] ) ) : ?>
									<span class="dxp-contact-label"><?php echo esc_html( $dxp_card['title'] ); ?></span>
									<?php endif; ?>
									<?php if ( ! empty( $dxp_card['text'] ) ) : ?>
									<span class="dxp-contact-value"><?php echo esc_html( $dxp_card['text'] ); ?></span>
									<?php endif; ?>
								</span>
							</span>
						<?php if ( ! empty( $dxp_card['url'] ) ) : ?>
						</a>
						<?php else : ?>
						</span>
						<?php endif; ?>
					</li>
					<?php endforeach; ?>
				</ul>
				<?php endif; ?>

				<?php /* Widget kullanmayan eski sayfalar: saatler şablondan gelir. */ ?>
				<?php if ( $dxp_hours ) : ?>
				<p class="dxp-contact-hours"><?php echo esc_html( $dxp_hours ); ?></p>
				<?php endif; ?>
			</article>
			<?php endif; /* ! $dxp_pw_var */ ?>

			<?php if ( $dxp_pw_var ) : ?>
			<?php echo DEVXPE_Page_Widgets::cikti( get_the_ID() ); // phpcs:ignore WordPress.Security.EscapeOutput -- ciz() kendi kaçışını yapar ?>

			<?php endif; ?>
			<?php
		endwhile;
		?>

		<?php /* Widget listesinde form varsa şablonun kendi formu tekrar çizilmez (çift form olmasın). */ ?>
		<?php if ( ! DEVXPE_Page_Widgets::icerir( get_the_ID(), 'form' ) ) : ?>
		<div class="dxp-contact-form">
			<?php devxpe_render_form_choice( devxpe_theme_get( 'contact_form_choice', 'quote' ), true ); ?>
		</div>
		<?php endif; ?>
		</div><!-- /.dxp-contact-grid -->
	</div>
</section>
<?php
get_footer();
