<?php
/**
 * "İletişim" sayfa düzeni.
 *
 * WordPress "Şablon" listesinde görünmez. Sayfa düzenleyicisindeki
 * "Sayfa Şablonu ve İçeriği" kutusundan "İletişim" seçilince yüklenir.
 *
 * Tüm sayfalarla aynı yerleşim: breadcrumb → başlık → içerik → widget'lar.
 * Widget listesi boşsa iletişim kartları, saatler ve form varsayılan olarak
 * çizilir (cikti() içindeki 'contact' varsayılan dizilimi).
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
get_template_part( 'template-parts/page-layout', null, array( 'context' => 'contact' ) );
get_footer();
