<?php
/**
 * Blog sayfası (yazıların listelendiği sayfa) şablonu.
 *
 * WordPress "Ayarlar → Okuma" ile blog sayfası olarak seçilen sayfa bu
 * şablonla açılır ve yalnızca normal yazıları listeler (içerik tipleri
 * karışmaz). Görünüm arşivlerle ortaktır.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$dxp_blog_id    = (int) get_option( 'page_for_posts' );
$dxp_blog_title = $dxp_blog_id ? get_the_title( $dxp_blog_id ) : __( 'Blog', 'devxpe-theme' );

get_template_part(
	'template-parts/archive-grid',
	null,
	array(
		'eyebrow'     => __( 'Blog', 'devxpe-theme' ),
		'title'       => $dxp_blog_title,
		'description' => get_the_archive_description(),
		'filters'     => true,
	)
);

get_footer();
