<?php
/**
 * Arşiv şablonu — kategori/etiket/blog dışındaki arşivler.
 *
 * Burada içerik tipi (CPT) arşivleri, tarih ve yazar arşivleri çizilir.
 * Blog tarafı kendi şablonlarını kullanır: `home.php` (blog sayfası),
 * `category.php` ve `tag.php`. Görünüm ortaktır
 * (`template-parts/archive-grid.php`); sorgular WordPress'in kendi ana
 * sorgusudur, içerik tipleri birbirine karışmaz.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

/*
 * Eyebrow: arşivin türünü tek kelimeyle özetler (içerik tipi adı, Yazar,
 * Tarih…). get_queried_object() türe göre WP_Post_Type/WP_Term/WP_User döner.
 */
$dxp_archive_obj = get_queried_object();
$dxp_eyebrow     = __( 'Arşiv', 'devxpe-theme' );

if ( is_post_type_archive() && $dxp_archive_obj instanceof WP_Post_Type ) {
	$dxp_eyebrow = $dxp_archive_obj->labels->singular_name;
} elseif ( is_author() ) {
	$dxp_eyebrow = __( 'Yazar', 'devxpe-theme' );
} elseif ( is_date() ) {
	$dxp_eyebrow = __( 'Tarih', 'devxpe-theme' );
} elseif ( is_tax() && $dxp_archive_obj instanceof WP_Term ) {
	$dxp_tax     = get_taxonomy( $dxp_archive_obj->taxonomy );
	$dxp_eyebrow = $dxp_tax ? $dxp_tax->labels->singular_name : __( 'Arşiv', 'devxpe-theme' );
}

get_template_part(
	'template-parts/archive-grid',
	null,
	array(
		'eyebrow'     => $dxp_eyebrow,
		'title'       => get_the_archive_title(),
		'description' => get_the_archive_description(),
	)
);

get_footer();
