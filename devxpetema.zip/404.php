<?php
/**
 * 404 şablonu — tema düzeni.
 *
 * Ortalanmış "404 / Sayfa bulunamadı" bloğu ve anasayfa butonu.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>
<section class="dxp-404">
	<div class="dxp-404-box">
		<div class="dxp-404-code">404</div>
		<h1 class="dxp-404-title"><?php esc_html_e( 'Sayfa bulunamadı', 'devxpe-theme' ); ?></h1>
		<p class="dxp-404-text"><?php esc_html_e( 'Aradığınız sayfa mevcut değil ya da taşınmış olabilir. Aşağıdan anasayfaya dönebilirsiniz.', 'devxpe-theme' ); ?></p>
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="dxp-btn dxp-btn--primary">
			<?php esc_html_e( 'Anasayfaya dön', 'devxpe-theme' ); ?>
		</a>
	</div>
</section>
<?php
get_footer();
