<?php
/**
 * Yorumlar şablonu.
 *
 * Blog yazısı (single-post.php) tasarımına uyar: kart yüzeyi, yuvarlatılmış
 * köşeler, marka yeşili vurgular ve panel/ön yüz form dili (44px girişler,
 * 12px köşe, odak halkası).
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * Yorum kapatılmış ve hiç yorum yoksa hiçbir şey çizme.
 */
if ( ! comments_open() && 0 === (int) get_comments_number() ) {
	return;
}
?>
<section id="comments" class="dxp-comments comments-area">

	<?php if ( have_comments() ) : ?>
		<h2 class="dxp-comments-title">
			<?php
			$dxp_sayi = (int) get_comments_number();
			printf(
				/* translators: %s: yorum sayısı. */
				esc_html( _n( '%s yorum', '%s yorum', $dxp_sayi, 'devxpe-theme' ) ),
				esc_html( number_format_i18n( $dxp_sayi ) )
			);
			?>
		</h2>

		<?php
		the_comments_navigation(
			array(
				'prev_text' => esc_html__( 'Önceki yorumlar', 'devxpe-theme' ),
				'next_text' => esc_html__( 'Sonraki yorumlar', 'devxpe-theme' ),
			)
		);
		?>

		<ol class="dxp-comment-list">
			<?php
			wp_list_comments(
				array(
					'style'      => 'ol',
					'avatar_size' => 48,
					'short_ping' => true,
					'callback'   => 'devxpe_comment_item',
				)
			);
			?>
		</ol>

		<?php
		the_comments_navigation(
			array(
				'prev_text' => esc_html__( 'Önceki yorumlar', 'devxpe-theme' ),
				'next_text' => esc_html__( 'Sonraki yorumlar', 'devxpe-theme' ),
			)
		);

		if ( ! comments_open() ) :
			?>
			<p class="dxp-comments-closed"><?php esc_html_e( 'Yorumlar kapalı.', 'devxpe-theme' ); ?></p>
			<?php
		endif;
	endif;

	/*
	 * Yorum formu — tema form diliyle (giriş 44px, 12px köşe, marka buton).
	 */
	comment_form(
		array(
			'class_form'           => 'dxp-comment-form',
			'title_reply'          => esc_html__( 'Yorum yap', 'devxpe-theme' ),
			'title_reply_to'       => esc_html__( '%s kullanıcısına yanıt ver', 'devxpe-theme' ),
			'cancel_reply_link'    => esc_html__( 'Yanıtı iptal et', 'devxpe-theme' ),
			'label_submit'         => esc_html__( 'Yorumu Gönder', 'devxpe-theme' ),
			'comment_notes_before' => '<p class="dxp-comment-notes">' . esc_html__( 'E-posta adresiniz yayımlanmaz. Zorunlu alanlar * ile işaretlidir.', 'devxpe-theme' ) . '</p>',
			'comment_notes_after'  => '',
			'comment_field'        => sprintf(
				'<p class="comment-form-comment dxp-field"><label for="comment">%s</label><textarea id="comment" name="comment" rows="5" required="required" aria-required="true" placeholder="%s"></textarea></p>',
				esc_html__( 'Yorumunuz', 'devxpe-theme' ),
				esc_attr__( 'Düşüncelerinizi yazın…', 'devxpe-theme' )
			),
			'fields'               => array(
				'author' => sprintf(
					'<p class="comment-form-author dxp-field"><label for="author">%s</label><input id="author" name="author" type="text" required="required" aria-required="true" autocomplete="name" placeholder="%s" /></p>',
					esc_html__( 'Ad', 'devxpe-theme' ),
					esc_attr__( 'Adınız', 'devxpe-theme' )
				),
				'email'  => sprintf(
					'<p class="comment-form-email dxp-field"><label for="email">%s</label><input id="email" name="email" type="email" required="required" aria-required="true" autocomplete="email" placeholder="%s" /></p>',
					esc_html__( 'E-posta', 'devxpe-theme' ),
					esc_attr__( 'ornek@site.com', 'devxpe-theme' )
				),
				'url'    => sprintf(
					'<p class="comment-form-url dxp-field"><label for="url">%s</label><input id="url" name="url" type="url" autocomplete="url" placeholder="%s" /></p>',
					esc_html__( 'Web sitesi', 'devxpe-theme' ),
					esc_attr__( 'https://', 'devxpe-theme' )
				),
			),
			'class_submit'         => 'dxp-comment-submit',
		)
	);
	?>
</section>
