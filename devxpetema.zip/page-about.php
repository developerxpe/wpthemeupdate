<?php
/**
 * "Hakkımızda" sayfa düzeni.
 *
 * WordPress "Şablon" listesinde görünmez. Sayfa düzenleyicisindeki
 * "Sayfa Şablonu ve İçeriği" kutusundan "Hakkımızda" seçilince yüklenir.
 *
 * Tüm sayfalarla aynı yerleşim: başlık + içerik + widget'lar.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
get_template_part( 'template-parts/page-layout' );
get_footer();
