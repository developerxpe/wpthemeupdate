<?php
/**
 * "Hakkımızda" sayfa düzeni.
 *
 * WordPress "Şablon" listesinde görünmez. Sayfa düzenleyicisindeki
 * "Sayfa Şablonu ve İçeriği" kutusundan "Hakkımızda" seçilince yüklenir
 * (bkz. devxpe_page_pick_template()).
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$dxp_title = (string) get_post_meta( get_the_ID(), '_dxp_hero_title', true );
if ( '' === $dxp_title ) {
	$dxp_title = get_the_title();
}

$dxp_intro = (string) get_post_meta( get_the_ID(), '_dxp_hero_subtitle', true );

/* Manşet altındaki istatistik sütunu (metabox). 0 = tema varsayılanı. */
$dxp_cols = (int) get_post_meta( get_the_ID(), '_dxp_about_cols', true );

$dxp_stats = array();
/* Önce sayfaya özel istatistikler (metabox), yoksa panel varsayılanı. */
$dxp_rows  = get_post_meta( get_the_ID(), '_dxp_about_stats', true );
if ( ! is_array( $dxp_rows ) || ! $dxp_rows ) {
	$dxp_rows = devxpe_theme_get( 'about_stats' );
}

if ( is_array( $dxp_rows ) ) {
	foreach ( $dxp_rows as $dxp_row ) {
		if ( ! is_array( $dxp_row ) || ( empty( $dxp_row['title'] ) && empty( $dxp_row['text'] ) ) ) {
			continue;
		}
		$dxp_stats[] = array(
			'icon'  => isset( $dxp_row['icon'] ) ? $dxp_row['icon'] : '',
			'value' => isset( $dxp_row['title'] ) ? $dxp_row['title'] : '',
			'label' => isset( $dxp_row['text'] ) ? $dxp_row['text'] : '',
		);
	}
}

/* Boşsa paneldeki manşet rozetlerinden (hero_stat_*) doldur. */
if ( ! $dxp_stats ) {
	for ( $dxp_i = 1; $dxp_i <= 4; $dxp_i++ ) {
		$dxp_val = devxpe_theme_get( 'hero_stat_' . $dxp_i . '_value' );
		if ( '' === $dxp_val ) {
			continue;
		}
		$dxp_stats[] = array(
			'icon'  => devxpe_theme_get( 'hero_stat_' . $dxp_i . '_icon', 'hammer' ),
			'value' => $dxp_val,
			'label' => devxpe_theme_get( 'hero_stat_' . $dxp_i . '_label' ),
		);
	}
}

$dxp_sections = devxpe_about_sections();

/*
 * Kayıtlı widget listesi varsa yerleşik bloklar zaten atlanır ve yalnızca
 * widget'lar gösterilir; liste boşsa şablonun kendi yerleşimi geçerlidir.
 * (Boş liste, cikti() içindeki yedek dizilimi tetiklemez.)
 */
$dxp_pw_var = (bool) DEVXPE_Page_Widgets::veri( get_the_ID() );
?>
<section class="dxp-band dxp-band--paper dxp-page-band">
	<div class="dxp-band-inner dxp-page-inner">
		<?php get_template_part( 'template-parts/breadcrumbs' ); ?>
		<?php
		while ( have_posts() ) :
			the_post();
			?>
			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
				<?php
				foreach ( $dxp_sections['order'] as $dxp_section ) :

					if ( ! devxpe_about_section_visible( $dxp_section ) ) {
						continue;
					}

					/*
					 * Aynı içerik widget olarak da eklenmişse yerleşik blok çizilmez
					 * (çift manşet / çift istatistik / çift içerik olmasın).
					 */
					$dxp_w_karsilik = array( 'hero' => 'manset', 'content' => 'icerik', 'stats' => 'stats' );

					if ( isset( $dxp_w_karsilik[ $dxp_section ] )
						&& DEVXPE_Page_Widgets::icerir( get_the_ID(), $dxp_w_karsilik[ $dxp_section ] ) ) {
						continue;
					}

					if ( 'stats' === $dxp_section && DEVXPE_Page_Widgets::icerir( get_the_ID(), 'ikon_kutulari' ) ) {
						continue;
					}

					if ( 'hero' === $dxp_section ) :
						?>
						<div class="dxp-eyebrow"><?php esc_html_e( 'Hakkımızda', 'devxpe-theme' ); ?></div>
						<h1 class="dxp-page-title dxp-page-title--xl"><?php echo esc_html( $dxp_title ); ?></h1>
						<?php if ( $dxp_intro ) : ?>
						<p class="dxp-page-lead"><?php echo esc_html( $dxp_intro ); ?></p>
						<?php endif; ?>

					<?php elseif ( 'content' === $dxp_section ) : ?>
						<?php if ( get_the_content() ) : ?>
						<div class="dxp-page-content"><?php the_content(); ?></div>
						<?php endif; ?>

					<?php elseif ( 'stats' === $dxp_section ) : ?>
						<?php if ( $dxp_stats ) : ?>
						<div class="dxp-stat-grid"<?php echo $dxp_cols ? ' style="grid-template-columns:repeat(' . absint( $dxp_cols ) . ',minmax(0,1fr))"' : ''; ?>>
							<?php foreach ( $dxp_stats as $dxp_stat ) : ?>
							<div class="dxp-stat-card">
								<?php echo devxpe_lucide( $dxp_stat['icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
								<div class="dxp-stat-value"><?php echo esc_html( $dxp_stat['value'] ); ?></div>
								<?php if ( $dxp_stat['label'] ) : ?>
								<div class="dxp-stat-label"><?php echo esc_html( $dxp_stat['label'] ); ?></div>
								<?php endif; ?>
							</div>
							<?php endforeach; ?>
						</div>
						<?php endif; ?>

					<?php endif; ?>

				<?php endforeach; ?>
			</article>
			<?php if ( $dxp_pw_var ) : ?>
			<?php echo DEVXPE_Page_Widgets::cikti( get_the_ID() ); // phpcs:ignore WordPress.Security.EscapeOutput -- ciz() kendi kaçışını yapar ?>
			<?php endif; ?>
			<?php
		endwhile;
		?>
	</div>
</section>
<?php
get_footer();
