<?php
/**
 * DEVXPE teması ana dosyası.
 *
 * Front-end boot'u + yönetim panelinin başlatılması burada yapılır.
 * Panel (DEVXPE_Theme_Panel) tamamen temanın içindedir ve DEVXPE Toolkit
 * eklentisinden bağımsızdır; eklenti kapalı olsa da çalışır.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * Tema yolu/URL'si.
 *
 * `get_template_*()` kullanılır: bir CHILD tema etkinse bile bu sabitler ÜST
 * temayı (devxpe) gösterir; tema dosyaları (includes/, assets/) her zaman
 * burada bulunur. `get_stylesheet_*()` kullanılsaydı child etkinken üst tema
 * dosyaları bulunamazdı.
 *
 * Çocuk temaya özel dosyalar gerekiyorsa `get_stylesheet_directory()` kullanın.
 */
define( 'DEVXPE_THEME_VERSION', '0.3.48' );
define( 'DEVXPE_THEME_PATH', get_template_directory() . '/' );
define( 'DEVXPE_THEME_URL', get_template_directory_uri() . '/' );

/*
 * Yapım aşamasındaki (dev) öğelerin gösterimi.
 *
 * `devxpe_show_dev_designs` filtresi varsayılan KAPALI'dır; müşteride dev-only
 * hiçbir şey görünmez. Aşağıdaki DEV bloğu yalnızca geliştirme kopyasında
 * bulunur — paketleyici (`prod/lib/yayin.php`) bu bloğu zip'e koymadan
 * ÇIKARIR, yani müşteri paketinde bu satırlar fiziksel olarak yoktur.
 */

/*
 * Demo/katalog varlıklarının taban adresi (AYRI AYAR).
 *
 * Varsayılan: update deposunun `assets` dalı (yayın paketi `main`'de, varlıklar
 * `assets`'te ayrı durur). Değiştirmek istersen wp-config.php'de tanımla:
 *
 *     define( 'DEVXPE_ASSETS_BASE', 'https://raw.githubusercontent.com/KULLANICI/REPO/assets/' );
 */


require_once DEVXPE_THEME_PATH . 'includes/class-devxpe-theme-fields.php';
require_once DEVXPE_THEME_PATH . 'includes/class-devxpe-theme-language.php';
require_once DEVXPE_THEME_PATH . 'includes/class-devxpe-seo.php';
require_once DEVXPE_THEME_PATH . 'includes/class-devxpe-theme-setup.php';
require_once DEVXPE_THEME_PATH . 'includes/class-devxpe-theme-update.php';
require_once DEVXPE_THEME_PATH . 'includes/class-devxpe-demos.php';
require_once DEVXPE_THEME_PATH . 'includes/class-devxpe-theme-demo.php';
require_once DEVXPE_THEME_PATH . 'includes/class-devxpe-theme-library.php';
require_once DEVXPE_THEME_PATH . 'includes/class-devxpe-theme-report.php';
require_once DEVXPE_THEME_PATH . 'includes/admin/class-devxpe-theme-panel.php';
require_once DEVXPE_THEME_PATH . 'includes/elementor/class-devxpe-dynamic-tag.php';
require_once DEVXPE_THEME_PATH . 'includes/class-devxpe-page-widgets.php';
require_once DEVXPE_THEME_PATH . 'includes/functions-icons.php';
require_once DEVXPE_THEME_PATH . 'includes/functions-cpt.php';
require_once DEVXPE_THEME_PATH . 'includes/functions-forms-validation.php';
require_once DEVXPE_THEME_PATH . 'includes/class-devxpe-form-handler.php';
require_once DEVXPE_THEME_PATH . 'includes/admin/functions-metaboxes.php';

/* Tema yardımcı modülleri (konuya göre ayrıldı) */
require_once DEVXPE_THEME_PATH . 'includes/theme-assets.php';
require_once DEVXPE_THEME_PATH . 'includes/theme-boot.php';
require_once DEVXPE_THEME_PATH . 'includes/theme-sections.php';
require_once DEVXPE_THEME_PATH . 'includes/theme-forms.php';
require_once DEVXPE_THEME_PATH . 'includes/theme-misc.php';
require_once DEVXPE_THEME_PATH . 'includes/theme-webp.php';

DEVXPE_Theme_Language::init();
DEVXPE_Theme_Setup::init();
DEVXPE_Theme_SEO::init();
DEVXPE_Theme_Demo::init();
DEVXPE_Theme_Report::init();
