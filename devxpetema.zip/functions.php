<?php
/**
 * DEVXPE teması ana dosyası.
 *
 * Front-end boot'u + yönetim panelinin başlatılması burada yapılır.
 * Panel (DEVXPE_Theme_Panel) tamamen temanın içindedir ve DEVXPE Toolkit
 * eklentisinden bağımsızdır; eklenti kapalı olsa da çalışır.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * Tema yolu/URL'si.
 *
 * `get_template_*()` kullanılır: bir CHILD tema etkinse bile bu sabitler ÜST
 * temayı (devxpe) gösterir; tema dosyaları (includes/, assets/) her zaman
 * burada bulunur. `get_stylesheet_*()` kullanılsaydı child etkinken üst tema
 * dosyaları bulunamazdı.
 *
 * Çocuk temaya özel dosyalar gerekiyorsa `get_stylesheet_directory()` kullanın.
 */
define( 'DEVXPE_THEME_VERSION', '0.3.42' );
define( 'DEVXPE_THEME_PATH', get_template_directory() . '/' );
define( 'DEVXPE_THEME_URL', get_template_directory_uri() . '/' );

require_once DEVXPE_THEME_PATH . 'includes/class-devxpe-theme-fields.php';
require_once DEVXPE_THEME_PATH . 'includes/class-devxpe-theme-language.php';
require_once DEVXPE_THEME_PATH . 'includes/class-devxpe-seo.php';
require_once DEVXPE_THEME_PATH . 'includes/class-devxpe-theme-setup.php';
require_once DEVXPE_THEME_PATH . 'includes/class-devxpe-theme-update.php';
require_once DEVXPE_THEME_PATH . 'includes/class-devxpe-theme-demo.php';
require_once DEVXPE_THEME_PATH . 'includes/admin/class-devxpe-theme-panel.php';
require_once DEVXPE_THEME_PATH . 'includes/elementor/class-devxpe-dynamic-tag.php';
require_once DEVXPE_THEME_PATH . 'includes/class-devxpe-page-widgets.php';
require_once DEVXPE_THEME_PATH . 'includes/functions-icons.php';
require_once DEVXPE_THEME_PATH . 'includes/functions-cpt.php';
require_once DEVXPE_THEME_PATH . 'includes/functions-forms-validation.php';
require_once DEVXPE_THEME_PATH . 'includes/class-devxpe-form-handler.php';
require_once DEVXPE_THEME_PATH . 'includes/admin/functions-metaboxes.php';

DEVXPE_Theme_Language::init();
DEVXPE_Theme_Setup::init();
DEVXPE_Theme_SEO::init();
DEVXPE_Theme_Demo::init();

/**
 * Çok satırlı / virgüllü metni temiz parçalara ayırır.
 *
 * Her parça trim edilir, boş parçalar atılır ve dizi yeniden indekslenir:
 * `array_filter( array_map( 'trim', explode( ... ) ) )` deseninin
 * yeniden indekslenmiş hâli.
 *
 * @param mixed  $text Ham metin (dizi de olabilir, string'e çevrilir).
 * @param string $sep  Ayırıcı (varsayılan: yeni satır).
 * @return array
 */
function devxpe_lines( $text, $sep = "\n" ) {
	return array_values( array_filter( array_map( 'trim', explode( $sep, (string) $text ) ) ) );
}

/**
 * Bölüm sırası/kapalılar satırını ortak biçimde ayrıştırır.
 *
 * `order` kayıtlı sıraya göre dizilir, eksik id'ler sona eklenir; `off` yalnızca
 * geçerli id'lerle sınırlanır. Çıktı: array( 'order' => array, 'off' => array ).
 *
 * @param mixed $row Bölüm iskeleti satırı (order/off alanları).
 * @param array $ids Geçerli bölüm id'leri.
 * @return array
 */
function devxpe_parse_order_off( $row, $ids ) {
	$row = is_array( $row ) ? $row : array();

	$order = isset( $row['order'] ) ? devxpe_lines( $row['order'], ',' ) : array();
	$order = array_values( array_intersect( $order, $ids ) );
	$order = array_merge( $order, array_values( array_diff( $ids, $order ) ) );

	$off = isset( $row['off'] ) ? devxpe_lines( $row['off'], ',' ) : array();
	$off = array_values( array_intersect( $off, $ids ) );

	return array( 'order' => $order, 'off' => $off );
}

/**
 * Tema kurulumu: çeviri, destekler, menüler.
 *
 * @return void
 */
function devxpe_theme_setup() {
	load_theme_textdomain( 'devxpe-theme', DEVXPE_THEME_PATH . 'languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'custom-logo' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );

	register_nav_menus(
		array(
			'primary' => __( 'Primary Menu', 'devxpe-theme' ),
			'footer'  => __( 'Footer Menu', 'devxpe-theme' ),
		)
	);
}
add_action( 'after_setup_theme', 'devxpe_theme_setup' );

/**
 * Görüntülenen sayfada "Sayfa İçeriği" widget'ı çiziliyor mu?
 *
 * Widget çıktısı üreten yerler:
 *  - Hakkımızda / İletişim tipi sayfalar (`_dxp_page_type` → about/contact),
 *  - panelde tanımlı içerik tiplerinin tekil sayfaları (single.php),
 *  - kayıtlı widget listesi olan sayfalar (gelecekte şablon çizerse).
 *
 * @return bool
 */
function devxpe_front_uses_widgets() {
	if ( ! is_singular() || ! class_exists( 'DEVXPE_Page_Widgets' ) ) {
		return false;
	}

	$post_id = (int) get_queried_object_id();
	if ( ! $post_id ) {
		return false;
	}

	/* about/contact sayfa tipi veya panelde tanımlı CPT bağlamı. */
	if ( '' !== DEVXPE_Page_Widgets::baglam_bul( $post_id ) ) {
		return true;
	}

	/* Normal sayfada kayıtlı widget listesi varsa stiller gerekebilir. */
	return (bool) DEVXPE_Page_Widgets::veri( $post_id );
}

/**
 * Görüntülenen sayfada herhangi bir form / teklif formu var mı?
 *
 * Form çizilen yerler:
 *  - anasayfa "Teklif Formu" bölümü (açıksa),
 *  - İletişim tipi sayfa (şablon her zaman bir form çizer),
 *  - widget listesinde `form` veya `cpt_quote` bulunan sayfa/CPT,
 *  - kayıtlı listesi olmayan CPT tekil (varsayılan ARC dizilimi `cpt_quote`).
 *
 * @return bool
 */
function devxpe_front_uses_forms() {
	/* Anasayfa: form bölümü açık mı? (Diğer sayfalarda false döner.) */
	if ( is_front_page() ) {
		return devxpe_section_visible( 'form' );
	}

	if ( ! is_singular() || ! class_exists( 'DEVXPE_Page_Widgets' ) ) {
		return false;
	}

	$post_id = (int) get_queried_object_id();
	if ( ! $post_id ) {
		return false;
	}

	$baglam = DEVXPE_Page_Widgets::baglam_bul( $post_id );

	/* İletişim sayfası: kayıtlı widget formu olsa da olmasa da form çizilir. */
	if ( 'contact' === $baglam ) {
		return true;
	}

	/* Widget listesinde iletişim formu (sayfa/CPT). */
	if ( DEVXPE_Page_Widgets::icerir( $post_id, 'form' ) ) {
		return true;
	}

	/* CPT tekil: teklif formu bölümü açık ve listede/varsayılanda var mı? */
	if ( '' !== $baglam && ! in_array( $baglam, array( 'about', 'contact' ), true ) ) {
		$type = get_post_type( $post_id );
		if ( $type && devxpe_cpt_section_visible( $type, 'quote' )
			&& ( DEVXPE_Page_Widgets::icerir( $post_id, 'cpt_quote' ) || ! DEVXPE_Page_Widgets::veri( $post_id ) ) ) {
			return true;
		}
	}

	return false;
}

/**
 * Tema CSS'ini ve panelden gelen renk değişkenlerini yükler.
 *
 * @return void
 */
function devxpe_theme_assets() {
	wp_enqueue_style( 'devxpe-fonts', 'https://fonts.googleapis.com/css2?family=Public+Sans:wght@400;500;600;700&display=swap', array(), null );
	$style_ver = filemtime( DEVXPE_THEME_PATH . 'style.css' ) . '-' . substr( md5( serialize( get_option( DEVXPE_Theme_Fields::OPTION_KEY, array() ) ) ), 0, 8 );
	wp_enqueue_style( 'devxpe-theme-style', DEVXPE_THEME_URL . 'style.css', array(), $style_ver );
	wp_enqueue_style( 'dashicons' );

	/*
	 * Widget/form düzeni yalnızca ilgili sayfalarda yüklenir. Dosyalar yoksa
	 * (henüz üretilmemiş sürüm) atlanır; kullanılan yerlerde gerekli stiller
	 * style.css'ten gelir.
	 */
	if ( devxpe_front_uses_widgets() && file_exists( DEVXPE_THEME_PATH . 'assets/css/widgets.css' ) ) {
		wp_enqueue_style( 'devxpe-widgets', DEVXPE_THEME_URL . 'assets/css/widgets.css', array( 'devxpe-theme-style' ), filemtime( DEVXPE_THEME_PATH . 'assets/css/widgets.css' ) );
	}
	if ( devxpe_front_uses_forms() && file_exists( DEVXPE_THEME_PATH . 'assets/css/forms.css' ) ) {
		wp_enqueue_style( 'devxpe-forms', DEVXPE_THEME_URL . 'assets/css/forms.css', array( 'devxpe-theme-style' ), filemtime( DEVXPE_THEME_PATH . 'assets/css/forms.css' ) );
	}

	/* Arşiv ve tekil içerik düzeni (şablonlara özel). */
	if ( is_archive() || is_home() || is_search() ) {
		wp_enqueue_style( 'devxpe-archive', DEVXPE_THEME_URL . 'assets/css/archive.css', array( 'devxpe-theme-style' ), filemtime( DEVXPE_THEME_PATH . 'assets/css/archive.css' ) );
	}
	if ( is_singular() && ! is_page() ) {
		wp_enqueue_style( 'devxpe-single', DEVXPE_THEME_URL . 'assets/css/single.css', array( 'devxpe-theme-style' ), filemtime( DEVXPE_THEME_PATH . 'assets/css/single.css' ) );
	}

	$primary   = devxpe_theme_get( 'primary_color', '#006731' );
	$secondary = devxpe_theme_get( 'secondary_color', '#033216' );
	$harmonize = '1' === devxpe_theme_get( 'harmonize_colors', '1' );

	/*
	 * Link rengi: uyum açıkken ana renge bağlanır (hover = koyu ton).
	 * Kapalıyken elle seçilen link rengi kullanılır.
	 */
	if ( '1' === devxpe_theme_get( 'link_harmonize', '1' ) ) {
		$link       = $primary;
		$link_hover = 'color-mix(in srgb, ' . $primary . ', black 12%)';
	} else {
		$link       = devxpe_theme_get( 'link_color', $primary );
		$link_hover = $link;
	}

	/*
	 * Header yazı rengi: uyum açıkken ana rengin açık tonuna bağlanır.
	 * Kapalıyken elle seçilen header yazı rengi kullanılır.
	 */
	if ( '1' === devxpe_theme_get( 'header_text_harmonize', '0' ) ) {
		$header_text       = 'color-mix(in srgb, ' . $primary . ', white 25%)';
		$header_text_hover = 'color-mix(in srgb, ' . $primary . ', white 45%)';
	} else {
		$header_text       = devxpe_theme_get( 'header_text', '#033216' );
		$header_text_hover = $header_text;
	}

	/*
	 * Uyum açıkken: hover = ana rengin beyazla açılmış tonu, focus/aktif =
	 * siyahla koyulaştırılmış tonu. Kapalıyken tüm durumlar ana rengi kullanır.
	 */
	if ( $harmonize ) {
		$primary_hover   = 'color-mix(in srgb, ' . $primary . ', white 18%)';
		$primary_focus   = 'color-mix(in srgb, ' . $primary . ', black 18%)';
		$secondary_hover = 'color-mix(in srgb, ' . $secondary . ', white 18%)';
		$secondary_focus = 'color-mix(in srgb, ' . $secondary . ', black 18%)';
	} else {
		$manual_hover    = devxpe_theme_get( 'primary_hover' );
		$manual_focus    = devxpe_theme_get( 'primary_focus' );
		$primary_hover   = $manual_hover ? $manual_hover : $primary;
		$primary_focus   = $manual_focus ? $manual_focus : $primary;
		$secondary_hover = $secondary;
		$secondary_focus = $secondary;
	}
	
	$service_icon_color = $primary;

	$colors = array(
		/* ARC paleti — referans sitenin birebir renkleri */
		'--brand-green'        => '#006731',
		'--brand-green-dark'   => '#00461b',
		'--brand-charcoal'     => '#033216',
		'--brand-paper'        => '#f6fcf7',
		'--brand-whatsapp'     => '#3fc168',
		'--dxp-accent'         => '#ddf1e1',
		'--dxp-accent-fg'      => '#00461b',
		'--dxp-border'         => '#dae4dc',
		'--dxp-muted'          => '#ebf5ed',
		'--dxp-muted-fg'       => '#57685b',

		'--dxp-primary'          => $primary,
		'--dxp-service-icon'     => $service_icon_color,
		'--dxp-primary-hover'    => $primary_hover,
		'--dxp-primary-focus'    => $primary_focus,
		'--dxp-primary-soft'     => 'color-mix(in srgb, ' . $primary . ', transparent 85%)',
		'--dxp-primary-contrast' => devxpe_theme_contrast_color( $primary ),
		
		'--dxp-secondary'          => $secondary,
		'--dxp-secondary-hover'    => $secondary_hover,
		'--dxp-secondary-focus'    => $secondary_focus,
		'--dxp-secondary-soft'     => 'color-mix(in srgb, ' . $secondary . ', transparent 85%)',
		'--dxp-secondary-contrast' => devxpe_theme_contrast_color( $secondary ),
		
		'--dxp-link'        => $link,
		'--dxp-link-hover'  => $link_hover,
		
		'--dxp-text'      => devxpe_theme_get( 'text_color', '#033216' ),
		'--dxp-header-bg' => devxpe_theme_get( 'header_bg', '#f6fcf7' ),
		'--dxp-header-text' => $header_text,
		'--dxp-header-text-hover' => $header_text_hover,
		/*
		 * Footer zemini + yazı rengi panelden gelir.
		 * Yazı rengi boşsa zemine göre kontrast otomatik seçilir.
		 */
		'--dxp-footer-bg' => devxpe_theme_get( 'footer_bg', '#09090b' ),
		'--dxp-footer-text' => ( '' !== (string) devxpe_theme_get( 'footer_text', '' ) )
			? devxpe_theme_get( 'footer_text', '' )
			: devxpe_theme_contrast_color( devxpe_theme_get( 'footer_bg', '#09090b' ) ),

		/*
		 * Sayfa düzeni: içerik sarmalayıcılarının azami genişliği ve yan boşluğu.
		 * Tam genişlik → kenarlara yakın; dar düzen → yanlarda daha çok boşluk.
		 */
		'--dxp-wrap-max' => ( 'full' === devxpe_theme_get( 'layout', 'boxed' ) ) ? 'none' : '1280px',
		'--dxp-wrap-pad' => ( 'full' === devxpe_theme_get( 'layout', 'boxed' ) ) ? '20px' : '32px',
	);

	$css = ':root{' . implode( ';', array_map( 'devxpe_theme_build_var', array_keys( $colors ), $colors ) ) . '}';

	/* Tipografi ve Google Fonts */
	$google_fonts = array();
	$typo_fields = array(
		'body' => 'typo_body',
		'h1'   => 'typo_h1',
		'h2'   => 'typo_h2',
		'h3'   => 'typo_h3',
		'h4'   => 'typo_h4',
		'h5'   => 'typo_h5',
		'h6'   => 'typo_h6',
	);

	foreach ( $typo_fields as $selector => $field_id ) {
		$val = devxpe_theme_get( $field_id, array() );
		$val = wp_parse_args( (array) $val, array( 'family' => 'system', 'size' => '', 'weight' => '', 'lh' => '', 'ls' => '' ) );
		
		$css_sel = ( 'body' === $selector ) ? 'body, p, div, span, section' : $selector;
		$css .= $css_sel . ' { ';
		
		if ( 'system' !== $val['family'] && '' !== $val['family'] ) {
			if ( strpos( $val['family'], 'var(' ) === 0 ) {
				$css .= 'font-family: ' . esc_attr( $val['family'] ) . '; ';
			} else {
				$css .= 'font-family: "' . esc_attr( $val['family'] ) . '", sans-serif; ';
				$google_fonts[] = $val['family'];
			}
		}
		
		if ( ! empty( $val['size'] ) ) { $css .= 'font-size: ' . esc_attr( $val['size'] ) . '; '; }
		if ( ! empty( $val['weight'] ) ) { $css .= 'font-weight: ' . esc_attr( $val['weight'] ) . '; '; }
		if ( ! empty( $val['lh'] ) ) { $css .= 'line-height: ' . esc_attr( $val['lh'] ) . '; '; }
		if ( ! empty( $val['ls'] ) ) { $css .= 'letter-spacing: ' . esc_attr( $val['ls'] ) . '; '; }
		
		$css .= '} ';
	}

	$google_fonts = array_unique( $google_fonts );
	if ( ! empty( $google_fonts ) ) {
		$font_family_args = array();
		foreach ( $google_fonts as $gf ) {
			$font_family_args[] = 'family=' . urlencode( $gf ) . ':wght@300;400;500;600;700;800;900';
		}
		$font_url = 'https://fonts.googleapis.com/css2?' . implode( '&', $font_family_args ) . '&display=swap';
		wp_enqueue_style( 'devxpe-google-fonts', $font_url, array(), null );
	}

	/*
	 * Mobil kırılma noktası (panelden).
	 *
	 * Menü / hamburger görünürlüğü burada, tek yerde yönetilir.
	 */
	$bp = absint( devxpe_theme_get( 'mobile_breakpoint', '992' ) );
	if ( $bp < 320 ) {
		$bp = 992;
	}

	$css .= '@media (max-width: ' . esc_attr( $bp ) . 'px) {';
	$css .= '.dxp-nav-wrap { display: none !important; }';
	$css .= '.dxp-burger { display: inline-flex !important; }';
	$css .= '}';

	$css .= '@media (min-width: ' . esc_attr( $bp + 1 ) . 'px) {';
	$css .= '.dxp-nav-wrap { display: block !important; }';
	$css .= '.dxp-burger { display: none !important; }';
	$css .= '.dxp-mobile-menu { display: none !important; }';
	$css .= '}';

	/*
	 * "Sabit Mobil Header": yalnızca kırılma noktasının altında yapışkan.
	 * (Masaüstü "Sabit Header" ayarı ayrıdır.)
	 */
	if ( '1' === devxpe_theme_get( 'sticky_mobile' ) ) {
		$css .= '@media (max-width: ' . esc_attr( $bp ) . 'px) {';
		$css .= '.dxp-header--sticky-mobile { position: sticky; top: 0; }';
		$css .= '.admin-bar .dxp-header--sticky-mobile { top: var(--wp-admin--admin-bar--height, 32px); }';
		$css .= '}';
	}

	/*
	 * Şablon 2 (mobil alt bar): yalnızca kırılma noktasının altında görünür;
	 * içeriğin altına bar yüksekliği kadar boşluk bırakılır.
	 */
	if ( '1' === devxpe_theme_get( 'float_enable', '1' ) && 'bar' === devxpe_theme_get( 'float_style', 'classic' ) ) {
		$css .= '@media (max-width: ' . esc_attr( $bp ) . 'px) {';
		$css .= '.dxp-mbar { display: flex; }';
		$css .= 'body { padding-bottom: 74px; }';
		/* Yukarı çık oku barın üstünde dursun (her iki şablonda da var). */
		$css .= '.dxp-mbar ~ .dxp-float--top { bottom: 90px; }';
		$css .= '}';
		/* Masaüstünde WhatsApp yüzen butonu görünür (Şablon 1'deki gibi solda). */
		$css .= '@media (min-width: ' . ( absint( $bp ) + 1 ) . 'px) { .dxp-float--wa.dxp-desktop-only { display: flex; } }';
	}

	/*
	 * Hamburger ikon rengi.
	 *
	 * Hamburger bir SVG'dir (stroke: currentColor), bu yüzden renk doğrudan
	 * butona verilir.
	 */
	$burger_color = devxpe_theme_get( 'burger_color' );
	if ( $burger_color ) {
		$css .= '.dxp-burger { color: ' . esc_attr( $burger_color ) . ' !important; }';
	}

	/* Yuvarlak Görseller: görsel kutusuyla birlikte yuvarlanır ki kart/çerçeve
	   köşeleriyle çakışıp tuhaf görünmesin. */
	if ( '1' === devxpe_theme_get( 'rounded_image' ) ) {
		$css .= '.dxp-main img, .dxp-sidebar img, .card-img-top, .entry-content img, .post-thumbnail img { border-radius: 8px; }';
		$css .= '.dxp-card-media, .dxp-project-media { border-radius: 8px; overflow: hidden; }';
		$css .= '.dxp-card-media img, .dxp-project-media img, .dxp-hero-media-frame img { border-radius: inherit; }';
	}

	wp_add_inline_style( 'devxpe-theme-style', $css );

	/*
	 * Ön yüz küçük efektleri: SSS akordeonu.
	 *
	 * ARC referansındaki Radix akordeon, içeriği ÖNCE ölçüp sonra yüksekliği
	 * 0 → ölçülen px arasında 200ms ease-out ile canlandırır. Aynı yöntem:
	 * açmadan önce details açılır (yoksa kapalıyken scrollHeight 0 döner),
	 * yükseklik ölçülür ve animasyon başlatılır. Kapanış da aynı şekilde
	 * animasyonlu çalışır (önce 0'a iner, sonra details kapanır).
	 */
	/*
	 * Ön yüz betiği: statik davranışlar (akordeon, doğrulama, mobil menü,
	 * yüzen butonlar, popup) assets/js/front.js içindedir → tarayıcıda
	 * önbelleklenir, sayfa geçişleri hızlanır. Panelden üretilen dinamik
	 * ayarlar küçük inline blok olarak KALIR ve dosyadan ÖNCE basılır.
	 */
	wp_enqueue_script(
		'devxpe-front',
		DEVXPE_THEME_URL . 'assets/js/front.js',
		array(),
		filemtime( DEVXPE_THEME_PATH . 'assets/js/front.js' ),
		true
	);

	/* Form ayarları yalnızca form bulunan sayfalarda basılır. */
	if ( devxpe_front_uses_forms() ) {
		wp_add_inline_script( 'devxpe-front', 'window.dxpFormMsgs = ' . wp_json_encode( devxpe_form_messages() ) . ';', 'before' );
		wp_add_inline_script( 'devxpe-front', 'window.dxpFormConfig = ' . wp_json_encode( devxpe_form_config() ) . ';', 'before' );
	}

	/* reCAPTCHA v3: site anahtarı JS'e verilir, betik yalnızca açıkken yüklenir. */
	if ( devxpe_recaptcha_enabled() ) {
		wp_add_inline_script( 'devxpe-front', 'window.dxpRecaptchaKey = ' . wp_json_encode( (string) devxpe_theme_get( 'recaptcha_site_key' ) ) . ';', 'before' );
		wp_enqueue_script(
			'devxpe-recaptcha',
			'https://www.google.com/recaptcha/api.js?render=' . rawurlencode( (string) devxpe_theme_get( 'recaptcha_site_key' ) ),
			array(),
			null,
			true
		);
	}
}
/**
 * Widget alanı (sidebar).
 *
 * @return void
 */
function devxpe_theme_widgets() {
	register_sidebar(
		array(
			'name'          => __( 'Sidebar', 'devxpe-theme' ),
			'id'            => 'sidebar-1',
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		)
	);
}
add_action( 'widgets_init', 'devxpe_theme_widgets' );

/**
 * Panelden gelen head script'ini wp_head sonuna ekler.
 *
 * @return void
 */
function devxpe_theme_head_scripts() {
	$scripts = devxpe_theme_get( 'script_head' );
	if ( $scripts ) {
		echo $scripts;
	}
}
add_action( 'wp_head', 'devxpe_theme_head_scripts', 99 );

/**
 * Bakım modu: etkinse ve giriş yapan yönetici değilse sayfayı durdurur.
 *
 * @return void
 */
function devxpe_theme_maintenance() {
	if ( '1' !== devxpe_theme_get( 'maintenance_enable' ) ) {
		return;
	}

	if ( is_user_logged_in() && current_user_can( 'manage_options' ) ) {
		return;
	}

	$title   = devxpe_theme_get( 'maintenance_title', __( 'Bakımdayız', 'devxpe-theme' ) );
	$message = devxpe_theme_get( 'maintenance_message', __( 'Sitemiz şu anda güncellenmektedir. Lütfen daha sonra tekrar deneyin.', 'devxpe-theme' ) );
	$image   = devxpe_theme_get( 'maintenance_image' );
	$date    = devxpe_theme_get( 'maintenance_date' ); // Format: 2026-12-31 23:59
	$primary = devxpe_theme_get( 'primary_color', '#c29525' );
	
	/*
	 * Yalnızca içerik döndürülür; charset/viewport/title'ı wp_die() üretir.
	 * Önceden tam HTML dokümanı gönderiliyordu: iç içe doküman oluşuyor ve
	 * WP'nin #error-page kuralları (ID özgüllüğü) düzeni bozuyordu.
	 */
	$html  = '<style>
		html { background: #f4f4f4; -webkit-text-size-adjust: 100%; }

		body {
			margin         : 0;
			padding        : 20px;
			box-sizing     : border-box;
			min-height     : 100vh;
			min-height     : 100svh;
			background     : #f4f4f4;
			border         : 0;
			box-shadow     : none;
			max-width      : none;
			color          : #333;
			font-family    : -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
			text-align     : center;
			display        : flex;
			align-items    : center;
			justify-content: center;
		}

		/* WP varsayılan wp_die kurallarını sıfırla */
		#error-page { margin: 0; }
		#error-page .wp-die-message { margin: 0; width: 100%; font-size: inherit; line-height: inherit; }

		.mnt-container {
			width        : 100%;
			max-width    : 600px;
			margin       : 0 auto;
			padding      : 40px 24px;
			box-sizing   : border-box;
			background   : #fff;
			border-radius: 12px;
			box-shadow   : 0 10px 30px rgba(0,0,0,.06);
		}

		.mnt-image {
			display      : block;
			width        : 100%;
			max-width    : 100%;
			height       : auto;
			max-height   : 300px;
			object-fit   : cover;
			border-radius: 8px;
			margin       : 0 auto 24px;
		}

		.mnt-container h1 {
			margin     : 0 0 16px;
			padding    : 0;
			border     : 0;
			font-size  : 28px;
			line-height: 1.25;
			color      : ' . esc_attr( $primary ) . ';
		}

		.mnt-container p {
			margin     : 0 0 24px;
			font-size  : 16px;
			line-height: 1.6;
			color      : #555;
		}

		.mnt-timer {
			display        : flex;
			flex-wrap      : nowrap;
			justify-content: center;
			gap            : 12px;
			margin-top     : 28px;
		}

		.mnt-timer-box {
			flex         : 1 1 0;
			min-width    : 0;
			background   : ' . esc_attr( $primary ) . ';
			color        : #fff;
			padding      : 14px 6px;
			border-radius: 8px;
		}

		.mnt-timer-box span { display: block; font-size: 24px; font-weight: 700; line-height: 1.1; }
		.mnt-timer-box small { display: block; margin-top: 2px; font-size: 12px; text-transform: uppercase; opacity: .85; }

		/* Tablet */
		@media (max-width: 991px) {
			.mnt-container { max-width: 560px; padding: 34px 22px; }
			.mnt-container h1 { font-size: 25px; }
			.mnt-container p { font-size: 15.5px; }
			.mnt-image { max-height: 260px; }
		}

		/* Büyük telefon / küçük tablet */
		@media (max-width: 767px) {
			body { padding: 16px; }
			.mnt-container { max-width: 100%; padding: 30px 20px; border-radius: 10px; }
			.mnt-container h1 { font-size: 23px; }
			.mnt-container p { font-size: 15px; }
			.mnt-image { max-height: 220px; }
			.mnt-timer { gap: 10px; margin-top: 24px; }
			.mnt-timer-box { padding: 12px 4px; }
			.mnt-timer-box span { font-size: 21px; }
		}

		/* Telefon */
		@media (max-width: 480px) {
			body { padding: 12px; }
			.mnt-container { padding: 26px 16px; }
			.mnt-container h1 { font-size: 21px; margin-bottom: 12px; }
			.mnt-container p { font-size: 14.5px; margin-bottom: 20px; }
			.mnt-image { max-height: 180px; margin-bottom: 18px; }
			.mnt-timer { gap: 8px; margin-top: 20px; }
			.mnt-timer-box { padding: 10px 3px; }
			.mnt-timer-box span { font-size: 19px; }
			.mnt-timer-box small { font-size: 10px; }
		}

		/* Çok dar ekran */
		@media (max-width: 360px) {
			.mnt-container h1 { font-size: 19px; }
			.mnt-timer-box span { font-size: 16px; }
			.mnt-timer-box small { font-size: 9px; }
		}
	</style>';

	$html .= '<div class="mnt-container">';
	
	if ( $image ) {
		$html .= '<img src="' . esc_url( $image ) . '" alt="Bakım" class="mnt-image" />';
	}
	
	$html .= '<h1>' . esc_html( $title ) . '</h1>';
	$html .= '<p>' . nl2br( esc_html( $message ) ) . '</p>';
	
	if ( $date ) {
		$html .= '<div class="mnt-timer" id="mntTimer">
			<div class="mnt-timer-box"><span id="mntDays">00</span><small>Gün</small></div>
			<div class="mnt-timer-box"><span id="mntHours">00</span><small>Saat</small></div>
			<div class="mnt-timer-box"><span id="mntMinutes">00</span><small>Dakika</small></div>
			<div class="mnt-timer-box"><span id="mntSeconds">00</span><small>Saniye</small></div>
		</div>';
		$html .= '<script>
			var countDownDate = new Date("' . esc_js( $date ) . '").getTime();
			var x = setInterval(function() {
				var now = new Date().getTime();
				var distance = countDownDate - now;
				if (distance < 0) {
					clearInterval(x);
					document.getElementById("mntTimer").innerHTML = "<strong>Süre Doldu, Yeniden Yükleniyor...</strong>";
					setTimeout(function(){ window.location.reload(); }, 3000);
					return;
				}
				var days = Math.floor(distance / (1000 * 60 * 60 * 24));
				var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
				var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
				var seconds = Math.floor((distance % (1000 * 60)) / 1000);
				
				document.getElementById("mntDays").innerHTML = days < 10 ? "0"+days : days;
				document.getElementById("mntHours").innerHTML = hours < 10 ? "0"+hours : hours;
				document.getElementById("mntMinutes").innerHTML = minutes < 10 ? "0"+minutes : minutes;
				document.getElementById("mntSeconds").innerHTML = seconds < 10 ? "0"+seconds : seconds;
			}, 1000);
		</script>';
	}
	
	$html .= '</div>';

	wp_die( $html, $title, array( 'response' => 503 ) );
}
add_action( 'template_redirect', 'devxpe_theme_maintenance' );

add_action( 'wp_enqueue_scripts', 'devxpe_theme_assets' );

/**
 * Ön yüzün tarayıcıda bayat kalmasını engeller.
 *
 * Panelde yapılan değişikliklerin (renk, logo, ticker vb.) normal sekmede
 * hemen görünmesi için HTML yanıtına no-cache başlıkları ekler.
 *
 * @param array $headers WP yanıt başlıkları.
 * @return array
 */
function devxpe_theme_no_cache_headers( $headers ) {
	if ( is_admin() ) {
		return $headers;
	}
	$headers['Cache-Control'] = 'no-cache, must-revalidate, max-age=0';
	$headers['Pragma']        = 'no-cache';
	$headers['Expires']       = '0';
	return $headers;
}
add_filter( 'wp_headers', 'devxpe_theme_no_cache_headers' );

/*
 * Arşiv başlığı önekini kaldırır.
 *
 * WP çekirdeği (get_the_archive_title) post type arşivlerine "Arşivler:"
 * öneki ekler ve önek varken başlığı '<span>...</span>' ile sarar. Bu önek
 * hem H1'de hem breadcrumb'da görünüyordu; breadcrumb'da esc_html()
 * yüzünden etiket düz metin olarak basılıyordu. Önek boş döndürülünce
 * hem "Arşivler:" hem de <span> sarması kalkar.
 */
add_filter( 'get_the_archive_title_prefix', '__return_empty_string' );

/**
 * CSS değişkeni metni oluşturur: '--ad: value' döndürür.
 *
 * @param string $key   Değişken adı.
 * @param string $value Değer.
 * @return string
 */
function devxpe_theme_build_var( $key, $value ) {
	return $key . ': ' . $value;
}

/**
 * Ana renge göre okunabilir metin rengini (siyah/beyaz) döndürür.
 *
 * Arka plan açıksa koyu, koyuysa açık metin verir. Hex olmayan
 * değerlerde (örn. Elementor var(--...) renkleri) güvenli varsayılan
 * olarak beyaz döner.
 *
 * @param string $color Hex renk (#rgb veya #rrggbb).
 * @return string
 */
function devxpe_theme_contrast_color( $color ) {
	if ( ! preg_match( '/^#([0-9a-f]{3}|[0-9a-f]{6})$/i', trim( (string) $color ), $m ) ) {
		return '#ffffff';
	}

	$hex = $m[1];
	if ( 3 === strlen( $hex ) ) {
		$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
	}

	$r = hexdec( substr( $hex, 0, 2 ) ) / 255;
	$g = hexdec( substr( $hex, 2, 2 ) ) / 255;
	$b = hexdec( substr( $hex, 4, 2 ) ) / 255;
	$luminance = 0.2126 * $r + 0.7152 * $g + 0.0722 * $b;

	return ( $luminance > 0.6 ) ? '#111111' : '#ffffff';
}

/**
 * Reklam alanlarını frontend'de gösterir.
 *
 * @param string $type Reklam tipi (header, sidebar, post_top vb.)
 */
function devxpe_render_ad( $type ) {
	if ( '1' === devxpe_theme_get( $type . '_enable' ) ) {
		$code = devxpe_theme_get( $type . '_code' );
		if ( ! empty( $code ) ) {
			echo '<div class="dxp-ad dxp-ad-' . esc_attr( str_replace( '_ad', '', $type ) ) . '">' . $code . '</div>';
		}
	}
}

/**
 * Yönetim panelini başlatır (admin_menu / admin_init hook'larını kurar).
 *
 * @return void
 */
function devxpe_theme_boot_panel() {
	DEVXPE_Theme_Panel::init();
}
add_action( 'after_setup_theme', 'devxpe_theme_boot_panel' );

/**
 * Panelin bulunduğu yönetim sayfasının adresini döndürür.
 *
 * Sınıf yüklenmemişse adres ana yönetim sayfasına (admin.php) düşer;
 * böylece var olmayan bir sayfaya yönlendirme yapılmaz.
 *
 * @param string $ek Opsiyonel ek sorgu/çapa (ör. '&demo=installed#settings--demo').
 * @return string
 */
function devxpe_panel_url( $ek = '' ) {
	if ( class_exists( 'DEVXPE_Theme_Panel' ) ) {
		return admin_url( 'admin.php?page=' . DEVXPE_Theme_Panel::MENU_SLUG ) . $ek;
	}

	return admin_url( 'admin.php' );
}

/**
 * Ticker'ı panelden seçilen kancaya bağlar.
 */
function devxpe_theme_hook_ticker() {
	if ( '1' !== devxpe_theme_get( 'ticker_enabled' ) ) {
		return;
	}
	$pos = devxpe_theme_get( 'ticker_position', 'header_bottom' );
	$hook = 'devxpe_after_header'; // Varsayılan

	if ( 'header_top' === $pos ) {
		$hook = 'devxpe_before_header';
	} elseif ( 'footer_top' === $pos ) {
		$hook = 'devxpe_before_footer';
	} elseif ( 'footer_bottom' === $pos ) {
		$hook = 'devxpe_after_footer';
	}

	add_action( $hook, function() {
		get_template_part( 'template-parts/ticker' );
	} );
}
add_action( 'wp', 'devxpe_theme_hook_ticker' );

/**
 * Panel ayarına göre Bootstrap container sınıfını döndürür.
 *
 * Kutulu/Tam genişlik ayrımı artık CSS değişkenleriyle yapılıyor
 * (--dxp-wrap-max / --dxp-wrap-pad): container-fluid kenarlara yakın durur,
 * container yanlarda boşluk bırakır.
 *
 * @return string
 */
function devxpe_get_container_class() {
	$layout = devxpe_theme_get( 'layout', 'boxed' );
	return ( 'full' === $layout ) ? 'container-fluid' : 'container';
}

/**
 * Bir anasayfa bölümü açık mı? (Sadece "Bölüm Aktif" anahtarı.)
 *
 * @param string $id Bölüm id'si.
 * @return bool
 */
function devxpe_section_enabled( $id ) {
	return ( '1' === devxpe_theme_get( $id . '_enable', '1' ) );
}

/**
 * Bölümün mevcut istekte çizilip çizilmeyeceğini döndürür.
 *
 * Otomatik akışta bölümler yalnızca anasayfada çizilir; başka sayfalarda
 * yerleştirmek için [devxpe_section id="..."] kısa kodu kullanılır.
 *
 * @param string $id Bölüm id'si.
 * @return bool
 */
function devxpe_section_visible( $id ) {
	if ( ! devxpe_section_enabled( $id ) ) {
		return false;
	}

	/* Kısa kod bağlamı: yalnızca istenen bölüm çizilir (sayfa şartı yok). */
	if ( ! empty( $GLOBALS['dxp_render_section'] ) ) {
		return ( $GLOBALS['dxp_render_section'] === $id );
	}

	return is_front_page();
}

/**
 * Tek bir anasayfa bölümünü kısa kodla çizer: [devxpe_section id="services"]
 *
 * @param array $atts Kısa kod öznitelikleri.
 * @return string
 */
function devxpe_section_shortcode( $atts = array() ) {
	$atts = shortcode_atts( array( 'id' => '' ), $atts, 'devxpe_section' );
	$id   = sanitize_key( $atts['id'] );

	if ( '' === $id || ! in_array( $id, devxpe_home_section_ids(), true ) ) {
		return '';
	}

	$GLOBALS['dxp_render_section'] = $id;
	ob_start();
	get_template_part( 'template-parts/home-sections' );
	$html = ob_get_clean();
	unset( $GLOBALS['dxp_render_section'] );

	return $html;
}
add_shortcode( 'devxpe_section', 'devxpe_section_shortcode' );

/**
 * CPT detay sayfasında kullanılabilen bölümler (varsayılan sıra).
 *
 * @return array
 */
function devxpe_cpt_section_ids() {
	return array( 'hero', 'includes', 'content', 'projects', 'services', 'faq', 'related', 'quote' );
}

/**
 * Bir içerik tipi için kayıtlı bölüm iskeletini döndürür.
 *
 * Kayıtlı olmayan (yeni eklenen) bölümler sona eklenir; hiçbir bölüm kaybolmaz.
 *
 * @param string $cpt İçerik tipi slug'ı.
 * @return array array( 'order' => array, 'off' => array )
 */
function devxpe_cpt_sections( $cpt ) {
	$all = devxpe_theme_get( 'cpt_sections' );
	$row = ( is_array( $all ) && isset( $all[ $cpt ] ) && is_array( $all[ $cpt ] ) ) ? $all[ $cpt ] : array();

	$ids = devxpe_cpt_section_ids();

	return devxpe_parse_order_off( $row, $ids );
}

/**
 * Bir CPT bölümünün gösterilip gösterilmeyeceğini döndürür.
 *
 * @param string $cpt     İçerik tipi slug'ı.
 * @param string $section Bölüm id'si.
 * @return bool
 */
function devxpe_cpt_section_visible( $cpt, $section ) {
	$sections = devxpe_cpt_sections( $cpt );
	if ( in_array( $section, $sections['off'], true ) ) {
		return false;
	}

	/*
	 * İçerik bazlı geçersiz kılma: tekil içerik düzenleyicisindeki
	 * "Bölüm İskeleti" kutusundan gizlenen bölümler ön yüzde çizilmez.
	 *
	 * NOT: Bu meta anahtarı eski kurulumlar için korunuyor; yazan arayüz
	 * kaldırıldı ama kayıtlı veri hâlâ okunuyor.
	 */
	if ( is_singular() ) {
		$post_id = (int) get_queried_object_id();
		if ( $post_id ) {
			$off = get_post_meta( $post_id, '_dxp_sections_off', true );
			if ( is_array( $off ) && in_array( $section, $off, true ) ) {
				return false;
			}
		}
	}

	return true;
}

/**
 * Hakkımızda sayfasında sıralanabilen bölümler (varsayılan sıra).
 *
 * @return array
 */
function devxpe_about_section_ids() {
	return array( 'hero', 'content', 'stats' );
}

/**
 * Hakkımızda bölüm iskeletini (sıra + kapalılar) döndürür.
 *
 * Kayıtlı olmayan (yeni eklenen) bölümler sona eklenir.
 *
 * @return array array( 'order' => array, 'off' => array )
 */
function devxpe_about_sections() {
	$row = devxpe_theme_get( 'about_sections' );
	$row = is_array( $row ) ? $row : array();
	$ids = devxpe_about_section_ids();

	return devxpe_parse_order_off( $row, $ids );
}

/**
 * Hakkımızda bölümünün gösterilip gösterilmeyeceği.
 *
 * @param string $section Bölüm id'si.
 * @return bool
 */
function devxpe_about_section_visible( $section ) {
	$sections = devxpe_about_sections();
	return ! in_array( $section, $sections['off'], true );
}

/**
 * Detay sayfası şablon (layout) kimlikleri.
 *
 * İçerikten bağımsız global isimler: hangi içerik tipi olursa olsun aynı iki
 * düzen kullanılır.
 *
 * @return array
 */
function devxpe_template_ids() {
	return array( 'layout_1', 'layout_2' );
}

/**
 * Şablonların görünen adları.
 *
 * @return array id => label
 */
function devxpe_template_labels() {
	return array(
		'layout_1' => __( 'Şablon 1 — İki sütun (yapışkan teklif formu)', 'devxpe-theme' ),
		'layout_2' => __( 'Şablon 2 — Tam genişlik bantlar', 'devxpe-theme' ),
	);
}

/**
 * Eski şablon anahtarlarını ('service'/'area') yeni global anahtarlara çevirir.
 *
 * @param string $tpl Şablon anahtarı.
 * @return string
 */
function devxpe_normalize_template( $tpl ) {
	$legacy = array( 'service' => 'layout_1', 'area' => 'layout_2' );
	$tpl    = isset( $legacy[ $tpl ] ) ? $legacy[ $tpl ] : $tpl;
	return in_array( $tpl, devxpe_template_ids(), true ) ? $tpl : 'layout_1';
}

/**
 * Şablon "tam genişlik bantlar" düzeni mi?
 *
 * @param string $tpl Şablon anahtarı.
 * @return bool
 */
function devxpe_template_is_banded( $tpl ) {
	return 'layout_2' === devxpe_normalize_template( $tpl );
}

/**
 * İletişim formunun varsayılan alan listesi.
 *
 * Panelde "Alan Ekle" ile değiştirilebilir; boş bırakılırsa bu liste kullanılır.
 *
 * @return array
 */
function devxpe_contact_default_fields() {
	return array(
		array( 'type' => 'input', 'label' => __( 'Ad', 'devxpe-theme' ), 'key' => 'ad', 'required' => '1', 'width' => 'half', 'placeholder' => '', 'options' => '' ),
		array( 'type' => 'input', 'label' => __( 'Soyad', 'devxpe-theme' ), 'key' => 'soyad', 'required' => '0', 'width' => 'half', 'placeholder' => '', 'options' => '' ),
		array( 'type' => 'tel', 'label' => __( 'Telefon', 'devxpe-theme' ), 'key' => 'telefon', 'required' => '0', 'width' => 'half', 'placeholder' => '', 'options' => '' ),
		array( 'type' => 'email', 'label' => __( 'E-posta', 'devxpe-theme' ), 'key' => 'eposta', 'required' => '0', 'width' => 'half', 'placeholder' => '', 'options' => '' ),
		array( 'type' => 'textarea', 'label' => __( 'Mesajınız', 'devxpe-theme' ), 'key' => 'mesaj', 'required' => '1', 'width' => 'full', 'placeholder' => '', 'options' => '' ),
		array( 'type' => 'file', 'label' => __( 'Dosya', 'devxpe-theme' ), 'key' => 'dosya', 'required' => '0', 'width' => 'full', 'placeholder' => '', 'options' => '' ),
	);
}

/**
 * Panelde tanımlı formları (slug => ad/buton) döndürür.
 *
 * Hiç form yoksa varsayılan "iletisim" formu döner.
 *
 * @return array
 */
function devxpe_custom_forms() {
	$forms = devxpe_theme_get( 'custom_forms' );
	$out   = array();

	if ( is_array( $forms ) ) {
		foreach ( $forms as $f ) {
			if ( ! is_array( $f ) || empty( $f['slug'] ) ) {
				continue;
			}
			$slug = sanitize_key( $f['slug'] );
			if ( '' === $slug ) {
				continue;
			}
			$out[ $slug ] = array(
				'name' => ! empty( $f['name'] ) ? $f['name'] : ucfirst( $slug ),
				'btn'  => isset( $f['btn'] ) ? $f['btn'] : '',
			);
		}
	}

	if ( ! $out ) {
		$out['iletisim'] = array(
			'name' => __( 'İletişim Formu', 'devxpe-theme' ),
			'btn'  => __( 'Mesaj Gönder', 'devxpe-theme' ),
		);
	}

	return $out;
}

/**
 * Oluşturucuda düzenlenen aktif formun slug'ı.
 *
 * @return string
 */
function devxpe_active_form_slug() {
	$forms = devxpe_custom_forms();

	return (string) array_key_first( $forms );
}

/**
 * Bir formun alan satırlarını döndürür (yoksa varsayılanlar).
 *
 * @param string $slug Form slug'ı.
 * @return array
 */
function devxpe_form_fields( $slug ) {
	$slug = sanitize_key( $slug );
	$rows = devxpe_theme_get( 'form_builder_' . $slug );

	if ( ! is_array( $rows ) || ! $rows ) {
		$rows = devxpe_contact_default_fields();
	}

	return $rows;
}

/**
 * Form seçim listesi: 4 adımlı teklif formu + panelde tanımlı formlar.
 *
 * @return array value => label
 */
function devxpe_form_choice_options() {
	$opts = array( 'quote' => __( '4 Adımlı Teklif Formu', 'devxpe-theme' ) );

	foreach ( devxpe_custom_forms() as $slug => $f ) {
		$opts[ $slug ] = $f['name'];
	}

	return $opts;
}

/**
 * Gizlilik politikası sayfasının adresi.
 *
 * Önce tema panelindeki "Yasal Sayfalar" listesi (footer'daki gizlilik
 * linkiyle aynı sayfa kullanılsın), yoksa WordPress'in gizlilik
 * politikası ayarı kullanılır.
 *
 * @return string URL veya ''.
 */
function devxpe_privacy_url() {
	/* Panelden elle verilen link her şeyden önceliklidir. */
	$ozel = trim( (string) devxpe_theme_get( 'privacy_url', '' ) );

	if ( '' !== $ozel ) {
		return $ozel;
	}

	foreach ( (array) devxpe_theme_get( 'footer_legal_pages', array() ) as $dxp_pid ) {
		$dxp_slug = (string) get_post_field( 'post_name', (int) $dxp_pid );

		if ( false !== strpos( $dxp_slug, 'gizlilik' ) || false !== strpos( $dxp_slug, 'privacy' ) ) {
			return (string) get_permalink( (int) $dxp_pid );
		}
	}

	return function_exists( 'get_privacy_policy_url' ) ? (string) get_privacy_policy_url() : '';
}

/**
 * Gizlilik politikası bağlantısının yazısı (tema diline göre).
 *
 * @return string
 */
function devxpe_privacy_label() {
	$lang = class_exists( 'DEVXPE_Theme_Language' ) ? DEVXPE_Theme_Language::selected() : 'auto';

	if ( 'auto' === $lang ) {
		$lang = ( 0 === strpos( (string) get_locale(), 'tr' ) ) ? 'tr_TR' : 'en_US';
	}

	return ( 'tr_TR' === $lang ) ? 'Gizlilik Politikası' : 'Privacy Policy';
}

/**
 * Onay metnini gizlilik politikası bağlantısıyla birlikte döndürür.
 *
 * Metinde `{privacy}` yer tutucusu varsa, yoksa bilinen TR/EN ifade
 * ("gizlilik politikası" / "privacy policy") varsa bağlantıya çevrilir;
 * hiçbiri yoksa bağlantı metnin sonuna eklenir. Dönüş değeri HTML'dir.
 *
 * @param string $metin Onay metni (panel ayarı).
 * @return string
 */
function devxpe_consent_metni( $metin ) {
	$metin = (string) $metin;

	if ( '' === trim( $metin ) ) {
		return '';
	}

	$url = devxpe_privacy_url();

	if ( '' === $url ) {
		return esc_html( $metin );
	}

	$link = '<a class="dxp-consent-link" href="' . esc_url( $url ) . '" target="_blank" rel="noopener nofollow">' . esc_html( devxpe_privacy_label() ) . '</a>';

	$guvenli = esc_html( $metin );

	/* 1) Yer tutucu: yeni metinler için önerilen yol. */
	if ( false !== strpos( $metin, '{privacy}' ) ) {
		return str_replace( '{privacy}', $link, $guvenli );
	}

	/* 2) Bilinen ifadeler: mevcut kayıtlar da otomatik bağlanır. */
	$ifadeler = array(
		'Gizlilik Politikasını',
		'Gizlilik Politikası',
		'gizlilik politikasını',
		'gizlilik politikası',
		'Privacy Policy',
		'privacy policy',
	);

	foreach ( $ifadeler as $ifade ) {
		if ( false !== strpos( $metin, $ifade ) ) {
			return str_replace( esc_html( $ifade ), $link, $guvenli );
		}
	}

	/* 3) İfade bulunamadıysa bağlantıyı sona ekle. */
	return $guvenli . ' ' . $link;
}

/**
 * Seçilen formu (teklif formu veya özel form) çizer.
 *
 * @param string $choice Form kimliği ('quote' → teklif formu).
 * @param bool   $bare   true ise yalnızca form gövdesi çizilir.
 * @return void
 */
function devxpe_render_form_choice( $choice, $bare = false ) {
	$choice = (string) $choice;

	if ( '' === $choice || 'quote' === $choice ) {
		$args = devxpe_quote_form_args();
		if ( $bare ) {
			/* Sarma (bölüm manşeti/zemini) olmadan yalnız form gövdesi. */
			$args['variant'] = 'bare';
		}
		if ( ! empty( $args['groups'] ) ) {
			get_template_part( 'template-parts/quote-form', null, $args );
		}
		return;
	}

	if ( isset( devxpe_custom_forms()[ $choice ] ) ) {
		get_template_part( 'template-parts/contact-form', null, array( 'slug' => $choice ) );
	}
}

/**
 * Anasayfada sıralanabilen bölümlerin sabit listesi (varsayılan sıra).
 *
 * @return array
 */
function devxpe_home_section_ids() {
	return array( 'hero', 'services', 'features', 'steps', 'projects', 'reviews', 'areas', 'faq', 'form' );
}

/**
 * Bölümlerin panelde/skeleton listesinde görünen adları.
 *
 * @return array
 */
function devxpe_home_section_labels() {
	$defaults = array(
		'hero'       => __( 'Manşet', 'devxpe-theme' ),
		'services'   => __( 'Hizmetler', 'devxpe-theme' ),
		'features'   => __( 'Neden Biz', 'devxpe-theme' ),
		'steps'      => __( 'Nasıl Çalışır', 'devxpe-theme' ),
		'projects'   => __( 'Projeler', 'devxpe-theme' ),
		'reviews'    => __( 'Yorumlar', 'devxpe-theme' ),
		'areas'      => __( 'Bölgeler', 'devxpe-theme' ),
		'faq'        => __( 'SSS', 'devxpe-theme' ),
		'form'       => __( 'Teklif Formu', 'devxpe-theme' ),
	);

	/* Panelden "Bölüm Adı" girildiyse onu kullan (müşteri kendi adını yazabilir). */
	$out = array();
	foreach ( $defaults as $id => $label ) {
		$custom      = trim( (string) devxpe_theme_get( 'home_label_' . $id ) );
		$out[ $id ] = ( '' !== $custom ) ? $custom : $label;
	}

	return $out;
}


/**
 * Panelde kaydedilen bölüm sırasını döndürür.
 *
 * Kayıtlı olmayan (yeni eklenen) bölümler listenin sonuna eklenir, böylece
 * hiçbir bölüm kaybolmaz.
 *
 * @return array
 */
function devxpe_home_sections_order() {
	$all   = devxpe_home_section_ids();
	$saved = devxpe_theme_get( 'home_sections_order' );

	if ( is_array( $saved ) ) {
		$saved = implode( ',', $saved );
	}

	$saved = devxpe_lines( $saved, ',' );
	$saved = array_values( array_intersect( $saved, $all ) );

	return array_merge( $saved, array_values( array_diff( $all, $saved ) ) );
}

/**
 * "Yan yana" işaretlenmiş bölümlerin id listesi.
 *
 * İşaretli bölüm, kendisinden sonra gelen ilk görünür bölümle aynı satırı
 * paylaşır (anasayfada 2 sütun).
 *
 * @return array
 */
function devxpe_home_section_splits() {
	$all   = devxpe_home_section_ids();
	$saved = devxpe_theme_get( 'home_sections_split' );

	if ( is_array( $saved ) ) {
		$saved = implode( ',', $saved );
	}

	$saved = devxpe_lines( $saved, ',' );

	return array_values( array_intersect( $saved, $all ) );
}

/**
 * Elementor varlık modu (panelden): auto | always | off.
 *
 * @return string
 */
function devxpe_elementor_assets_mode() {
	$mode = (string) devxpe_theme_get( 'elementor_assets', 'auto' );

	return in_array( $mode, array( 'auto', 'always', 'off' ), true ) ? $mode : 'auto';
}

/**
 * Görüntülenen içerik Elementor ile mi yapılmış?
 *
 * @return bool
 */
function devxpe_page_built_with_elementor() {
	if ( ! class_exists( '\Elementor\Plugin' ) ) {
		return false;
	}

	$post_id = (int) get_queried_object_id();
	if ( ! $post_id ) {
		return false;
	}

	$documents = \Elementor\Plugin::$instance->documents;
	if ( ! $documents || ! method_exists( $documents, 'get' ) ) {
		return false;
	}

	$doc = $documents->get( $post_id );

	return ( $doc && method_exists( $doc, 'is_built_with_elementor' ) && $doc->is_built_with_elementor() );
}

/**
 * Elementor'un ön yüz varlıklarını gereksizse kaldırır.
 *
 * Elementor CSS+JS sayfa başına ~60 KB. Sayfalar Elementor ile yapılmadıysa
 * "Otomatik" mod bunları hiç yüklemez.
 *
 * @return void
 */
function devxpe_trim_elementor_assets() {
	$mode = devxpe_elementor_assets_mode();

	if ( 'always' === $mode ) {
		return;
	}
	if ( 'auto' === $mode && devxpe_page_built_with_elementor() ) {
		return;
	}

	foreach ( array( wp_styles(), wp_scripts() ) as $registry ) {
		foreach ( (array) $registry->queue as $handle ) {
			if ( 0 === strpos( (string) $handle, 'elementor' ) ) {
				$registry->dequeue( $handle );
			}
		}
	}
}
add_action( 'wp_enqueue_scripts', 'devxpe_trim_elementor_assets', 999 );

/* ══════════════════════════════════════════════════════════
   Detay sayfası: teklif formu + SSS meta box'ı
══════════════════════════════════════════════════════════ */

/**
 * Teklif formu şablonuna geçirilecek argümanları üretir.
 *
 * @return array
 */
function devxpe_quote_form_args() {
	$groups = array();

	foreach ( (array) devxpe_theme_get( 'form_services' ) as $row ) {
		if ( ! is_array( $row ) || empty( $row['title'] ) ) {
			continue;
		}
		$options = devxpe_lines( $row['text'] );
		if ( ! $options ) {
			continue;
		}
		$groups[] = array(
			'title'   => $row['title'],
			'options' => array_values( $options ),
		);
	}

	return array(
		'variant'       => 'full',
		'groups'        => $groups,
		'eyebrow'       => devxpe_theme_get( 'form_eyebrow' ),
		'title'         => devxpe_theme_get( 'form_title' ),
		'subtitle'      => devxpe_theme_get( 'form_subtitle' ),
		'benefits'      => devxpe_lines( devxpe_theme_get( 'form_benefits' ) ),
		'phone'         => devxpe_theme_get( 'phone' ),
		'phone_text'    => devxpe_theme_get( 'form_phone_text' ),
		'note'          => devxpe_theme_get( 'form_note' ),
		'steps'         => array(
			devxpe_theme_get( 'form_step1_title', __( 'Hizmet', 'devxpe-theme' ) ),
			devxpe_theme_get( 'form_step2_title', __( 'Projeniz', 'devxpe-theme' ) ),
			devxpe_theme_get( 'form_step3_title', __( 'Bilgileriniz', 'devxpe-theme' ) ),
			devxpe_theme_get( 'form_step4_title', __( 'Gözden geçir ve gönder', 'devxpe-theme' ) ),
		),
		'mini_title'    => devxpe_theme_get( 'form_mini_title' ),
		'mini_subtitle' => devxpe_theme_get( 'form_mini_subtitle' ),
	);
}

/**
 * Teklif formu bütçe alanının hazır TL seçenek listesini döndürür.
 *
 * @return string Virgülle ayrılmış seçenekler.
 */
function devxpe_quote_budget_options() {
	/*
	 * `options` alanı virgülle ayrılmış tek satır bekler (devxpe_lines ile
	 * bölünür). Bu yüzden seçenek metinlerinde virgül KULLANILMAZ.
	 */
	return implode( ', ', array(
		__( '25.000 ₺ altı', 'devxpe-theme' ),
		__( '25.000 - 50.000 ₺', 'devxpe-theme' ),
		__( '50.000 - 100.000 ₺', 'devxpe-theme' ),
		__( '100.000 - 250.000 ₺', 'devxpe-theme' ),
		__( '250.000 ₺ üzeri', 'devxpe-theme' ),
		__( 'Henüz emin değilim', 'devxpe-theme' ),
	) );
}

/**
 * Form alanı oluşturucuda "Hazır şablon" için ön tanımlı seçenek setleri.
 *
 * Değerler, panelde alanın "Seçenekler" kutusuna yazılacak virgülle ayrılmış
 * metinlerdir (virgülsüz seçenekler). Müşteri elle yazmak yerine seçebilsin.
 *
 * @return array Kalıp anahtarı => seçenek metni.
 */
function devxpe_form_field_templates() {
	return array(
		'budget'    => devxpe_quote_budget_options(),
		'reply_by'  => implode( ', ', array(
			__( 'Telefon araması', 'devxpe-theme' ),
			__( 'E-posta', 'devxpe-theme' ),
			__( 'WhatsApp', 'devxpe-theme' ),
			__( 'Kısa mesaj', 'devxpe-theme' ),
		) ),
		'reach_time' => implode( ', ', array(
			__( 'Fark etmez', 'devxpe-theme' ),
			__( 'Sabah', 'devxpe-theme' ),
			__( 'Öğleden sonra', 'devxpe-theme' ),
			__( 'Akşam', 'devxpe-theme' ),
		) ),
		'urgency'   => implode( ', ', array(
			__( 'Acil - en kısa sürede', 'devxpe-theme' ),
			__( '1 - 2 hafta içinde', 'devxpe-theme' ),
			__( '1 ay içinde', 'devxpe-theme' ),
			__( 'Tarih esnek', 'devxpe-theme' ),
		) ),
	);
}

/**
 * Teklif formu "Proje" adımının varsayılan alanları (ARC referansı).
 *
 * @return array
 */
function devxpe_quote_project_default_fields() {
	return array(
		array(
			'type'        => 'input',
			'label'       => __( 'Yaklaşık proje büyüklüğü', 'devxpe-theme' ),
			'key'         => 'size',
			'required'    => '0',
			'width'       => 'full',
			'placeholder' => __( 'Örn. 20 metrekare veya 15 metre uzunluk', 'devxpe-theme' ),
			'help'        => __( 'Kaba bir ölçü yeterli - alanın boyutları ya da kaplanacak alan.', 'devxpe-theme' ),
			'options'     => '',
		),
		array(
			'type'        => 'select',
			'label'       => __( 'Yaklaşık bütçe', 'devxpe-theme' ),
			'key'         => 'budget',
			'required'    => '0',
			'width'       => 'full',
			'placeholder' => __( 'Bir aralık seçin', 'devxpe-theme' ),
			'help'        => __( 'Bu yalnızca uygun malzemeyi belirlememize yardımcı olur. Fiyatınızı belirlemez - fiyat yazılı teklifte netleşir.', 'devxpe-theme' ),
			'options'     => devxpe_quote_budget_options(),
		),
		array(
			'type'        => 'date',
			'label'       => __( 'Tercih edilen başlangıç tarihi (opsiyonel)', 'devxpe-theme' ),
			'key'         => 'start',
			'required'    => '0',
			'width'       => 'full',
			'placeholder' => '',
			'help'        => '',
			'options'     => '',
		),
		array(
			'type'        => 'file',
			'label'       => __( 'Fotoğraflar (opsiyonel)', 'devxpe-theme' ),
			'key'         => 'photos',
			'required'    => '0',
			'width'       => 'full',
			'placeholder' => __( 'Alanın fotoğrafını yükleyin', 'devxpe-theme' ),
			'help'        => __( 'Mevcut durumun fotoğrafı teklifi ciddi biçimde hızlandırır.', 'devxpe-theme' ),
			'options'     => '',
		),
		array(
			'type'        => 'textarea',
			'label'       => __( 'Ek detaylar (opsiyonel)', 'devxpe-theme' ),
			'key'         => 'details',
			'required'    => '0',
			'width'       => 'full',
			'placeholder' => __( 'Erişim, kot farkı, beğendiğiniz malzemeler, bilmemiz gereken her şey', 'devxpe-theme' ),
			'help'        => '',
			'options'     => '',
		),
	);
}

/**
 * Teklif formu "İletişim" adımının varsayılan alanları (ARC referansı).
 *
 * @return array
 */
function devxpe_quote_contact_default_fields() {
	return array(
		array(
			'type'        => 'input',
			'label'       => __( 'Ad Soyad', 'devxpe-theme' ),
			'key'         => 'name',
			'required'    => '1',
			'width'       => 'full',
			'placeholder' => '',
			'help'        => '',
			'options'     => '',
		),
		array(
			'type'        => 'tel',
			'label'       => __( 'Telefon numarası', 'devxpe-theme' ),
			'key'         => 'phone',
			'required'    => '1',
			'width'       => 'full',
			'placeholder' => '',
			'help'        => '',
			'options'     => '',
		),
		array(
			'type'        => 'email',
			'label'       => __( 'E-posta', 'devxpe-theme' ),
			'key'         => 'email',
			'required'    => '1',
			'width'       => 'full',
			'placeholder' => '',
			'help'        => '',
			'options'     => '',
		),
		array(
			'type'        => 'input',
			'label'       => __( 'İş adresi veya posta kodu', 'devxpe-theme' ),
			'key'         => 'address',
			'required'    => '0',
			'width'       => 'full',
			'placeholder' => '',
			'help'        => __( 'Bu bilgiyi işin hizmet bölgemizde olduğunu doğrulamak için kullanırız.', 'devxpe-theme' ),
			'options'     => '',
		),
		array(
			'type'        => 'select',
			'label'       => __( 'Nasıl yanıt verelim?', 'devxpe-theme' ),
			'key'         => 'reply_by',
			'required'    => '0',
			'width'       => 'half',
			'placeholder' => '',
			'help'        => '',
			'options'     => devxpe_form_field_templates()['reply_by'],
		),
		array(
			'type'        => 'select',
			'label'       => __( 'Size ulaşmak için en uygun zaman', 'devxpe-theme' ),
			'key'         => 'reach_time',
			'required'    => '0',
			'width'       => 'half',
			'placeholder' => '',
			'help'        => '',
			'options'     => devxpe_form_field_templates()['reach_time'],
		),
	);
}

/**
 * Teklif formu adımının alanlarını döndürür (panelden, boşsa varsayılan).
 *
 * @param string $step 'project' veya 'contact'.
 * @return array
 */
function devxpe_quote_step_fields( $step ) {
	$step = ( 'project' === $step ) ? 'project' : 'contact';
	$rows = devxpe_theme_get( 'quote_' . $step . '_fields' );

	if ( is_array( $rows ) && $rows ) {
		return $rows;
	}

	return ( 'project' === $step ) ? devxpe_quote_project_default_fields() : devxpe_quote_contact_default_fields();
}

/**
 * Anahtar → etiket eşlemesi (gelen mesaj kutusu ve e-posta için).
 *
 * @return array
 */
function devxpe_form_field_labels() {
	$map = array();
	foreach ( array_merge( devxpe_quote_project_default_fields(), devxpe_quote_contact_default_fields() ) as $row ) {
		if ( ! empty( $row['key'] ) ) {
			$map[ $row['key'] ] = $row['label'];
		}
	}
	foreach ( array_merge( devxpe_quote_step_fields( 'project' ), devxpe_quote_step_fields( 'contact' ) ) as $row ) {
		if ( ! empty( $row['key'] ) && ! empty( $row['label'] ) ) {
			$map[ $row['key'] ] = $row['label'];
		}
	}
	$map['postcode'] = __( 'İş adresi veya posta kodu', 'devxpe-theme' );
	return $map;
}

/**
 * Teklif formunun 2. ve 3. adımındaki tek bir alanı çizer.
 *
 * Alan tanımı panelden gelir; tür, etiket, yer tutucu, alt not, genişlik ve
 * zorunluluk anahtarı müşteri tarafından değiştirilebilir.
 *
 * @param array $row Alan tanımı.
 * @return void
 */
function devxpe_render_quote_field( $row ) {
	$type  = isset( $row['type'] ) ? $row['type'] : 'input';
	$label = isset( $row['label'] ) ? (string) $row['label'] : '';
	$key   = isset( $row['key'] ) ? (string) $row['key'] : '';
	if ( '' === $label || '' === $key ) {
		return;
	}

	$req    = ( isset( $row['required'] ) && '1' === $row['required'] );
	$ph     = isset( $row['placeholder'] ) ? (string) $row['placeholder'] : '';
	$help   = isset( $row['help'] ) ? (string) $row['help'] : '';
	$opts   = isset( $row['options'] ) ? devxpe_lines( $row['options'], ',' ) : array();
	$half   = ( isset( $row['width'] ) && 'half' === $row['width'] ) ? ' dxp-qfield--half' : '';
	$id     = 'dxp-q-' . $key;
	$req_at = $req ? ' required' : '';
	$lbl    = esc_html( $label ) . ( $req ? ' *' : '' );
	$data   = ' data-label="' . esc_attr( $label ) . '"';

	/* Dosyalar ortak yükleme akışını kullanır (dxp_file_ ön eki). */
	$name = ( 'file' === $type ) ? 'dxp_file_' . $key : $key;

	echo '<div class="dxp-qfield' . esc_attr( $half ) . '">';
	echo '<label for="' . esc_attr( $id ) . '"><span>' . $lbl . '</span></label>';

	if ( 'select' === $type ) {
		echo '<select id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '"' . $req_at . $data . '>';
		echo '<option value="">' . esc_html( $ph ? $ph : __( 'Seçiniz', 'devxpe-theme' ) ) . '</option>';
		foreach ( $opts as $opt ) {
			echo '<option value="' . esc_attr( $opt ) . '">' . esc_html( $opt ) . '</option>';
		}
		echo '</select>';
	} elseif ( 'textarea' === $type ) {
		echo '<textarea id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" rows="4" placeholder="' . esc_attr( $ph ) . '"' . $req_at . $data . devxpe_field_maxlength_attr( 'textarea' ) . '></textarea>';
		devxpe_render_field_counter( 'textarea' );
	} elseif ( 'file' === $type ) {
		$accept = '.' . implode( ',.', devxpe_lines( devxpe_theme_get( 'contact_upload_types', 'jpg,jpeg,png,webp,pdf' ), ',' ) );
		echo '<input type="file" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" accept="' . esc_attr( $accept ) . '"' . $req_at . $data . ' />';
	} else {
		$html_type = in_array( $type, array( 'email', 'tel', 'url', 'number', 'date' ), true ) ? $type : 'text';

		if ( 'tel' === $type ) {
			echo '<div class="dxp-tel-wrap">';
			devxpe_form_country_select( $key );
			echo '<input type="tel" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" placeholder="' . esc_attr( $ph ) . '"' . $req_at . $data . ' />';
			echo '</div>';
		} else {
			$max_attr = in_array( $html_type, array( 'text', 'email', 'url' ), true ) ? devxpe_field_maxlength_attr( $html_type ) : '';
			echo '<input type="' . esc_attr( $html_type ) . '" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" placeholder="' . esc_attr( $ph ) . '"' . $req_at . $data . $max_attr . ' />';
		}
	}

	if ( '' !== $help ) {
		echo '<small class="dxp-qhint">' . esc_html( $help ) . '</small>';
	}
	echo '</div>';
}

/**
 * "Neler dahil" bölümünün görünür adını döndürür.
 *
 * Panelde global bir ad tanımlanmışsa onu, aksi hâlde çevrilmiş
 * varsayılanı ("Neler dahil") kullanır. İçerikteki meta alanı yine
 * üzerine yazabilir.
 *
 * @return string
 */
function devxpe_includes_heading() {
	$global = trim( (string) devxpe_theme_get( 'includes_heading' ) );

	return '' !== $global ? $global : __( 'Neler dahil', 'devxpe-theme' );
}

/**
 * Kaynaktaki içerikleri kart verisine dönüştürür.
 *
 * Kaynak biçimi:
 *   - "manual"     → boş dizi döner (manuel listeye düşülür)
 *   - "category:5" → o terime ait yazılar (taxonomy:term_id)
 *   - "post"       → son yazılar
 *   - "page"       → sayfalar
 *
 * @param string $source Kaynak değeri.
 * @param int    $limit  En fazla kaç kart.
 * @return array array( array( 'image' =>, 'title' =>, 'text' =>, 'url' => ), ... )
 */
function devxpe_cards_from_source( $source, $limit = 6 ) {
	$limit = absint( $limit );
	if ( $limit < 1 ) {
		$limit = 6;
	}

	if ( ! $source || 'manual' === $source ) {
		return array();
	}

	$args = array(
		'numberposts' => $limit,
		'post_status' => 'publish',
	);

	if ( false !== strpos( $source, ':' ) ) {
		list( $prefix, $rest ) = explode( ':', $source, 2 );

		if ( 'cpt' === $prefix ) {
			/* Panelden tanımlı özel içerik tipi. */
			$args['post_type'] = $rest;
		} else {
			$args['post_type'] = 'any';
			$args['tax_query'] = array(
				array(
					'taxonomy' => $prefix,
					'field'    => 'term_id',
					'terms'    => absint( $rest ),
				),
			);
		}
	} elseif ( 'page' === $source ) {
		$args['post_type'] = 'page';
	} elseif ( 'post' === $source ) {
		$args['post_type'] = 'post';
	} else {
		return array();
	}

	$out = array();

	foreach ( get_posts( $args ) as $item ) {
		$out[] = array(
			'image' => (string) get_the_post_thumbnail_url( $item, 'large' ),
			'title' => get_the_title( $item ),
			'text'  => wp_strip_all_tags( get_the_excerpt( $item ) ),
			'url'   => get_permalink( $item ),
		);
	}

	return $out;
}


/**
 * Öge listesi girdisini link olarak döndürür; link yoksa düz metin olarak.
 *
 * @param array  $item  title/url anahtarları.
 * @param string $class CSS sınıfı.
 * @return string
 */
function devxpe_item_link( $item, $class = 'dxp-tag' ) {
	$title = isset( $item['title'] ) ? $item['title'] : '';
	$attr  = $class ? ' class="' . esc_attr( $class ) . '"' : '';

	if ( empty( $item['url'] ) ) {
		return '<span' . $attr . '>' . esc_html( $title ) . '</span>';
	}

	return '<a' . $attr . ' href="' . esc_url( $item['url'] ) . '">' . esc_html( $title ) . '</a>';
}

/**
 * Arşivi kapatır: anasayfaya yönlendirir ya da 404 verir.
 *
 * @param string $action 'home' | '404'.
 * @return void
 */
function devxpe_archive_close( $action ) {
	if ( 'home' === $action ) {
		/* 302: ayar geri alındığında tarayıcıda kalıcı 301 önbelleği kalmaz. */
		wp_safe_redirect( home_url( '/' ), 302 );
		exit;
	}

	global $wp_query;
	$wp_query->set_404();
	status_header( 404 );
	nocache_headers();
}

/**
 * WordPress kategori arşivlerini kapatır (panel ayarına göre).
 *
 * Kategoriler yalnızca bölümlerde kaynak olarak kullanılıyorsa arşiv
 * sayfaları gereksizdir: anasayfaya yönlendirilir ya da 404 verilir.
 *
 * @return void
 */
function devxpe_category_archive_guard() {
	if ( is_admin() || ! is_category() ) {
		return;
	}

	$action = devxpe_theme_get( 'category_archive_action', 'normal' );

	if ( 'normal' !== $action ) {
		devxpe_archive_close( $action );
	}
}
add_action( 'template_redirect', 'devxpe_category_archive_guard' );

/**
 * Devxpe panelinde tanımlı içerik tiplerinin arşiv sayfalarını kapatır.
 *
 * WordPress kategorilerinden bağımsızdır; yalnızca panelde tanımlı
 * içerik tiplerinin (services, areas…) arşivleri için geçerlidir.
 *
 * @return void
 */
function devxpe_cpt_archive_guard() {
	if ( is_admin() || ! is_post_type_archive() ) {
		return;
	}

	$object = get_queried_object();
	if ( ! $object || ! in_array( $object->name, wp_list_pluck( devxpe_custom_post_types(), 'slug' ), true ) ) {
		return;
	}

	$action = devxpe_theme_get( 'cpt_archive_action', 'normal' );

	if ( 'normal' !== $action ) {
		devxpe_archive_close( $action );
	}
}
add_action( 'template_redirect', 'devxpe_cpt_archive_guard' );

/**
 * Sayfanın "Hakkımızda" / "İletişim" şablonuyla render edilmesini sağlar.
 *
 * Şablon seçimi sayfa düzenleyicisindeki metabox'tan yapılır
 * (`_dxp_page_type` = about | contact). WordPress şablon listesinde
 * görünmesin diye bu şablonların "Template Name" başlığı kaldırılmıştır.
 * Eski kurulumlar için panel seçicileri (about_page_pick/contact_page_pick)
 * yedek olarak korunur.
 *
 * @param string $template Mevcut şablon yolu.
 * @return string
 */
function devxpe_page_pick_template( $template ) {
	global $wp_query;
	if ( empty( $wp_query->is_page ) || empty( $wp_query->get_queried_object_id() ) ) {
		return $template;
	}

	$dxp_page_id = (int) $wp_query->get_queried_object_id();
	$tpl         = '';

	/* 1) Metabox seçimi (asıl yol). */
	if ( 'page' === get_post_type( $dxp_page_id ) ) {
		$dxp_type = (string) get_post_meta( $dxp_page_id, '_dxp_page_type', true );
		if ( 'about' === $dxp_type ) {
			$tpl = 'page-about.php';
		} elseif ( 'contact' === $dxp_type ) {
			$tpl = 'page-contact.php';
		}
	}

	/* 2) Eski panel seçicileri (geriye dönük uyumluluk). */
	if ( '' === $tpl ) {
		$picked = (int) devxpe_theme_get( 'about_page_pick' );
		$tpl    = 'page-about.php';
		if ( ! $picked ) {
			$picked = (int) devxpe_theme_get( 'contact_page_pick' );
			$tpl    = 'page-contact.php';
		}
		if ( ! $picked || $picked !== $dxp_page_id ) {
			return $template;
		}
	}

	$located = locate_template( $tpl );

	return $located ? $located : $template;
}
add_filter( 'template_include', 'devxpe_page_pick_template', 99 );

/**
 * Kaynaktan öge (etiket/kategori/sayfa/yazı) listesi üretir.
 *
 * Fallback altyapısı: panelde bir kaynak seçilir ve liste otomatik doldurulur.
 * Yeni yazı/sayfa/terim eklendiğinde kendiliğinden listeye girer.
 *
 * @param string $source category | post_tag | page | post.
 * @param int    $limit  En fazla kaç öge. 0 → sınırsız.
 * @return array array( array( 'title' => ..., 'url' => ... ), ... )
 */
function devxpe_items_list( $source, $limit = 10 ) {
	$limit = absint( $limit );
	if ( $limit < 1 ) {
		$limit = -1; /* 0 veya boş → sınırsız (panelde limit alanı olmayan listeler için) */
	}

	$out = array();

	/* Kategori arşivleri kapalıysa ölü link üretmemek için url boş bırakılır. */
	$link_off = ( 'category' === $source && 'normal' !== devxpe_theme_get( 'category_archive_action', 'normal' ) );

	switch ( $source ) {
		case 'category':
		case 'post_tag':
			$terms = get_terms(
				array(
					'taxonomy'   => $source,
					'hide_empty' => true,
					'number'     => $limit > 0 ? $limit : 0,
					'orderby'    => 'count',
					'order'      => 'DESC',
				)
			);

			if ( ! is_wp_error( $terms ) ) {
				foreach ( $terms as $term ) {
					$link = get_term_link( $term );
					if ( is_wp_error( $link ) ) {
						continue;
					}
					$out[] = array(
						'title' => $term->name,
						'url'   => $link_off ? '' : $link,
					);
				}
			}
			break;

		case 'page':
			foreach ( get_pages( array( 'number' => $limit > 0 ? $limit : 0, 'sort_column' => 'menu_order,post_title' ) ) as $page ) {				$out[] = array( 'title' => $page->post_title, 'url' => get_permalink( $page->ID ) );
			}
			break;

		case 'post':
			foreach ( get_posts( array( 'numberposts' => $limit > 0 ? $limit : -1, 'post_status' => 'publish' ) ) as $post ) {				$out[] = array( 'title' => get_the_title( $post ), 'url' => get_permalink( $post ) );
			}
			break;

		default:
			$parts  = array_pad( explode( ':', $source, 2 ), 2, '' );
			$prefix = $parts[0];
			$rest   = $parts[1];

			if ( 'cpt' === $prefix && '' !== $rest ) {
				/* Panelden tanımlı özel içerik tipi: cpt:<slug> */
				foreach ( get_posts( array( 'numberposts' => $limit > 0 ? $limit : -1, 'post_type' => $rest, 'post_status' => 'publish' ) ) as $item ) {
					$out[] = array( 'title' => get_the_title( $item ), 'url' => get_permalink( $item ) );
				}
			} elseif ( '' !== $prefix && '' !== $rest && taxonomy_exists( $prefix ) ) {
				/* Taksonomi terimi: <taxonomy>:<term_id> */
				$term_id  = absint( $rest );
				$link_off = ( 'category' === $prefix && 'normal' !== devxpe_theme_get( 'category_archive_action', 'normal' ) );

				if ( $term_id ) {
					$items = get_posts(
						array(
							'numberposts' => $limit > 0 ? $limit : -1,
							'post_status' => 'publish',
							'post_type'   => 'any',
							'tax_query'   => array(
								array(
									'taxonomy' => $prefix,
									'field'    => 'term_id',
									'terms'    => $term_id,
								),
							),
						)
					);

					foreach ( $items as $item ) {
						$out[] = array(
							'title' => get_the_title( $item ),
							'url'   => $link_off ? '' : get_permalink( $item ),
						);
					}
				}
			}
			break;
	}

	return $out;
}


/*
 * NOT: "Sayfa Manşeti" metabox'ı KALDIRILDI.
 *
 * Manşet artık sayfa düzenleyicideki "Sayfa Şablonu ve İçeriği" kutusundaki
 * WIDGET sisteminden eklenir (widget tipi: 'manset' → DEVXPE_Page_Widgets).
 * Eski _dxp_hero_title / _dxp_hero_subtitle değerleri veritabanında kalır ve
 * şablonlar (page-about.php / page-contact.php) onları okumaya devam eder;
 * yeni sayfalarda başlık yoksa sayfa adına düşer.
 */

/* ══════════════════════════════════════════════════════════
   Google reCAPTCHA v3
   ══════════════════════════════════════════════════════════ */

/**
 * reCAPTCHA v3 kullanılabilir mi? (aktif + iki anahtar da girilmiş)
 *
 * @return bool
 */
function devxpe_recaptcha_enabled() {
	return (
		'1' === devxpe_theme_get( 'recaptcha_enable' ) &&
		'' !== trim( (string) devxpe_theme_get( 'recaptcha_site_key' ) ) &&
		'' !== trim( (string) devxpe_theme_get( 'recaptcha_secret_key' ) )
	);
}

/**
 * Gönderilen reCAPTCHA token'ını Google'da doğrular.
 *
 * @return bool Doğrulama başarılıysa true (kapalıysa da true).
 */
function devxpe_verify_recaptcha() {
	if ( ! devxpe_recaptcha_enabled() ) {
		return true;
	}

	$token = isset( $_POST['dxp_recaptcha'] ) ? sanitize_text_field( wp_unslash( $_POST['dxp_recaptcha'] ) ) : '';
	if ( '' === $token ) {
		return false;
	}

	$response = wp_remote_post(
		'https://www.google.com/recaptcha/api/siteverify',
		array(
			'timeout' => 8,
			'body'    => array(
				'secret'   => (string) devxpe_theme_get( 'recaptcha_secret_key' ),
				'response' => $token,
				'remoteip' => isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '',
			),
		)
	);

	if ( is_wp_error( $response ) ) {
		return false;
	}

	$data = json_decode( wp_remote_retrieve_body( $response ), true );
	if ( empty( $data['success'] ) ) {
		return false;
	}

	/* v3: eylem adı ve puan eşiği de kontrol edilir. */
	if ( isset( $data['action'] ) && 'dxp_form' !== $data['action'] ) {
		return false;
	}

	$min = (float) devxpe_theme_get( 'recaptcha_score', '0.5' );
	if ( isset( $data['score'] ) && (float) $data['score'] < $min ) {
		return false;
	}

	return true;
}

/* ══════════════════════════════════════════════════════════
   Hakkımızda / İletişim sayfaları — içerik ve sütun düzeni
   ══════════════════════════════════════════════════════════ */

/*
 * NOT: "Sayfa Şablonu ve İçeriği" metabox'ı KALDIRILDI.
 *
 * İstatistik satırları, iletişim kartları ve sütun sayısı artık sayfa
 * düzenleyicideki "İçerik Düzeni" metabox'ındaki WIDGET sisteminden
 * yönetilir (widget tipleri: 'stats', 'iletisim_kart', 'ikon_kutulari',
 * 'manset'). Eski sayfa meta'ları (_dxp_about_stats, _dxp_about_cols,
 * _dxp_contact_cards, _dxp_contact_cols) veritabanında kalır ve şablonlar
 * varsayılan olarak onları kullanmaya devam eder.
 */


/* ══════════════════════════════════════════════════════════
   Panel "Yeni" etiketi — güncellemeyle gelen özellikler
   ══════════════════════════════════════════════════════════ */

/**
 * "Yeni" etiketi alacak panel bölümleri: alt bölüm id'si => tanıtıldığı sürüm.
 *
 * KURAL:
 *  - Buraya YALNIZCA o sürümde İLK KEZ eklenen panel bölümleri yazılır.
 *  - Var olan bir bölüme yalnızca alan/içerik eklendiyse YAZILMAZ → o bölüm
 *    "Yeni" rozeti almaz.
 *  - Bir sürümde yalnızca o sürümün kayıtları rozet alır; yeni bir sürüm
 *    geldiğinde önceki rozetler otomatik silinir (en son değişiklik "Yeni").
 *
 * @return array
 */
function devxpe_panel_feature_versions() {
	return array(
		'captcha' => '0.2.1',
		'demo'    => '0.2.1',
	);
}

/**
 * "Yeni" rozetinin kaç gün görüneceği.
 *
 * @return int
 */
function devxpe_new_badge_days() {
	return 1;
}

/**
 * Tema sürümü değiştiğinde yeni özellikleri işaretler (admin tarafında).
 *
 * @return void
 */
function devxpe_sync_new_features() {
	$current = (string) DEVXPE_THEME_VERSION;
	$prev    = get_option( 'devxpe_theme_badge_version' );

	/* Geçerli sürümün rozet alacak bölümleri. */
	$current_keys = array();
	foreach ( devxpe_panel_feature_versions() as $key => $version ) {
		if ( $version === $current ) {
			$current_keys[ $key ] = true;
		}
	}

	/* İlk kurulum: rozet gösterme, yalnızca sürümü kaydet. */
	if ( false === $prev ) {
		update_option( 'devxpe_theme_badge_version', $current, false );
		return;
	}

	if ( $prev !== $current ) {
		/*
		 * Yeni sürüm: rozetler SIFIRDAN kurulur. Böylece önceki sürümün
		 * "Yeni" rozetleri silinir; yalnızca en son değişiklik "Yeni" kalır.
		 */
		$new = array();
		foreach ( array_keys( $current_keys ) as $key ) {
			$new[ $key ] = time();
		}

		update_option( 'devxpe_theme_new_features', $new, false );
		update_option( 'devxpe_theme_badge_version', $current, false );

		return;
	}

	/*
	 * Sürüm aynı ama haritadan bir bölüm çıkarılmış olabilir (ör. geriye dönük
	 * "Yeni" vermeyi bıraktık). Kalan rozetleri hemen temizle.
	 */
	$saved = get_option( 'devxpe_theme_new_features', array() );
	if ( is_array( $saved ) && $saved ) {
		$pruned = array_intersect_key( $saved, $current_keys );
		if ( count( $pruned ) !== count( $saved ) ) {
			update_option( 'devxpe_theme_new_features', $pruned, false );
		}
	}
}
add_action( 'admin_init', 'devxpe_sync_new_features' );

/**
 * Özellik hâlâ "yeni" mi? (işaretlenmiş ve süresi dolmamış)
 *
 * @param string $key Bölüm id'si.
 * @return bool
 */
function devxpe_feature_is_new( $key ) {
	$new = get_option( 'devxpe_theme_new_features', array() );
	if ( ! is_array( $new ) || empty( $new[ $key ] ) ) {
		return false;
	}

	return ( time() - (int) $new[ $key ] ) < ( devxpe_new_badge_days() * DAY_IN_SECONDS );
}

/**
 * Bölümün herhangi bir alt bölümü yeni mi?
 *
 * @param array $section Panel bölüm tanımı.
 * @return bool
 */
function devxpe_section_has_new( $section ) {
	if ( empty( $section['subsections'] ) ) {
		return false;
	}

	foreach ( $section['subsections'] as $sub_id => $sub ) {
		if ( devxpe_feature_is_new( $sub_id ) ) {
			return true;
		}
	}

	return false;
}

/**
 * "Yeni" rozeti HTML'i (yeni değilse boş döner).
 *
 * @param string $key Bölüm id'si.
 * @return string
 */
function devxpe_new_badge( $key ) {
	if ( ! devxpe_feature_is_new( $key ) ) {
		return '';
	}

	return '<span class="dxp-new-badge">' . esc_html__( 'Yeni', 'devxpe-theme' ) . '</span>';
}
