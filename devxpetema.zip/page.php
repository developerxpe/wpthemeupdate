<?php
/**
 * Sayfa şablonu — "normal sayfa" düzeni.
 *
 * Beyaz zemin, ortalanmış 3xl içerik kolonu; başlık + gövde.
 * (referans /terms ve diğer düz sayfaların düzeni.)
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>
<section class="dxp-band dxp-band--white dxp-page-band">
	<div class="dxp-band-inner dxp-page-inner">
		<?php get_template_part( 'template-parts/breadcrumbs' ); ?>
		<?php
		while ( have_posts() ) :
			the_post();
			?>
			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
				<h1 class="dxp-page-title"><?php the_title(); ?></h1>
				<div class="dxp-page-content"><?php the_content(); ?></div>
			</article>
			<?php
		endwhile;
		?>
	</div>
</section>
<?php
/*
 * Sayfa widget'ları: kayıtlı liste varsa içerik bandının altında çizilir.
 * (Widget'lar her sayfada eklenebilir; liste boşsa hiçbir şey çizilmez.)
 */
$dxp_pw_html = class_exists( 'DEVXPE_Page_Widgets' ) ? (string) DEVXPE_Page_Widgets::cikti( get_the_ID() ) : '';
if ( '' !== trim( $dxp_pw_html ) ) {
	echo '<section class="dxp-band dxp-band--white"><div class="dxp-band-inner">' . $dxp_pw_html . '</div></section>'; // phpcs:ignore WordPress.Security.EscapeOutput
}
?>
<?php
get_footer();
