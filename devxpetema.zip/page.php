<?php
/**
 * Sayfa şablonu — ortak yerleşim.
 *
 * Başlık + içerik + widget'lar; ayrıntı: template-parts/page-layout.php.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
get_template_part( 'template-parts/page-layout' );
get_footer();
