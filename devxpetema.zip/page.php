<?php
/**
 * Sayfa şablonu — ARC "normal sayfa" düzeni.
 *
 * Beyaz zemin, ortalanmış 3xl içerik kolonu; başlık + gövde.
 * (ARC /terms ve diğer düz sayfaların düzeni.)
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>
<section class="dxp-band dxp-band--white dxp-page-band">
	<div class="dxp-band-inner dxp-page-inner">
		<?php get_template_part( 'template-parts/breadcrumbs' ); ?>
		<?php
		while ( have_posts() ) :
			the_post();
			?>
			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
				<h1 class="dxp-page-title"><?php the_title(); ?></h1>
				<div class="dxp-page-content"><?php the_content(); ?></div>
			</article>
			<?php
		endwhile;
		?>
	</div>
</section>
<?php
get_footer();
