<?php
/**
 * Başlık şablonu.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$topbar_on  = '1' === devxpe_theme_get( 'topbar_enabled' );
$sticky     = '1' === devxpe_theme_get( 'sticky_header' );
$logo_url   = devxpe_theme_get( 'logo' );
$phone      = devxpe_theme_get( 'phone' );
$email      = devxpe_theme_get( 'email' );
$site_name  = devxpe_theme_get( 'site_title', get_bloginfo( 'name' ) );

$quote_on   = ( '1' === devxpe_theme_get( 'header_btn_enable' ) );
$quote_text = devxpe_theme_get( 'header_btn_text' );
$quote_url  = devxpe_theme_get( 'header_btn_url' );
if ( ! $quote_text ) {
	$quote_text = __( 'Ücretsiz Teklif', 'devxpe-theme' );
}
if ( ! $quote_url ) {
	$quote_url = home_url( '/' );
}

$phone_href = $phone ? 'tel:' . preg_replace( '/\s+/', '', $phone ) : '';

/* Lucide ikonları (referans siteyle aynı) */
$icon_phone = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384"></path></svg>';
$icon_menu  = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 5h16"></path><path d="M4 12h16"></path><path d="M4 19h16"></path></svg>';
$icon_close = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 6 6 18"></path><path d="m6 6 12 12"></path></svg>';

/*
 * Hamburger butonu tek yerde üretilir; "Hamburger Konumu" ayarına göre
 * logonun solunda (akışın başında) ya da sağında (aksiyonların içinde) basılır.
 */
$burger_pos = ( 'left' === devxpe_theme_get( 'mobile_menu_position', 'right' ) ) ? 'left' : 'right';
$burger_btn = '<button type="button" class="dxp-icon-btn dxp-burger" id="dxp-burger-btn"'
	. ' aria-label="' . esc_attr__( 'Menüyü Aç/Kapat', 'devxpe-theme' ) . '"'
	. ' aria-expanded="false" aria-controls="dxp-mobile-nav">'
	. '<span class="dxp-burger-open">' . $icon_menu . '</span>'
	. '<span class="dxp-burger-close">' . $icon_close . '</span>'
	. '</button>';
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<?php
$body_scripts = devxpe_theme_get( 'script_body' );
if ( $body_scripts ) {
	// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo $body_scripts;
}
?>

<a class="skip-link screen-reader-text" href="#content">
	<?php esc_html_e( 'İçeriğe geç', 'devxpe-theme' ); ?>
</a>

<?php do_action( 'devxpe_before_header' ); ?>

<!-- ══ HEADER ════════════════════════════════════════════ -->
<header class="dxp-header<?php echo $sticky ? ' dxp-header--sticky' : ''; ?><?php echo ( ! $sticky && '1' === devxpe_theme_get( 'sticky_mobile' ) ) ? ' dxp-header--sticky-mobile' : ''; ?>" role="banner">

	<?php
	/*
	 * Sosyal linkler üst barda gösterilir. Üst bar, telefon/e-posta olmasa da
	 * yalnızca sosyal hesap varsa açılır; aksi halde boş bar çizilmez.
	 */
	$socials = array(
		'facebook'  => array( 'url' => devxpe_theme_get( 'facebook' ),  'icon' => 'dashicons-facebook' ),
		'instagram' => array( 'url' => devxpe_theme_get( 'instagram' ), 'icon' => 'dashicons-instagram' ),
		'twitter'   => array( 'url' => devxpe_theme_get( 'twitter' ),   'icon' => 'dashicons-twitter' ),
		'youtube'   => array( 'url' => devxpe_theme_get( 'youtube' ),   'icon' => 'dashicons-youtube' ),
		'linkedin'  => array( 'url' => devxpe_theme_get( 'linkedin' ),  'icon' => 'dashicons-linkedin' ),
	);
	$has_social = (bool) array_filter( wp_list_pluck( $socials, 'url' ) );
	?>
	<?php if ( $topbar_on && ( $phone || $email || $has_social ) ) : ?>
	<div class="dxp-topbar py-2 border-bottom">
		<div class="dxp-header-inner d-flex justify-content-between align-items-center small">
			<div class="dxp-topbar-left d-flex flex-wrap gap-3">
				<?php if ( $phone ) : ?>
				<a href="<?php echo esc_url( $phone_href ); ?>" class="dxp-topbar-link text-decoration-none d-flex align-items-center gap-1">
					<span class="dashicons dashicons-phone"></span>
					<?php echo esc_html( $phone ); ?>
				</a>
				<?php endif; ?>
				<?php if ( $email ) : ?>
				<a href="mailto:<?php echo esc_attr( $email ); ?>" class="dxp-topbar-link text-decoration-none d-flex align-items-center gap-1">
					<span class="dashicons dashicons-email"></span>
					<?php echo esc_html( $email ); ?>
				</a>
				<?php endif; ?>
			</div>
			<div class="dxp-topbar-right d-flex gap-2">
				<?php
				foreach ( $socials as $key => $social ) :
					if ( ! $social['url'] ) {
						continue;
					}
					?>
				<a href="<?php echo esc_url( $social['url'] ); ?>" target="_blank" rel="noopener noreferrer"
				   aria-label="<?php echo esc_attr( ucfirst( $key ) ); ?>" class="dxp-topbar-link text-decoration-none">
					<span class="dashicons <?php echo esc_attr( $social['icon'] ); ?>"></span>
				</a>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
	<?php endif; ?>

	<div class="dxp-header-bar">
		<div class="dxp-header-inner<?php echo 'left' === $burger_pos ? ' dxp-burger-left' : ''; ?>">

			<!-- Marka / Logo -->
			<a class="dxp-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php echo esc_attr( $site_name ); ?>">
				<?php
				$mobile_logo = devxpe_theme_get( 'mobile_logo' );
				$show_title  = '1' === devxpe_theme_get( 'show_site_title', '1' );
				?>
				<?php if ( $mobile_logo ) : ?>
					<img src="<?php echo esc_url( $mobile_logo ); ?>" class="dxp-logo dxp-logo--mobile" alt="<?php echo esc_attr( $site_name ); ?>">
				<?php endif; ?>

				<?php if ( $logo_url ) : ?>
					<img src="<?php echo esc_url( $logo_url ); ?>" class="dxp-logo<?php echo $mobile_logo ? ' dxp-logo--desktop' : ''; ?>" alt="<?php echo esc_attr( $site_name ); ?>">
				<?php elseif ( $show_title ) : ?>
					<span class="dxp-brand-name"><?php echo esc_html( $site_name ); ?></span>
				<?php endif; ?>

				<?php
				/* Slogan (panelden açılıp kapanır) — logonun/başlığın yanında, ince çizgiyle ayrılır. */
				$tagline_text = get_bloginfo( 'description' );
				if ( '1' === devxpe_theme_get( 'show_site_tagline', '1' ) && '' !== trim( (string) $tagline_text ) ) :
					?>
					<span class="dxp-brand-tagline"><?php echo esc_html( $tagline_text ); ?></span>
				<?php endif; ?>
			</a>

			<?php if ( 'left' === $burger_pos ) : ?>
				<?php echo $burger_btn; // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<?php endif; ?>

			<!-- Masaüstü menü -->
			<div class="dxp-nav-wrap">
				<nav class="dxp-nav" aria-label="<?php esc_attr_e( 'Ana Menü', 'devxpe-theme' ); ?>">
					<?php
					if ( has_nav_menu( 'primary' ) ) {
						wp_nav_menu(
							array(
								'theme_location' => 'primary',
								'container'      => false,
								'menu_class'     => 'dxp-nav-list',
								'depth'          => 2,
								'fallback_cb'    => false,
							)
						);
					}
					?>
				</nav>
			</div>

			<!-- Aksiyonlar -->
			<div class="dxp-actions">
				<?php if ( $phone ) : ?>
				<a href="<?php echo esc_url( $phone_href ); ?>" class="dxp-pill dxp-pill--phone">
					<?php echo $icon_phone; // phpcs:ignore WordPress.Security.EscapeOutput ?>
					<span><?php echo esc_html( $phone ); ?></span>
				</a>
				<?php endif; ?>

				<?php if ( $quote_on ) : ?>
				<a href="<?php echo esc_url( $quote_url ); ?>" class="dxp-pill dxp-pill--quote">
					<?php echo esc_html( $quote_text ); ?>
				</a>
				<?php endif; ?>

				<?php if ( $phone ) : ?>
				<a href="<?php echo esc_url( $phone_href ); ?>" class="dxp-icon-btn dxp-icon-btn--phone" aria-label="<?php esc_attr_e( 'Bizi arayın', 'devxpe-theme' ); ?>">
					<?php echo $icon_phone; // phpcs:ignore WordPress.Security.EscapeOutput ?>
				</a>
				<?php endif; ?>

				<?php if ( 'right' === $burger_pos ) : ?>
					<?php echo $burger_btn; // phpcs:ignore WordPress.Security.EscapeOutput ?>
				<?php endif; ?>
			</div>

		</div>
	</div>

</header>

<?php
/*
 * Mobil menü — panelden seçilen "Açılış Efekti (Stili)".
 */
$dxp_menu_style = (string) devxpe_theme_get( 'mobile_menu_style', 'dropdown' );
if ( ! in_array( $dxp_menu_style, array( 'dropdown', 'offcanvas_left', 'offcanvas_right', 'modal_center' ), true ) ) {
	$dxp_menu_style = 'dropdown';
}
$dxp_menu_overlay = ( 'dropdown' !== $dxp_menu_style );
$dxp_menu_logo    = devxpe_theme_get( 'mobile_logo' );
if ( ! $dxp_menu_logo ) {
	$dxp_menu_logo = $logo_url;
}
?>

<?php if ( $dxp_menu_overlay ) : ?>
<div class="dxp-mobile-overlay" id="dxp-menu-overlay" aria-hidden="true"></div>
<?php endif; ?>

<nav class="dxp-mobile-menu dxp-mobile-menu--<?php echo esc_attr( $dxp_menu_style ); ?>" id="dxp-mobile-nav"
	data-style="<?php echo esc_attr( $dxp_menu_style ); ?>" aria-label="<?php esc_attr_e( 'Mobil Menü', 'devxpe-theme' ); ?>">

	<button type="button" class="dxp-mobile-close" id="dxp-burger-close" aria-label="<?php esc_attr_e( 'Kapat', 'devxpe-theme' ); ?>">
		<?php echo $icon_close; // phpcs:ignore WordPress.Security.EscapeOutput ?>
	</button>

	<?php if ( $dxp_menu_logo ) : ?>
	<img class="dxp-mobile-logo" src="<?php echo esc_url( $dxp_menu_logo ); ?>" alt="<?php echo esc_attr( $site_name ); ?>">
	<?php endif; ?>

	<?php
	if ( has_nav_menu( 'primary' ) ) {
		wp_nav_menu(
			array(
				'theme_location' => 'primary',
				'container'      => false,
				'menu_class'     => 'dxp-mobile-list',
				'depth'          => 2,
				'fallback_cb'    => false,
			)
		);
	}
	?>

	<?php if ( $quote_on ) : ?>
	<a class="dxp-mobile-cta" href="<?php echo esc_url( $quote_url ); ?>"><?php echo esc_html( $quote_text ); ?></a>
	<?php endif; ?>
</nav>

<?php do_action( 'devxpe_after_header' ); ?>

<main class="dxp-main flex-grow-1">


<?php devxpe_render_ad( 'header_ad' ); ?>

<?php /* Kırıntı menü: tekil içerik/sayfalarda bölüm arkaplanını paylaşması için şablon içinde çizilir. */ ?>
<?php if ( '1' === devxpe_theme_get( 'breadcrumb_enabled', '1' ) && ! is_front_page() && ! is_singular() && ! is_404() ) : ?>
<div class="dxp-crumbs-outer">
	<div class="dxp-detail-inner">
		<?php get_template_part( 'template-parts/breadcrumbs' ); ?>
	</div>
</div>
<?php endif; ?>

<!-- İçerik başlangıcı (footer.php'de kapatılır) -->
<div id="content" class="site-content">

<?php do_action( 'devxpe_content_top' ); ?>
