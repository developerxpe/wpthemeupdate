<?php
/**
 * Tekli içerik şablonu — yazılar ve panelden tanımlı içerik tipleri (CPT).
 *
 * Ön yüz yalnızca içerik düzenleyicideki "İçerik Düzeni" widget'larından çizilir.
 * Widget eklenmemişse hiçbir bölüm çizilmez; Şablon 1 / Şablon 2 yalnızca
 * yerleşimi belirler, içeriği değil:
 *
 *   Manşet (kırıntı + manşet widget'ı)
 *   ├─ Şablon 1: sol kolon + sağ sticky form
 *   └─ Şablon 2: tam genişlik bantlar
 *
 * Demo ve eski sürümle oluşturulmuş içeriklerde widget listesi yoksa
 * DEVXPE_Page_Widgets::cizim_listesi() onu eski meta alanlarından türetir.
 *
 * Teklif formu kapalıysa düzen tek sütuna düşer.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

while ( have_posts() ) :
	the_post();

	$dxp_type = get_post_type();
	$dxp_pid  = get_the_ID();

	/* Şablon (global düzen): içerik > içerik tipi varsayılanı > Şablon 1. */
	$dxp_raw_tpl = (string) get_post_meta( $dxp_pid, '_dxp_template', true );

	if ( '' === $dxp_raw_tpl ) {
		foreach ( devxpe_custom_post_types() as $dxp_cpt ) {
			if ( isset( $dxp_cpt['slug'], $dxp_cpt['template'] ) && $dxp_cpt['slug'] === $dxp_type ) {
				$dxp_raw_tpl = (string) $dxp_cpt['template'];
				break;
			}
		}
	}

	$dxp_tpl    = devxpe_normalize_template( $dxp_raw_tpl );
	$dxp_banded = devxpe_template_is_banded( $dxp_tpl );

	/* Widget listesi: liste yoksa hiçbir bölüm çizilmez (varsayılan dizilim yok). */
	$dxp_w_list = class_exists( 'DEVXPE_Page_Widgets' ) ? DEVXPE_Page_Widgets::cizim_listesi( $dxp_pid ) : array();

	/* Manşet ve teklif formu widget'ları ayrı işlenir. */
	$dxp_hero_w  = null;
	$dxp_quote_w = null;

	foreach ( $dxp_w_list as $dxp_w ) {
		$dxp_tip = isset( $dxp_w['tip'] ) ? sanitize_key( $dxp_w['tip'] ) : '';
		if ( 'cpt_hero' === $dxp_tip && null === $dxp_hero_w ) {
			$dxp_hero_w = $dxp_w;
		}
		if ( 'cpt_quote' === $dxp_tip && null === $dxp_quote_w ) {
			$dxp_quote_w = $dxp_w;
		}
	}

	/* Teklif yerleşimi: widget var + bölüm açık + form alanları dolu. */
	$dxp_quote_args = devxpe_quote_form_args();
	$dxp_quote_on   = ( null !== $dxp_quote_w )
		&& devxpe_cpt_section_visible( $dxp_type, 'quote' )
		&& ! empty( $dxp_quote_args['groups'] );

	/* Widget tipi → bant zemin anahtarı eşlemesi. */
	$dxp_band_key = array(
		'cpt_content'  => 'content',
		'cpt_includes' => 'includes',
		'cpt_projects' => 'projects',
		'cpt_services' => 'services',
		'cpt_faq'      => 'faq',
		'cpt_related'  => 'related',
	);

	$dxp_band_bg = array(
		'content'  => 'white',
		'includes' => 'white',
		'projects' => 'paper',
		'services' => 'white',
		'faq'      => 'paper',
		'related'  => 'white',
	);

	/* Manşet: widget var ve bölüm açıksa çizilir; yoksa başlık yalnızca ekran okuyucuya kalır. */
	$dxp_hero_show = ( null !== $dxp_hero_w ) && devxpe_cpt_section_visible( $dxp_type, 'hero' );

	/*
	 * ── Bölümler: widget listesinden ──
	 *
	 * Her bölümün HTML'i (bant sarmalayıcısı dâhil, aynı sınıflarla)
	 * toplanır ve ortak gruplama adımına (govde_sar) verilir. Böylece CPT
	 * bölümleri sayfa widget'larıyla AYNI full/nested davranışını paylaşır.
	 */
	$dxp_parcalar = array();

	foreach ( $dxp_w_list as $dxp_w ) :

		$dxp_w_tip = isset( $dxp_w['tip'] ) ? sanitize_key( $dxp_w['tip'] ) : '';
		if ( '' === $dxp_w_tip || 'cpt_hero' === $dxp_w_tip || 'cpt_quote' === $dxp_w_tip ) {
			continue;
		}

		$dxp_w_html = trim( (string) DEVXPE_Page_Widgets::ciz( $dxp_w ) );
		if ( '' === $dxp_w_html ) {
			continue;
		}

		if ( $dxp_banded ) {
			$dxp_key    = isset( $dxp_band_key[ $dxp_w_tip ] ) ? $dxp_band_key[ $dxp_w_tip ] : 'content';
			$dxp_bg     = isset( $dxp_band_bg[ $dxp_key ] ) ? $dxp_band_bg[ $dxp_key ] : 'white';
			$dxp_w_html = '<section class="dxp-band dxp-band--' . esc_attr( $dxp_bg ) . ' dxp-band--' . esc_attr( $dxp_key ) . '"><div class="dxp-band-inner">' . $dxp_w_html . '</div></section>';
		}

		$dxp_parcalar[] = array(
			'html' => $dxp_w_html,
			'yer'  => DEVXPE_Page_Widgets::yer( $dxp_w ),
		);

	endforeach;

	$dxp_govde = DEVXPE_Page_Widgets::govde_sar( $dxp_pid, $dxp_parcalar );

	/* Şablon 1 ızgarası yalnızca içerik ya da teklif formu varsa açılır; boş kutu çizilmez. */
	$dxp_grid = ! $dxp_banded && ( '' !== trim( $dxp_govde ) || $dxp_quote_on );
	?>
	<div class="dxp-single<?php echo $dxp_banded ? ' dxp-single--banded' : ' dxp-single--split'; ?>">
	<?php
	/*
	 * Kırıntı menü, manşet/banner ile AYNI açık yeşil zemini paylaşır
	 * (--brand-paper). Böylece split ve banded şablonlarında aynı görünür;
	 * arşiv/arama/kırıntıları da aynı .dxp-crumbs-outer sarmalayıcısını kullanır.
	 */
	?>
	<?php if ( '1' === devxpe_theme_get( 'breadcrumb_enabled', '1' ) ) : ?>
	<div class="dxp-crumbs-outer">
		<div class="dxp-detail-inner"><?php get_template_part( 'template-parts/breadcrumbs' ); ?></div>
	</div>
	<?php endif; ?>
	<?php if ( $dxp_hero_show ) : ?>
	<div class="dxp-detail-hero<?php echo $dxp_banded ? ' dxp-detail-hero--area' : ''; ?>">
		<?php echo DEVXPE_Page_Widgets::ciz( $dxp_hero_w ); // phpcs:ignore WordPress.Security.EscapeOutput -- ciz() kendi kaçışını yapar ?>
	</div>
	<?php else : ?>
	<h1 class="dxp-sr-only"><?php the_title(); ?></h1>
	<?php endif; ?>
	<?php
	/* ── Şablon 1: iki sütun (sol içerik + sağ sticky teklif formu) ── */
	if ( $dxp_grid ) {
		echo '<div class="dxp-detail-grid' . ( $dxp_quote_on ? '' : ' dxp-detail-grid--solo' ) . '"><div class="dxp-detail-main">';
	}

	echo $dxp_govde; // phpcs:ignore WordPress.Security.EscapeOutput -- govde_sar() kendi çıktısını üretir

	/* ── Teklif formu: Şablon 2'de bant, Şablon 1'de sağ sticky sütun ── */
	if ( $dxp_banded && $dxp_quote_on ) {

		echo DEVXPE_Page_Widgets::ciz( $dxp_quote_w ); // phpcs:ignore WordPress.Security.EscapeOutput

	} elseif ( $dxp_grid && $dxp_quote_on ) {

		echo '</div><aside class="dxp-detail-aside">';
		echo DEVXPE_Page_Widgets::ciz( $dxp_quote_w ); // phpcs:ignore WordPress.Security.EscapeOutput
		echo '</aside></div>';

	} elseif ( $dxp_grid ) {

		/* Tek sütun: ızgarayı kapat. */
		echo '</div></div>';
	}

	echo '</div>'; // .dxp-single

endwhile;

get_footer();
