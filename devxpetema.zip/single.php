<?php
/**
 * Tekli içerik şablonu — yazılar ve panelden tanımlı içerik tipleri (CPT).
 *
 * ARC hizmet/bölge detay düzeni tek kaynaktan, widget çıktısından kurulur:
 *   Manşet (kırıntı + manşet widget'ı)
 *   ├─ Şablon 1: sol kolon + sağ sticky form
 *   └─ Şablon 2: tam genişlik bantlar
 *
 * Düzen içerik bazında kaydedilmiş "Sayfa İçeriği" widget'larından gelir
 * (bkz. DEVXPE_Page_Widgets). Meta boşsa varsayılan ARC dizilimi yalnızca
 * render anında üretilir; sayfaya YAZILMAZ.
 *
 * Hangi bölümün gösterileceği içerik düzenleyicideki "Sayfa İçeriği"
 * widget'larından yönetilir. Teklif formu kapalıysa düzen tek sütuna düşer.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

while ( have_posts() ) :
	the_post();

	$dxp_type = get_post_type();
	$dxp_pid  = get_the_ID();

	/* Şablon (global düzen): içerik > içerik tipi varsayılanı > Şablon 1. */
	$dxp_raw_tpl = (string) get_post_meta( $dxp_pid, '_dxp_template', true );

	if ( '' === $dxp_raw_tpl ) {
		foreach ( devxpe_custom_post_types() as $dxp_cpt ) {
			if ( isset( $dxp_cpt['slug'], $dxp_cpt['template'] ) && $dxp_cpt['slug'] === $dxp_type ) {
				$dxp_raw_tpl = (string) $dxp_cpt['template'];
				break;
			}
		}
	}

	$dxp_tpl    = devxpe_normalize_template( $dxp_raw_tpl );
	$dxp_banded = devxpe_template_is_banded( $dxp_tpl );

	/*
	 * Widget listesi: kayıtlı liste varsa o kullanılır. Meta boşsa
	 * varsayılan ARC dizilimi render anında kurulur; meta'ya yazılmaz
	 * (cikti() ile aynı davranış).
	 */
	$dxp_w_list    = array();
	$dxp_meta_modu = false;

	if ( class_exists( 'DEVXPE_Page_Widgets' ) ) {
		$dxp_w_list    = DEVXPE_Page_Widgets::veri( $dxp_pid );
		$dxp_meta_modu = ! empty( $dxp_w_list );

		if ( ! $dxp_meta_modu ) {
			$dxp_baglam = DEVXPE_Page_Widgets::baglam_bul( $dxp_pid );
			foreach ( DEVXPE_Page_Widgets::varsayilan_dizilim( $dxp_baglam ) as $dxp_tip ) {
				$dxp_w_list[] = array(
					'tip'  => $dxp_tip,
					'ayar' => DEVXPE_Page_Widgets::varsayilan( $dxp_tip ),
				);
			}
		}
	}

	/* Manşet ve teklif formu widget'ları ayrı işlenir. */
	$dxp_hero_w  = null;
	$dxp_quote_w = null;

	foreach ( $dxp_w_list as $dxp_w ) {
		$dxp_tip = isset( $dxp_w['tip'] ) ? sanitize_key( $dxp_w['tip'] ) : '';
		if ( 'cpt_hero' === $dxp_tip && null === $dxp_hero_w ) {
			$dxp_hero_w = $dxp_w;
		}
		if ( 'cpt_quote' === $dxp_tip && null === $dxp_quote_w ) {
			$dxp_quote_w = $dxp_w;
		}
	}

	/* Teklif yerleşimi: widget var + bölüm açık + form alanları dolu. */
	$dxp_quote_args = devxpe_quote_form_args();
	$dxp_quote_on   = ( null !== $dxp_quote_w )
		&& devxpe_cpt_section_visible( $dxp_type, 'quote' )
		&& ! empty( $dxp_quote_args['groups'] );

	/* Widget tipi → bant zemin anahtarı eşlemesi. */
	$dxp_band_key = array(
		'cpt_content'  => 'content',
		'cpt_includes' => 'includes',
		'cpt_projects' => 'projects',
		'cpt_services' => 'services',
		'cpt_faq'      => 'faq',
		'cpt_related'  => 'related',
	);

	$dxp_band_bg = array(
		'content'  => 'white',
		'includes' => 'white',
		'projects' => 'paper',
		'services' => 'white',
		'faq'      => 'paper',
		'related'  => 'white',
	);

	/* Manşet: kırıntı menü her zaman çizilir; hero içeriği bölüm açıksa. */
	$dxp_hero_on = devxpe_cpt_section_visible( $dxp_type, 'hero' );
	?>
	<div class="dxp-single<?php echo $dxp_banded ? ' dxp-single--banded' : ' dxp-single--split'; ?>">
	<div class="dxp-detail-hero<?php echo $dxp_banded ? ' dxp-detail-hero--area' : ''; ?>">
		<div class="dxp-detail-inner"><?php get_template_part( 'template-parts/breadcrumbs' ); ?></div>
		<?php
		if ( $dxp_hero_on ) {
			if ( $dxp_hero_w ) {
				echo DEVXPE_Page_Widgets::ciz( $dxp_hero_w ); // phpcs:ignore WordPress.Security.EscapeOutput -- ciz() kendi kaçışını yapar
			} else {
				get_template_part( 'template-parts/single-hero', null, array( 'banded' => $dxp_banded ) );
			}
		} else {
			/* Manşet kapalı olsa da sayfada tek H1 bulunsun (erişilebilirlik). */
			?>
			<div class="dxp-detail-inner">
				<h1 class="dxp-detail-title"><?php the_title(); ?></h1>
			</div>
			<?php
		}
		?>
	</div>
	<?php

	/* ── Şablon 1: iki sütun (sol içerik + sağ sticky teklif formu) ── */
	if ( ! $dxp_banded ) {
		echo '<div class="dxp-detail-grid' . ( $dxp_quote_on ? '' : ' dxp-detail-grid--solo' ) . '"><div class="dxp-detail-main">';
	}

	/*
	 * ── Bölümler: kayıtlı ya da varsayılan widget listesinden ──
	 *
	 * Her bölümün HTML'i (bant sarmalayıcısı dâhil, aynı sınıflarla)
	 * toplanır ve ortak gruplama adımına (govde_sar) verilir. Böylece CPT
	 * bölümleri sayfa widget'larıyla AYNI full/nested davranışını paylaşır:
	 * full düzende çıktı eskisiyle yapısal olarak birebir aynıdır, nested
	 * düzende ise yer ('sol'/'sag'/'tam') etkili olur.
	 */
	$dxp_parcalar = array();

	foreach ( $dxp_w_list as $dxp_w ) :

		$dxp_w_tip = isset( $dxp_w['tip'] ) ? sanitize_key( $dxp_w['tip'] ) : '';
		if ( '' === $dxp_w_tip || 'cpt_hero' === $dxp_w_tip || 'cpt_quote' === $dxp_w_tip ) {
			continue;
		}

		/*
		 * Meta boşken varsayılan dizilim kullanılır; bölüm iskeletindeki
		 * aç/kapa ayarı burada uygulanır. Kayıtlı widget listesinde
		 * kullanıcının seçimi geçerlidir.
		 */
		if ( ! $dxp_meta_modu ) {
			$dxp_section = ( 0 === strpos( $dxp_w_tip, 'cpt_' ) ) ? substr( $dxp_w_tip, 4 ) : '';
			if ( '' !== $dxp_section && ! devxpe_cpt_section_visible( $dxp_type, $dxp_section ) ) {
				continue;
			}
		}

		$dxp_w_html = trim( (string) DEVXPE_Page_Widgets::ciz( $dxp_w ) );
		if ( '' === $dxp_w_html ) {
			continue;
		}

		if ( $dxp_banded ) {
			$dxp_key    = isset( $dxp_band_key[ $dxp_w_tip ] ) ? $dxp_band_key[ $dxp_w_tip ] : 'content';
			$dxp_bg     = isset( $dxp_band_bg[ $dxp_key ] ) ? $dxp_band_bg[ $dxp_key ] : 'white';
			$dxp_w_html = '<section class="dxp-band dxp-band--' . esc_attr( $dxp_bg ) . ' dxp-band--' . esc_attr( $dxp_key ) . '"><div class="dxp-band-inner">' . $dxp_w_html . '</div></section>';
		}

		$dxp_parcalar[] = array(
			'html' => $dxp_w_html,
			'yer'  => DEVXPE_Page_Widgets::yer( $dxp_w ),
		);

	endforeach;

	echo DEVXPE_Page_Widgets::govde_sar( $dxp_pid, $dxp_parcalar ); // phpcs:ignore WordPress.Security.EscapeOutput

	/* ── Teklif formu: Şablon 2'de bant, Şablon 1'de sağ sticky sütun ── */
	if ( $dxp_banded && $dxp_quote_on ) {

		echo DEVXPE_Page_Widgets::ciz( $dxp_quote_w ); // phpcs:ignore WordPress.Security.EscapeOutput

	} elseif ( ! $dxp_banded && $dxp_quote_on ) {

		echo '</div><aside class="dxp-detail-aside">';
		echo DEVXPE_Page_Widgets::ciz( $dxp_quote_w ); // phpcs:ignore WordPress.Security.EscapeOutput
		echo '</aside></div>';

	} elseif ( ! $dxp_banded ) {

		/* Tek sütun: ızgarayı kapat. */
		echo '</div></div>';
	}

	echo '</div>'; // .dxp-single

endwhile;

get_footer();
