<?php
/**
 * Form alanları, teklif formu adımları ve gizlilik/onay metinleri.
 *
 * functions.php'den ayrıldı.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * İletişim formunun varsayılan alan listesi.
 *
 * Panelde "Alan Ekle" ile değiştirilebilir; boş bırakılırsa bu liste kullanılır.
 *
 * @return array
 */
function devxpe_contact_default_fields() {
	return array(
		array( 'type' => 'input', 'label' => __( 'Ad', 'devxpe-theme' ), 'key' => 'ad', 'required' => '1', 'width' => 'half', 'placeholder' => '', 'options' => '' ),
		array( 'type' => 'input', 'label' => __( 'Soyad', 'devxpe-theme' ), 'key' => 'soyad', 'required' => '0', 'width' => 'half', 'placeholder' => '', 'options' => '' ),
		array( 'type' => 'tel', 'label' => __( 'Telefon', 'devxpe-theme' ), 'key' => 'telefon', 'required' => '0', 'width' => 'half', 'placeholder' => '', 'options' => '' ),
		array( 'type' => 'email', 'label' => __( 'E-posta', 'devxpe-theme' ), 'key' => 'eposta', 'required' => '0', 'width' => 'half', 'placeholder' => '', 'options' => '' ),
		array( 'type' => 'textarea', 'label' => __( 'Mesajınız', 'devxpe-theme' ), 'key' => 'mesaj', 'required' => '1', 'width' => 'full', 'placeholder' => '', 'options' => '' ),
		array( 'type' => 'file', 'label' => __( 'Dosya', 'devxpe-theme' ), 'key' => 'dosya', 'required' => '0', 'width' => 'full', 'placeholder' => '', 'options' => '' ),
	);
}

/**
 * Panelde tanımlı formları (slug => ad/buton) döndürür.
 *
 * Hiç form yoksa varsayılan "iletisim" formu döner.
 *
 * @return array
 */
function devxpe_custom_forms() {
	$forms = devxpe_theme_get( 'custom_forms' );
	$out   = array();

	if ( is_array( $forms ) ) {
		foreach ( $forms as $f ) {
			if ( ! is_array( $f ) || empty( $f['slug'] ) ) {
				continue;
			}
			$slug = sanitize_key( $f['slug'] );
			if ( '' === $slug ) {
				continue;
			}
			$out[ $slug ] = array(
				'name' => ! empty( $f['name'] ) ? $f['name'] : ucfirst( $slug ),
				'btn'  => isset( $f['btn'] ) ? $f['btn'] : '',
			);
		}
	}

	if ( ! $out ) {
		$out['iletisim'] = array(
			'name' => __( 'İletişim Formu', 'devxpe-theme' ),
			'btn'  => __( 'Mesaj Gönder', 'devxpe-theme' ),
		);
	}

	return $out;
}

/**
 * Oluşturucuda düzenlenen aktif formun slug'ı.
 *
 * @return string
 */
function devxpe_active_form_slug() {
	$forms = devxpe_custom_forms();

	return (string) array_key_first( $forms );
}

/**
 * Bir formun alan satırlarını döndürür (yoksa varsayılanlar).
 *
 * @param string $slug Form slug'ı.
 * @return array
 */
function devxpe_form_fields( $slug ) {
	$slug = sanitize_key( $slug );
	$rows = devxpe_theme_get( 'form_builder_' . $slug );

	if ( ! is_array( $rows ) || ! $rows ) {
		$rows = devxpe_contact_default_fields();
	}

	return $rows;
}

/**
 * Form seçim listesi: 4 adımlı teklif formu + panelde tanımlı formlar.
 *
 * @return array value => label
 */
function devxpe_form_choice_options() {
	$opts = array( 'quote' => __( '4 Adımlı Teklif Formu', 'devxpe-theme' ) );

	foreach ( devxpe_custom_forms() as $slug => $f ) {
		$opts[ $slug ] = $f['name'];
	}

	return $opts;
}

/**
 * Gizlilik politikası sayfasının adresi.
 *
 * Önce tema panelindeki "Yasal Sayfalar" listesi (footer'daki gizlilik
 * linkiyle aynı sayfa kullanılsın), yoksa WordPress'in gizlilik
 * politikası ayarı kullanılır.
 *
 * @return string URL veya ''.
 */
function devxpe_privacy_url() {
	/* Panelden elle verilen link her şeyden önceliklidir. */
	$ozel = trim( (string) devxpe_theme_get( 'privacy_url', '' ) );

	if ( '' !== $ozel ) {
		return $ozel;
	}

	foreach ( (array) devxpe_theme_get( 'footer_legal_pages', array() ) as $dxp_pid ) {
		$dxp_slug = (string) get_post_field( 'post_name', (int) $dxp_pid );

		if ( false !== strpos( $dxp_slug, 'gizlilik' ) || false !== strpos( $dxp_slug, 'privacy' ) ) {
			return (string) get_permalink( (int) $dxp_pid );
		}
	}

	return function_exists( 'get_privacy_policy_url' ) ? (string) get_privacy_policy_url() : '';
}

/**
 * Gizlilik politikası bağlantısının yazısı (tema diline göre).
 *
 * @return string
 */
function devxpe_privacy_label() {
	$lang = class_exists( 'DEVXPE_Theme_Language' ) ? DEVXPE_Theme_Language::selected() : 'auto';

	if ( 'auto' === $lang ) {
		$lang = ( 0 === strpos( (string) get_locale(), 'tr' ) ) ? 'tr_TR' : 'en_US';
	}

	return ( 'tr_TR' === $lang ) ? 'Gizlilik Politikası' : 'Privacy Policy';
}

/**
 * Onay metnini gizlilik politikası bağlantısıyla birlikte döndürür.
 *
 * Metinde `{privacy}` yer tutucusu varsa, yoksa bilinen TR/EN ifade
 * ("gizlilik politikası" / "privacy policy") varsa bağlantıya çevrilir;
 * hiçbiri yoksa bağlantı metnin sonuna eklenir. Dönüş değeri HTML'dir.
 *
 * @param string $metin Onay metni (panel ayarı).
 * @return string
 */
function devxpe_consent_metni( $metin ) {
	$metin = (string) $metin;

	if ( '' === trim( $metin ) ) {
		return '';
	}

	$url = devxpe_privacy_url();

	if ( '' === $url ) {
		return esc_html( $metin );
	}

	$link = '<a class="dxp-consent-link" href="' . esc_url( $url ) . '" target="_blank" rel="noopener nofollow">' . esc_html( devxpe_privacy_label() ) . '</a>';

	$guvenli = esc_html( $metin );

	/* 1) Yer tutucu: yeni metinler için önerilen yol. */
	if ( false !== strpos( $metin, '{privacy}' ) ) {
		return str_replace( '{privacy}', $link, $guvenli );
	}

	/* 2) Bilinen ifadeler: mevcut kayıtlar da otomatik bağlanır. */
	$ifadeler = array(
		'Gizlilik Politikasını',
		'Gizlilik Politikası',
		'gizlilik politikasını',
		'gizlilik politikası',
		'Privacy Policy',
		'privacy policy',
	);

	foreach ( $ifadeler as $ifade ) {
		if ( false !== strpos( $metin, $ifade ) ) {
			return str_replace( esc_html( $ifade ), $link, $guvenli );
		}
	}

	/* 3) İfade bulunamadıysa bağlantıyı sona ekle. */
	return $guvenli . ' ' . $link;
}

/**
 * Seçilen formu (teklif formu veya özel form) çizer.
 *
 * @param string $choice Form kimliği ('quote' → teklif formu).
 * @param bool   $bare   true ise yalnızca form gövdesi çizilir.
 * @return void
 */
function devxpe_render_form_choice( $choice, $bare = false ) {
	$choice = (string) $choice;

	if ( '' === $choice || 'quote' === $choice ) {
		$args = devxpe_quote_form_args();
		if ( $bare ) {
			/* Sarma (bölüm manşeti/zemini) olmadan yalnız form gövdesi. */
			$args['variant'] = 'bare';
		}
		if ( ! empty( $args['groups'] ) ) {
			get_template_part( 'template-parts/quote-form', null, $args );
		}
		return;
	}

	if ( isset( devxpe_custom_forms()[ $choice ] ) ) {
		get_template_part( 'template-parts/contact-form', null, array( 'slug' => $choice ) );
	}
}

/**
 * Teklif formu şablonuna geçirilecek argümanları üretir.
 *
 * @return array
 */
function devxpe_quote_form_args() {
	$groups = array();

	foreach ( (array) devxpe_theme_get( 'form_services' ) as $row ) {
		if ( ! is_array( $row ) || empty( $row['title'] ) ) {
			continue;
		}
		$options = devxpe_lines( $row['text'] );
		if ( ! $options ) {
			continue;
		}
		$groups[] = array(
			'title'   => $row['title'],
			'options' => array_values( $options ),
		);
	}

	return array(
		'variant'       => 'full',
		'groups'        => $groups,
		'eyebrow'       => devxpe_theme_get( 'form_eyebrow' ),
		'title'         => devxpe_theme_get( 'form_title' ),
		'subtitle'      => devxpe_theme_get( 'form_subtitle' ),
		'benefits'      => devxpe_lines( devxpe_theme_get( 'form_benefits' ) ),
		'phone'         => devxpe_theme_get( 'phone' ),
		'phone_text'    => devxpe_theme_get( 'form_phone_text' ),
		'note'          => devxpe_theme_get( 'form_note' ),
		'steps'         => array(
			devxpe_theme_get( 'form_step1_title', __( 'Hizmet', 'devxpe-theme' ) ),
			devxpe_theme_get( 'form_step2_title', __( 'Projeniz', 'devxpe-theme' ) ),
			devxpe_theme_get( 'form_step3_title', __( 'Bilgileriniz', 'devxpe-theme' ) ),
			devxpe_theme_get( 'form_step4_title', __( 'Gözden geçir ve gönder', 'devxpe-theme' ) ),
		),
		'mini_title'    => devxpe_theme_get( 'form_mini_title' ),
		'mini_subtitle' => devxpe_theme_get( 'form_mini_subtitle' ),
	);
}

/**
 * Teklif formu bütçe alanının hazır TL seçenek listesini döndürür.
 *
 * @return string Virgülle ayrılmış seçenekler.
 */
function devxpe_quote_budget_options() {
	/*
	 * `options` alanı virgülle ayrılmış tek satır bekler (devxpe_lines ile
	 * bölünür). Bu yüzden seçenek metinlerinde virgül KULLANILMAZ.
	 */
	return implode( ', ', array(
		__( '25.000 ₺ altı', 'devxpe-theme' ),
		__( '25.000 - 50.000 ₺', 'devxpe-theme' ),
		__( '50.000 - 100.000 ₺', 'devxpe-theme' ),
		__( '100.000 - 250.000 ₺', 'devxpe-theme' ),
		__( '250.000 ₺ üzeri', 'devxpe-theme' ),
		__( 'Henüz emin değilim', 'devxpe-theme' ),
	) );
}

/**
 * Form alanı oluşturucuda "Hazır şablon" için ön tanımlı seçenek setleri.
 *
 * Değerler, panelde alanın "Seçenekler" kutusuna yazılacak virgülle ayrılmış
 * metinlerdir (virgülsüz seçenekler). Müşteri elle yazmak yerine seçebilsin.
 *
 * @return array Kalıp anahtarı => seçenek metni.
 */
function devxpe_form_field_templates() {
	return array(
		'budget'    => devxpe_quote_budget_options(),
		'reply_by'  => implode( ', ', array(
			__( 'Telefon araması', 'devxpe-theme' ),
			__( 'E-posta', 'devxpe-theme' ),
			__( 'WhatsApp', 'devxpe-theme' ),
			__( 'Kısa mesaj', 'devxpe-theme' ),
		) ),
		'reach_time' => implode( ', ', array(
			__( 'Fark etmez', 'devxpe-theme' ),
			__( 'Sabah', 'devxpe-theme' ),
			__( 'Öğleden sonra', 'devxpe-theme' ),
			__( 'Akşam', 'devxpe-theme' ),
		) ),
		'urgency'   => implode( ', ', array(
			__( 'Acil - en kısa sürede', 'devxpe-theme' ),
			__( '1 - 2 hafta içinde', 'devxpe-theme' ),
			__( '1 ay içinde', 'devxpe-theme' ),
			__( 'Tarih esnek', 'devxpe-theme' ),
		) ),
	);
}

/**
 * Teklif formu "Proje" adımının varsayılan alanları (referans tasarım).
 *
 * @return array
 */
function devxpe_quote_project_default_fields() {
	return array(
		array(
			'type'        => 'input',
			'label'       => __( 'Yaklaşık proje büyüklüğü', 'devxpe-theme' ),
			'key'         => 'size',
			'required'    => '0',
			'width'       => 'full',
			'placeholder' => __( 'Örn. 20 metrekare veya 15 metre uzunluk', 'devxpe-theme' ),
			'help'        => __( 'Kaba bir ölçü yeterli - alanın boyutları ya da kaplanacak alan.', 'devxpe-theme' ),
			'options'     => '',
		),
		array(
			'type'        => 'select',
			'label'       => __( 'Yaklaşık bütçe', 'devxpe-theme' ),
			'key'         => 'budget',
			'required'    => '0',
			'width'       => 'full',
			'placeholder' => __( 'Bir aralık seçin', 'devxpe-theme' ),
			'help'        => __( 'Bu yalnızca uygun malzemeyi belirlememize yardımcı olur. Fiyatınızı belirlemez - fiyat yazılı teklifte netleşir.', 'devxpe-theme' ),
			'options'     => devxpe_quote_budget_options(),
		),
		array(
			'type'        => 'date',
			'label'       => __( 'Tercih edilen başlangıç tarihi (opsiyonel)', 'devxpe-theme' ),
			'key'         => 'start',
			'required'    => '0',
			'width'       => 'full',
			'placeholder' => '',
			'help'        => '',
			'options'     => '',
		),
		array(
			'type'        => 'file',
			'label'       => __( 'Fotoğraflar (opsiyonel)', 'devxpe-theme' ),
			'key'         => 'photos',
			'required'    => '0',
			'width'       => 'full',
			'placeholder' => __( 'Alanın fotoğrafını yükleyin', 'devxpe-theme' ),
			'help'        => __( 'Mevcut durumun fotoğrafı teklifi ciddi biçimde hızlandırır.', 'devxpe-theme' ),
			'options'     => '',
		),
		array(
			'type'        => 'textarea',
			'label'       => __( 'Ek detaylar (opsiyonel)', 'devxpe-theme' ),
			'key'         => 'details',
			'required'    => '0',
			'width'       => 'full',
			'placeholder' => __( 'Erişim, kot farkı, beğendiğiniz malzemeler, bilmemiz gereken her şey', 'devxpe-theme' ),
			'help'        => '',
			'options'     => '',
		),
	);
}

/**
 * Teklif formu "İletişim" adımının varsayılan alanları (referans tasarım).
 *
 * @return array
 */
function devxpe_quote_contact_default_fields() {
	return array(
		array(
			'type'        => 'input',
			'label'       => __( 'Ad Soyad', 'devxpe-theme' ),
			'key'         => 'name',
			'required'    => '1',
			'width'       => 'full',
			'placeholder' => '',
			'help'        => '',
			'options'     => '',
		),
		array(
			'type'        => 'tel',
			'label'       => __( 'Telefon numarası', 'devxpe-theme' ),
			'key'         => 'phone',
			'required'    => '1',
			'width'       => 'full',
			'placeholder' => '',
			'help'        => '',
			'options'     => '',
		),
		array(
			'type'        => 'email',
			'label'       => __( 'E-posta', 'devxpe-theme' ),
			'key'         => 'email',
			'required'    => '1',
			'width'       => 'full',
			'placeholder' => '',
			'help'        => '',
			'options'     => '',
		),
		array(
			'type'        => 'input',
			'label'       => __( 'İş adresi veya posta kodu', 'devxpe-theme' ),
			'key'         => 'address',
			'required'    => '0',
			'width'       => 'full',
			'placeholder' => '',
			'help'        => __( 'Bu bilgiyi işin hizmet bölgemizde olduğunu doğrulamak için kullanırız.', 'devxpe-theme' ),
			'options'     => '',
		),
		array(
			'type'        => 'select',
			'label'       => __( 'Nasıl yanıt verelim?', 'devxpe-theme' ),
			'key'         => 'reply_by',
			'required'    => '0',
			'width'       => 'half',
			'placeholder' => '',
			'help'        => '',
			'options'     => devxpe_form_field_templates()['reply_by'],
		),
		array(
			'type'        => 'select',
			'label'       => __( 'Size ulaşmak için en uygun zaman', 'devxpe-theme' ),
			'key'         => 'reach_time',
			'required'    => '0',
			'width'       => 'half',
			'placeholder' => '',
			'help'        => '',
			'options'     => devxpe_form_field_templates()['reach_time'],
		),
	);
}

/**
 * Teklif formu adımının alanlarını döndürür (panelden, boşsa varsayılan).
 *
 * @param string $step 'project' veya 'contact'.
 * @return array
 */
function devxpe_quote_step_fields( $step ) {
	$step = ( 'project' === $step ) ? 'project' : 'contact';
	$rows = devxpe_theme_get( 'quote_' . $step . '_fields' );

	if ( is_array( $rows ) && $rows ) {
		return $rows;
	}

	return ( 'project' === $step ) ? devxpe_quote_project_default_fields() : devxpe_quote_contact_default_fields();
}

/**
 * Anahtar → etiket eşlemesi (gelen mesaj kutusu ve e-posta için).
 *
 * @return array
 */
function devxpe_form_field_labels() {
	$map = array();
	foreach ( array_merge( devxpe_quote_project_default_fields(), devxpe_quote_contact_default_fields() ) as $row ) {
		if ( ! empty( $row['key'] ) ) {
			$map[ $row['key'] ] = $row['label'];
		}
	}
	foreach ( array_merge( devxpe_quote_step_fields( 'project' ), devxpe_quote_step_fields( 'contact' ) ) as $row ) {
		if ( ! empty( $row['key'] ) && ! empty( $row['label'] ) ) {
			$map[ $row['key'] ] = $row['label'];
		}
	}
	$map['postcode'] = __( 'İş adresi veya posta kodu', 'devxpe-theme' );
	return $map;
}

/**
 * Teklif formunun 2. ve 3. adımındaki tek bir alanı çizer.
 *
 * Alan tanımı panelden gelir; tür, etiket, yer tutucu, alt not, genişlik ve
 * zorunluluk anahtarı müşteri tarafından değiştirilebilir.
 *
 * @param array $row Alan tanımı.
 * @return void
 */
function devxpe_render_quote_field( $row ) {
	$type  = isset( $row['type'] ) ? $row['type'] : 'input';
	$label = isset( $row['label'] ) ? (string) $row['label'] : '';
	$key   = isset( $row['key'] ) ? (string) $row['key'] : '';
	if ( '' === $label || '' === $key ) {
		return;
	}

	$req    = ( isset( $row['required'] ) && '1' === $row['required'] );
	$ph     = isset( $row['placeholder'] ) ? (string) $row['placeholder'] : '';
	$help   = isset( $row['help'] ) ? (string) $row['help'] : '';
	$opts   = isset( $row['options'] ) ? devxpe_lines( $row['options'], ',' ) : array();
	$half   = ( isset( $row['width'] ) && 'half' === $row['width'] ) ? ' dxp-qfield--half' : '';
	$id     = 'dxp-q-' . $key;
	$req_at = $req ? ' required' : '';
	$lbl    = esc_html( $label ) . ( $req ? ' *' : '' );
	$data   = ' data-label="' . esc_attr( $label ) . '"';

	/* Dosyalar ortak yükleme akışını kullanır (dxp_file_ ön eki). */
	$name = ( 'file' === $type ) ? 'dxp_file_' . $key : $key;

	echo '<div class="dxp-qfield' . esc_attr( $half ) . '">';
	echo '<label for="' . esc_attr( $id ) . '"><span>' . $lbl . '</span></label>';

	if ( 'select' === $type ) {
		echo '<select id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '"' . $req_at . $data . '>';
		echo '<option value="">' . esc_html( $ph ? $ph : __( 'Seçiniz', 'devxpe-theme' ) ) . '</option>';
		foreach ( $opts as $opt ) {
			echo '<option value="' . esc_attr( $opt ) . '">' . esc_html( $opt ) . '</option>';
		}
		echo '</select>';
	} elseif ( 'textarea' === $type ) {
		echo '<textarea id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" rows="4" placeholder="' . esc_attr( $ph ) . '"' . $req_at . $data . devxpe_field_maxlength_attr( 'textarea' ) . '></textarea>';
		devxpe_render_field_counter( 'textarea' );
	} elseif ( 'file' === $type ) {
		$accept = '.' . implode( ',.', devxpe_lines( devxpe_theme_get( 'contact_upload_types', 'jpg,jpeg,png,webp,pdf' ), ',' ) );
		echo '<input type="file" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" accept="' . esc_attr( $accept ) . '"' . $req_at . $data . ' />';
	} else {
		$html_type = in_array( $type, array( 'email', 'tel', 'url', 'number', 'date' ), true ) ? $type : 'text';

		if ( 'tel' === $type ) {
			echo '<div class="dxp-tel-wrap">';
			devxpe_form_country_select( $key );
			echo '<input type="tel" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" placeholder="' . esc_attr( $ph ) . '"' . $req_at . $data . ' />';
			echo '</div>';
		} else {
			$max_attr = in_array( $html_type, array( 'text', 'email', 'url' ), true ) ? devxpe_field_maxlength_attr( $html_type ) : '';
			echo '<input type="' . esc_attr( $html_type ) . '" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" placeholder="' . esc_attr( $ph ) . '"' . $req_at . $data . $max_attr . ' />';
		}
	}

	if ( '' !== $help ) {
		echo '<small class="dxp-qhint">' . esc_html( $help ) . '</small>';
	}
	echo '</div>';
}

