<?php
/**
 * DEVXPE form gönderim/kayıt işleyicileri.
 *
 * Form mesaj kutusu (option), dosya yükleyici, AJAX gönderimleri, SMTP
 * ayarları, kısa kodlar ve panelden mesaj silme işlemleri buradadır.
 *
 * Kamu Yüzeyi: devxpe_form_* fonksiyon adları, DEVXPE_FORM_OPTION sabiti,
 * admin_post_devxpe_form_delete, wp_ajax_devxpe_form_submit,
 * wp_ajax_devxpe_contact_submit, admin_post_devxpe_smtp_test hook'ları ve
 * devxpe_contact_form / devxpe_form / devxpe_popup kısa kodları sözleşmedir;
 * değiştirilmez.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ══════════════════════════════════════════════════════════
   Form: kayıt kutusu + e-posta
══════════════════════════════════════════════════════════ */

/**
 * Gelen form mesajlarının saklandığı option anahtarı.
 *
 * Tema opsiyonlarından ayrı tutulur; panel kaydı bunları silmez.
 */
const DEVXPE_FORM_OPTION = 'devxpe_form_entries';

/**
 * Form kayıtlarının saklama süresi (gün). 0 = sınırsız.
 *
 * @return int
 */
function devxpe_form_retention_days() {
	$gun = (int) devxpe_theme_get( 'form_retention_days', 365 );
	$gun = (int) apply_filters( 'devxpe_form_retention_days', $gun );

	return max( 0, $gun );
}

/**
 * Saklama süresini aşan kayıtları ayıklar (yan etkisiz; test edilebilir).
 *
 * Zamanı okunamayan kayıtlar silinmez (kanıtsız veri kaybı olmasın).
 *
 * @param array    $entries Kayıtlar.
 * @param int      $gun     Saklama süresi (gün); 0 = sınırsız.
 * @param int|null $simdi   Şimdiki zaman (site saati, unix). null = time().
 * @return array
 */
function devxpe_form_retention_filter( $entries, $gun, $simdi = null ) {
	$entries = is_array( $entries ) ? $entries : array();
	$gun     = (int) $gun;

	if ( $gun <= 0 ) {
		return $entries;
	}

	$simdi = ( null === $simdi ) ? time() : (int) $simdi;
	$esik  = $simdi - ( $gun * 86400 );
	$out   = array();

	foreach ( $entries as $entry ) {
		if ( ! is_array( $entry ) ) {
			continue;
		}

		$zaman = isset( $entry['time'] ) ? strtotime( (string) $entry['time'] ) : false;

		if ( false === $zaman || $zaman >= $esik ) {
			$out[] = $entry;
		}
	}

	return $out;
}

/**
 * Kayıtlı form mesajlarını (en yeni önce) döndürür.
 *
 * @return array
 */
function devxpe_form_entries() {
	$entries = get_option( DEVXPE_FORM_OPTION, array() );
	$entries = is_array( $entries ) ? $entries : array();
	$gun     = devxpe_form_retention_days();

	return ( $gun > 0 ) ? devxpe_form_retention_filter( $entries, $gun, (int) current_time( 'timestamp' ) ) : $entries;
}

/**
 * Yeni form mesajı kaydeder. En yeni 200 kayıt tutulur.
 *
 * @param array $entry Mesaj alanları.
 * @return array
 */
function devxpe_form_add_entry( $entry ) {
	$entry['id']   = uniqid( 'dxp', true );
	$entry['time'] = current_time( 'mysql' );
	$entry['read'] = ''; // Yeni kayıt: okunmadı.

	$entries = devxpe_form_entries();
	array_unshift( $entries, $entry );
	$entries = array_slice( $entries, 0, 200 );

	update_option( DEVXPE_FORM_OPTION, $entries, false );

	return $entry;
}

/**
 * Kayda, gönderilen e-postanın konusunu ve gövdesini yazar.
 *
 * Panelde "Gelen Mesajlar" altında mailin birebir içeriği görünsün diye
 * gönderim anında saklanır (eski kayıtlarda bu alanlar boş olabilir).
 *
 * @param string $id      Kayıt kimliği.
 * @param string $subject E-posta konusu.
 * @param string $body    E-posta gövdesi (düz metin).
 * @return void
 */
function devxpe_form_set_entry_mail( $id, $subject, $body ) {
	$id = (string) $id;

	if ( '' === $id ) {
		return;
	}

	$entries = devxpe_form_entries();

	foreach ( $entries as $i => $entry ) {
		if ( isset( $entry['id'] ) && (string) $entry['id'] === $id ) {
			$entries[ $i ]['mail_subject'] = (string) $subject;
			$entries[ $i ]['mail_body']    = (string) $body;
			update_option( DEVXPE_FORM_OPTION, $entries, false );
			return;
		}
	}
}

/**
 * Tek bir mesajı siler.
 *
 * @param string $id Mesaj kimliği.
 * @return void
 */
function devxpe_form_delete_entry( $id ) {
	$entries = devxpe_form_entries();
	$entries = array_values(
		array_filter(
			$entries,
			function ( $entry ) use ( $id ) {
				return ! isset( $entry['id'] ) || $entry['id'] !== $id;
			}
		)
	);
	update_option( DEVXPE_FORM_OPTION, $entries, false );
}

/**
 * Tüm mesajları siler.
 *
 * @return void
 */
function devxpe_form_clear_entries() {
	delete_option( DEVXPE_FORM_OPTION );
}

/* ══════════════════════════════════════════════════════════
   Form: okundu / okunmadı
═════════════════════════════════════════════════════════════ */

/**
 * Kayıt okunmadı mı?
 *
 * Veri sözleşmesi: `read` = '1' okundu; boş = okunmadı. Ancak `read` anahtarı
 * hiç yoksa kayıt ESKİ kabul edilir ve OKUNDU sayılır (mevcut kurulumda bir
 * anda yüzlerce okunmadı çıkmasın diye).
 *
 * @param array $entry Form kaydı.
 * @return bool
 */
function devxpe_form_is_unread( $entry ) {
	if ( ! is_array( $entry ) || ! array_key_exists( 'read', $entry ) ) {
		return false;
	}

	return '1' !== (string) $entry['read'];
}

/**
 * Okunmamış mesaj sayısını döndürür.
 *
 * @return int
 */
function devxpe_form_unread_count() {
	$count = 0;

	foreach ( devxpe_form_entries() as $entry ) {
		if ( devxpe_form_is_unread( $entry ) ) {
			$count++;
		}
	}

	return $count;
}

/**
 * Menüdeki kırmızı sayaç rozeti (okunmadı yoksa boş döner).
 *
 * @return string
 */
function devxpe_form_unread_badge() {
	$count = devxpe_form_unread_count();

	if ( $count < 1 ) {
		return '';
	}

	return '<span class="dxp-count-badge">' . esc_html( number_format_i18n( $count ) ) . '</span>';
}

/**
 * Tek bir kaydı okundu/okunmadı olarak işaretler.
 *
 * @param string $id   Kayıt kimliği.
 * @param bool   $read true = okundu, false = okunmadı.
 * @return void
 */
function devxpe_form_mark_read( $id, $read = true ) {
	$id = (string) $id;

	if ( '' === $id ) {
		return;
	}

	$entries = devxpe_form_entries();
	$changed = false;

	foreach ( $entries as $i => $entry ) {
		if ( isset( $entry['id'] ) && (string) $entry['id'] === $id ) {
			$entries[ $i ]['read'] = $read ? '1' : '';
			$changed               = true;
		}
	}

	if ( $changed ) {
		update_option( DEVXPE_FORM_OPTION, $entries, false );
	}
}

/**
 * Tüm kayıtları okundu/okunmadı olarak işaretler.
 *
 * @param bool $read true = okundu, false = okunmadı.
 * @return void
 */
function devxpe_form_mark_all_read( $read = true ) {
	$entries = devxpe_form_entries();

	if ( ! $entries ) {
		return;
	}

	foreach ( $entries as $i => $entry ) {
		$entries[ $i ]['read'] = $read ? '1' : '';
	}

	update_option( DEVXPE_FORM_OPTION, $entries, false );
}

/**
 * Dosya yükleme kuralını denetler (yan etkisiz; test edilebilir).
 *
 * @param string $anahtar            Alan anahtarı (dxp_file_ sonrası).
 * @param int    $boyut              Dosya boyutu (bayt).
 * @param string $uzanti             Dosya uzantısı.
 * @param array  $izinli_anahtarlar  Formda tanımlı dosya alanları.
 * @param array  $izinli_uzantilar   İzinli uzantılar.
 * @param int    $adet               Bu dosyayla birlikte toplam dosya sayısı.
 * @param int    $toplam             Önceki dosyaların toplam boyutu (bayt).
 * @return string Hata mesajı; geçerliyse ''.
 */
function devxpe_form_upload_check( $anahtar, $boyut, $uzanti, $izinli_anahtarlar, $izinli_uzantilar, $adet, $toplam ) {
	if ( ! in_array( (string) $anahtar, (array) $izinli_anahtarlar, true ) ) {
		return __( 'Bu formda dosya alanı yok.', 'devxpe-theme' );
	}

	if ( ! in_array( strtolower( (string) $uzanti ), (array) $izinli_uzantilar, true ) ) {
		return __( 'Bu dosya türüne izin verilmiyor.', 'devxpe-theme' );
	}

	if ( (int) $boyut > 8 * 1024 * 1024 ) {
		return __( 'Dosya çok büyük (en fazla 8 MB).', 'devxpe-theme' );
	}

	if ( (int) $adet > 3 ) {
		return __( 'En fazla 3 dosya yükleyebilirsiniz.', 'devxpe-theme' );
	}

	if ( (int) $toplam + (int) $boyut > 15 * 1024 * 1024 ) {
		return __( 'Dosyaların toplamı 15 MB sınırını aşıyor.', 'devxpe-theme' );
	}

	return '';
}

/**
 * Bir uzantı için kabul edilebilir MIME türleri.
 *
 * Önce bilinen eşlemeler (alias'lar: OOXML sıkıştırılmış algılanır, csv metin
 * olarak algılanır), sonra WordPress'in kendi uzantı→MIME tablosu. Böylece
 * panelde tanımlanan özel türler (ör. `zip`, `heic`) filtre yazmadan çalışır.
 *
 * @param string $uzanti Dosya uzantısı.
 * @return array İzinli MIME türleri (boşsa uzantı reddedilir).
 */
function devxpe_upload_expected_mimes( $uzanti ) {
	$uzanti = strtolower( (string) $uzanti );

	$bilinen = array(
		'txt'  => array( 'text/plain' ),
		'csv'  => array( 'text/csv', 'text/plain', 'application/csv' ),
		'doc'  => array( 'application/msword', 'application/vnd.ms-office' ),
		'xls'  => array( 'application/vnd.ms-excel', 'application/vnd.ms-office' ),
		'ppt'  => array( 'application/vnd.ms-powerpoint', 'application/vnd.ms-office' ),
		/* OOXML dosyaları sıkıştırılmış olduğu için zip olarak da algılanır. */
		'docx' => array( 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/zip' ),
		'xlsx' => array( 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/zip' ),
		'pptx' => array( 'application/vnd.openxmlformats-officedocument.presentationml.presentation', 'application/zip' ),
		'heic' => array( 'image/heic', 'image/heif', 'application/octet-stream' ),
		'zip'  => array( 'application/zip', 'application/x-zip-compressed' ),
	);

	$bilinen = (array) apply_filters( 'devxpe_upload_mime_map', $bilinen );

	if ( isset( $bilinen[ $uzanti ] ) ) {
		return (array) $bilinen[ $uzanti ];
	}

	if ( function_exists( 'wp_get_mime_types' ) ) {
		foreach ( (array) wp_get_mime_types() as $uzantilar => $mime ) {
			if ( in_array( $uzanti, explode( '|', (string) $uzantilar ), true ) ) {
				return array( (string) $mime );
			}
		}
	}

	return array();
}

/**
 * Uzantı–içerik (MIME) eşleşmesini denetler (yan etkisiz; test edilebilir).
 *
 * Yalnızca uzantıya bakmak yetmez: `.jpg` adlı bir SVG/PHP dosyası tarayıcıda
 * çalışabilir. Burada dosyanın gerçek içerik türü beklenen türle karşılaştırılır.
 *
 * @param string $uzanti Dosya uzantısı.
 * @param string $mime   Gerçek içerik türü (finfo / imza denetimi).
 * @return bool
 */
function devxpe_form_upload_mime_ok( $uzanti, $mime ) {
	$izinli = devxpe_upload_expected_mimes( $uzanti );
	$mime   = strtolower( trim( (string) $mime ) );

	return $izinli && in_array( $mime, $izinli, true );
}

/**
 * İçerik imzasından MIME türü (finfo yoksa yedek yol).
 *
 * `getimagesize` görselleri, bayt imzaları PDF/Office arşivlerini tanır;
 * böylece fileinfo eklentisi kapalı sunucularda da doğru dosyalar geçer.
 *
 * @param string $yol    Dosya yolu.
 * @param string $uzanti Dosya uzantısı.
 * @return string Tür bulunamazsa ''.
 */
function devxpe_form_upload_mime_signature( $yol, $uzanti ) {
	$uzanti = strtolower( (string) $uzanti );

	if ( '' === (string) $yol || ! is_file( $yol ) ) {
		return '';
	}

	if ( in_array( $uzanti, array( 'jpg', 'jpeg', 'png', 'webp', 'gif' ), true ) && function_exists( 'getimagesize' ) ) {
		$bilgi = @getimagesize( $yol ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		$tur   = array(
			IMAGETYPE_JPEG => 'image/jpeg',
			IMAGETYPE_PNG  => 'image/png',
			IMAGETYPE_GIF  => 'image/gif',
			IMAGETYPE_WEBP => 'image/webp',
		);
		$no    = ( is_array( $bilgi ) && isset( $bilgi[2] ) ) ? (int) $bilgi[2] : 0;

		return isset( $tur[ $no ] ) ? $tur[ $no ] : '';
	}

	$fh = @fopen( $yol, 'rb' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
	if ( false === $fh ) {
		return '';
	}
	$bas = (string) fread( $fh, 16 );
	fclose( $fh );

	if ( 'pdf' === $uzanti && 0 === strpos( $bas, '%PDF-' ) ) {
		return 'application/pdf';
	}

	if ( in_array( $uzanti, array( 'zip', 'docx', 'xlsx', 'pptx' ), true ) && 0 === strpos( $bas, "PK\x03\x04" ) ) {
		return 'application/zip';
	}

	if ( in_array( $uzanti, array( 'doc', 'xls', 'ppt' ), true ) && 0 === strpos( $bas, "\xD0\xCF\x11\xE0" ) ) {
		return 'application/vnd.ms-office';
	}

	if ( in_array( $uzanti, array( 'txt', 'csv' ), true ) && false === strpos( $bas, "\0" ) ) {
		return 'text/plain';
	}

	return '';
}

/**
 * Dosya gerçekten bu uzantıyla uyumlu mu? (yükleyicinin kullandığı kapı)
 *
 * Adaylar: finfo/mime_content_type sonucu ve içerik imzası. Biri beklenen
 * türle eşleşirse geçer — böylece fileinfo kapalıyken de, finfo türü
 * `application/octet-stream` dediğinde de doğru dosyalar engellenmez.
 *
 * @param string $yol    Geçici dosya yolu.
 * @param string $uzanti Dosya uzantısı.
 * @return bool
 */
function devxpe_form_upload_mime_gecerli( $yol, $uzanti ) {
	$izinli = devxpe_upload_expected_mimes( $uzanti );

	if ( ! $izinli ) {
		return false;
	}

	$adaylar = array( devxpe_form_upload_mime( $yol, $uzanti ) );
	$imza    = devxpe_form_upload_mime_signature( $yol, $uzanti );

	if ( '' !== $imza ) {
		$adaylar[] = $imza;
	}

	foreach ( $adaylar as $aday ) {
		$aday = strtolower( trim( (string) $aday ) );

		if ( '' !== $aday && in_array( $aday, $izinli, true ) ) {
			return true;
		}
	}

	return false;
}

/**
 * Geçici dosyanın gerçek MIME türünü okur: finfo → mime_content_type → imza.
 *
 * @param string $yol    Geçici dosya yolu.
 * @param string $uzanti Dosya uzantısı (imza denetimi için).
 * @return string Tür bulunamazsa ''.
 */
function devxpe_form_upload_mime( $yol, $uzanti = '' ) {
	$yol = (string) $yol;

	if ( '' === $yol || ! is_file( $yol ) ) {
		return '';
	}

	if ( function_exists( 'finfo_open' ) ) {
		$finfo = finfo_open( FILEINFO_MIME_TYPE );
		if ( false !== $finfo ) {
			$mime = (string) finfo_file( $finfo, $yol );
			finfo_close( $finfo );

			if ( '' !== trim( $mime ) ) {
				return $mime;
			}
		}
	}

	if ( function_exists( 'mime_content_type' ) ) {
		$mime = (string) mime_content_type( $yol );

		if ( '' !== trim( $mime ) ) {
			return $mime;
		}
	}

	return devxpe_form_upload_mime_signature( $yol, $uzanti );
}

/**
 * Hata sonrası yüklenmiş dosyaları siler.
 *
 * @param array $yollar Sunucudaki dosya yolları.
 * @return void
 */
function devxpe_form_upload_temizle( $yollar ) {
	foreach ( (array) $yollar as $y ) {
		if ( is_string( $y ) && '' !== $y && file_exists( $y ) ) {
			@unlink( $y ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		}
	}
}

/**
 * Form dosya yüklemelerini işler.
 *
 * Yalnızca formda tanımlı dosya alanları kabul edilir; en fazla 3 dosya ve
 * toplam 15 MB. Hata olursa o ana kadar yüklenen dosyalar silinir.
 *
 * @param array $izinli_anahtarlar Formda tanımlı dosya alanı anahtarları.
 * @return array Yüklenen dosya URL'leri.
 */
function devxpe_form_upload_files( $izinli_anahtarlar = array() ) {
	$urls = array();

	if ( empty( $_FILES ) ) {
		return $urls;
	}

	require_once ABSPATH . 'wp-admin/includes/file.php';

	$izinli = array_filter( array_map( 'strtolower', array_map( 'trim', explode( ',', (string) devxpe_theme_get( 'contact_upload_types', 'jpg,jpeg,png,webp,pdf' ) ) ) ) );
	$adet   = 0;
	$toplam = 0;
	$yuklenen = array();

	foreach ( $_FILES as $fk => $file ) {
		if ( 0 !== strpos( (string) $fk, 'dxp_file_' ) || empty( $file['name'] ) ) {
			continue;
		}

		/* Çoklu yükleme (name="dxp_file_x[]") desteklenmez: gelen tür dizi olur. */
		if ( ! is_string( $file['name'] ) || ! isset( $file['tmp_name'] ) || ! is_string( $file['tmp_name'] ) || is_array( $file['size'] ) ) {
			devxpe_form_upload_temizle( $yuklenen );
			wp_send_json_error( array( 'message' => __( 'Dosya alanı geçersiz.', 'devxpe-theme' ) ) );
		}

		$anahtar = substr( (string) $fk, strlen( 'dxp_file_' ) );
		$boyut   = (int) $file['size'];
		$uzanti  = strtolower( pathinfo( sanitize_file_name( wp_unslash( $file['name'] ) ), PATHINFO_EXTENSION ) );
		$hata    = devxpe_form_upload_check( $anahtar, $boyut, $uzanti, $izinli_anahtarlar, $izinli, $adet + 1, $toplam );

		if ( '' !== $hata ) {
			devxpe_form_upload_temizle( $yuklenen );
			wp_send_json_error( array( 'message' => $hata ) );
		}

		/* İçerik denetimi: uzantı ile gerçek MIME uyuşmalı (SVG/PHP gizlenemez). */
		if ( ! is_uploaded_file( $file['tmp_name'] ) || ! devxpe_form_upload_mime_gecerli( $file['tmp_name'], $uzanti ) ) {
			devxpe_form_upload_temizle( $yuklenen );
			wp_send_json_error( array( 'message' => __( 'Dosya içeriği uzantısıyla uyuşmuyor.', 'devxpe-theme' ) ) );
		}

		$up = wp_handle_upload( $file, array( 'test_form' => false ) );

		if ( isset( $up['error'] ) ) {
			devxpe_form_upload_temizle( $yuklenen );
			wp_send_json_error( array( 'message' => $up['error'] ) );
		}

		$adet++;
		$toplam += $boyut;
		$yuklenen[] = isset( $up['file'] ) ? (string) $up['file'] : '';
		$urls[]     = esc_url_raw( $up['url'] );
	}

	return $urls;
}

function devxpe_form_rate_ok() {
	$ip = devxpe_form_client_ip();

	/* IP başına 10 saniyelik bekleme (art arda gönderim engeli). */
	if ( get_transient( 'dxp_fr_' . md5( $ip ) ) ) {
		return false;
	}

	set_transient( 'dxp_fr_' . md5( $ip ), 1, 10 );

	return true;
}

/**
 * İstemci IP'si (proxy farkındalıklı).
 *
 * Başlıklara yalnızca güvenilir proxy arkasındaysa bakılır; ayrıntı ve
 * yapılandırma için `includes/theme-ip.php`.
 *
 * @return string
 */
function devxpe_form_client_ip() {
	if ( function_exists( 'devxpe_client_ip' ) ) {
		return devxpe_client_ip( $_SERVER );
	}

	return isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( (string) $_SERVER['REMOTE_ADDR'] ) ) : '0';
}

/**
 * Teklif formu gönderimini işler (AJAX).
 *
 * Güvenlik: nonce doğrulaması, honeypot alanı ve sunucu tarafı temizleme.
 *
 * @return void
 */
function devxpe_form_submit() {
	if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'devxpe_form' ) ) {
		wp_send_json_error( array( 'message' => __( 'Güvenlik doğrulaması başarısız. Sayfayı yenileyip tekrar deneyin.', 'devxpe-theme' ) ) );
	}

	if ( ! devxpe_form_rate_ok() ) {
		wp_send_json_error( array( 'message' => __( 'Çok sık gönderim yapıldı. Lütfen birkaç dakika sonra tekrar deneyin.', 'devxpe-theme' ) ), 429 );
	}

	/* Honeypot: botlar bu gizli alanı doldurur. */
	if ( ! empty( $_POST['website'] ) ) {
		wp_send_json_success( array( 'message' => __( 'Teşekkürler!', 'devxpe-theme' ) ) );
	}

	/* Google reCAPTCHA v3 (açıksa). */
	if ( ! devxpe_verify_recaptcha() ) {
		wp_send_json_error( array( 'message' => __( 'Güvenlik doğrulaması başarısız. Lütfen sayfayı yenileyip tekrar deneyin.', 'devxpe-theme' ) ) );
	}

	$service = sanitize_text_field( wp_unslash( $_POST['service'] ?? '' ) );
	if ( '' === $service ) {
		wp_send_json_error( array( 'message' => __( 'Lütfen bir hizmet seçin.', 'devxpe-theme' ) ) );
	}

	/*
	 * Alanlar panelden gelir; burada türüne göre temizlenir. Böylece müşteri
	 * alan ekleyip çıkarınca/etiketini değiştirince kayıt ve e-posta bozulmaz.
	 */
	$values = array();
	$lines  = array( sprintf( __( 'Hizmet: %s', 'devxpe-theme' ), $service ) );
	$email  = '';

	/* Dosya alanları yalnızca bu formda tanımlıysa kabul edilir. */
	$dxp_rows      = array_merge( devxpe_quote_step_fields( 'project' ), devxpe_quote_step_fields( 'contact' ) );
	$dxp_file_keys = array();

	foreach ( $dxp_rows as $dxp_row ) {
		if ( isset( $dxp_row['type'] ) && 'file' === $dxp_row['type'] && ! empty( $dxp_row['key'] ) ) {
			$dxp_file_keys[] = (string) $dxp_row['key'];
		}
	}

	foreach ( $dxp_rows as $row ) {
		$type = isset( $row['type'] ) ? $row['type'] : 'input';
		$key  = isset( $row['key'] ) ? (string) $row['key'] : '';
		$lbl  = isset( $row['label'] ) ? (string) $row['label'] : $key;

		if ( '' === $key || 'file' === $type ) {
			continue;
		}

		$raw = isset( $_POST[ $key ] ) ? wp_unslash( $_POST[ $key ] ) : '';

		if ( 'textarea' === $type ) {
			$val = sanitize_textarea_field( $raw );
		} elseif ( 'email' === $type ) {
			$val = sanitize_email( $raw );
		} else {
			$val = sanitize_text_field( $raw );
		}

		if ( '1' === ( isset( $row['required'] ) ? $row['required'] : '0' ) && '' === $val ) {
			wp_send_json_error( array( 'message' => __( 'Lütfen zorunlu alanları doldurun.', 'devxpe-theme' ) ) );
		}
		if ( 'email' === $type && '' !== $val && ! is_email( $val ) ) {
			wp_send_json_error( array( 'message' => __( 'Geçerli bir e-posta adresi girin.', 'devxpe-theme' ) ) );
		}
		if ( 'email' === $type && '' !== $val && ! devxpe_form_email_allowed( $val ) ) {
			$dxp_msgs = devxpe_form_messages();
			wp_send_json_error( array( 'message' => $dxp_msgs['tld'] ) );
		}
		/* Telefon: seçilen ülke kodu numaranın başına eklenir. */
		if ( 'tel' === $type && '' !== $val ) {
			$val = devxpe_form_apply_country( $key, $val );
		}

		$values[ $key ] = $val;
		if ( '' !== $val ) {
			$lines[] = $lbl . ': ' . $val;
		}
		if ( 'email' === $type && '' !== $val ) {
			$email = $val;
		}
	}

	/* Dosyalar: ortak yükleyici (dxp_file_ ön eki). */
	$file_urls = devxpe_form_upload_files( $dxp_file_keys );
	if ( $file_urls ) {
		$lines[] = __( 'Dosya', 'devxpe-theme' ) . ': ' . implode( ', ', $file_urls );
	}

	$fields = array_merge( array( 'service' => $service ), $values );
	if ( $file_urls ) {
		$fields['file'] = $file_urls[0];
	}

	/* IP kayıtla BİRLİKTE yazılır (sonradan eklenince kalıcı olmuyordu). */
	$fields['ip'] = devxpe_form_client_ip();

	$entry = devxpe_form_add_entry( $fields );

	/* Konu değişkenleri: kayıt no (en yeni = 1), tarih ve kimlik. */
	$fields['no']   = count( (array) devxpe_form_entries() );
	$fields['date'] = date_i18n( (string) get_option( 'date_format' ) . ' H:i' );
	$fields['id']   = isset( $entry['id'] ) ? (string) $entry['id'] : '';

	/* E-posta bildirimi — virgülle ayrılmış çoklu alıcı desteklenir. */
	$to      = devxpe_form_recipients();
	$subject = (string) devxpe_theme_get( 'form_subject' );

	if ( '' === trim( $subject ) ) {
		/* Varsayılan konu biçimi: #kayıt no | hizmet | ad soyad */
		$subject = '#{no} | {service} | {name}';
	}

	/* Konudaki {alan} değişkenleri gönderilen değerlerle doldurulur. */
	$subject = devxpe_form_fill_tokens( $subject, $fields );

	$mail_body = implode( "\n", $lines );
	$mail_ok   = (bool) wp_mail( $to, $subject, $mail_body );

	/* Gönderim başarısızsa kayıtta görünsün (panele yansır). */
	if ( ! $mail_ok ) {
		$mail_body .= "\n\n" . __( '[E-posta gönderilemedi]', 'devxpe-theme' );
	}

	/* Gönderilen mailin içeriği panelde görünsün diye kayda yazılır. */
	devxpe_form_set_entry_mail( $entry['id'], $subject, $mail_body );

	$success = devxpe_theme_get( 'form_success' );
	if ( ! $success ) {
		$success = __( 'Teşekkürler! En kısa sürede size döneceğiz.', 'devxpe-theme' );
	}

	wp_send_json_success( array( 'message' => $success ) );
}
add_action( 'wp_ajax_devxpe_form_submit', 'devxpe_form_submit' );
add_action( 'wp_ajax_nopriv_devxpe_form_submit', 'devxpe_form_submit' );

/* ══════════════════════════════════════════════════════════
   SMTP — form e-postaları kendi sunucudan gönderilsin
══════════════════════════════════════════════════════════ */

/**
 * PHPMailer'ı panelden girilen SMTP ayarlarıyla yapılandırır.
 *
 * SMTP kapalıysa ya da sunucu boşsa hiçbir şey yapılmaz; WordPress'in
 * kendi gönderim yolu kullanılır.
 *
 * @param PHPMailer\PHPMailer\PHPMailer $phpmailer PHPMailer nesnesi.
 * @return void
 */
function devxpe_smtp_configure( $phpmailer ) {
	if ( '1' !== devxpe_theme_get( 'smtp_enable' ) ) {
		return;
	}

	$host = trim( (string) devxpe_theme_get( 'smtp_host' ) );
	if ( '' === $host ) {
		return;
	}

	$port = (int) devxpe_theme_get( 'smtp_port', '587' );
	$enc  = (string) devxpe_theme_get( 'smtp_encryption', 'tls' );

	$phpmailer->isSMTP();
	$phpmailer->Host = $host;
	$phpmailer->Port = $port > 0 ? $port : 587;

	if ( in_array( $enc, array( 'ssl', 'tls' ), true ) ) {
		$phpmailer->SMTPSecure = $enc;
	} else {
		$phpmailer->SMTPSecure  = '';
		$phpmailer->SMTPAutoTLS = false;
	}

	if ( '1' === devxpe_theme_get( 'smtp_auth', '1' ) ) {
		$phpmailer->SMTPAuth = true;
		$phpmailer->Username = (string) devxpe_theme_get( 'smtp_user' );
		$phpmailer->Password = (string) devxpe_theme_get( 'smtp_pass' );
	} else {
		$phpmailer->SMTPAuth = false;
	}

	$from = sanitize_email( (string) devxpe_theme_get( 'smtp_from_email' ) );
	if ( $from ) {
		$phpmailer->From = $from;
	}

	$from_name = trim( (string) devxpe_theme_get( 'smtp_from_name' ) );
	if ( '' !== $from_name ) {
		$phpmailer->FromName = $from_name;
	}
}
add_action( 'phpmailer_init', 'devxpe_smtp_configure' );

/**
 * Gönderim hatasını geçici olarak saklar; panelde gösterilir.
 *
 * @param WP_Error $wp_error Hata nesnesi.
 * @return void
 */
function devxpe_smtp_capture_error( $wp_error ) {
	if ( is_wp_error( $wp_error ) ) {
		set_transient( 'devxpe_smtp_notice', $wp_error->get_error_message(), 60 );
	}
}
add_action( 'wp_mail_failed', 'devxpe_smtp_capture_error' );

/**
 * Panelden test e-postası gönderir ve panele geri döner.
 *
 * @return void
 */
function devxpe_smtp_test() {
	if ( ! isset( $_POST['dxp_smtp_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['dxp_smtp_nonce'] ) ), 'devxpe_smtp_test' ) ) {
		wp_die( esc_html__( 'Güvenlik doğrulaması başarısız.', 'devxpe-theme' ) );
	}
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Bu işlem için yetkiniz yok.', 'devxpe-theme' ) );
	}

	$to = isset( $_POST['dxp_smtp_to'] ) ? sanitize_email( wp_unslash( $_POST['dxp_smtp_to'] ) ) : '';
	$ok = false;

	if ( is_email( $to ) ) {
		$site    = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		$subject = sprintf( __( '%s — SMTP test e-postası', 'devxpe-theme' ), $site );
		$body    = __( 'Bu e-posta panelin SMTP ayarları üzerinden gönderildi. Ayarlar çalışıyor.', 'devxpe-theme' );
		$ok      = wp_mail( $to, $subject, $body );
	}

	$back = wp_get_referer();
	if ( ! $back ) {
		$back = admin_url();
	}

	wp_safe_redirect( add_query_arg( 'dxp_smtp', $ok ? 'ok' : 'fail', $back ) );
	exit;
}
add_action( 'admin_post_devxpe_smtp_test', 'devxpe_smtp_test' );

/**
 * Basit iletişim formu gönderimini işler (AJAX).
 *
 * Ad/Soyad/Telefon/E-posta/Mesaj + isteğe bağlı onay kutusu ve dosya.
 *
 * @return void
 */
function devxpe_contact_submit() {
	check_ajax_referer( 'devxpe_form', 'nonce' );

	if ( ! devxpe_form_rate_ok() ) {
		wp_send_json_error( array( 'message' => __( 'Çok sık gönderim yapıldı. Lütfen birkaç dakika sonra tekrar deneyin.', 'devxpe-theme' ) ), 429 );
	}

	/* Google reCAPTCHA v3 (açıksa). */
	if ( ! devxpe_verify_recaptcha() ) {
		wp_send_json_error( array( 'message' => __( 'Güvenlik doğrulaması başarısız. Lütfen sayfayı yenileyip tekrar deneyin.', 'devxpe-theme' ) ) );
	}

	$slug  = isset( $_POST['dxp_form_slug'] ) ? sanitize_key( wp_unslash( $_POST['dxp_form_slug'] ) ) : devxpe_active_form_slug();
	$forms = devxpe_custom_forms();
	if ( ! isset( $forms[ $slug ] ) ) {
		$slug = devxpe_active_form_slug();
	}
	$fields = devxpe_form_fields( $slug );

	/* Dosya alanları yalnızca bu formda tanımlıysa kabul edilir. */
	$dxp_file_keys = array();

	foreach ( $fields as $dxp_f ) {
		if ( isset( $dxp_f['type'] ) && 'file' === $dxp_f['type'] && ! empty( $dxp_f['key'] ) ) {
			$dxp_file_keys[] = (string) $dxp_f['key'];
		}
	}

	$lines     = array();
	$first     = '';
	$email_val = '';
	$phone_val = '';

	foreach ( $fields as $f ) {
		$type  = isset( $f['type'] ) ? $f['type'] : 'text';
		$label = isset( $f['label'] ) ? $f['label'] : '';
		$key   = isset( $f['key'] ) ? $f['key'] : '';
		$req   = ! empty( $f['required'] );
		$name  = 'field_' . $key;

		if ( 'file' === $type ) {
			continue; // Dosyalar ayrı işlenir.
		}

		if ( 'checkbox' === $type ) {
			$checked = ! empty( $_POST[ $name ] );
			if ( $req && ! $checked ) {
				/* translators: %s: field label. */
				wp_send_json_error( array( 'message' => sprintf( __( '"%s" alanı zorunludur.', 'devxpe-theme' ), $label ) ) );
			}
			$val = $checked ? __( 'Evet', 'devxpe-theme' ) : __( 'Hayır', 'devxpe-theme' );
		} else {
			$raw = isset( $_POST[ $name ] ) ? wp_unslash( $_POST[ $name ] ) : '';
			$val = ( 'textarea' === $type ) ? sanitize_textarea_field( $raw ) : sanitize_text_field( $raw );

			/* Telefon: seçilen ülke kodu numaranın başına eklenir. */
			if ( 'tel' === $type && '' !== $val ) {
				$val = devxpe_form_apply_country( preg_replace( '/^field_/', '', (string) $name ), $val );
			}

			if ( $req && '' === trim( (string) $val ) ) {
				/* translators: %s: field label. */
				wp_send_json_error( array( 'message' => sprintf( __( '"%s" alanı zorunludur.', 'devxpe-theme' ), $label ) ) );
			}
			if ( 'email' === $type && '' !== $val && ! is_email( $val ) ) {
				wp_send_json_error( array( 'message' => __( 'Geçerli bir e-posta adresi girin.', 'devxpe-theme' ) ) );
			}
			if ( 'email' === $type && '' !== $val && ! devxpe_form_email_allowed( $val ) ) {
				$dxp_msgs = devxpe_form_messages();
				wp_send_json_error( array( 'message' => $dxp_msgs['tld'] ) );
			}
			if ( '' === $first && '' !== trim( (string) $val ) ) {
				$first = $val;
			}
			if ( 'email' === $type && '' !== $val ) {
				$email_val = $val;
			}
			if ( 'tel' === $type && '' !== $val ) {
				$phone_val = $val;
			}
		}

		$lines[] = $label . ': ' . $val;
	}

	if ( '1' === devxpe_theme_get( 'contact_consent_enable', '1' ) && empty( $_POST['consent'] ) ) {
		wp_send_json_error( array( 'message' => __( 'Lütfen onay kutusunu işaretleyin.', 'devxpe-theme' ) ) );
	}

	/* Dosyalar (yalnızca bu formun dosya alanları) */
	$file_urls = devxpe_form_upload_files( $dxp_file_keys );
	if ( $file_urls ) {
		$lines[] = __( 'Dosya', 'devxpe-theme' ) . ': ' . implode( ', ', $file_urls );
	}

	$entry = array(
		'type'    => 'contact',
		'name'    => $first,
		'email'   => $email_val,
		'phone'   => $phone_val,
		'service' => isset( $forms[ $slug ]['name'] ) ? $forms[ $slug ]['name'] : __( 'İletişim formu', 'devxpe-theme' ),
		'details' => implode( "\n", $lines ),
		'file'    => $file_urls ? $file_urls[0] : '',
		'ip'      => devxpe_form_client_ip(),
	);

	devxpe_form_add_entry( $entry );

	/* E-posta bildirimi — çoklu alıcı desteklenir. */
	$to = devxpe_form_recipients();

	$contact_subject = sprintf( __( 'Yeni iletişim mesajı: %s', 'devxpe-theme' ), $entry['name'] );
	$contact_body    = implode( "\n", $lines );
	$contact_ok      = (bool) wp_mail( $to, $contact_subject, $contact_body );

	if ( ! $contact_ok ) {
		$contact_body .= "\n\n" . __( '[E-posta gönderilemedi]', 'devxpe-theme' );
	}

	/* Gönderilen mailin içeriği panelde görünsün diye kayda yazılır. */
	$kayit = devxpe_form_entries();
	if ( isset( $kayit[0]['id'] ) ) {
		devxpe_form_set_entry_mail( $kayit[0]['id'], $contact_subject, $contact_body );
	}

	/* Başarı mesajı: teklif formuyla aynı alan (tek yerden yönetim). */
	$success = devxpe_theme_get( 'form_success' );
	if ( ! $success ) {
		$success = __( 'Mesajınız için teşekkürler! En kısa sürede dönüş yapacağız.', 'devxpe-theme' );
	}

	wp_send_json_success( array( 'message' => $success ) );
}
add_action( 'wp_ajax_devxpe_contact_submit', 'devxpe_contact_submit' );
add_action( 'wp_ajax_nopriv_devxpe_contact_submit', 'devxpe_contact_submit' );

/**
 * Basit iletişim formunu her yere gömmek için kısa kod: [devxpe_contact_form]
 *
 * @return string
 */
function devxpe_contact_form_shortcode( $atts = array() ) {
	$atts = shortcode_atts( array( 'slug' => '' ), $atts, 'devxpe_form' );

	ob_start();
	get_template_part( 'template-parts/contact-form', null, array( 'slug' => $atts['slug'] ) );
	return ob_get_clean();
}
add_shortcode( 'devxpe_contact_form', 'devxpe_contact_form_shortcode' );
add_shortcode( 'devxpe_form', 'devxpe_contact_form_shortcode' );

/**
 * Popup açan link kısa kodu.
 *
 * Kullanım: [devxpe_popup]Duyuruyu gör[/devxpe_popup]
 * ya da:    [devxpe_popup text="Duyuruyu gör" class="btn"]
 *
 * @param array       $atts    Kısa kod öznitelikleri.
 * @param string|null $content Kısa kod içeriği (link yazısı).
 * @return string
 */
function devxpe_popup_shortcode( $atts = array(), $content = null ) {
	$atts = shortcode_atts(
		array(
			'text'  => '',
			'class' => '',
		),
		$atts,
		'devxpe_popup'
	);

	$label = '' !== $atts['text'] ? $atts['text'] : (string) $content;
	if ( '' === trim( $label ) ) {
		$label = __( 'Duyuruyu gör', 'devxpe-theme' );
	}

	$class = trim( 'dxp-popup-open ' . $atts['class'] );

	return '<a class="' . esc_attr( $class ) . '" href="#duyuru" data-dxp-popup>' . esc_html( $label ) . '</a>';
}
add_shortcode( 'devxpe_popup', 'devxpe_popup_shortcode' );

/**
 * Panelden mesaj silme (admin-post).
 *
 * @return void
 */
function devxpe_form_handle_delete() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Yetkiniz yok.', 'devxpe-theme' ) );
	}
	check_admin_referer( 'devxpe_form_delete' );

	$id = isset( $_GET['id'] ) ? sanitize_text_field( wp_unslash( $_GET['id'] ) ) : '';

	if ( 'all' === $id ) {
		devxpe_form_clear_entries();
	} else {
		devxpe_form_delete_entry( $id );
	}

	wp_safe_redirect( admin_url( 'admin.php?page=' . DEVXPE_Theme_Panel::MENU_SLUG . '#form/inbox' ) );
	exit;
}
add_action( 'admin_post_devxpe_form_delete', 'devxpe_form_handle_delete' );

/**
 * Panelden toplu/tek okundu işaretleme (admin-post).
 *
 * Parametreler: scope = all | unread | one; id (scope=one); okundu = 1 | 0.
 *
 * @return void
 */
function devxpe_form_handle_read() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Yetkiniz yok.', 'devxpe-theme' ) );
	}
	check_admin_referer( 'devxpe_form_read' );

	$scope  = isset( $_GET['scope'] ) ? sanitize_key( wp_unslash( $_GET['scope'] ) ) : 'one';
	$okundu = isset( $_GET['okundu'] ) && '1' === (string) wp_unslash( $_GET['okundu'] );

	if ( 'all' === $scope ) {
		devxpe_form_mark_all_read( $okundu );
	} elseif ( 'unread' === $scope ) {
		devxpe_form_mark_all_read( false );
	} elseif ( 'one' === $scope ) {
		$id = isset( $_GET['id'] ) ? sanitize_text_field( wp_unslash( $_GET['id'] ) ) : '';
		devxpe_form_mark_read( $id, $okundu );
	}

	$back = wp_get_referer();
	wp_safe_redirect( $back ? $back : admin_url() );
	exit;
}
add_action( 'admin_post_devxpe_form_read', 'devxpe_form_handle_read' );

/**
 * AJAX: tek mesajı okundu işaretler (panelde detay açılınca).
 *
 * Dönüş: { success: true, data: { unread: N } } — rozetler bu sayıyla güncellenir.
 *
 * @return void
 */
function devxpe_form_ajax_read() {
	check_ajax_referer( 'devxpe_form_read', 'nonce' );

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => 'yetki' ) );
	}

	$id = isset( $_POST['id'] ) ? sanitize_text_field( wp_unslash( $_POST['id'] ) ) : '';

	if ( '' !== $id ) {
		devxpe_form_mark_read( $id, true );
	}

	wp_send_json_success( array( 'unread' => devxpe_form_unread_count() ) );
}
add_action( 'wp_ajax_devxpe_form_read_ajax', 'devxpe_form_ajax_read' );

