<?php
/**
 * DEVXPE form gönderim/kayıt işleyicileri.
 *
 * Form mesaj kutusu (option), dosya yükleyici, AJAX gönderimleri, SMTP
 * ayarları, kısa kodlar ve panelden mesaj silme işlemleri buradadır.
 *
 * Kamu Yüzeyi: devxpe_form_* fonksiyon adları, DEVXPE_FORM_OPTION sabiti,
 * admin_post_devxpe_form_delete, wp_ajax_devxpe_form_submit,
 * wp_ajax_devxpe_contact_submit, admin_post_devxpe_smtp_test hook'ları ve
 * devxpe_contact_form / devxpe_form / devxpe_popup kısa kodları sözleşmedir;
 * değiştirilmez.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ══════════════════════════════════════════════════════════
   Form: kayıt kutusu + e-posta
══════════════════════════════════════════════════════════ */

/**
 * Gelen form mesajlarının saklandığı option anahtarı.
 *
 * Tema opsiyonlarından ayrı tutulur; panel kaydı bunları silmez.
 */
const DEVXPE_FORM_OPTION = 'devxpe_form_entries';

/**
 * Kayıtlı form mesajlarını (en yeni önce) döndürür.
 *
 * @return array
 */
function devxpe_form_entries() {
	$entries = get_option( DEVXPE_FORM_OPTION, array() );
	return is_array( $entries ) ? $entries : array();
}

/**
 * Yeni form mesajı kaydeder. En yeni 200 kayıt tutulur.
 *
 * @param array $entry Mesaj alanları.
 * @return array
 */
function devxpe_form_add_entry( $entry ) {
	$entry['id']   = uniqid( 'dxp', true );
	$entry['time'] = current_time( 'mysql' );
	$entry['read'] = ''; // Yeni kayıt: okunmadı.

	$entries = devxpe_form_entries();
	array_unshift( $entries, $entry );
	$entries = array_slice( $entries, 0, 200 );

	update_option( DEVXPE_FORM_OPTION, $entries, false );

	return $entry;
}

/**
 * Kayda, gönderilen e-postanın konusunu ve gövdesini yazar.
 *
 * Panelde "Gelen Mesajlar" altında mailin birebir içeriği görünsün diye
 * gönderim anında saklanır (eski kayıtlarda bu alanlar boş olabilir).
 *
 * @param string $id      Kayıt kimliği.
 * @param string $subject E-posta konusu.
 * @param string $body    E-posta gövdesi (düz metin).
 * @return void
 */
function devxpe_form_set_entry_mail( $id, $subject, $body ) {
	$id = (string) $id;

	if ( '' === $id ) {
		return;
	}

	$entries = devxpe_form_entries();

	foreach ( $entries as $i => $entry ) {
		if ( isset( $entry['id'] ) && (string) $entry['id'] === $id ) {
			$entries[ $i ]['mail_subject'] = (string) $subject;
			$entries[ $i ]['mail_body']    = (string) $body;
			update_option( DEVXPE_FORM_OPTION, $entries, false );
			return;
		}
	}
}

/**
 * Tek bir mesajı siler.
 *
 * @param string $id Mesaj kimliği.
 * @return void
 */
function devxpe_form_delete_entry( $id ) {
	$entries = devxpe_form_entries();
	$entries = array_values(
		array_filter(
			$entries,
			function ( $entry ) use ( $id ) {
				return ! isset( $entry['id'] ) || $entry['id'] !== $id;
			}
		)
	);
	update_option( DEVXPE_FORM_OPTION, $entries, false );
}

/**
 * Tüm mesajları siler.
 *
 * @return void
 */
function devxpe_form_clear_entries() {
	delete_option( DEVXPE_FORM_OPTION );
}

/* ══════════════════════════════════════════════════════════
   Form: okundu / okunmadı
═════════════════════════════════════════════════════════════ */

/**
 * Kayıt okunmadı mı?
 *
 * Veri sözleşmesi: `read` = '1' okundu; boş = okunmadı. Ancak `read` anahtarı
 * hiç yoksa kayıt ESKİ kabul edilir ve OKUNDU sayılır (mevcut kurulumda bir
 * anda yüzlerce okunmadı çıkmasın diye).
 *
 * @param array $entry Form kaydı.
 * @return bool
 */
function devxpe_form_is_unread( $entry ) {
	if ( ! is_array( $entry ) || ! array_key_exists( 'read', $entry ) ) {
		return false;
	}

	return '1' !== (string) $entry['read'];
}

/**
 * Okunmamış mesaj sayısını döndürür.
 *
 * @return int
 */
function devxpe_form_unread_count() {
	$count = 0;

	foreach ( devxpe_form_entries() as $entry ) {
		if ( devxpe_form_is_unread( $entry ) ) {
			$count++;
		}
	}

	return $count;
}

/**
 * Menüdeki kırmızı sayaç rozeti (okunmadı yoksa boş döner).
 *
 * @return string
 */
function devxpe_form_unread_badge() {
	$count = devxpe_form_unread_count();

	if ( $count < 1 ) {
		return '';
	}

	return '<span class="dxp-count-badge">' . esc_html( number_format_i18n( $count ) ) . '</span>';
}

/**
 * Tek bir kaydı okundu/okunmadı olarak işaretler.
 *
 * @param string $id   Kayıt kimliği.
 * @param bool   $read true = okundu, false = okunmadı.
 * @return void
 */
function devxpe_form_mark_read( $id, $read = true ) {
	$id = (string) $id;

	if ( '' === $id ) {
		return;
	}

	$entries = devxpe_form_entries();
	$changed = false;

	foreach ( $entries as $i => $entry ) {
		if ( isset( $entry['id'] ) && (string) $entry['id'] === $id ) {
			$entries[ $i ]['read'] = $read ? '1' : '';
			$changed               = true;
		}
	}

	if ( $changed ) {
		update_option( DEVXPE_FORM_OPTION, $entries, false );
	}
}

/**
 * Tüm kayıtları okundu/okunmadı olarak işaretler.
 *
 * @param bool $read true = okundu, false = okunmadı.
 * @return void
 */
function devxpe_form_mark_all_read( $read = true ) {
	$entries = devxpe_form_entries();

	if ( ! $entries ) {
		return;
	}

	foreach ( $entries as $i => $entry ) {
		$entries[ $i ]['read'] = $read ? '1' : '';
	}

	update_option( DEVXPE_FORM_OPTION, $entries, false );
}

/**
 * Form dosya yüklemelerini işler (dxp_file_ ön ekli alanlar).
 *
 * Tür ve boyut denetimi burada yapılır; hata olursa JSON ile çıkılır.
 *
 * @return array Yüklenen dosya URL'leri.
 */
function devxpe_form_upload_files() {
	$urls = array();

	if ( empty( $_FILES ) ) {
		return $urls;
	}

	require_once ABSPATH . 'wp-admin/includes/file.php';
	$allowed = array_filter( array_map( 'strtolower', array_map( 'trim', explode( ',', (string) devxpe_theme_get( 'contact_upload_types', 'jpg,jpeg,png,webp,pdf' ) ) ) ) );

	foreach ( $_FILES as $fk => $file ) {
		if ( 0 !== strpos( $fk, 'dxp_file_' ) || empty( $file['name'] ) ) {
			continue;
		}
		if ( (int) $file['size'] > 8 * 1024 * 1024 ) {
			wp_send_json_error( array( 'message' => __( 'Dosya çok büyük (en fazla 8 MB).', 'devxpe-theme' ) ) );
		}
		$ext = strtolower( pathinfo( sanitize_file_name( wp_unslash( $file['name'] ) ), PATHINFO_EXTENSION ) );
		if ( ! in_array( $ext, $allowed, true ) ) {
			wp_send_json_error( array( 'message' => __( 'Bu dosya türüne izin verilmiyor.', 'devxpe-theme' ) ) );
		}
		$up = wp_handle_upload( $file, array( 'test_form' => false ) );
		if ( isset( $up['error'] ) ) {
			wp_send_json_error( array( 'message' => $up['error'] ) );
		}
		$urls[] = esc_url_raw( $up['url'] );
	}

	return $urls;
}

/**
 * Teklif formu gönderimini işler (AJAX).
 *
 * Güvenlik: nonce doğrulaması, honeypot alanı ve sunucu tarafı temizleme.
 *
 * @return void
 */
function devxpe_form_submit() {
	if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'devxpe_form' ) ) {
		wp_send_json_error( array( 'message' => __( 'Güvenlik doğrulaması başarısız. Sayfayı yenileyip tekrar deneyin.', 'devxpe-theme' ) ) );
	}

	/* Honeypot: botlar bu gizli alanı doldurur. */
	if ( ! empty( $_POST['website'] ) ) {
		wp_send_json_success( array( 'message' => __( 'Teşekkürler!', 'devxpe-theme' ) ) );
	}

	/* Google reCAPTCHA v3 (açıksa). */
	if ( ! devxpe_verify_recaptcha() ) {
		wp_send_json_error( array( 'message' => __( 'Güvenlik doğrulaması başarısız. Lütfen sayfayı yenileyip tekrar deneyin.', 'devxpe-theme' ) ) );
	}

	$service = sanitize_text_field( wp_unslash( $_POST['service'] ?? '' ) );
	if ( '' === $service ) {
		wp_send_json_error( array( 'message' => __( 'Lütfen bir hizmet seçin.', 'devxpe-theme' ) ) );
	}

	/*
	 * Alanlar panelden gelir; burada türüne göre temizlenir. Böylece müşteri
	 * alan ekleyip çıkarınca/etiketini değiştirince kayıt ve e-posta bozulmaz.
	 */
	$values = array();
	$lines  = array( sprintf( __( 'Hizmet: %s', 'devxpe-theme' ), $service ) );
	$email  = '';

	foreach ( array_merge( devxpe_quote_step_fields( 'project' ), devxpe_quote_step_fields( 'contact' ) ) as $row ) {
		$type = isset( $row['type'] ) ? $row['type'] : 'input';
		$key  = isset( $row['key'] ) ? (string) $row['key'] : '';
		$lbl  = isset( $row['label'] ) ? (string) $row['label'] : $key;

		if ( '' === $key || 'file' === $type ) {
			continue;
		}

		$raw = isset( $_POST[ $key ] ) ? wp_unslash( $_POST[ $key ] ) : '';

		if ( 'textarea' === $type ) {
			$val = sanitize_textarea_field( $raw );
		} elseif ( 'email' === $type ) {
			$val = sanitize_email( $raw );
		} else {
			$val = sanitize_text_field( $raw );
		}

		if ( '1' === ( isset( $row['required'] ) ? $row['required'] : '0' ) && '' === $val ) {
			wp_send_json_error( array( 'message' => __( 'Lütfen zorunlu alanları doldurun.', 'devxpe-theme' ) ) );
		}
		if ( 'email' === $type && '' !== $val && ! is_email( $val ) ) {
			wp_send_json_error( array( 'message' => __( 'Geçerli bir e-posta adresi girin.', 'devxpe-theme' ) ) );
		}
		if ( 'email' === $type && '' !== $val && ! devxpe_form_email_allowed( $val ) ) {
			$dxp_msgs = devxpe_form_messages();
			wp_send_json_error( array( 'message' => $dxp_msgs['tld'] ) );
		}
		/* Telefon: seçilen ülke kodu numaranın başına eklenir. */
		if ( 'tel' === $type && '' !== $val ) {
			$val = devxpe_form_apply_country( $key, $val );
		}

		$values[ $key ] = $val;
		if ( '' !== $val ) {
			$lines[] = $lbl . ': ' . $val;
		}
		if ( 'email' === $type && '' !== $val ) {
			$email = $val;
		}
	}

	/* Dosyalar: ortak yükleyici (dxp_file_ ön eki). */
	$file_urls = devxpe_form_upload_files();
	if ( $file_urls ) {
		$lines[] = __( 'Dosya', 'devxpe-theme' ) . ': ' . implode( ', ', $file_urls );
	}

	$fields = array_merge( array( 'service' => $service ), $values );
	if ( $file_urls ) {
		$fields['file'] = $file_urls[0];
	}

	$entry         = devxpe_form_add_entry( $fields );
	$entry['ip']   = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';

	/* Konu değişkenleri: kayıt no (en yeni = 1), tarih ve kimlik. */
	$fields['no']   = count( (array) devxpe_form_entries() );
	$fields['date'] = date_i18n( (string) get_option( 'date_format' ) . ' H:i' );
	$fields['id']   = isset( $entry['id'] ) ? (string) $entry['id'] : '';

	/* E-posta bildirimi — virgülle ayrılmış çoklu alıcı desteklenir. */
	$to      = devxpe_form_recipients();
	$subject = (string) devxpe_theme_get( 'form_subject' );

	if ( '' === trim( $subject ) ) {
		/* Varsayılan konu biçimi: #kayıt no | hizmet | ad soyad */
		$subject = '#{no} | {service} | {name}';
	}

	/* Konudaki {alan} değişkenleri gönderilen değerlerle doldurulur. */
	$subject = devxpe_form_fill_tokens( $subject, $fields );

	wp_mail( $to, $subject, implode( "\n", $lines ) );

	/* Gönderilen mailin içeriği panelde görünsün diye kayda yazılır. */
	devxpe_form_set_entry_mail( $entry['id'], $subject, implode( "\n", $lines ) );

	$success = devxpe_theme_get( 'form_success' );
	if ( ! $success ) {
		$success = __( 'Teşekkürler! En kısa sürede size döneceğiz.', 'devxpe-theme' );
	}

	wp_send_json_success( array( 'message' => $success ) );
}
add_action( 'wp_ajax_devxpe_form_submit', 'devxpe_form_submit' );
add_action( 'wp_ajax_nopriv_devxpe_form_submit', 'devxpe_form_submit' );

/* ══════════════════════════════════════════════════════════
   SMTP — form e-postaları kendi sunucudan gönderilsin
══════════════════════════════════════════════════════════ */

/**
 * PHPMailer'ı panelden girilen SMTP ayarlarıyla yapılandırır.
 *
 * SMTP kapalıysa ya da sunucu boşsa hiçbir şey yapılmaz; WordPress'in
 * kendi gönderim yolu kullanılır.
 *
 * @param PHPMailer\PHPMailer\PHPMailer $phpmailer PHPMailer nesnesi.
 * @return void
 */
function devxpe_smtp_configure( $phpmailer ) {
	if ( '1' !== devxpe_theme_get( 'smtp_enable' ) ) {
		return;
	}

	$host = trim( (string) devxpe_theme_get( 'smtp_host' ) );
	if ( '' === $host ) {
		return;
	}

	$port = (int) devxpe_theme_get( 'smtp_port', '587' );
	$enc  = (string) devxpe_theme_get( 'smtp_encryption', 'tls' );

	$phpmailer->isSMTP();
	$phpmailer->Host = $host;
	$phpmailer->Port = $port > 0 ? $port : 587;

	if ( in_array( $enc, array( 'ssl', 'tls' ), true ) ) {
		$phpmailer->SMTPSecure = $enc;
	} else {
		$phpmailer->SMTPSecure  = '';
		$phpmailer->SMTPAutoTLS = false;
	}

	if ( '1' === devxpe_theme_get( 'smtp_auth', '1' ) ) {
		$phpmailer->SMTPAuth = true;
		$phpmailer->Username = (string) devxpe_theme_get( 'smtp_user' );
		$phpmailer->Password = (string) devxpe_theme_get( 'smtp_pass' );
	} else {
		$phpmailer->SMTPAuth = false;
	}

	$from = sanitize_email( (string) devxpe_theme_get( 'smtp_from_email' ) );
	if ( $from ) {
		$phpmailer->From = $from;
	}

	$from_name = trim( (string) devxpe_theme_get( 'smtp_from_name' ) );
	if ( '' !== $from_name ) {
		$phpmailer->FromName = $from_name;
	}
}
add_action( 'phpmailer_init', 'devxpe_smtp_configure' );

/**
 * Gönderim hatasını geçici olarak saklar; panelde gösterilir.
 *
 * @param WP_Error $wp_error Hata nesnesi.
 * @return void
 */
function devxpe_smtp_capture_error( $wp_error ) {
	if ( is_wp_error( $wp_error ) ) {
		set_transient( 'devxpe_smtp_notice', $wp_error->get_error_message(), 60 );
	}
}
add_action( 'wp_mail_failed', 'devxpe_smtp_capture_error' );

/**
 * Panelden test e-postası gönderir ve panele geri döner.
 *
 * @return void
 */
function devxpe_smtp_test() {
	if ( ! isset( $_POST['dxp_smtp_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['dxp_smtp_nonce'] ) ), 'devxpe_smtp_test' ) ) {
		wp_die( esc_html__( 'Güvenlik doğrulaması başarısız.', 'devxpe-theme' ) );
	}
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Bu işlem için yetkiniz yok.', 'devxpe-theme' ) );
	}

	$to = isset( $_POST['dxp_smtp_to'] ) ? sanitize_email( wp_unslash( $_POST['dxp_smtp_to'] ) ) : '';
	$ok = false;

	if ( is_email( $to ) ) {
		$site    = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		$subject = sprintf( __( '%s — SMTP test e-postası', 'devxpe-theme' ), $site );
		$body    = __( 'Bu e-posta panelin SMTP ayarları üzerinden gönderildi. Ayarlar çalışıyor.', 'devxpe-theme' );
		$ok      = wp_mail( $to, $subject, $body );
	}

	$back = wp_get_referer();
	if ( ! $back ) {
		$back = admin_url();
	}

	wp_safe_redirect( add_query_arg( 'dxp_smtp', $ok ? 'ok' : 'fail', $back ) );
	exit;
}
add_action( 'admin_post_devxpe_smtp_test', 'devxpe_smtp_test' );

/**
 * Basit iletişim formu gönderimini işler (AJAX).
 *
 * Ad/Soyad/Telefon/E-posta/Mesaj + isteğe bağlı onay kutusu ve dosya.
 *
 * @return void
 */
function devxpe_contact_submit() {
	check_ajax_referer( 'devxpe_form', 'nonce' );

	/* Google reCAPTCHA v3 (açıksa). */
	if ( ! devxpe_verify_recaptcha() ) {
		wp_send_json_error( array( 'message' => __( 'Güvenlik doğrulaması başarısız. Lütfen sayfayı yenileyip tekrar deneyin.', 'devxpe-theme' ) ) );
	}

	$slug  = isset( $_POST['dxp_form_slug'] ) ? sanitize_key( wp_unslash( $_POST['dxp_form_slug'] ) ) : devxpe_active_form_slug();
	$forms = devxpe_custom_forms();
	if ( ! isset( $forms[ $slug ] ) ) {
		$slug = devxpe_active_form_slug();
	}
	$fields = devxpe_form_fields( $slug );

	$lines     = array();
	$first     = '';
	$email_val = '';
	$phone_val = '';

	foreach ( $fields as $f ) {
		$type  = isset( $f['type'] ) ? $f['type'] : 'text';
		$label = isset( $f['label'] ) ? $f['label'] : '';
		$key   = isset( $f['key'] ) ? $f['key'] : '';
		$req   = ! empty( $f['required'] );
		$name  = 'field_' . $key;

		if ( 'file' === $type ) {
			continue; // Dosyalar ayrı işlenir.
		}

		if ( 'checkbox' === $type ) {
			$checked = ! empty( $_POST[ $name ] );
			if ( $req && ! $checked ) {
				/* translators: %s: field label. */
				wp_send_json_error( array( 'message' => sprintf( __( '"%s" alanı zorunludur.', 'devxpe-theme' ), $label ) ) );
			}
			$val = $checked ? __( 'Evet', 'devxpe-theme' ) : __( 'Hayır', 'devxpe-theme' );
		} else {
			$raw = isset( $_POST[ $name ] ) ? wp_unslash( $_POST[ $name ] ) : '';
			$val = ( 'textarea' === $type ) ? sanitize_textarea_field( $raw ) : sanitize_text_field( $raw );

			/* Telefon: seçilen ülke kodu numaranın başına eklenir. */
			if ( 'tel' === $type && '' !== $val ) {
				$val = devxpe_form_apply_country( preg_replace( '/^field_/', '', (string) $name ), $val );
			}

			if ( $req && '' === trim( (string) $val ) ) {
				/* translators: %s: field label. */
				wp_send_json_error( array( 'message' => sprintf( __( '"%s" alanı zorunludur.', 'devxpe-theme' ), $label ) ) );
			}
			if ( 'email' === $type && '' !== $val && ! is_email( $val ) ) {
				wp_send_json_error( array( 'message' => __( 'Geçerli bir e-posta adresi girin.', 'devxpe-theme' ) ) );
			}
			if ( 'email' === $type && '' !== $val && ! devxpe_form_email_allowed( $val ) ) {
				$dxp_msgs = devxpe_form_messages();
				wp_send_json_error( array( 'message' => $dxp_msgs['tld'] ) );
			}
			if ( '' === $first && '' !== trim( (string) $val ) ) {
				$first = $val;
			}
			if ( 'email' === $type && '' !== $val ) {
				$email_val = $val;
			}
			if ( 'tel' === $type && '' !== $val ) {
				$phone_val = $val;
			}
		}

		$lines[] = $label . ': ' . $val;
	}

	if ( '1' === devxpe_theme_get( 'contact_consent_enable', '1' ) && empty( $_POST['consent'] ) ) {
		wp_send_json_error( array( 'message' => __( 'Lütfen onay kutusunu işaretleyin.', 'devxpe-theme' ) ) );
	}

	/* Dosyalar */
	$file_urls = devxpe_form_upload_files();
	if ( $file_urls ) {
		$lines[] = __( 'Dosya', 'devxpe-theme' ) . ': ' . implode( ', ', $file_urls );
	}

	$entry = array(
		'type'    => 'contact',
		'name'    => $first,
		'email'   => $email_val,
		'phone'   => $phone_val,
		'service' => isset( $forms[ $slug ]['name'] ) ? $forms[ $slug ]['name'] : __( 'İletişim formu', 'devxpe-theme' ),
		'details' => implode( "\n", $lines ),
		'file'    => $file_urls ? $file_urls[0] : '',
	);

	devxpe_form_add_entry( $entry );

	/* E-posta bildirimi — çoklu alıcı desteklenir. */
	$to = devxpe_form_recipients();

	$contact_subject = sprintf( __( 'Yeni iletişim mesajı: %s', 'devxpe-theme' ), $entry['name'] );
	$contact_body    = implode( "\n", $lines );

	wp_mail( $to, $contact_subject, $contact_body );

	/* Gönderilen mailin içeriği panelde görünsün diye kayda yazılır. */
	$kayit = devxpe_form_entries();
	if ( isset( $kayit[0]['id'] ) ) {
		devxpe_form_set_entry_mail( $kayit[0]['id'], $contact_subject, $contact_body );
	}

	/* Başarı mesajı: teklif formuyla aynı alan (tek yerden yönetim). */
	$success = devxpe_theme_get( 'form_success' );
	if ( ! $success ) {
		$success = __( 'Mesajınız için teşekkürler! En kısa sürede dönüş yapacağız.', 'devxpe-theme' );
	}

	wp_send_json_success( array( 'message' => $success ) );
}
add_action( 'wp_ajax_devxpe_contact_submit', 'devxpe_contact_submit' );
add_action( 'wp_ajax_nopriv_devxpe_contact_submit', 'devxpe_contact_submit' );

/**
 * Basit iletişim formunu her yere gömmek için kısa kod: [devxpe_contact_form]
 *
 * @return string
 */
function devxpe_contact_form_shortcode( $atts = array() ) {
	$atts = shortcode_atts( array( 'slug' => '' ), $atts, 'devxpe_form' );

	ob_start();
	get_template_part( 'template-parts/contact-form', null, array( 'slug' => $atts['slug'] ) );
	return ob_get_clean();
}
add_shortcode( 'devxpe_contact_form', 'devxpe_contact_form_shortcode' );
add_shortcode( 'devxpe_form', 'devxpe_contact_form_shortcode' );

/**
 * Popup açan link kısa kodu.
 *
 * Kullanım: [devxpe_popup]Duyuruyu gör[/devxpe_popup]
 * ya da:    [devxpe_popup text="Duyuruyu gör" class="btn"]
 *
 * @param array       $atts    Kısa kod öznitelikleri.
 * @param string|null $content Kısa kod içeriği (link yazısı).
 * @return string
 */
function devxpe_popup_shortcode( $atts = array(), $content = null ) {
	$atts = shortcode_atts(
		array(
			'text'  => '',
			'class' => '',
		),
		$atts,
		'devxpe_popup'
	);

	$label = '' !== $atts['text'] ? $atts['text'] : (string) $content;
	if ( '' === trim( $label ) ) {
		$label = __( 'Duyuruyu gör', 'devxpe-theme' );
	}

	$class = trim( 'dxp-popup-open ' . $atts['class'] );

	return '<a class="' . esc_attr( $class ) . '" href="#duyuru" data-dxp-popup>' . esc_html( $label ) . '</a>';
}
add_shortcode( 'devxpe_popup', 'devxpe_popup_shortcode' );

/**
 * Panelden mesaj silme (admin-post).
 *
 * @return void
 */
function devxpe_form_handle_delete() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Yetkiniz yok.', 'devxpe-theme' ) );
	}
	check_admin_referer( 'devxpe_form_delete' );

	$id = isset( $_GET['id'] ) ? sanitize_text_field( wp_unslash( $_GET['id'] ) ) : '';

	if ( 'all' === $id ) {
		devxpe_form_clear_entries();
	} else {
		devxpe_form_delete_entry( $id );
	}

	wp_safe_redirect( admin_url( 'admin.php?page=' . DEVXPE_Theme_Panel::MENU_SLUG . '#form/inbox' ) );
	exit;
}
add_action( 'admin_post_devxpe_form_delete', 'devxpe_form_handle_delete' );

/**
 * Panelden toplu/tek okundu işaretleme (admin-post).
 *
 * Parametreler: scope = all | unread | one; id (scope=one); okundu = 1 | 0.
 *
 * @return void
 */
function devxpe_form_handle_read() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Yetkiniz yok.', 'devxpe-theme' ) );
	}
	check_admin_referer( 'devxpe_form_read' );

	$scope  = isset( $_GET['scope'] ) ? sanitize_key( wp_unslash( $_GET['scope'] ) ) : 'one';
	$okundu = isset( $_GET['okundu'] ) && '1' === (string) wp_unslash( $_GET['okundu'] );

	if ( 'all' === $scope ) {
		devxpe_form_mark_all_read( $okundu );
	} elseif ( 'unread' === $scope ) {
		devxpe_form_mark_all_read( false );
	} elseif ( 'one' === $scope ) {
		$id = isset( $_GET['id'] ) ? sanitize_text_field( wp_unslash( $_GET['id'] ) ) : '';
		devxpe_form_mark_read( $id, $okundu );
	}

	$back = wp_get_referer();
	wp_safe_redirect( $back ? $back : admin_url() );
	exit;
}
add_action( 'admin_post_devxpe_form_read', 'devxpe_form_handle_read' );

/**
 * AJAX: tek mesajı okundu işaretler (panelde detay açılınca).
 *
 * Dönüş: { success: true, data: { unread: N } } — rozetler bu sayıyla güncellenir.
 *
 * @return void
 */
function devxpe_form_ajax_read() {
	check_ajax_referer( 'devxpe_form_read', 'nonce' );

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => 'yetki' ) );
	}

	$id = isset( $_POST['id'] ) ? sanitize_text_field( wp_unslash( $_POST['id'] ) ) : '';

	if ( '' !== $id ) {
		devxpe_form_mark_read( $id, true );
	}

	wp_send_json_success( array( 'unread' => devxpe_form_unread_count() ) );
}
add_action( 'wp_ajax_devxpe_form_read_ajax', 'devxpe_form_ajax_read' );

