<?php
/**
 * Tema varlıkları (CSS/JS) ve Elementor varlık yönetimi.
 *
 * functions.php'den ayrıldı.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Görüntülenen sayfada "Sayfa İçeriği" widget'ı çiziliyor mu?
 *
 * Widget çıktısı üreten yerler:
 *  - Hakkımızda / İletişim tipi sayfalar (`_dxp_page_type` → about/contact),
 *  - panelde tanımlı içerik tiplerinin tekil sayfaları (single.php),
 *  - kayıtlı widget listesi olan sayfalar (gelecekte şablon çizerse).
 *
 * @return bool
 */
function devxpe_front_uses_widgets() {
	if ( ! is_singular() || ! class_exists( 'DEVXPE_Page_Widgets' ) ) {
		return false;
	}

	$post_id = (int) get_queried_object_id();
	if ( ! $post_id ) {
		return false;
	}

	/* about/contact sayfa tipi veya panelde tanımlı CPT bağlamı. */
	if ( '' !== DEVXPE_Page_Widgets::baglam_bul( $post_id ) ) {
		return true;
	}

	/* Normal sayfada kayıtlı widget listesi varsa stiller gerekebilir. */
	return (bool) DEVXPE_Page_Widgets::veri( $post_id );
}

/**
 * Görüntülenen sayfada herhangi bir form / teklif formu var mı?
 *
 * Form çizilen yerler:
 *  - anasayfa "Teklif Formu" bölümü (açıksa),
 *  - İletişim tipi sayfa (şablon her zaman bir form çizer),
 *  - widget listesinde `form` veya `cpt_quote` bulunan sayfa/CPT,
 *  - kayıtlı listesi olmayan CPT tekil (varsayılan tema dizilimi `cpt_quote`).
 *
 * @return bool
 */
function devxpe_front_uses_forms() {
	/* Anasayfa: form bölümü açık mı? (Diğer sayfalarda false döner.) */
	if ( is_front_page() ) {
		return devxpe_section_visible( 'form' );
	}

	if ( ! is_singular() || ! class_exists( 'DEVXPE_Page_Widgets' ) ) {
		return false;
	}

	$post_id = (int) get_queried_object_id();
	if ( ! $post_id ) {
		return false;
	}

	$baglam = DEVXPE_Page_Widgets::baglam_bul( $post_id );

	/* İletişim sayfası: kayıtlı widget formu olsa da olmasa da form çizilir. */
	if ( 'contact' === $baglam ) {
		return true;
	}

	/* Widget listesinde iletişim formu (sayfa/CPT). */
	if ( DEVXPE_Page_Widgets::icerir( $post_id, 'form' ) ) {
		return true;
	}

	/* CPT tekil: teklif formu bölümü açık ve listede/varsayılanda var mı? */
	if ( '' !== $baglam && ! in_array( $baglam, array( 'about', 'contact' ), true ) ) {
		$type = get_post_type( $post_id );
		if ( $type && devxpe_cpt_section_visible( $type, 'quote' )
			&& ( DEVXPE_Page_Widgets::icerir( $post_id, 'cpt_quote' ) || ! DEVXPE_Page_Widgets::veri( $post_id ) ) ) {
			return true;
		}
	}

	return false;
}

/**
 * Tema CSS'ini ve panelden gelen renk değişkenlerini yükler.
 *
 * @return void
 */
function devxpe_theme_assets() {
	wp_enqueue_style( 'devxpe-fonts', DEVXPE_THEME_URL . 'assets/css/public-sans.css', array(), filemtime( DEVXPE_THEME_PATH . 'assets/css/public-sans.css' ) );
	$style_ver = filemtime( DEVXPE_THEME_PATH . 'style.css' ) . '-' . substr( md5( serialize( get_option( DEVXPE_Theme_Fields::OPTION_KEY, array() ) ) ), 0, 8 );
	wp_enqueue_style( 'devxpe-theme-style', DEVXPE_THEME_URL . 'style.css', array(), $style_ver );
	wp_enqueue_style( 'dashicons' );

	/*
	 * Widget/form düzeni yalnızca ilgili sayfalarda yüklenir. Dosyalar yoksa
	 * (henüz üretilmemiş sürüm) atlanır; kullanılan yerlerde gerekli stiller
	 * style.css'ten gelir.
	 */
	if ( devxpe_front_uses_widgets() && file_exists( DEVXPE_THEME_PATH . 'assets/css/widgets.css' ) ) {
		wp_enqueue_style( 'devxpe-widgets', DEVXPE_THEME_URL . 'assets/css/widgets.css', array( 'devxpe-theme-style' ), filemtime( DEVXPE_THEME_PATH . 'assets/css/widgets.css' ) );
	}
	if ( devxpe_front_uses_forms() && file_exists( DEVXPE_THEME_PATH . 'assets/css/forms.css' ) ) {
		wp_enqueue_style( 'devxpe-forms', DEVXPE_THEME_URL . 'assets/css/forms.css', array( 'devxpe-theme-style' ), filemtime( DEVXPE_THEME_PATH . 'assets/css/forms.css' ) );
	}

	/* Arşiv ve tekil içerik düzeni (şablonlara özel). */
	if ( is_archive() || is_home() || is_search() ) {
		wp_enqueue_style( 'devxpe-archive', DEVXPE_THEME_URL . 'assets/css/archive.css', array( 'devxpe-theme-style' ), filemtime( DEVXPE_THEME_PATH . 'assets/css/archive.css' ) );
	}
	if ( is_singular() && ! is_page() ) {
		wp_enqueue_style( 'devxpe-single', DEVXPE_THEME_URL . 'assets/css/single.css', array( 'devxpe-theme-style' ), filemtime( DEVXPE_THEME_PATH . 'assets/css/single.css' ) );
	}

	$primary   = devxpe_theme_get( 'primary_color', '#006731' );
	$secondary = devxpe_theme_get( 'secondary_color', '#033216' );
	$harmonize = '1' === devxpe_theme_get( 'harmonize_colors', '1' );

	/*
	 * Link rengi: uyum açıkken ana renge bağlanır (hover = koyu ton).
	 * Kapalıyken elle seçilen link rengi kullanılır.
	 */
	if ( '1' === devxpe_theme_get( 'link_harmonize', '1' ) ) {
		$link       = $primary;
		$link_hover = 'color-mix(in srgb, ' . $primary . ', black 12%)';
	} else {
		$link       = devxpe_theme_get( 'link_color', $primary );
		$link_hover = $link;
	}

	/*
	 * Header yazı rengi: uyum açıkken ana rengin açık tonuna bağlanır.
	 * Kapalıyken elle seçilen header yazı rengi kullanılır.
	 */
	if ( '1' === devxpe_theme_get( 'header_text_harmonize', '0' ) ) {
		$header_text       = 'color-mix(in srgb, ' . $primary . ', white 25%)';
		$header_text_hover = 'color-mix(in srgb, ' . $primary . ', white 45%)';
	} else {
		$header_text       = devxpe_theme_get( 'header_text', '#033216' );
		$header_text_hover = $header_text;
	}

	/*
	 * Uyum açıkken: hover = ana rengin beyazla açılmış tonu, focus/aktif =
	 * siyahla koyulaştırılmış tonu. Kapalıyken tüm durumlar ana rengi kullanır.
	 */
	if ( $harmonize ) {
		$primary_hover   = 'color-mix(in srgb, ' . $primary . ', white 18%)';
		$primary_focus   = 'color-mix(in srgb, ' . $primary . ', black 18%)';
		$secondary_hover = 'color-mix(in srgb, ' . $secondary . ', white 18%)';
		$secondary_focus = 'color-mix(in srgb, ' . $secondary . ', black 18%)';
	} else {
		$manual_hover    = devxpe_theme_get( 'primary_hover' );
		$manual_focus    = devxpe_theme_get( 'primary_focus' );
		$primary_hover   = $manual_hover ? $manual_hover : $primary;
		$primary_focus   = $manual_focus ? $manual_focus : $primary;
		$secondary_hover = $secondary;
		$secondary_focus = $secondary;
	}
	
	$service_icon_color = $primary;

	$colors = array(
		/* tema paleti — referans sitenin birebir renkleri */
		'--brand-green'        => '#006731',
		'--brand-green-dark'   => '#00461b',
		'--brand-charcoal'     => '#033216',
		'--brand-paper'        => '#f6fcf7',
		'--brand-whatsapp'     => '#3fc168',
		'--dxp-accent'         => '#ddf1e1',
		'--dxp-accent-fg'      => '#00461b',
		'--dxp-border'         => '#dae4dc',
		'--dxp-muted'          => '#ebf5ed',
		'--dxp-muted-fg'       => '#57685b',

		'--dxp-primary'          => $primary,
		'--dxp-service-icon'     => $service_icon_color,
		'--dxp-primary-hover'    => $primary_hover,
		'--dxp-primary-focus'    => $primary_focus,
		'--dxp-primary-soft'     => 'color-mix(in srgb, ' . $primary . ', transparent 85%)',
		'--dxp-primary-contrast' => devxpe_theme_contrast_color( $primary ),
		
		'--dxp-secondary'          => $secondary,
		'--dxp-secondary-hover'    => $secondary_hover,
		'--dxp-secondary-focus'    => $secondary_focus,
		'--dxp-secondary-soft'     => 'color-mix(in srgb, ' . $secondary . ', transparent 85%)',
		'--dxp-secondary-contrast' => devxpe_theme_contrast_color( $secondary ),
		
		'--dxp-link'        => $link,
		'--dxp-link-hover'  => $link_hover,
		
		'--dxp-text'      => devxpe_theme_get( 'text_color', '#033216' ),
		'--dxp-header-bg' => devxpe_theme_get( 'header_bg', '#f6fcf7' ),
		'--dxp-header-text' => $header_text,
		'--dxp-header-text-hover' => $header_text_hover,
		/*
		 * Footer zemini + yazı rengi panelden gelir.
		 * Yazı rengi boşsa zemine göre kontrast otomatik seçilir.
		 */
		'--dxp-footer-bg' => devxpe_theme_get( 'footer_bg', '#09090b' ),
		'--dxp-footer-text' => ( '' !== (string) devxpe_theme_get( 'footer_text', '' ) )
			? devxpe_theme_get( 'footer_text', '' )
			: devxpe_theme_contrast_color( devxpe_theme_get( 'footer_bg', '#09090b' ) ),

		/*
		 * Sayfa düzeni: içerik sarmalayıcılarının azami genişliği ve yan boşluğu.
		 * Tam genişlik → kenarlara yakın; dar düzen → yanlarda daha çok boşluk.
		 */
		'--dxp-wrap-max' => ( 'full' === devxpe_theme_get( 'layout', 'boxed' ) ) ? 'none' : '1280px',
		'--dxp-wrap-pad' => ( 'full' === devxpe_theme_get( 'layout', 'boxed' ) ) ? '20px' : '32px',
	);

	$css = ':root{' . implode( ';', array_map( 'devxpe_theme_build_var', array_keys( $colors ), $colors ) ) . '}';

	/* Tipografi ve Google Fonts */
	$google_fonts = array();
	$typo_fields = array(
		'body' => 'typo_body',
		'h1'   => 'typo_h1',
		'h2'   => 'typo_h2',
		'h3'   => 'typo_h3',
		'h4'   => 'typo_h4',
		'h5'   => 'typo_h5',
		'h6'   => 'typo_h6',
	);

	foreach ( $typo_fields as $selector => $field_id ) {
		$val = devxpe_theme_get( $field_id, array() );
		$val = wp_parse_args( (array) $val, array( 'family' => 'system', 'size' => '', 'weight' => '', 'lh' => '', 'ls' => '' ) );
		
		$css_sel = ( 'body' === $selector ) ? 'body, p, div, span, section' : $selector;
		$css .= $css_sel . ' { ';
		
		if ( 'system' !== $val['family'] && '' !== $val['family'] ) {
			if ( strpos( $val['family'], 'var(' ) === 0 ) {
				$css .= 'font-family: ' . esc_attr( $val['family'] ) . '; ';
			} else {
				$css .= 'font-family: "' . esc_attr( $val['family'] ) . '", sans-serif; ';
				$google_fonts[] = $val['family'];
			}
		}
		
		if ( ! empty( $val['size'] ) ) { $css .= 'font-size: ' . esc_attr( $val['size'] ) . '; '; }
		if ( ! empty( $val['weight'] ) ) { $css .= 'font-weight: ' . esc_attr( $val['weight'] ) . '; '; }
		if ( ! empty( $val['lh'] ) ) { $css .= 'line-height: ' . esc_attr( $val['lh'] ) . '; '; }
		if ( ! empty( $val['ls'] ) ) { $css .= 'letter-spacing: ' . esc_attr( $val['ls'] ) . '; '; }
		
		$css .= '} ';
	}

	$google_fonts = array_unique( $google_fonts );
	if ( ! empty( $google_fonts ) ) {
		$font_family_args = array();
		foreach ( $google_fonts as $gf ) {
			$font_family_args[] = 'family=' . urlencode( $gf ) . ':wght@300;400;500;600;700;800;900';
		}
		$font_url = 'https://fonts.googleapis.com/css2?' . implode( '&', $font_family_args ) . '&display=swap';
		wp_enqueue_style( 'devxpe-google-fonts', $font_url, array(), null );
	}

	/*
	 * Mobil kırılma noktası (panelden).
	 *
	 * Menü / hamburger görünürlüğü burada, tek yerde yönetilir.
	 */
	$bp = absint( devxpe_theme_get( 'mobile_breakpoint', '992' ) );
	if ( $bp < 320 ) {
		$bp = 992;
	}

	$css .= '@media (max-width: ' . esc_attr( $bp ) . 'px) {';
	$css .= '.dxp-nav-wrap { display: none !important; }';
	$css .= '.dxp-burger { display: inline-flex !important; }';
	$css .= '}';

	$css .= '@media (min-width: ' . esc_attr( $bp + 1 ) . 'px) {';
	$css .= '.dxp-nav-wrap { display: block !important; }';
	$css .= '.dxp-burger { display: none !important; }';
	$css .= '.dxp-mobile-menu { display: none !important; }';
	$css .= '}';

	/*
	 * "Sabit Mobil Header": yalnızca kırılma noktasının altında yapışkan.
	 * (Masaüstü "Sabit Header" ayarı ayrıdır.)
	 */
	if ( '1' === devxpe_theme_get( 'sticky_mobile' ) ) {
		$css .= '@media (max-width: ' . esc_attr( $bp ) . 'px) {';
		$css .= '.dxp-header--sticky-mobile { position: sticky; top: 0; }';
		$css .= '.admin-bar .dxp-header--sticky-mobile { top: var(--wp-admin--admin-bar--height, 32px); }';
		$css .= '}';
	}

	/*
	 * Şablon 2 (mobil alt bar): yalnızca kırılma noktasının altında görünür;
	 * içeriğin altına bar yüksekliği kadar boşluk bırakılır.
	 */
	if ( '1' === devxpe_theme_get( 'float_enable', '1' ) && 'bar' === devxpe_theme_get( 'float_style', 'classic' ) ) {
		$css .= '@media (max-width: ' . esc_attr( $bp ) . 'px) {';
		$css .= '.dxp-mbar { display: flex; }';
		/*
		 * ŞABLON 2'YE ÖZEL: sabit alt bar, footer'ın son satırını (telif +
		 * yasal linkler) kapatmasın diye footer'a bar yüksekliği kadar boşluk
		 * verilir. Boşluk footer zemininde kaldığı için beyaz şerit oluşmaz.
		 * Şablon 1'i (classic) ETKİLEMEZ; o dalda boşluk verilmez.
		 * 64px = alt bar yüksekliği (~60px) + küçük pay; gereksiz boşluk bırakmaz.
		 */
		$css .= '.dxp-footer { padding-bottom: 64px; }';
		/* Mobil/tablet'te footer iç boşluğu daha kompakt (16px yeterli; yan 20px korunur). */
		$css .= '.dxp-footer-inner { padding: 16px 20px; }';
		/* Yukarı çık oku barın üstünde dursun (her iki şablonda da var). */
		$css .= '.dxp-mbar ~ .dxp-float--top { bottom: 90px; }';
		$css .= '}';
		/* Masaüstünde WhatsApp yüzen butonu görünür (Şablon 1'deki gibi solda). */
		$css .= '@media (min-width: ' . ( absint( $bp ) + 1 ) . 'px) { .dxp-float--wa.dxp-desktop-only { display: flex; } }';
	}

	/*
	 * Şablon 1 (yüzen butonlar): sayfa altına EK boşluk BIRAKILMAZ.
	 *
	 * Önceden mobilde `body { padding-bottom: 76px }` ile sayfa uzatılıyordu;
	 * bu, footer'ın altında gereksiz bir şerit oluşturuyordu. Kaldırıldı:
	 * yüzen butonlar footer'ın üzerine binebilir, ama sayfa uzamaz.
	 */

	/*
	 * Hamburger ikon rengi.
	 *
	 * Hamburger bir SVG'dir (stroke: currentColor), bu yüzden renk doğrudan
	 * butona verilir.
	 */
	$burger_color = devxpe_theme_get( 'burger_color' );
	if ( $burger_color ) {
		$css .= '.dxp-burger { color: ' . esc_attr( $burger_color ) . ' !important; }';
	}

	/* Yuvarlak Görseller: görsel kutusuyla birlikte yuvarlanır ki kart/çerçeve
	   köşeleriyle çakışıp tuhaf görünmesin. */
	if ( '1' === devxpe_theme_get( 'rounded_image' ) ) {
		$css .= '.dxp-main img, .dxp-sidebar img, .card-img-top, .entry-content img, .post-thumbnail img { border-radius: 8px; }';
		$css .= '.dxp-card-media, .dxp-project-media { border-radius: 8px; overflow: hidden; }';
		$css .= '.dxp-card-media img, .dxp-project-media img, .dxp-hero-media-frame img { border-radius: inherit; }';
	}

	wp_add_inline_style( 'devxpe-theme-style', $css );

	/*
	 * Ön yüz küçük efektleri: SSS akordeonu.
	 *
	 * referans tasarımdaki Radix akordeon, içeriği ÖNCE ölçüp sonra yüksekliği
	 * 0 → ölçülen px arasında 200ms ease-out ile canlandırır. Aynı yöntem:
	 * açmadan önce details açılır (yoksa kapalıyken scrollHeight 0 döner),
	 * yükseklik ölçülür ve animasyon başlatılır. Kapanış da aynı şekilde
	 * animasyonlu çalışır (önce 0'a iner, sonra details kapanır).
	 */
	/*
	 * Ön yüz betiği: statik davranışlar (akordeon, doğrulama, mobil menü,
	 * yüzen butonlar, popup) assets/js/front.js içindedir → tarayıcıda
	 * önbelleklenir, sayfa geçişleri hızlanır. Panelden üretilen dinamik
	 * ayarlar küçük inline blok olarak KALIR ve dosyadan ÖNCE basılır.
	 */
	wp_enqueue_script(
		'devxpe-front',
		DEVXPE_THEME_URL . 'assets/js/front.js',
		array(),
		filemtime( DEVXPE_THEME_PATH . 'assets/js/front.js' ),
		true
	);

	/* Form ayarları yalnızca form bulunan sayfalarda basılır. */
	if ( devxpe_front_uses_forms() ) {
		wp_add_inline_script( 'devxpe-front', 'window.dxpFormMsgs = ' . wp_json_encode( devxpe_form_messages() ) . ';', 'before' );
		wp_add_inline_script( 'devxpe-front', 'window.dxpFormConfig = ' . wp_json_encode( devxpe_form_config() ) . ';', 'before' );
	}

	/* reCAPTCHA v3: site anahtarı JS'e verilir, betik yalnızca açıkken yüklenir. */
	if ( devxpe_recaptcha_enabled() ) {
		wp_add_inline_script( 'devxpe-front', 'window.dxpRecaptchaKey = ' . wp_json_encode( (string) devxpe_theme_get( 'recaptcha_site_key' ) ) . ';', 'before' );
		wp_enqueue_script(
			'devxpe-recaptcha',
			'https://www.google.com/recaptcha/api.js?render=' . rawurlencode( (string) devxpe_theme_get( 'recaptcha_site_key' ) ),
			array(),
			null,
			true
		);
	}
}

/**
 * Panelden gelen head script'ini wp_head sonuna ekler.
 *
 * @return void
 */
function devxpe_theme_head_scripts() {
	$scripts = devxpe_theme_get( 'script_head' );
	if ( $scripts ) {
		echo $scripts;
	}
}
add_action( 'wp_head', 'devxpe_theme_head_scripts', 99 );

/**
 * CSS değişkeni metni oluşturur: '--ad: value' döndürür.
 *
 * @param string $key   Değişken adı.
 * @param string $value Değer.
 * @return string
 */
function devxpe_theme_build_var( $key, $value ) {
	return $key . ': ' . $value;
}

/**
 * Ana renge göre okunabilir metin rengini (siyah/beyaz) döndürür.
 *
 * Arka plan açıksa koyu, koyuysa açık metin verir. Hex olmayan
 * değerlerde (örn. Elementor var(--...) renkleri) güvenli varsayılan
 * olarak beyaz döner.
 *
 * @param string $color Hex renk (#rgb veya #rrggbb).
 * @return string
 */
function devxpe_theme_contrast_color( $color ) {
	if ( ! preg_match( '/^#([0-9a-f]{3}|[0-9a-f]{6})$/i', trim( (string) $color ), $m ) ) {
		return '#ffffff';
	}

	$hex = $m[1];
	if ( 3 === strlen( $hex ) ) {
		$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
	}

	$r = hexdec( substr( $hex, 0, 2 ) ) / 255;
	$g = hexdec( substr( $hex, 2, 2 ) ) / 255;
	$b = hexdec( substr( $hex, 4, 2 ) ) / 255;
	$luminance = 0.2126 * $r + 0.7152 * $g + 0.0722 * $b;

	return ( $luminance > 0.6 ) ? '#111111' : '#ffffff';
}

/**
 * Elementor varlık modu (panelden): auto | always | off.
 *
 * @return string
 */
function devxpe_elementor_assets_mode() {
	$mode = (string) devxpe_theme_get( 'elementor_assets', 'auto' );

	return in_array( $mode, array( 'auto', 'always', 'off' ), true ) ? $mode : 'auto';
}

/**
 * Görüntülenen içerik Elementor ile mi yapılmış?
 *
 * @return bool
 */
function devxpe_page_built_with_elementor() {
	if ( ! class_exists( '\Elementor\Plugin' ) ) {
		return false;
	}

	$post_id = (int) get_queried_object_id();
	if ( ! $post_id ) {
		return false;
	}

	$documents = \Elementor\Plugin::$instance->documents;
	if ( ! $documents || ! method_exists( $documents, 'get' ) ) {
		return false;
	}

	$doc = $documents->get( $post_id );

	return ( $doc && method_exists( $doc, 'is_built_with_elementor' ) && $doc->is_built_with_elementor() );
}

/**
 * Elementor'un ön yüz varlıklarını gereksizse kaldırır.
 *
 * Elementor CSS+JS sayfa başına ~60 KB. Sayfalar Elementor ile yapılmadıysa
 * "Otomatik" mod bunları hiç yüklemez.
 *
 * @return void
 */
function devxpe_trim_elementor_assets() {
	$mode = devxpe_elementor_assets_mode();

	if ( 'always' === $mode ) {
		return;
	}
	if ( 'auto' === $mode && devxpe_page_built_with_elementor() ) {
		return;
	}

	foreach ( array( wp_styles(), wp_scripts() ) as $registry ) {
		foreach ( (array) $registry->queue as $handle ) {
			if ( 0 === strpos( (string) $handle, 'elementor' ) ) {
				$registry->dequeue( $handle );
			}
		}
	}
}
add_action( 'wp_enqueue_scripts', 'devxpe_trim_elementor_assets', 999 );

/* ══════════════════════════════════════════════════════════
   Detay sayfası: teklif formu + SSS meta box'ı
══════════════════════════════════════════════════════════ */

