<?php
/**
 * DEVXPE Tema Kütüphanesi — tasarım (child theme) kataloğu.
 *
 * "Görünüm": motor (bu tema) sabit kalır; her görünüm ayrı bir CHILD temadır.
 * Tasarımlar GitHub'daki bir katalogdan (themes.json) okunur, panelden kurulur
 * ve WordPress'in kendi Theme_Upgrader + switch_theme mekanizmasıyla etkinleşir.
 *
 * Manifest (themes.json) biçimi:
 * {
 *   "designs": [
 *     {
 *       "slug": "devxpe-arc",
 *       "stylesheet": "devxpe-arc",
 *       "name": "ARC",
 *       "description": "…",
 *       "version": "1.0.0",
 *       "requires": "0.3.43",
 *       "package": "https://…/designs/devxpe-arc.zip",
 *       "cover": "https://…/designs/devxpe-arc/cover.jpg",
 *       "gallery": ["https://…/1.jpg", "…"]
 *     }
 *   ]
 * }
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DEVXPE_Theme_Library {

	/**
	 * Manifest önbellek transient'i.
	 */
	const CACHE = 'dxp_design_catalog';

	/**
	 * Önbellek süresi.
	 */
	const CACHE_TTL = 21600; // 6 saat.

	/**
	 * Demo/katalog varlıklarının taban adresi (ayrı ayar).
	 *
	 * Varsayılan: update deposunun `assets` dalı. `DEVXPE_ASSETS_BASE` sabiti
	 * (wp-config) veya `devxpe_assets_base` filtresiyle değiştirilebilir.
	 */
	const ASSETS_BASE = 'https://raw.githubusercontent.com/developerxpe/wpthemeupdate/assets/';

	/**
	 * Varlık taban adresi (ayar).
	 *
	 * @return string
	 */
	public static function assets_base() {
		$base = defined( 'DEVXPE_ASSETS_BASE' ) ? (string) DEVXPE_ASSETS_BASE : self::ASSETS_BASE;
		return (string) apply_filters( 'devxpe_assets_base', trailingslashit( $base ) );
	}

	/**
	 * Katalog manifest adresi.
	 *
	 * @return string
	 */
	public static function catalog_url() {
		return (string) apply_filters( 'devxpe_design_catalog_url', self::assets_base() . 'themes.json' );
	}

	/**
	 * Üst tema (motor) slug'ı.
	 *
	 * @return string
	 */
	public static function parent_slug() {
		return get_template();
	}

	/**
	 * Etkin tema slug'ı (child etkinse child).
	 *
	 * @return string
	 */
	public static function active_slug() {
		return get_stylesheet();
	}

	/**
	 * Katalogdaki tasarımlar (uzak manifest, önbellekli).
	 *
	 * @param bool $force Önbelleği atla.
	 * @return array
	 */
	public static function manifest( $force = false ) {
		if ( ! $force && isset( $_GET['dxp_catalog_refresh'] ) && current_user_can( 'manage_options' ) ) {
			$force = true;
		}
		if ( ! $force ) {
			$cache = get_transient( self::CACHE );
			if ( is_array( $cache ) ) {
				return $cache;
			}
		}

		$list = array();
		$url  = self::catalog_url();

		if ( wp_http_validate_url( $url ) ) {
			$res = wp_remote_get( $url, array( 'timeout' => 15 ) );
			if ( ! is_wp_error( $res ) && 200 === (int) wp_remote_retrieve_response_code( $res ) ) {
				$body = ltrim( (string) wp_remote_retrieve_body( $res ), "\xEF\xBB\xBF" );
				$json = json_decode( $body, true );
				if ( is_array( $json ) && ! empty( $json['designs'] ) && is_array( $json['designs'] ) ) {
					$list = $json['designs'];
				}
			}
		}

		set_transient( self::CACHE, $list, self::CACHE_TTL );

		return $list;
	}

	/**
	 * Kurulu child tasarımlar: slug => WP_Theme.
	 *
	 * @return array
	 */
	public static function installed_designs() {
		$out    = array();
		$parent = self::parent_slug();

		foreach ( wp_get_themes() as $slug => $theme ) {
			if ( $slug !== $parent && $theme->get( 'Template' ) === $parent ) {
				$out[ $slug ] = $theme;
			}
		}

		return $out;
	}

	/**
	 * Tasarım üst tema sürümüyle uyumlu mu?
	 *
	 * @param array $design Tasarım tanımı.
	 * @return bool
	 */
	public static function is_compatible( $design ) {
		if ( empty( $design['requires'] ) ) {
			return true;
		}
		return version_compare( DEVXPE_THEME_VERSION, (string) $design['requires'], '>=' );
	}

	/**
	 * Tasarımın galeri görselleri (kapak + gallery).
	 *
	 * @param array $design Tasarım tanımı.
	 * @return array
	 */
	public static function gallery( $design ) {
		$imgs = array();

		if ( ! empty( $design['cover'] ) ) {
			$imgs[] = (string) $design['cover'];
		}
		if ( ! empty( $design['gallery'] ) && is_array( $design['gallery'] ) ) {
			foreach ( $design['gallery'] as $g ) {
				$imgs[] = (string) $g;
			}
		}

		return array_values( array_unique( array_filter( $imgs ) ) );
	}

	/**
	 * Bir tasarım "yapım aşamasında" mı? (manifest: "status": "dev")
	 *
	 * @param array $design Tasarım tanımı.
	 * @return bool
	 */
	public static function is_dev_design( $design ) {
		return ( isset( $design['status'] ) && 'dev' === strtolower( (string) $design['status'] ) );
	}

	/**
	 * Gösterilebilir tasarımlar.
	 *
	 * "Yapım aşamasında" (status: dev) olanlar yalnızca geliştirme modunda
	 * listelenir; müşteride gizlenir.
	 *
	 * @return array
	 */
	public static function visible_designs() {
		$out = array();

		foreach ( self::manifest() as $d ) {
			if ( self::is_dev_design( $d ) && ! self::show_dev() ) {
				continue;
			}
			$out[] = $d;
		}

		return $out;
	}

	/**
	 * Yapım aşamasındaki (dev) tasarımlar gösterilsin mi?
	 *
	 * Varsayılan KAPALI'dır. Geliştirme sitesinde `functions.php` içindeki
	 * DEV bloğu (paketleyici tarafından çıkarılır) filtreyi `true` yapar.
	 *
	 * @return bool
	 */
	private static function show_dev() {
		return (bool) apply_filters( 'devxpe_show_dev_designs', false );
	}

	/**
	 * Katalogdan bir tasarım tanımını bulur.
	 *
	 * @param string $slug Tasarım slug'ı.
	 * @return array|null
	 */
	public static function find( $slug ) {
		foreach ( self::manifest() as $d ) {
			if ( isset( $d['slug'] ) && (string) $d['slug'] === (string) $slug ) {
				return $d;
			}
		}
		return null;
	}

	/**
	 * Tasarımı kurar ve etkinleştirir.
	 *
	 * @param string $slug Tasarım slug'ı.
	 * @return string Sonuç kodu.
	 */
	public static function install( $slug ) {
		$slug   = sanitize_key( $slug );
		$design = self::find( $slug );

		if ( ! $design || empty( $design['package'] ) ) {
			return 'design_error';
		}
		/* Yapım aşamasındaki tasarım yalnızca geliştirmede kurulabilir. */
		if ( self::is_dev_design( $design ) && ! self::show_dev() ) {
			return 'design_error';
		}
		if ( ! self::is_compatible( $design ) ) {
			return 'design_incompatible';
		}

		$url = esc_url_raw( (string) $design['package'] );
		if ( ! wp_http_validate_url( $url ) ) {
			return 'design_error';
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/misc.php';
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';

		$upgrader = new Theme_Upgrader( new Automatic_Upgrader_Skin() );
		$result   = $upgrader->install( $url );

		if ( is_wp_error( $result ) || ! $result ) {
			return 'design_error';
		}

		$target = ! empty( $design['stylesheet'] ) ? (string) $design['stylesheet'] : $slug;

		return self::activate( $target );
	}

	/**
	 * Kurulu bir child tasarımı etkinleştirir.
	 *
	 * @param string $slug Tasarım slug'ı (stylesheet).
	 * @return string Sonuç kodu.
	 */
	public static function activate( $slug ) {
		$slug  = sanitize_key( $slug );
		$theme = wp_get_theme( $slug );

		if ( ! $theme->exists() ) {
			return 'design_missing';
		}
		/* Yalnızca bu temanın child'ı etkinleştirilebilir. */
		if ( $theme->get( 'Template' ) !== self::parent_slug() ) {
			return 'design_notchild';
		}

		switch_theme( $slug );

		return 'design_ok';
	}

	/**
	 * Varsayılan görünüme (üst tema) döner.
	 *
	 * @return string
	 */
	public static function reset_default() {
		switch_theme( self::parent_slug() );
		return 'design_reset';
	}
}
