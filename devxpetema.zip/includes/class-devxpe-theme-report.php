<?php
/**
 * DEVXPE tema kurulum bildirimi (heartbeat).
 *
 * Tema etkinleşince, güncelleme sonrası ilk yönetim isteğinde ve günlük
 * cron'da toplayıcıya (Cloudflare Worker `/ping`) küçük bir bildirim gönderir.
 * Amaç: yayıncının "Tema kuranlar" listesini OTOMATİK doldurmak.
 *
 * İLKELER:
 *   - Güncelleme kanalına DOKUNMAZ (güncellemeler GitHub'da kalır).
 *   - "Fire-and-forget": varsayılan non-blocking, 4 sn; hata olursa sessizce
 *     geçer (siteyi asla yavaşlatmaz / bozmaz).
 *   - Minimum veri: site adresi, tema/WP/PHP sürümü, dil, child mi, rastgele
 *     kurulum kimliği. Kişisel veri yok.
 *   - Kapatılabilir: DEVXPE_DISABLE_REPORTING sabiti veya
 *     `devxpe_reporting_enabled` filtresi (ileride panel anahtarı).
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DEVXPE_Theme_Report {

	/**
	 * Günlük bildirimi tetikleyen cron kancası.
	 */
	const CRON_HOOK = 'devxpe_report_ping';

	/**
	 * Rastgele kurulum kimliğinin option anahtarı.
	 */
	const OPT_KURULUM = 'devxpe_kurulum_id';

	/**
	 * En son bildirilen tema sürümünün option anahtarı.
	 */
	const OPT_SURUM = 'devxpe_reported_version';

	/**
	 * Varsayılan toplayıcı adresi (Cloudflare Worker).
	 *
	 * Sabit (DEVXPE_REPORT_URL) veya `devxpe_report_url` filtresiyle değiştirilir.
	 */
	const DEFAULT_URL = 'https://dxp-collector.xpecrise-2da.workers.dev/ping';

	/**
	 * Kancaları bağlar.
	 *
	 * @return void
	 */
	public static function init() {
		/* Tema etkinleştirildiğinde hemen bildir. */
		add_action( 'after_switch_theme', array( __CLASS__, 'on_activate' ) );

		/* Günlük cron'u kur. */
		add_action( 'init', array( __CLASS__, 'maybe_schedule' ) );
		add_action( self::CRON_HOOK, array( __CLASS__, 'cron_send' ) );

		/* Sürüm değişince (güncelleme sonrası) bir kez bildir. */
		add_action( 'admin_init', array( __CLASS__, 'maybe_report_version' ) );
	}

	/**
	 * Bildirim kapalı mı?
	 *
	 * @return bool
	 */
	public static function enabled() {
		if ( defined( 'DEVXPE_DISABLE_REPORTING' ) && DEVXPE_DISABLE_REPORTING ) {
			return false;
		}

		return (bool) apply_filters( 'devxpe_reporting_enabled', true );
	}

	/**
	 * Toplayıcı adresi.
	 *
	 * @return string
	 */
	public static function url() {
		$url = defined( 'DEVXPE_REPORT_URL' ) ? (string) DEVXPE_REPORT_URL : self::DEFAULT_URL;

		return (string) apply_filters( 'devxpe_report_url', $url );
	}

	/**
	 * Kalıcı, rastgele kurulum kimliği (yoksa üretir).
	 *
	 * @return string
	 */
	private static function kurulum_id() {
		$id = (string) get_option( self::OPT_KURULUM, '' );

		if ( '' === $id ) {
			$id = function_exists( 'wp_generate_uuid4' )
				? wp_generate_uuid4()
				: md5( uniqid( (string) mt_rand(), true ) );
			update_option( self::OPT_KURULUM, $id, false );
		}

		return $id;
	}

	/**
	 * Günlük cron'u kurar; bildirim kapalıysa kaldırır.
	 *
	 * @return void
	 */
	public static function maybe_schedule() {
		if ( ! self::enabled() ) {
			$zaman = wp_next_scheduled( self::CRON_HOOK );
			if ( $zaman ) {
				wp_unschedule_event( $zaman, self::CRON_HOOK );
			}
			return;
		}

		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time() + 300, 'daily', self::CRON_HOOK );
		}
	}

	/**
	 * Tema etkinleştirildiğinde çalışır.
	 *
	 * @return void
	 */
	public static function on_activate() {
		if ( ! self::enabled() ) {
			return;
		}

		self::send();
		update_option( self::OPT_SURUM, DEVXPE_THEME_VERSION, false );
	}

	/**
	 * Sürüm değiştiyse bir kez bildirir (güncelleme sonrası tespit).
	 *
	 * @return void
	 */
	public static function maybe_report_version() {
		if ( ! self::enabled() ) {
			return;
		}

		if ( get_option( self::OPT_SURUM, '' ) === DEVXPE_THEME_VERSION ) {
			return;
		}

		self::send();
		update_option( self::OPT_SURUM, DEVXPE_THEME_VERSION, false );
	}

	/**
	 * Cron kancası sarmalayıcısı.
	 *
	 * @return void
	 */
	public static function cron_send() {
		self::send();
	}

	/**
	 * Gönderilecek veri (minimum).
	 *
	 * @return array
	 */
	private static function payload() {
		return array(
			'app'        => 'devxpe',
			'site'       => home_url(),
			'site_url'   => home_url(),
			'v'          => DEVXPE_THEME_VERSION,
			'wp'         => get_bloginfo( 'version' ),
			'php'        => PHP_VERSION,
			'dil'        => get_locale(),
			'child'      => ( get_stylesheet() !== get_template() ) ? 1 : 0,
			'kurulum_id' => self::kurulum_id(),
		);
	}

	/**
	 * Toplayıcıya bildirir.
	 *
	 * @param bool $blocking Yanıtı beklesin mi (test için true).
	 * @return array|false WP_Error|array, kapalıysa false.
	 */
	public static function send( $blocking = false ) {
		if ( ! self::enabled() ) {
			return false;
		}

		$url = self::url();
		if ( '' === $url || ! wp_http_validate_url( $url ) ) {
			return false;
		}

		return wp_remote_post(
			$url,
			array(
				'timeout'    => 4,
				'blocking'   => (bool) $blocking,
				'user-agent' => 'DEVXPE/' . DEVXPE_THEME_VERSION,
				'headers'    => array( 'Content-Type' => 'application/json' ),
				'body'       => wp_json_encode( self::payload() ),
			)
		);
	}
}
