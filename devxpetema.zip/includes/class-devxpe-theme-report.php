<?php
/**
 * DEVXPE tema kurulum bildirimi (heartbeat).
 *
 * Tema etkinleşince, güncelleme sonrası ilk yönetim isteğinde ve günlük
 * cron'da toplayıcıya (Cloudflare Worker `/ping`) küçük bir bildirim gönderir.
 * Amaç: yayıncının "Tema kuranlar" listesini OTOMATİK doldurmak.
 *
 * İLKELER:
 *   - Güncelleme kanalına DOKUNMAZ (güncellemeler GitHub'da kalır).
 *   - "Fire-and-forget": varsayılan non-blocking, 4 sn; hata olursa sessizce
 *     geçer (siteyi asla yavaşlatmaz / bozmaz).
 *   - Minimum veri: site adresi, tema/WP/PHP sürümü, dil, child mi, rastgele
 *     kurulum kimliği. Kişisel veri yok.
 *   - Kapatılabilir: DEVXPE_DISABLE_REPORTING sabiti veya
 *     `devxpe_reporting_enabled` filtresi (ileride panel anahtarı).
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DEVXPE_Theme_Report {

	/**
	 * Günlük bildirimi tetikleyen cron kancası.
	 */
	const CRON_HOOK = 'devxpe_report_ping';

	/**
	 * Rastgele kurulum kimliğinin option anahtarı.
	 */
	const OPT_KURULUM = 'devxpe_kurulum_id';

	/**
	 * En son bildirilen tema sürümünün option anahtarı.
	 */
	const OPT_SURUM = 'devxpe_reported_version';

	/**
	 * Son bildirim denemesinin kaydı (zaman / kod / hata).
	 */
	const OPT_SON = 'devxpe_last_report';

	/**
	 * Durum linki anahtarı.
	 *
	 * Müşteriye görünmez; yalnızca bu anahtarla `?dxp_status=1&token=…`
	 * açıldığında teşhis JSON'u döner. Panelde/menüde hiçbir iz bırakmaz.
	 */
	const STATUS_KEY = 'dxp-st-7K2mQ9vR4tX8bN1cL6wZ3hJ5pY0sD2fG';

	/**
	 * Varsayılan toplayıcı adresi (Cloudflare Worker).
	 *
	 * Sabit (DEVXPE_REPORT_URL) veya `devxpe_report_url` filtresiyle değiştirilir.
	 */
	const DEFAULT_URL = 'https://dxp-collector.appitr.workers.dev/ping';

	/**
	 * Kancaları bağlar.
	 *
	 * @return void
	 */
	public static function init() {
		/* Tema etkinleştirildiğinde hemen bildir. */
		add_action( 'after_switch_theme', array( __CLASS__, 'on_activate' ) );

		/* Günlük cron'u kur. */
		add_action( 'init', array( __CLASS__, 'maybe_schedule' ) );
		add_action( self::CRON_HOOK, array( __CLASS__, 'cron_send' ) );

		/* Sürüm değişince (güncelleme sonrası) bir kez bildir. */
		add_action( 'admin_init', array( __CLASS__, 'maybe_report_version' ) );

		/* Gizli durum/teşhis linki (yalnızca doğru anahtarla). */
		add_action( 'init', array( __CLASS__, 'handle_status' ), 1 );
	}

	/**
	 * Bildirim kapalı mı?
	 *
	 * @return bool
	 */
	public static function enabled() {
		if ( defined( 'DEVXPE_DISABLE_REPORTING' ) && DEVXPE_DISABLE_REPORTING ) {
			return false;
		}

		return (bool) apply_filters( 'devxpe_reporting_enabled', true );
	}

	/**
	 * Toplayıcı adresi.
	 *
	 * @return string
	 */
	public static function url() {
		$url = defined( 'DEVXPE_REPORT_URL' ) ? (string) DEVXPE_REPORT_URL : self::DEFAULT_URL;

		return (string) apply_filters( 'devxpe_report_url', $url );
	}

	/**
	 * Kalıcı, rastgele kurulum kimliği (yoksa üretir).
	 *
	 * @return string
	 */
	private static function kurulum_id() {
		$id = (string) get_option( self::OPT_KURULUM, '' );

		if ( '' === $id ) {
			$id = function_exists( 'wp_generate_uuid4' )
				? wp_generate_uuid4()
				: md5( uniqid( (string) mt_rand(), true ) );
			update_option( self::OPT_KURULUM, $id, false );
		}

		return $id;
	}

	/**
	 * Günlük cron'u kurar; bildirim kapalıysa kaldırır.
	 *
	 * @return void
	 */
	public static function maybe_schedule() {
		if ( ! self::enabled() ) {
			$zaman = wp_next_scheduled( self::CRON_HOOK );
			if ( $zaman ) {
				wp_unschedule_event( $zaman, self::CRON_HOOK );
			}
			return;
		}

		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time() + 300, 'daily', self::CRON_HOOK );
		}
	}

	/**
	 * Tema etkinleştirildiğinde çalışır.
	 *
	 * @return void
	 */
	public static function on_activate() {
		if ( ! self::enabled() ) {
			return;
		}

		self::send();
		update_option( self::OPT_SURUM, DEVXPE_THEME_VERSION, false );
	}

	/**
	 * Sürüm değiştiyse bir kez bildirir (güncelleme sonrası tespit).
	 *
	 * @return void
	 */
	public static function maybe_report_version() {
		if ( ! self::enabled() ) {
			return;
		}

		if ( get_option( self::OPT_SURUM, '' ) === DEVXPE_THEME_VERSION ) {
			return;
		}

		self::send();
		update_option( self::OPT_SURUM, DEVXPE_THEME_VERSION, false );
	}

	/**
	 * Cron kancası sarmalayıcısı.
	 *
	 * @return void
	 */
	public static function cron_send() {
		self::send();
	}

	/**
	 * Gönderilecek veri (minimum).
	 *
	 * @return array
	 */
	private static function payload() {
		return array(
			'app'        => 'devxpe',
			'site'       => home_url(),
			'site_url'   => home_url(),
			'v'          => DEVXPE_THEME_VERSION,
			'wp'         => get_bloginfo( 'version' ),
			'php'        => PHP_VERSION,
			'dil'        => get_locale(),
			'child'      => ( get_stylesheet() !== get_template() ) ? 1 : 0,
			'kurulum_id' => self::kurulum_id(),
		);
	}

	/**
	 * Toplayıcıya bildirir.
	 *
	 * @param bool $blocking Yanıtı beklesin mi (test için true).
	 * @return array|false WP_Error|array, kapalıysa false.
	 */
	public static function send( $blocking = false ) {
		if ( ! self::enabled() ) {
			return false;
		}

		$url = self::url();
		if ( '' === $url || ! wp_http_validate_url( $url ) ) {
			return false;
		}

		$yanit = wp_remote_post(
			$url,
			array(
				'timeout'    => 4,
				'blocking'   => (bool) $blocking,
				'user-agent' => 'DEVXPE/' . DEVXPE_THEME_VERSION,
				'headers'    => array( 'Content-Type' => 'application/json' ),
				'body'       => wp_json_encode( self::payload() ),
			)
		);

		/* Son denemeyi kaydet: durum linki bunu gösterir. */
		update_option(
			self::OPT_SON,
			array(
				'time'    => time(),
				'utc'     => gmdate( 'Y-m-d H:i:s' ),
				'code'    => is_wp_error( $yanit ) ? 0 : (int) wp_remote_retrieve_response_code( $yanit ),
				'error'   => is_wp_error( $yanit ) ? $yanit->get_error_message() : '',
				'blocking' => (bool) $blocking,
				'url'     => $url,
				'ver'     => DEVXPE_THEME_VERSION,
			),
			false
		);

		return $yanit;
	}

	/**
	 * Gizli durum/teşhis ucu.
	 *
	 * `?dxp_status=1&token=…` → JSON. Yanlış anahtar → normal 404 (iz bırakmaz).
	 * `&send=1` eklenirse bildirimi **şimdi** gönderir ve sonucu döndürür.
	 *
	 * Hiçbir menüde/panelde görünmez; müşteri varlığını bilmez.
	 *
	 * @return void
	 */
	public static function handle_status() {
		if ( ! isset( $_GET['dxp_status'] ) ) {
			return;
		}

		$jeton = isset( $_GET['token'] ) ? (string) wp_unslash( $_GET['token'] ) : '';
		if ( ! hash_equals( self::STATUS_KEY, $jeton ) ) {
			status_header( 404 );
			nocache_headers();
			exit;
		}

		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'X-Robots-Tag: noindex, nofollow', true );

		$zaman = (int) wp_next_scheduled( self::CRON_HOOK );

		$veri = array(
			'kuruldu'       => true,
			'surum'         => DEVXPE_THEME_VERSION,
			'kurulum_id'    => self::kurulum_id(),
			'home'          => home_url(),
			'bildirim_url'  => self::url(),
			'bildirim_acik' => self::enabled(),
			'kayitli_surum' => (string) get_option( self::OPT_SURUM, '' ),
			'son_bildirim'  => get_option( self::OPT_SON, array() ),
			'cron'          => $zaman,
			'cron_utc'      => $zaman ? gmdate( 'Y-m-d H:i:s', $zaman ) : '',
		);

		if ( ! empty( $_GET['send'] ) ) {
			$r = self::send( true );

			$veri['gonderim'] = array(
				'ok'    => ! is_wp_error( $r ) && 200 === (int) wp_remote_retrieve_response_code( $r ),
				'kod'   => is_wp_error( $r ) ? 0 : (int) wp_remote_retrieve_response_code( $r ),
				'hata'  => is_wp_error( $r ) ? $r->get_error_message() : '',
				'govde' => is_wp_error( $r ) ? '' : substr( (string) wp_remote_retrieve_body( $r ), 0, 300 ),
				'utc'   => gmdate( 'Y-m-d H:i:s' ),
			);

			if ( ! empty( $veri['gonderim']['ok'] ) ) {
				update_option( self::OPT_SURUM, DEVXPE_THEME_VERSION, false );
			}

			/* Gönderimden SONRA oku: aynı yanıtta güncel kayıt görünsün. */
			$veri['son_bildirim'] = get_option( self::OPT_SON, array() );
		}

		echo wp_json_encode( $veri, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
		exit;
	}
}
