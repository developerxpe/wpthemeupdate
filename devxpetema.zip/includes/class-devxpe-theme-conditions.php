<?php
/**
 * DEVXPE tema — modüler koşul (görünürlük) motoru.
 *
 * Panelde bir alanın/grupun/sekmenin gösterilip gösterilmeyeceğine
 * istemci tarafında (JS + CSS display:none) değil, sunucu tarafında karar
 * verir. Koşul her render'da kayıtlı ayarlardan yeniden hesaplanır.
 *
 * Kural biçimi eski `depends` ile geriye uyumludur:
 *
 *   array( 'field' => 'float_style', 'value' => 'bar' )   // = (varsayılan)
 *
 * Desteklenen operatörler (`operator` anahtarı):
 *   =        (varsayılan)  yukarıdaki gibi: değer === value
 *   !=                     değer !== value
 *   in                     value bir dizi; değer dizide ise
 *   !=in                   value bir dizi; değer dizide DEĞİLSE
 *   notempty               değer boş değilse ('' / '0' / boş dizi değil)
 *   empty                  değer boşsa
 *
 * Birleşik kurallar:
 *   array( 'all' => array( kural, kural ) )   // hepsi sağlanmalı
 *   array( 'any' => array( kural, kural ) )   // en az biri sağlanmalı
 *
 * FAIL-OPEN: kural eksik/bozuksa, alan tanımlı değilse veya operatör
 * bilinmiyorsa `true` döner; yani eleman GÖSTERİLİR. Amaç, bir hata
 * yüzünden alanın panelden tamamen kaybolmamasıdır.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DEVXPE_Theme_Conditions {

	/**
	 * Bir kuralın sağlanıp sağlanmadığını kayıtlı ayarlara bakarak döndürür.
	 *
	 * @param mixed $rule Kural dizisi (veya boş).
	 * @return bool Koşul sağlanıyorsa true; eksik/bozuksa FAIL-OPEN olarak true.
	 */
	public static function met( $rule ) {
		/* Kural yok → göster. */
		if ( ! is_array( $rule ) || empty( $rule ) ) {
			return true;
		}

		/* Birleşik kurallar: hepsi / en az biri. */
		if ( isset( $rule['all'] ) || isset( $rule['any'] ) ) {
			$branch  = isset( $rule['all'] ) ? $rule['all'] : $rule['any'];
			$is_all  = isset( $rule['all'] );
			$branch  = (array) $branch;

			if ( empty( $branch ) ) {
				return true; /* FAIL-OPEN: boş birleşik kural. */
			}

			foreach ( $branch as $child ) {
				$ok = self::met( $child );
				if ( $is_all && ! $ok ) {
					return false;
				}
				if ( ! $is_all && $ok ) {
					return true;
				}
			}

			return $is_all;
		}

		/* Yaprak kural: field + operator + value. */
		$field = isset( $rule['field'] ) ? (string) $rule['field'] : '';
		if ( '' === $field ) {
			return true; /* FAIL-OPEN: alan adı yok. */
		}

		/* Tanımsız alan → FAIL-OPEN (alan asla kaybolmasın). */
		$all = DEVXPE_Theme_Fields::all();
		if ( ! isset( $all[ $field ] ) ) {
			return true;
		}

		$value    = DEVXPE_Theme_Fields::get( $field );
		$operator = isset( $rule['operator'] ) ? strtolower( trim( (string) $rule['operator'] ) ) : '=';
		$target   = isset( $rule['value'] ) ? $rule['value'] : '';

		switch ( $operator ) {
			case '=':
				return self::equals( $value, $target );

			case '!=':
				return ! self::equals( $value, $target );

			case 'in':
				return self::in( $value, (array) $target );

			case '!=in':
				return ! self::in( $value, (array) $target );

			case 'notempty':
				return ! self::is_empty( $value );

			case 'empty':
				return self::is_empty( $value );

			default:
				return true; /* FAIL-OPEN: bilinmeyen operatör. */
		}
	}

	/**
	 * Verilen kural listesindeki koşul kaynağı alan adlarını toplar.
	 *
	 * Panelde "kaydet ve yeniden çiz" davranışını yalnızca bu alanlara
	 * bağlamak için kullanılır.
	 *
	 * @param array $rules Kural listesi (her eleman bir kural dizisi).
	 * @return array Benzersiz alan adları.
	 */
	public static function sources( $rules ) {
		$out = array();
		foreach ( (array) $rules as $rule ) {
			self::collect_sources( (array) $rule, $out );
		}
		return array_values( array_unique( $out ) );
	}

	/* ── İç yardımcılar ───────────────────────────────────── */

	/**
	 * Bir kural ağacındaki alan adlarını özyinelemeli toplar.
	 *
	 * @param array $rule Kural.
	 * @param array $out  Toplanan alan adları (referans).
	 * @return void
	 */
	private static function collect_sources( $rule, &$out ) {
		if ( isset( $rule['all'] ) || isset( $rule['any'] ) ) {
			$branch = isset( $rule['all'] ) ? $rule['all'] : $rule['any'];
			foreach ( (array) $branch as $child ) {
				self::collect_sources( (array) $child, $out );
			}
			return;
		}

		if ( ! empty( $rule['field'] ) ) {
			$out[] = (string) $rule['field'];
		}
	}

	/**
	 * İki değeri metin olarak karşılaştırır (select/checkbox değerleri string).
	 *
	 * @param mixed $a Değer.
	 * @param mixed $b Beklenen değer.
	 * @return bool
	 */
	private static function equals( $a, $b ) {
		return self::as_string( $a ) === self::as_string( $b );
	}

	/**
	 * Değer, verilen listede var mı (metin karşılaştırması).
	 *
	 * @param mixed $value Değer.
	 * @param array $list  Adaylar.
	 * @return bool
	 */
	private static function in( $value, $list ) {
		$needle = self::as_string( $value );
		foreach ( $list as $candidate ) {
			if ( self::as_string( $candidate ) === $needle ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Değerin "boş" sayılıp sayılmayacağı.
	 *
	 * @param mixed $value Değer.
	 * @return bool
	 */
	private static function is_empty( $value ) {
		if ( is_array( $value ) ) {
			return empty( $value );
		}
		$value = self::as_string( $value );
		return ( '' === $value || '0' === $value );
	}

	/**
	 * Değeri güvenli biçimde metne çevirir (dizi gelirse boş kabul eder).
	 *
	 * @param mixed $value Değer.
	 * @return string
	 */
	private static function as_string( $value ) {
		if ( is_scalar( $value ) ) {
			return (string) $value;
		}
		return '';
	}
}
