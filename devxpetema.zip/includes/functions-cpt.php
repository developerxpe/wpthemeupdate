<?php
/**
 * DEVXPE özel içerik tipleri (panelden tanımlanan CPT'ler).
 *
 * Panelde tanımlı içerik tiplerini WordPress'e kaydeder; ayrılmış (çekirdek)
 * slug'ları ve kategori/etiket slug çakışmalarını engeller; panelden kaldırılan
 * tiplerin yazılarını temizler.
 *
 * Kamu Yüzeyi: devxpe_custom_post_types, devxpe_register_custom_post_types,
 * devxpe_cpt_* fonksiyon adları ile `init` (öncelik 5), `pre_insert_term`,
 * `wp_update_term_data`, `admin_notices` ve `update_option_devxpe_theme_options`
 * hook'ları sözleşmedir; değiştirilmez.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ══════════════════════════════════════════════════════════
   Özel içerik tipleri (panelden tanımlanır)
══════════════════════════════════════════════════════════ */

/**
 * Özel içerik tipi olarak kullanılamayacak (çekirdek) slug'lar.
 *
 * @return array
 */
function devxpe_cpt_reserved_slugs() {
	return array(
		'post', 'page', 'attachment', 'revision', 'nav_menu_item', 'custom_css',
		'customize_changeset', 'oembed_cache', 'user_request', 'wp_block',
		'wp_template', 'wp_template_part', 'wp_global_styles', 'wp_navigation',
	);
}

/**
 * Panelde tanımlı özel içerik tiplerini döndürür.
 *
 * Ayrılmış slug'lar burada da süzülür: kayıtlı veri elle/bozuk gelirse
 * çekirdek 'post'/'page' tiplerinin üzerine yazılmasını engeller.
 *
 * @return array array( array( 'name' =>, 'slug' =>, 'icon' =>, 'archive' => ), ... )
 */
function devxpe_custom_post_types() {
	$cpts = devxpe_theme_get( 'custom_post_types' );
	if ( ! is_array( $cpts ) ) {
		return array();
	}

	$reserved = devxpe_cpt_reserved_slugs();
	$out      = array();

	foreach ( $cpts as $cpt ) {
		if ( empty( $cpt['slug'] ) || empty( $cpt['name'] ) ) {
			continue;
		}
		if ( in_array( $cpt['slug'], $reserved, true ) ) {
			continue;
		}
		/* Aynı slug'da kategori/etiket varsa içerik tipini yok say (çakışma). */
		if ( get_term_by( 'slug', $cpt['slug'], 'category' ) || get_term_by( 'slug', $cpt['slug'], 'post_tag' ) ) {
			continue;
		}
		$out[] = $cpt;
	}

	return $out;
}

/**
 * Panelde tanımlı içerik tiplerini WordPress'e kaydeder.
 *
 * Tanımlar değiştiğinde rewrite kuralları bir kez yenilenir (URL'ler
 * çalışsın diye).
 *
 * @return void
 */
function devxpe_register_custom_post_types() {
	foreach ( devxpe_custom_post_types() as $cpt ) {
		if ( empty( $cpt['slug'] ) || empty( $cpt['name'] ) ) {
			continue;
		}

		$slug = $cpt['slug'];
		$name = $cpt['name'];

		register_post_type(
			$slug,
			array(
				'labels'       => array(
					'name'          => $name,
					'singular_name' => $name,
					/* translators: %s: content type name. */
					'add_new_item'  => sprintf( __( 'Yeni %s Ekle', 'devxpe-theme' ), $name ),
					/* translators: %s: content type name. */
					'edit_item'     => sprintf( __( '%s Düzenle', 'devxpe-theme' ), $name ),
					/* translators: %s: content type name. */
					'all_items'     => sprintf( __( 'Tüm %s', 'devxpe-theme' ), $name ),
					'menu_name'     => $name,
				),
				'public'       => true,
				'show_ui'      => true,
				'show_in_menu' => true,
				'menu_icon'    => ! empty( $cpt['icon'] ) ? $cpt['icon'] : 'dashicons-admin-post',
				'has_archive'  => ( isset( $cpt['archive'] ) && '1' === $cpt['archive'] ),
				'rewrite'      => array(
					'slug'       => $slug,
					'with_front' => false,
				),
				'supports'     => array( 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes' ),
				'show_in_rest' => true,
			)
		);
	}

	$hash = md5( (string) wp_json_encode( devxpe_custom_post_types() ) );
	if ( get_option( 'devxpe_cpt_hash' ) !== $hash ) {
		update_option( 'devxpe_cpt_hash', $hash, false );
		flush_rewrite_rules( false );
	}
}
add_action( 'init', 'devxpe_register_custom_post_types', 5 );

/**
 * Verilen slug panelde tanımlı bir içerik tipiyle çakışıyor mu?
 *
 * @param string $slug Kontrol edilecek slug.
 * @return bool
 */
function devxpe_cpt_slug_conflict( $slug ) {
	if ( '' === (string) $slug ) {
		return false;
	}

	foreach ( devxpe_custom_post_types() as $cpt ) {
		if ( isset( $cpt['slug'] ) && $cpt['slug'] === $slug ) {
			return true;
		}
	}

	return false;
}

/**
 * Kategori/etiket oluştururken içerik tipi slug'ıyla çakışmayı engeller.
 *
 * Aynı içerik hem kategori hem içerik tipi olarak gruplanmasın.
 *
 * @param string|WP_Error $term     Terim adı.
 * @param string          $taxonomy Taksonomi.
 * @param array           $args     Terim argümanları.
 * @return string|WP_Error
 */
function devxpe_block_term_slug_collision( $term, $taxonomy, $args = array() ) {
	if ( ! in_array( $taxonomy, array( 'category', 'post_tag' ), true ) ) {
		return $term;
	}

	$slug = ! empty( $args['slug'] ) ? sanitize_title( $args['slug'] ) : sanitize_title( $term );

	if ( devxpe_cpt_slug_conflict( $slug ) ) {
		return new WP_Error(
			'devxpe_cpt_slug_collision',
			sprintf(
				/* translators: %s: slug. */
				__( '"%s" slug\'ı bir içerik tipi tarafından kullanılıyor. Lütfen farklı bir ad/slug seçin.', 'devxpe-theme' ),
				$slug
			)
		);
	}

	return $term;
}
add_filter( 'pre_insert_term', 'devxpe_block_term_slug_collision', 10, 3 );

/**
 * Kategori/etiket güncellerken slug'ı içerik tipiyle çakıştırmaz.
 *
 * Çakışma varsa mevcut slug korunur (sessizce geri alınır).
 *
 * @param array  $data     Güncellenecek veri.
 * @param int    $term_id  Terim kimliği.
 * @param string $taxonomy Taksonomi.
 * @param array  $args     Argümanlar.
 * @return array
 */
function devxpe_block_term_slug_update( $data, $term_id, $taxonomy, $args ) {
	if ( ! in_array( $taxonomy, array( 'category', 'post_tag' ), true ) ) {
		return $data;
	}

	if ( empty( $data['slug'] ) || ! devxpe_cpt_slug_conflict( $data['slug'] ) ) {
		return $data;
	}

	$existing = get_term( $term_id, $taxonomy );
	if ( $existing && ! is_wp_error( $existing ) ) {
		$data['slug'] = $existing->slug;
	}

	return $data;
}
add_filter( 'wp_update_term_data', 'devxpe_block_term_slug_update', 10, 4 );

/**
 * Atlanan içerik tipi tanımlarını panelde uyarı olarak gösterir.
 *
 * @return void
 */
function devxpe_cpt_skipped_notice() {
	$skipped = get_transient( 'devxpe_cpt_skipped' );
	if ( ! $skipped ) {
		return;
	}

	delete_transient( 'devxpe_cpt_skipped' );
	?>
	<div class="notice notice-warning is-dismissible">
		<p><strong><?php esc_html_e( 'Bazı içerik tipleri eklenmedi:', 'devxpe-theme' ); ?></strong></p>
		<ul style="list-style:disc;margin-left:20px;">
			<?php foreach ( (array) $skipped as $cpt_line ) : ?>
			<li><?php echo esc_html( $cpt_line ); ?></li>
			<?php endforeach; ?>
		</ul>
	</div>
	<?php
}
add_action( 'admin_notices', 'devxpe_cpt_skipped_notice' );

/**
 * Panelden kaldırılan içerik tipinin yazılarını siler.
 *
 * Tanım listeden çıkarıldığında o tipe ait tüm içerik de silinir (kalıcı);
 * aksi halde erişilemeyen "yetim" yazılar kalır. Yanlışlıkla silmeyi
 * önlemek için iki tarafta da 'custom_post_types' anahtarı dizi olmalı.
 *
 * @param mixed $old_value Önceki ayarlar.
 * @param mixed $new_value Yeni ayarlar.
 * @return void
 */
function devxpe_handle_removed_cpts( $old_value, $new_value ) {
	$old = ( is_array( $old_value ) && isset( $old_value['custom_post_types'] ) && is_array( $old_value['custom_post_types'] ) ) ? $old_value['custom_post_types'] : null;
	$new = ( is_array( $new_value ) && isset( $new_value['custom_post_types'] ) && is_array( $new_value['custom_post_types'] ) ) ? $new_value['custom_post_types'] : null;

	if ( null === $old || null === $new ) {
		return;
	}

	$old_slugs = array();
	foreach ( $old as $cpt ) {
		if ( ! empty( $cpt['slug'] ) ) {
			$old_slugs[ $cpt['slug'] ] = true;
		}
	}

	$new_slugs = array();
	foreach ( $new as $cpt ) {
		if ( ! empty( $cpt['slug'] ) ) {
			$new_slugs[ $cpt['slug'] ] = true;
		}
	}

	$removed = array_diff_key( $old_slugs, $new_slugs );
	if ( ! $removed ) {
		return;
	}

	$reserved = devxpe_cpt_reserved_slugs();

	foreach ( array_keys( $removed ) as $slug ) {
		/* Çekirdek tiplere asla dokunma. */
		if ( in_array( $slug, $reserved, true ) || ! post_type_exists( $slug ) ) {
			continue;
		}

		$ids = get_posts(
			array(
				'post_type'        => $slug,
				'post_status'      => 'any',
				'numberposts'      => -1,
				'fields'           => 'ids',
				'suppress_filters' => false,
			)
		);

		foreach ( $ids as $cpt_post_id ) {
			wp_delete_post( $cpt_post_id, true );
		}
	}
}
add_action( 'update_option_devxpe_theme_options', 'devxpe_handle_removed_cpts', 10, 2 );
