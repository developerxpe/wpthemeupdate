<?php
/**
 * DEVXPE tema dil değiştirici.
 *
 * Panelin dilini (Türkçe / İngilizce) sitenin genel dilinden bağımsız yönetir.
 * Seçim, tema metin alanının .mo dosyasını değiştirerek uygulanır.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DEVXPE_Theme_Language {

	/**
	 * Seçili dilin saklandığı option anahtarı.
	 */
	const OPTION_KEY = 'devxpe_theme_lang';

	/**
	 * Kancaları bağlar ve dil değiştirme formunu işler.
	 *
	 * @return void
	 */
	public static function init() {
		// Dil değiştirme formu gönderildiyse kaydet ve geri yönlendir.
		if ( isset( $_POST['devxpe_theme_lang'], $_POST['devxpe_theme_lang_nonce'] )
			&& wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['devxpe_theme_lang_nonce'] ) ), 'devxpe_theme_switch_lang' )
			&& current_user_can( 'manage_options' )
		) {
			$requested = sanitize_text_field( wp_unslash( $_POST['devxpe_theme_lang'] ) );
			$lang      = in_array( $requested, self::ids(), true ) ? $requested : 'auto';

			update_option( self::OPTION_KEY, $lang, false );
			wp_safe_redirect( wp_get_referer() ? wp_get_referer() : devxpe_panel_url() );
			exit;
		}

		add_filter( 'load_textdomain_mofile', array( __CLASS__, 'mofile' ), 10, 2 );
	}

	/**
	 * Geçerli dil kimlikleri.
	 *
	 * @return array
	 */
	public static function ids() {
		return array( 'auto', 'tr_TR', 'en_US' );
	}

	/**
	 * Seçili dili döndürür.
	 *
	 * Kayıtlı bir seçim varsa ona uyulur. Kayıt yoksa 'auto' döner ve
	 * tema WordPress sitesinin diline (get_locale) göre metin yükler.
	 * Böylece kurulumda hiçbir seçim yapılmadıysa panel site diliyle
	 * aynı dilde başlar.
	 *
	 * @return string 'auto' | 'tr_TR' | 'en_US'
	 */
	public static function selected() {
		$lang = get_option( self::OPTION_KEY, '' );
		if ( in_array( $lang, self::ids(), true ) ) {
			return $lang;
		}

		return 'auto';
	}

	/**
	 * Sitenin mevcut diline göre varsayılan dil kimliği.
	 *
	 * @return string 'tr_TR' | 'en_US'
	 */
	public static function default_lang() {
		return ( 0 === strpos( (string) get_locale(), 'tr' ) ) ? 'tr_TR' : 'en_US';
	}

	/**
	 * Görünen dil adı.
	 *
	 * @param string $id Dil kimliği.
	 * @return string
	 */
	public static function name( $id ) {
		switch ( $id ) {
			case 'tr_TR':
				return 'Türkçe';
			case 'en_US':
				return 'English';
			default:
				return __( 'Otomatik (Site Dili)', 'devxpe-theme' );
		}
	}

	/**
	 * Seçili dile göre tema .mo dosyasını değiştirir.
	 *
	 * @param string $mofile Varsayılan .mo yolu.
	 * @param string $domain Metin alanı.
	 * @return string
	 */
	public static function mofile( $mofile, $domain ) {
		if ( 'devxpe-theme' !== $domain ) {
			return $mofile;
		}

		/*
		 * ÖN YÜZ: her zaman WordPress (site) dilini kullanır; tema dil ayarı
		 * ön yüzü ETKİLEMEZ.
		 */
		if ( ! is_admin() ) {
			return $mofile;
		}

		/* PANEL (admin): seçili tema/panel dili (auto = site dili) uygulanır. */
		$lang = self::selected();
		if ( 'auto' === $lang ) {
			return $mofile;
		}

		$custom = DEVXPE_THEME_PATH . 'languages/devxpe-theme-' . $lang . '.mo';

		return file_exists( $custom ) ? $custom : $mofile;
	}

	/**
	 * Panel üst çubuğu için dil seçici formu çizer.
	 *
	 * @return void
	 */
	public static function render_switcher() {
		$lang = self::selected();
		?>
		<form class="dxp-lang-switch" method="post" action="">
			<input type="hidden" class="dxp-lang-value" name="devxpe_theme_lang" value="<?php echo esc_attr( $lang ); ?>" />
			<button type="button" class="dxp-lang-trigger" aria-haspopup="listbox" aria-expanded="false">
				<span class="dashicons dashicons-translation" aria-hidden="true"></span>
				<span class="dxp-lang-current"><?php echo esc_html( self::name( $lang ) ); ?></span>
				<span class="dxp-lang-caret" aria-hidden="true">▾</span>
			</button>
			<div class="dxp-lang-menu" role="listbox" hidden>
				<?php foreach ( self::ids() as $id ) : ?>
					<button type="button" role="option" class="dxp-lang-item<?php echo ( $id === $lang ) ? ' is-selected' : ''; ?>" data-lang="<?php echo esc_attr( $id ); ?>" aria-selected="<?php echo ( $id === $lang ) ? 'true' : 'false'; ?>">
						<?php echo esc_html( self::name( $id ) ); ?>
					</button>
				<?php endforeach; ?>
			</div>
			<?php wp_nonce_field( 'devxpe_theme_switch_lang', 'devxpe_theme_lang_nonce' ); ?>
		</form>
		<?php
	}
}
