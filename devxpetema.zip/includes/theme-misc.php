<?php
/**
 * reCAPTCHA, "yeni" rozeti ve yorum öğesi.
 *
 * functions.php'den ayrıldı.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * reCAPTCHA v3 kullanılabilir mi? (aktif + iki anahtar da girilmiş)
 *
 * @return bool
 */
function devxpe_recaptcha_enabled() {
	return (
		'1' === devxpe_theme_get( 'recaptcha_enable' ) &&
		'' !== trim( (string) devxpe_theme_get( 'recaptcha_site_key' ) ) &&
		'' !== trim( (string) devxpe_theme_get( 'recaptcha_secret_key' ) )
	);
}

/**
 * Gönderilen reCAPTCHA token'ını Google'da doğrular.
 *
 * @return bool Doğrulama başarılıysa true (kapalıysa da true).
 */
function devxpe_verify_recaptcha() {
	if ( ! devxpe_recaptcha_enabled() ) {
		return true;
	}

	$token = isset( $_POST['dxp_recaptcha'] ) ? sanitize_text_field( wp_unslash( $_POST['dxp_recaptcha'] ) ) : '';
	if ( '' === $token ) {
		return false;
	}

	$response = wp_remote_post(
		'https://www.google.com/recaptcha/api/siteverify',
		array(
			'timeout' => 8,
			'body'    => array(
				'secret'   => (string) devxpe_theme_get( 'recaptcha_secret_key' ),
				'response' => $token,
				'remoteip' => isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '',
			),
		)
	);

	if ( is_wp_error( $response ) ) {
		return false;
	}

	$data = json_decode( wp_remote_retrieve_body( $response ), true );
	if ( empty( $data['success'] ) ) {
		return false;
	}

	/* v3: eylem adı ve puan eşiği de kontrol edilir. */
	if ( isset( $data['action'] ) && 'dxp_form' !== $data['action'] ) {
		return false;
	}

	$min = (float) devxpe_theme_get( 'recaptcha_score', '0.5' );
	if ( isset( $data['score'] ) && (float) $data['score'] < $min ) {
		return false;
	}

	return true;
}

/* ══════════════════════════════════════════════════════════
   Hakkımızda / İletişim sayfaları — içerik ve sütun düzeni
   ══════════════════════════════════════════════════════════ */

/*
 * NOT: "Sayfa Şablonu ve İçeriği" metabox'ı KALDIRILDI.
 *
 * İstatistik satırları, iletişim kartları ve sütun sayısı artık sayfa
 * düzenleyicideki "İçerik Düzeni" metabox'ındaki WIDGET sisteminden
 * yönetilir (widget tipleri: 'stats', 'iletisim_kart', 'ikon_kutulari',
 * 'manset'). Eski sayfa meta'ları (_dxp_about_stats, _dxp_about_cols,
 * _dxp_contact_cards, _dxp_contact_cols) veritabanında kalır ve şablonlar
 * varsayılan olarak onları kullanmaya devam eder.
 */


/* ══════════════════════════════════════════════════════════
   Panel "Yeni" etiketi — güncellemeyle gelen özellikler
   ══════════════════════════════════════════════════════════ */

/**
 * "Yeni" etiketi alacak panel bölümleri: alt bölüm id'si => tanıtıldığı sürüm.
 *
 * KURAL:
 *  - Buraya YALNIZCA o sürümde İLK KEZ eklenen panel bölümleri yazılır.
 *  - Var olan bir bölüme yalnızca alan/içerik eklendiyse YAZILMAZ → o bölüm
 *    "Yeni" rozeti almaz.
 *  - Bir sürümde yalnızca o sürümün kayıtları rozet alır; yeni bir sürüm
 *    geldiğinde önceki rozetler otomatik silinir (en son değişiklik "Yeni").
 *
 * @return array
 */
function devxpe_panel_feature_versions() {
	return array(
		'captcha' => '0.2.1',
		'demo'    => '0.2.1',
	);
}

/**
 * "Yeni" rozetinin kaç gün görüneceği.
 *
 * @return int
 */
function devxpe_new_badge_days() {
	return 1;
}

/**
 * Tema sürümü değiştiğinde yeni özellikleri işaretler (admin tarafında).
 *
 * @return void
 */
function devxpe_sync_new_features() {
	$current = (string) DEVXPE_THEME_VERSION;
	$prev    = get_option( 'devxpe_theme_badge_version' );

	/* Geçerli sürümün rozet alacak bölümleri. */
	$current_keys = array();
	foreach ( devxpe_panel_feature_versions() as $key => $version ) {
		if ( $version === $current ) {
			$current_keys[ $key ] = true;
		}
	}

	/* İlk kurulum: rozet gösterme, yalnızca sürümü kaydet. */
	if ( false === $prev ) {
		update_option( 'devxpe_theme_badge_version', $current, false );
		return;
	}

	if ( $prev !== $current ) {
		/*
		 * Yeni sürüm: rozetler SIFIRDAN kurulur. Böylece önceki sürümün
		 * "Yeni" rozetleri silinir; yalnızca en son değişiklik "Yeni" kalır.
		 */
		$new = array();
		foreach ( array_keys( $current_keys ) as $key ) {
			$new[ $key ] = time();
		}

		update_option( 'devxpe_theme_new_features', $new, false );
		update_option( 'devxpe_theme_badge_version', $current, false );

		return;
	}

	/*
	 * Sürüm aynı ama haritadan bir bölüm çıkarılmış olabilir (ör. geriye dönük
	 * "Yeni" vermeyi bıraktık). Kalan rozetleri hemen temizle.
	 */
	$saved = get_option( 'devxpe_theme_new_features', array() );
	if ( is_array( $saved ) && $saved ) {
		$pruned = array_intersect_key( $saved, $current_keys );
		if ( count( $pruned ) !== count( $saved ) ) {
			update_option( 'devxpe_theme_new_features', $pruned, false );
		}
	}
}
add_action( 'admin_init', 'devxpe_sync_new_features' );

/**
 * Özellik hâlâ "yeni" mi? (işaretlenmiş ve süresi dolmamış)
 *
 * @param string $key Bölüm id'si.
 * @return bool
 */
function devxpe_feature_is_new( $key ) {
	$new = get_option( 'devxpe_theme_new_features', array() );
	if ( ! is_array( $new ) || empty( $new[ $key ] ) ) {
		return false;
	}

	return ( time() - (int) $new[ $key ] ) < ( devxpe_new_badge_days() * DAY_IN_SECONDS );
}

/**
 * Bölümün herhangi bir alt bölümü yeni mi?
 *
 * @param array $section Panel bölüm tanımı.
 * @return bool
 */
function devxpe_section_has_new( $section ) {
	if ( empty( $section['subsections'] ) ) {
		return false;
	}

	foreach ( $section['subsections'] as $sub_id => $sub ) {
		if ( devxpe_feature_is_new( $sub_id ) ) {
			return true;
		}
	}

	return false;
}

/**
 * "Yeni" rozeti HTML'i (yeni değilse boş döner).
 *
 * @param string $key Bölüm id'si.
 * @return string
 */
function devxpe_new_badge( $key ) {
	if ( ! devxpe_feature_is_new( $key ) ) {
		return '';
	}

	return '<span class="dxp-new-badge">' . esc_html__( 'Yeni', 'devxpe-theme' ) . '</span>';
}

/**
 * Tek bir yorumu tema tasarımıyla çizer (wp_list_comments callback).
 *
 * Blog yazısı kart dili: yuvarlatılmış yüzey, avatar + ad + tarih satırı,
 * marka yeşili "Yanıtla" bağlantısı. Pingback/iz sürümleri sade gösterilir.
 *
 * @param WP_Comment $comment Yorum nesnesi.
 * @param array      $args    wp_list_comments argümanları.
 * @param int        $depth   Girinti derinliği.
 * @return void
 */
function devxpe_comment_item( $comment, $args, $depth ) {
	$dxp_etiket = 'div' === $args['style'] ? 'div' : 'li';
	?>
	<<?php echo $dxp_etiket; ?> id="comment-<?php comment_ID(); ?>" <?php comment_class( 'dxp-comment' ); ?>>
		<article class="dxp-comment-body">
			<div class="dxp-comment-head">
				<?php echo get_avatar( $comment, (int) $args['avatar_size'], '', '', array( 'class' => 'dxp-comment-avatar' ) ); ?>
				<div class="dxp-comment-meta">
					<span class="dxp-comment-author"><?php echo get_comment_author_link( $comment ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
					<time class="dxp-comment-date" datetime="<?php echo esc_attr( get_comment_time( 'c' ) ); ?>">
						<?php
						printf(
							/* translators: %s: yorum tarihi. */
							esc_html__( '%s tarihinde', 'devxpe-theme' ),
							esc_html( get_comment_date( '', $comment ) )
						);
						?>
					</time>
				</div>
			</div>

			<?php if ( '0' === (string) $comment->comment_approved ) : ?>
				<p class="dxp-comment-pending"><?php esc_html_e( 'Yorumunuz onay bekliyor.', 'devxpe-theme' ); ?></p>
			<?php endif; ?>

			<div class="dxp-comment-text"><?php comment_text(); ?></div>

			<div class="dxp-comment-actions">
				<?php
				comment_reply_link(
					array_merge(
						$args,
						array(
							'depth'     => $depth,
							'max_depth' => $args['max_depth'],
							'reply_text' => esc_html__( 'Yanıtla', 'devxpe-theme' ),
						)
					)
				);
				edit_comment_link( esc_html__( 'Düzenle', 'devxpe-theme' ), '<span class="dxp-comment-edit">', '</span>' );
				?>
			</div>
		</article>
	<?php
	// Kapanış etiketi wp_list_comments tarafından eklenir.
}

