<?php
/**
 * reCAPTCHA, "yeni" rozeti ve yorum öğesi.
 *
 * functions.php'den ayrıldı.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * reCAPTCHA v3 kullanılabilir mi? (aktif + iki anahtar da girilmiş)
 *
 * @return bool
 */
function devxpe_recaptcha_enabled() {
	return (
		'1' === devxpe_theme_get( 'recaptcha_enable' ) &&
		'' !== trim( (string) devxpe_theme_get( 'recaptcha_site_key' ) ) &&
		'' !== trim( (string) devxpe_theme_get( 'recaptcha_secret_key' ) )
	);
}

/**
 * Gönderilen reCAPTCHA token'ını Google'da doğrular.
 *
 * @return bool Doğrulama başarılıysa true (kapalıysa da true).
 */
function devxpe_verify_recaptcha() {
	if ( ! devxpe_recaptcha_enabled() ) {
		return true;
	}

	$token = isset( $_POST['dxp_recaptcha'] ) ? sanitize_text_field( wp_unslash( $_POST['dxp_recaptcha'] ) ) : '';
	if ( '' === $token ) {
		return false;
	}

	$response = wp_remote_post(
		'https://www.google.com/recaptcha/api/siteverify',
		array(
			'timeout' => 8,
			'body'    => array(
				'secret'   => (string) devxpe_theme_get( 'recaptcha_secret_key' ),
				'response' => $token,
				'remoteip' => isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '',
			),
		)
	);

	if ( is_wp_error( $response ) ) {
		return false;
	}

	$data = json_decode( wp_remote_retrieve_body( $response ), true );
	if ( empty( $data['success'] ) ) {
		return false;
	}

	/* v3: eylem adı ve puan eşiği de kontrol edilir. */
	if ( isset( $data['action'] ) && 'dxp_form' !== $data['action'] ) {
		return false;
	}

	$min = (float) devxpe_theme_get( 'recaptcha_score', '0.5' );
	if ( isset( $data['score'] ) && (float) $data['score'] < $min ) {
		return false;
	}

	return true;
}

/* ══════════════════════════════════════════════════════════
   Hakkımızda / İletişim sayfaları — içerik ve sütun düzeni
   ══════════════════════════════════════════════════════════ */

/*
 * NOT: "Sayfa Şablonu ve İçeriği" metabox'ı KALDIRILDI.
 *
 * İstatistik satırları, iletişim kartları ve sütun sayısı artık sayfa
 * düzenleyicideki "İçerik Düzeni" metabox'ındaki WIDGET sisteminden
 * yönetilir (widget tipleri: 'stats', 'iletisim_kart', 'ikon_kutulari',
 * 'manset'). Eski sayfa meta'ları (_dxp_about_stats, _dxp_about_cols,
 * _dxp_contact_cards, _dxp_contact_cols) veritabanında kalır ve şablonlar
 * varsayılan olarak onları kullanmaya devam eder.
 */


/* ══════════════════════════════════════════════════════════
   Panel "Yeni" etiketi — güncellemeyle gelen özellikler
   ══════════════════════════════════════════════════════════ */

/**
 * "Yeni" etiketi alacak panel öğeleri: anahtar => tanıtıldığı sürüm.
 *
 * Anahtar bir ALT BÖLÜM id'si (ör. "reviews") ya da bir BÖLÜM id'si
 * (ör. "ads", tüm bölümü işaretler) olabilir.
 *
 * KURAL (standart):
 *  - Rozet YALNIZCA tema sürümü buradaki sürüme EŞİTKEN görünür.
 *  - Sürüm numarası bir sonraki güncellemede değişince rozet kendiliğinden
 *    kaybolur; elle temizlik / ek kayıt GEREKMEZ.
 *  - Yeni özellik işaretlemek için: 'anahtar' => '<yayınlanan sürüm>'.
 *  - Yalnızca o sürümde İLK KEZ eklenen/değişen öğeler yazılır.
 *
 * @return array
 */
function devxpe_panel_feature_versions() {
	return array(
		/* Reklam Ayarları: kod alanlarına "önerilen ölçü + örnek kodu kopyala". */
		'ads'      => '0.3.56',

		/* Anasayfa: sekmeli tekrarlayıcılar (+ / − sayaç, 3 sütun + mobil sekme). */
		'steps'    => '0.3.56',
		'projects' => '0.3.56',
		'reviews'  => '0.3.56',
		'faq'      => '0.3.56',

		/* Form → Doğrulama: 4 eşit kart düzeni. */
		'validate' => '0.3.56',

		/* Site Ayarları: Tema Dili (ön yüz) + mobil alt bar buton kartları. */
		'general'  => '0.3.56',
		'floating' => '0.3.56',

		/* Tasarım: arkaplan rengi (bg_color) tüm bölüm zeminlerine. */
		'design'   => '0.3.56',
	);
}

/**
 * Özellik "yeni" mi? (yalnızca tanıtıldığı sürümde görünür)
 *
 * @param string $key Bölüm veya alt bölüm id'si.
 * @return bool
 */
function devxpe_feature_is_new( $key ) {
	$map = devxpe_panel_feature_versions();

	return isset( $map[ $key ] ) && (string) $map[ $key ] === (string) DEVXPE_THEME_VERSION;
}

/**
 * Bölümde "yeni" bir öğe var mı? (bölümün kendisi ya da bir alt bölümü)
 *
 * @param array  $section    Panel bölüm tanımı.
 * @param string $section_id Bölüm id'si.
 * @return bool
 */
function devxpe_section_has_new( $section, $section_id = '' ) {
	if ( '' !== $section_id && devxpe_feature_is_new( $section_id ) ) {
		return true;
	}

	if ( empty( $section['subsections'] ) ) {
		return false;
	}

	foreach ( $section['subsections'] as $sub_id => $sub ) {
		if ( devxpe_feature_is_new( $sub_id ) ) {
			return true;
		}
	}

	return false;
}

/**
 * "Yeni" rozeti HTML'i (yeni değilse boş döner).
 *
 * @param string $key Bölüm veya alt bölüm id'si.
 * @return string
 */
function devxpe_new_badge( $key ) {
	if ( ! devxpe_feature_is_new( $key ) ) {
		return '';
	}

	return ' <span class="dxp-new-badge">' . esc_html__( 'Yeni', 'devxpe-theme' ) . '</span>';
}

/**
 * Verilen zemin rengi koyu mu? (Okunabilir metin rengi beyazsa zemin koyudur.)
 *
 * @param string $color Hex renk.
 * @return bool
 */
function devxpe_bg_is_dark( $color ) {
	if ( ! function_exists( 'devxpe_theme_contrast_color' ) ) {
		return false;
	}

	return ( '#ffffff' === devxpe_theme_contrast_color( (string) $color ) );
}

/**
 * Zemine uygun marka logosunu döndürür.
 *
 * Panelde iki logo vardır: `logo` (açık zeminler) ve `logo_dark` (koyu
 * zeminler). Zemin koyuysa ve "Koyu Zemin Logosu" yüklüyse o kullanılır;
 * yüklü değilse normal logoya düşülür. Logo rengi ÇEVRİLMEZ.
 *
 * @param string $bg Zemin rengi (boşsa header zemini).
 * @return string Logo URL'si (yoksa '').
 */
function devxpe_brand_logo( $bg = '' ) {
	$bg = ( '' !== (string) $bg ) ? (string) $bg : (string) devxpe_theme_get( 'header_bg', '#f6fcf7' );

	if ( devxpe_bg_is_dark( $bg ) ) {
		$dark_logo = (string) devxpe_theme_get( 'logo_dark' );

		if ( '' !== trim( $dark_logo ) ) {
			return $dark_logo;
		}
	}

	return (string) devxpe_theme_get( 'logo' );
}

/**
 * Header sloganının logoya/başlığa göre konumu.
 *
 * @return string 'left' | 'right' | 'top' | 'bottom'
 */
function devxpe_tagline_position() {
	$pos = (string) devxpe_theme_get( 'tagline_pos', 'right' );

	return in_array( $pos, array( 'left', 'right', 'top', 'bottom' ), true ) ? $pos : 'right';
}

/**
 * Tek bir yorumu tema tasarımıyla çizer (wp_list_comments callback).
 *
 * Blog yazısı kart dili: yuvarlatılmış yüzey, avatar + ad + tarih satırı,
 * marka yeşili "Yanıtla" bağlantısı. Pingback/iz sürümleri sade gösterilir.
 *
 * @param WP_Comment $comment Yorum nesnesi.
 * @param array      $args    wp_list_comments argümanları.
 * @param int        $depth   Girinti derinliği.
 * @return void
 */
function devxpe_comment_item( $comment, $args, $depth ) {
	$dxp_etiket = 'div' === $args['style'] ? 'div' : 'li';
	?>
	<<?php echo $dxp_etiket; ?> id="comment-<?php comment_ID(); ?>" <?php comment_class( 'dxp-comment' ); ?>>
		<article class="dxp-comment-body">
			<div class="dxp-comment-head">
				<?php echo get_avatar( $comment, (int) $args['avatar_size'], '', '', array( 'class' => 'dxp-comment-avatar' ) ); ?>
				<div class="dxp-comment-meta">
					<span class="dxp-comment-author"><?php echo get_comment_author_link( $comment ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
					<time class="dxp-comment-date" datetime="<?php echo esc_attr( get_comment_time( 'c' ) ); ?>">
						<?php
						printf(
							/* translators: %s: yorum tarihi. */
							esc_html__( '%s tarihinde', 'devxpe-theme' ),
							esc_html( get_comment_date( '', $comment ) )
						);
						?>
					</time>
				</div>
			</div>

			<?php if ( '0' === (string) $comment->comment_approved ) : ?>
				<p class="dxp-comment-pending"><?php esc_html_e( 'Yorumunuz onay bekliyor.', 'devxpe-theme' ); ?></p>
			<?php endif; ?>

			<div class="dxp-comment-text"><?php comment_text(); ?></div>

			<div class="dxp-comment-actions">
				<?php
				comment_reply_link(
					array_merge(
						$args,
						array(
							'depth'     => $depth,
							'max_depth' => $args['max_depth'],
							'reply_text' => esc_html__( 'Yanıtla', 'devxpe-theme' ),
						)
					)
				);
				edit_comment_link( esc_html__( 'Düzenle', 'devxpe-theme' ), '<span class="dxp-comment-edit">', '</span>' );
				?>
			</div>
		</article>
	<?php
	// Kapanış etiketi wp_list_comments tarafından eklenir.
}

