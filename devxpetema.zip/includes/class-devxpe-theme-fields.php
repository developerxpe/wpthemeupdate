<?php
/**
 * DEVXPE tema alan sistemi.
 *
 * Alan tanımlarını tutar; güvenli okuma, temizleme ve çizim sağlar.
 * Temalar değerleri devxpe_theme_get() ile okur.
 * Desteklenen tipler: text, textarea, select, checkbox, url, email, tel,
 * color, image, scripts.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DEVXPE_Theme_Fields {

	/**
	 * Temanın tek ayar kaydı (Safir'e benzer tek option'da tüm panel).
	 */
	const OPTION_KEY = 'devxpe_theme_options';

	/**
	 * Kayıtlı alan tanımları: id => args.
	 *
	 * @var array
	 */
	private static $registered = array();

	/**
	 * Tema option dizisinin istek-içi RAM önbelleği.
	 *
	 * `get_option(self::OPTION_KEY)` her `devxpe_theme_get()` çağrısında
	 * tekrarlanmasın diye. Kaydet/import/sil sonrası `flush()` ile sıfırlanır.
	 *
	 * @var array|null
	 */
	private static $options_cache = null;

	/**
	 * Yeni bir alan kaydeder.
	 *
	 * 'wp_option' set edilirse alan bu WordPress option'ına doğrudan
	 * yazılır/okunur (örn. site_title -> blogname).
	 *
	 * @param string $id   Benzersiz alan id'si.
	 * @param array  $args Alan argümanları: label, type, default, options, wp_option, help.
	 * @return void
	 */
	public static function register( $id, $args ) {
		$defaults = array(
			'label'     => '',
			'type'      => 'text',
			'default'   => '',
			'options'   => array(),
			'wp_option' => '',
			'help'      => '',
		);

		self::$registered[ $id ] = wp_parse_args( $args, $defaults );
	}

	/**
	 * Tüm kayıtlı alanları döndürür.
	 *
	 * @return array
	 */
	public static function all() {
		return self::$registered;
	}

	/**
	 * Bir alanın değerini okur.
	 *
	 * @param string $id      Alan id'si.
	 * @param mixed  $default Alan boşsa kullanılacak değer.
	 * @return mixed
	 */
	public static function get( $id, $default = '' ) {
		if ( ! isset( self::$registered[ $id ] ) ) {
			return $default;
		}

		$field = self::$registered[ $id ];

		if ( ! empty( $field['wp_option'] ) ) {
			$value = get_option( $field['wp_option'], $default );

			/*
			 * WordPress çekirdeği `blogname`/`blogdescription` değerini kayıtta
			 * esc_html() ile kaçırır (sanitize_option). Panelde ve temada gerçek
			 * metni ("&") görmek için burada çözüyoruz; kayıt tarafında tekrar
			 * kaçırılacağı için DB'de entity kalması normaldir. Çıktıda esc_*
			 * kullanıldığından çift kaçış oluşmaz (esc_* mevcut entity'leri
			 * yeniden kodlamaz).
			 */
			if (
				in_array( $field['wp_option'], array( 'blogname', 'blogdescription' ), true )
				&& is_string( $value )
			) {
				$value = wp_specialchars_decode( $value, ENT_QUOTES );
			}

			return $value;
		}

		/*
		 * Tüm tema option'ı tek istekte bir kez okunur (RAM önbelleği).
		 * Kaydettikten sonra bayat kalmasın diye `flush()` çağrılır.
		 * get_option kendisi de otomatik yükleme yapar; bu yalnızca dizi
		 * kurulumunu tekrarlamamak içindir.
		 */
		if ( null === self::$options_cache ) {
			$opts = get_option( self::OPTION_KEY, array() );
			self::$options_cache = is_array( $opts ) ? $opts : array();
		}

		if ( isset( self::$options_cache[ $id ] ) ) {
			return self::$options_cache[ $id ];
		}

		return isset( $field['default'] ) ? $field['default'] : $default;
	}

	/**
	 * Option RAM önbelleğini temizler (kaydet/import/sil sonrası çağrılır).
	 *
	 * @return void
	 */
	public static function flush() {
		self::$options_cache = null;
	}

	/**
	 * Alan tipine uygun sanitleştirici adını döndürür.
	 *
	 * @param string $type Alan tipi.
	 * @return callable|string
	 */
	public static function sanitizer( $type ) {
		switch ( $type ) {
			case 'textarea':
				return 'sanitize_textarea_field';
			case 'scripts':
				return 'devxpe_theme_sanitize_scripts';
			case 'email':
				return 'sanitize_email';
			case 'url':
			case 'image':
				return 'esc_url_raw';
			case 'checkbox':
				return 'devxpe_theme_sanitize_checkbox';
			case 'password':
				return 'devxpe_theme_sanitize_password';
			case 'color':
				return 'sanitize_text_field';
			case 'datetime':
				return 'devxpe_theme_sanitize_datetime';
			case 'typography':
				return 'devxpe_theme_sanitize_typography';
			case 'team':
				return 'devxpe_theme_sanitize_team';
			case 'pages':
				return 'devxpe_theme_sanitize_pages';
			case 'countries':
				return 'devxpe_theme_sanitize_countries';
			case 'logos':
				return 'devxpe_theme_sanitize_logos';
			case 'cards':
				return 'devxpe_theme_sanitize_cards';
			case 'rows':
				return 'devxpe_theme_sanitize_rows';
			case 'projects':
				return 'devxpe_theme_sanitize_projects';
			case 'form_fields':
				return 'devxpe_theme_sanitize_form_fields';
			case 'forms':
				return 'devxpe_theme_sanitize_forms';
			case 'cpts':
				return 'devxpe_theme_sanitize_cpts';
			case 'sections':
				return 'devxpe_theme_sanitize_section_order';
			default:
				return 'sanitize_text_field';
		}
	}

	/**
	 * Tek bir alanın değerini tipine göre temizler.
	 *
	 * @param string $id    Alan id'si.
	 * @param mixed  $value Kullanıcıdan gelen ham değer.
	 * @return string
	 */
	public static function sanitize( $id, $value ) {
		if ( ! isset( self::$registered[ $id ] ) ) {
			return self::skaler_temizle( $value );
		}

		$type = self::$registered[ $id ]['type'];
		$fn   = self::sanitizer( $type );

		/*
		 * Dizi (liste) tipi alanlar: temizleyici diziyi bekler, skaler değeri
		 * diziye çevirip veririz. Diğerleri metin temizleyicisinden geçer.
		 */
		$dizi_tipleri = array( 'typography', 'team', 'pages', 'countries', 'logos', 'cards', 'rows', 'projects', 'form_fields', 'forms', 'cpts' );

		if ( in_array( $type, $dizi_tipleri, true ) ) {
			return call_user_func( $fn, (array) $value );
		}

		$clean = self::skaler_temizle( $value, $fn );

		// Alan için karakter limiti tanımlıysa sunucu tarafında da uygula.
		if ( ! empty( self::$registered[ $id ]['maxlength'] ) ) {
			$clean = mb_substr( $clean, 0, absint( self::$registered[ $id ]['maxlength'] ) );
		}

		return $clean;
	}

	/**
	 * Skaler olmayan değeri güvenle metne çevirir.
	 *
	 * NEDEN: İçe aktarma ya da bozuk bir kayıt, metin bekleyen bir alana dizi
	 * gönderebilir. Eskiden doğrudan `(string) $value` yapıldığı için PHP
	 * "Array to string conversion" uyarısı üretiyordu. Artık dizi gelirse
	 * anlamlı bir metne çevrilir; uyarı çıkmaz.
	 *
	 * @param mixed         $value Değer.
	 * @param callable|null $fn    Metin temizleyici (null ise sanitize_text_field).
	 * @return string
	 */
	private static function skaler_temizle( $value, $fn = null ) {
		if ( is_array( $value ) ) {
			/* Düz liste ise virgülle birleştir; iç içe dizi ise boş döner. */
			$duz = array();

			foreach ( $value as $v ) {
				if ( is_scalar( $v ) ) {
					$duz[] = (string) $v;
				}
			}

			$value = implode( ', ', $duz );
		} elseif ( is_object( $value ) ) {
			$value = '';
		} elseif ( null === $value || is_bool( $value ) ) {
			$value = $value ? '1' : '';
		} else {
			$value = (string) $value;
		}

		if ( ! is_callable( $fn ) ) {
			$fn = 'sanitize_text_field';
		}

		return (string) call_user_func( $fn, $value );
	}

	/**
	 * Tek bir alan inputunu tipine göre çizer.
	 *
	 * @param string $id    Alan id'si.
	 * @param array  $field Alan tanımı.
	 * @param string $value Güncel değer.
	 * @param string $name  İsteğe bağlı input name'i.
	 * @return void
	 */
	public static function render_input( $id, $field, $value, $name = null ) {
		$name = $name ? $name : $id;

		switch ( $field['type'] ) {
			case 'textarea':
				$max = ! empty( $field['maxlength'] ) ? absint( $field['maxlength'] ) : 0;
				echo '<textarea id="dxp_' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" class="large-text" rows="4" autocomplete="off"' . ( $max ? ' maxlength="' . esc_attr( $max ) . '"' : '' ) . '>' . esc_textarea( $value ) . '</textarea>';
				if ( $max ) {
					echo '<p class="description dxp-charcount" data-for="dxp_' . esc_attr( $id ) . '" data-max="' . esc_attr( $max ) . '"></p>';
				}
				break;

			case 'scripts':
				echo '<textarea id="dxp_' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" rows="6" class="large-text code" autocomplete="off">' . esc_textarea( $value ) . '</textarea>';
				break;

			case 'select':
				self::render_custom_select( $name, $field['options'], $value );
				break;

			case 'checkbox':
				echo '<label for="dxp_' . esc_attr( $id ) . '">';
				echo '<input type="checkbox" id="dxp_' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" value="1" ' . checked( '1', $value, false ) . ' />';
				echo '</label>';
				break;

			case 'url':
				echo '<input type="url" id="dxp_' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '" class="regular-text" autocomplete="off" />';
				break;

			case 'email':
				echo '<input type="email" id="dxp_' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '" class="regular-text" autocomplete="off" />';
				break;

			case 'tel':
				echo '<input type="tel" id="dxp_' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '" class="regular-text" autocomplete="off" />';
				break;

			case 'datetime':
				/* Takvimli tarih-saat seçici (tarayıcı yerel). */
				echo '<input type="datetime-local" id="dxp_' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( devxpe_theme_sanitize_datetime( $value ) ) . '" class="regular-text" />';
				break;

			case 'password':
				/* Şifre alanı: tarayıcı otomatik doldurmasın, göz ikonu ile görülebilir. */
				echo '<input type="password" id="dxp_' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '" class="regular-text" autocomplete="new-password" />';
				break;

			case 'subject':
				/*
				 * E-posta konusu: üstünde tıklanabilir {alan} çipleri.
				 * Çipe tıklayınca değişken input'a eklenir (panel.js bindTokens).
				 */
				echo '<div class="dxp-tokens">';
				echo '<span class="dxp-tokens-hint">' . esc_html__( 'Tıklayınca konuya eklenir:', 'devxpe-theme' ) . '</span>';
				foreach ( devxpe_form_token_options() as $dxp_token ) {
					echo '<button type="button" class="dxp-token" data-token="' . esc_attr( $dxp_token['token'] ) . '" title="' . esc_attr( $dxp_token['token'] ) . '">'
						. esc_html( $dxp_token['label'] ) . '</button>';
				}
				echo '</div>';
				echo '<input type="text" id="dxp_' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '" class="regular-text" autocomplete="off" />';
				break;

			case 'color':
				echo '<div class="dxp-color-field">';
				$hex_val = strpos( $value, '#' ) === 0 ? substr( $value, 0, 7 ) : '#000000';
				$opacity = 100;
				if ( preg_match( '/rgba\(.*?,.*?,.*?,(.*?)\)/', $value, $matches ) ) {
					$opacity = floatval( $matches[1] ) * 100;
					$hex_val = '#000000'; // fallback
				}
				$uid = 'dxp_' . esc_attr( $id );
				
				echo '<input type="color" id="clr_' . $uid . '" class="dxp-color-swatch" value="' . esc_attr( $hex_val ) . '" aria-label="' . esc_attr__( 'Renk Seçici', 'devxpe-theme' ) . '" title="' . esc_attr__( 'Renk Seçici', 'devxpe-theme' ) . '" />';
				echo '<input type="range" id="opc_' . $uid . '" class="dxp-color-opacity" min="0" max="100" value="' . esc_attr( $opacity ) . '" aria-label="' . esc_attr__( 'Şeffaflık (Opacity)', 'devxpe-theme' ) . '" title="' . esc_attr__( 'Şeffaflık (Opacity)', 'devxpe-theme' ) . '" />';
				echo '<input type="text" id="' . $uid . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '" class="regular-text dxp-color-input" autocomplete="off" aria-label="' . esc_attr__( 'Renk değeri', 'devxpe-theme' ) . '" placeholder="' . esc_attr__( 'Hex, rgba() veya var()', 'devxpe-theme' ) . '" />';
				
				echo '<script>
					(function(){
						var clr = document.getElementById("clr_' . $uid . '");
						var opc = document.getElementById("opc_' . $uid . '");
						var txt = document.getElementById("' . $uid . '");
						function hexToRgba(hex, alpha) {
							var r = parseInt(hex.slice(1, 3), 16), g = parseInt(hex.slice(3, 5), 16), b = parseInt(hex.slice(5, 7), 16);
							return "rgba(" + r + ", " + g + ", " + b + ", " + alpha + ")";
						}
						function updateText() {
							if (opc.value < 100) {
								txt.value = hexToRgba(clr.value, opc.value / 100);
							} else {
								txt.value = clr.value;
							}
						}
						clr.addEventListener("input", updateText);
						opc.addEventListener("input", updateText);
					})();
				</script>';
				
				if ( class_exists( 'Elementor\Plugin' ) ) {
					$ecolor_options = array();
					$kit_id         = get_option( 'elementor_active_kit' );
					if ( $kit_id ) {
						$meta        = get_post_meta( $kit_id, '_elementor_page_settings', true );
						$all_ecolors = array_merge(
							! empty( $meta['system_colors'] ) ? $meta['system_colors'] : array(),
							! empty( $meta['custom_colors'] ) ? $meta['custom_colors'] : array()
						);
						foreach ( $all_ecolors as $ecolor ) {
							$ecolor_options[ 'var(--e-global-color-' . $ecolor['_id'] . ')' ] = $ecolor['title'];
						}
					}

					if ( ! empty( $ecolor_options ) ) {
						echo '<div class="dxp-select dxp-select-elem" data-target="' . esc_attr( $uid ) . '">';
						echo '<button type="button" class="dxp-select-trigger" aria-haspopup="listbox" aria-expanded="false"><span class="dxp-select-current">' . esc_html__( 'Elementor Rengi', 'devxpe-theme' ) . '</span><span class="dxp-select-caret" aria-hidden="true">▾</span></button>';
						echo '<div class="dxp-select-menu" role="listbox" hidden>';
						foreach ( $ecolor_options as $ev => $el ) {
							echo '<button type="button" role="option" class="dxp-select-item" data-value="' . esc_attr( $ev ) . '">' . esc_html( $el ) . '</button>';
						}
						echo '</div></div>';
					}
				}
				echo '</div>';
				break;

			case 'typography':
				$val = wp_parse_args( (array) $value, array(
					'family' => 'system',
					'size'   => '',
					'weight' => '',
					'lh'     => '',
					'ls'     => '',
				) );
				
				echo '<div class="dxp-typography-wrap">';
				
				// Font Family
				$family_options = array( 'system' => __( 'Sistem Varsayılanı', 'devxpe-theme' ) );

				if ( class_exists( 'Elementor\Plugin' ) ) {
					$kit_id = get_option( 'elementor_active_kit' );
					if ( $kit_id ) {
						$meta       = get_post_meta( $kit_id, '_elementor_page_settings', true );
						$all_efonts = array_merge(
							! empty( $meta['system_typography'] ) ? $meta['system_typography'] : array(),
							! empty( $meta['custom_typography'] ) ? $meta['custom_typography'] : array()
						);
						foreach ( $all_efonts as $efont ) {
							$family_options[ 'var(--e-global-typography-' . $efont['_id'] . '-font-family)' ] = $efont['title'];
						}
					}
				}

				$google_fonts = array( 'Inter', 'Roboto', 'Open Sans', 'Montserrat', 'Poppins', 'Lato', 'Oswald', 'Source Sans Pro', 'Raleway', 'Ubuntu', 'Merriweather', 'Playfair Display', 'Nunito', 'Rubik', 'Work Sans' );
				foreach ( $google_fonts as $gf ) {
					$family_options[ $gf ] = $gf;
				}

				echo '<div class="dxp-typography-group"><span class="dxp-typography-label">' . esc_html__( 'Font Ailesi', 'devxpe-theme' ) . '</span>';
				self::render_custom_select( $name . '[family]', $family_options, $val['family'] );
				echo '</div>';

				// Font Size
				echo '<div class="dxp-typography-group"><label class="dxp-typography-label" for="dxp_' . esc_attr( $name ) . '_size">' . esc_html__( 'Boyut (örn: 16px, 1.2rem)', 'devxpe-theme' ) . '</label>';
				echo '<input type="text" id="dxp_' . esc_attr( $name ) . '_size" autocomplete="off" name="' . esc_attr( $name ) . '[size]" value="' . esc_attr( $val['size'] ) . '" /></div>';

				// Font Weight
				$weights = array(
					''    => __( 'Varsayılan', 'devxpe-theme' ),
					'100' => '100 (Thin)',
					'300' => '300 (Light)',
					'400' => '400 (Normal)',
					'500' => '500 (Medium)',
					'600' => '600 (Semi-Bold)',
					'700' => '700 (Bold)',
					'900' => '900 (Black)',
				);
				echo '<div class="dxp-typography-group"><span class="dxp-typography-label">' . esc_html__( 'Kalınlık', 'devxpe-theme' ) . '</span>';
				self::render_custom_select( $name . '[weight]', $weights, $val['weight'] );
				echo '</div>';
				
				// Line Height
				echo '<div class="dxp-typography-group"><label class="dxp-typography-label" for="dxp_' . esc_attr( $name ) . '_lh">' . esc_html__( 'Satır Yüksekliği (örn: 1.5, 24px)', 'devxpe-theme' ) . '</label>';
				echo '<input type="text" id="dxp_' . esc_attr( $name ) . '_lh" autocomplete="off" name="' . esc_attr( $name ) . '[lh]" value="' . esc_attr( $val['lh'] ) . '" /></div>';
				
				// Letter Spacing
				echo '<div class="dxp-typography-group"><label class="dxp-typography-label" for="dxp_' . esc_attr( $name ) . '_ls">' . esc_html__( 'Harf Boşluğu (örn: 0.5px)', 'devxpe-theme' ) . '</label>';
				echo '<input type="text" id="dxp_' . esc_attr( $name ) . '_ls" autocomplete="off" name="' . esc_attr( $name ) . '[ls]" value="' . esc_attr( $val['ls'] ) . '" /></div>';
				
				echo '</div>';
				break;

			case 'radio_image':
				echo '<div class="dxp-radio-image-wrap">';
				foreach ( $field['options'] as $opt_value => $opt_data ) {
					$img_url = isset( $opt_data['image'] ) ? $opt_data['image'] : '';
					$opt_lbl = isset( $opt_data['label'] ) ? $opt_data['label'] : $opt_value;
					$uid     = 'dxp_' . esc_attr( $id . '_' . $opt_value );
					$is_sel  = ( (string) $value === (string) $opt_value );

					echo '<label for="' . esc_attr( $uid ) . '" class="dxp-radio-image-label' . ( $is_sel ? ' is-selected' : '' ) . '">';
					echo '<input type="radio" class="dxp-radio-image-input" id="' . esc_attr( $uid ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $opt_value ) . '"' . checked( $is_sel, true, false ) . ' />';
					echo '<img src="' . esc_attr( $img_url ) . '" alt="' . esc_attr( $opt_lbl ) . '" />';
					echo '<span>' . esc_html( $opt_lbl ) . '</span>';
					echo '</label>';
				}
				echo '</div>';
				break;

			case 'image':
				self::render_image_field( $id, $name, $value );
				break;

			case 'team':
				self::render_team_field( $id, $name, $value );
				break;

			case 'logos':
				self::render_logos_field( $id, $name, $value );
				break;

			case 'cards':
				self::render_cards_field( $id, $name, $value );
				break;

			case 'rows':
				self::render_rows_field( $id, $name, $value, $field );
				break;

			case 'projects':
				self::render_projects_field( $id, $name, $value );
				break;

			case 'form_fields':
				/* Form oluşturucu: kayıt yoksa formun varsayılan alanlarıyla başlar. */
				if ( ( ! is_array( $value ) || ! $value ) && ! empty( $field['slug'] ) ) {
					$value = devxpe_form_fields( $field['slug'] );
				}
				self::render_form_fields_list( $id, $name, $value );
				break;

			case 'forms':
				self::render_forms_field( $id, $name, $value );
				break;

			case 'shortcode':
				self::render_shortcode_field( $id, $value, $field );
				break;

			case 'cpts':
				self::render_cpts_field( $id, $name, $value );
				break;

			case 'sections':
				self::render_sections_field( $id, $name, $value );
				break;

			case 'pages':
				self::render_pages_field( $id, $name, $value );
				break;

			case 'countries':
				self::render_countries_field( $name, $value );
				break;

			case 'icon':
				self::render_icon_field( $id, $name, $field, $value );
				break;

			case 'icon_lucide':
				self::render_lucide_picker( $name, $value );
				break;

			default:
				echo '<input type="text" id="dxp_' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '" class="regular-text" autocomplete="off" />';
				break;
		}
	}

	/**
	 * Özel (native olmayan) açılır menü çizer.
	 *
	 * Native <select> yerine panel temasına tam uyumlu bir dropdown üretir;
	 * değeri gizli bir input taşır.
	 *
	 * @param string $name    Input name'i.
	 * @param array  $options value => label.
	 * @param string $value   Seçili değer.
	 * @return void
	 */
	public static function render_custom_select( $name, $options, $value ) {
		$options = (array) $options;
		$value   = (string) $value;
		$current = '';

		foreach ( $options as $ov => $ol ) {
			if ( (string) $ov === $value ) {
				$current = $ol;
				break;
			}
		}
		if ( '' === $current && ! empty( $options ) ) {
			$keys    = array_keys( $options );
			$value   = (string) $keys[0];
			$current = $options[ $keys[0] ];
		}
		?>
		<div class="dxp-select">
			<input type="hidden" class="dxp-select-value" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>" />
			<button type="button" class="dxp-select-trigger" aria-haspopup="listbox" aria-expanded="false">
				<span class="dxp-select-current"><?php echo esc_html( $current ); ?></span>
				<span class="dxp-select-caret" aria-hidden="true">▾</span>
			</button>
			<div class="dxp-select-menu" role="listbox" hidden>
				<?php foreach ( $options as $ov => $ol ) : ?>
				<button type="button" role="option" class="dxp-select-item<?php echo ( (string) $ov === $value ) ? ' is-selected' : ''; ?>" data-value="<?php echo esc_attr( $ov ); ?>" aria-selected="<?php echo ( (string) $ov === $value ) ? 'true' : 'false'; ?>">
					<?php echo esc_html( $ol ); ?>
				</button>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Medyadan seçimli resim alanını çizer.
	 *
	 * @param string $id    Alan id'si.
	 * @param string $name  Input name'i.
	 * @param string $value Güncel resim URL'si.
	 * @return void
	 */
	private static function render_image_field( $id, $name, $value ) {
		echo '<div class="dxp-image-field">';
		if ( $value ) {
			echo '<div class="dxp-image-preview"><img src="' . esc_url( $value ) . '" alt="" /></div>';
		} else {
			echo '<div class="dxp-image-preview"></div>';
		}
		echo '<div class="dxp-image-controls">';
		echo '<input type="text" id="dxp_' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" value="' . esc_url( $value ) . '" class="dxp-image-url" autocomplete="off" placeholder="https://" />';
		echo '<button type="button" class="dxp-image-upload">' . esc_html__( 'Resim Seç', 'devxpe-theme' ) . '</button>';
		if ( $value ) {
			echo '<button type="button" class="dxp-image-remove" onclick="this.closest(\'.dxp-image-field\').querySelector(\'.dxp-image-url\').value=\'\';this.closest(\'.dxp-image-field\').querySelector(\'.dxp-image-preview\').innerHTML=\'\';">' . esc_html__( 'Kaldır', 'devxpe-theme' ) . '</button>';
		}
		echo '</div>';
		echo '</div>';
	}

	/**
	 * Tekrarlanabilir "çalışan" listesini çizer.
	 *
	 * Her satır: isim, görsel ve görev. Satırlar eklenir/silinir/sıralanır;
	 * sıralama panel.js'teki repeater mantığıyla yönetilir.
	 *
	 * @param string $id    Alan id'si.
	 * @param string $name  Input name'i.
	 * @param mixed  $value Kayıtlı satırlar (array).
	 * @return void
	 */
	private static function render_team_field( $id, $name, $value ) {
		$items = is_array( $value ) ? array_values( $value ) : array();

		echo '<div class="dxp-repeater" data-repeater="' . esc_attr( $id ) . '">';
		echo '<div class="dxp-repeater-list">';
		$index = 0;
		foreach ( $items as $item ) {
			self::render_team_row( $name, $item, $index );
			$index++;
		}
		echo '</div>';
		echo '<button type="button" class="dxp-repeater-add">' . esc_html__( '+ Çalışan Ekle', 'devxpe-theme' ) . '</button>';
		echo '<template class="dxp-repeater-template">';
		self::render_team_row( $name, array( 'name' => '', 'image' => '', 'role' => '' ), 0 );
		echo '</template>';
		echo '</div>';
	}

	/**
	 * Tek bir çalışan satırını çizer.
	 *
	 * @param string $name  Input name ön eki.
	 * @param array  $item  name/image/role değerleri.
	 * @param int    $index Satır indeksi.
	 * @return void
	 */
	private static function render_team_row( $name, $item, $index = 0 ) {
		$item  = wp_parse_args( (array) $item, array( 'name' => '', 'image' => '', 'role' => '' ) );
		$index = absint( $index );
		?>
		<div class="dxp-repeater-row">
			<div class="dxp-repeater-fields">
				<div class="dxp-repeater-field">
					<span class="dxp-repeater-label"><?php esc_html_e( 'İsim', 'devxpe-theme' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][name]" autocomplete="off" aria-label="<?php esc_attr_e( 'Çalışan adı', 'devxpe-theme' ); ?>" value="<?php echo esc_attr( $item['name'] ); ?>" />
				</div>
				<div class="dxp-repeater-field">
					<span class="dxp-repeater-label"><?php esc_html_e( 'Görev', 'devxpe-theme' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][role]" autocomplete="off" aria-label="<?php esc_attr_e( 'Çalışan görevi', 'devxpe-theme' ); ?>" value="<?php echo esc_attr( $item['role'] ); ?>" />
				</div>
				<div class="dxp-repeater-field dxp-image-field">
					<div class="dxp-image-preview"><?php if ( $item['image'] ) : ?><img src="<?php echo esc_url( $item['image'] ); ?>" alt="" /><?php endif; ?></div>
					<div class="dxp-image-controls">
						<input type="text" name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][image]" autocomplete="off" aria-label="<?php esc_attr_e( 'Çalışan görseli URL', 'devxpe-theme' ); ?>" value="<?php echo esc_url( $item['image'] ); ?>" class="dxp-image-url" placeholder="https://" />
						<button type="button" class="dxp-image-upload"><?php esc_html_e( 'Resim Seç', 'devxpe-theme' ); ?></button>
						<?php if ( $item['image'] ) : ?>
						<button type="button" class="dxp-image-remove" onclick="this.closest('.dxp-image-field').querySelector('.dxp-image-url').value='';this.closest('.dxp-image-field').querySelector('.dxp-image-preview').innerHTML='';"><?php esc_html_e( 'Kaldır', 'devxpe-theme' ); ?></button>
						<?php endif; ?>
					</div>
				</div>
			</div>
			<div class="dxp-repeater-actions">
				<button type="button" class="dxp-repeater-up" title="<?php esc_attr_e( 'Yukarı Taşı', 'devxpe-theme' ); ?>">&uarr;</button>
				<button type="button" class="dxp-repeater-down" title="<?php esc_attr_e( 'Aşağı Taşı', 'devxpe-theme' ); ?>">&darr;</button>
				<button type="button" class="dxp-repeater-remove" title="<?php esc_attr_e( 'Sil', 'devxpe-theme' ); ?>">&times;</button>
			</div>
		</div>
		<?php
	}

	/**
	 * Tekrarlanabilir "referans logosu" listesini çizer.
	 *
	 * Satırlar eklenir/silinir/sıralanır; davranış `team` alanıyla aynıdır
	 * (panel.js'teki .dxp-repeater mantığı ortaktır).
	 *
	 * @param string $id    Alan id'si.
	 * @param string $name  Input name'i.
	 * @param mixed  $value Kayıtlı satırlar (array).
	 * @return void
	 */
	private static function render_logos_field( $id, $name, $value ) {
		$items = is_array( $value ) ? array_values( $value ) : array();

		echo '<div class="dxp-repeater" data-repeater="' . esc_attr( $id ) . '">';
		echo '<div class="dxp-repeater-list">';
		$index = 0;
		foreach ( $items as $item ) {
			self::render_logos_row( $name, $item, $index );
			$index++;
		}
		echo '</div>';
		echo '<button type="button" class="dxp-repeater-add">' . esc_html__( '+ Logo Ekle', 'devxpe-theme' ) . '</button>';
		echo '<template class="dxp-repeater-template">';
		self::render_logos_row( $name, array( 'image' => '', 'url' => '', 'alt' => '' ), 0 );
		echo '</template>';
		echo '</div>';
	}

	/**
	 * Tek bir referans logo satırını çizer.
	 *
	 * @param string $name  Input name ön eki.
	 * @param array  $item  image/url/alt değerleri.
	 * @param int    $index Satır indeksi.
	 * @return void
	 */
	private static function render_logos_row( $name, $item, $index = 0 ) {
		$item  = wp_parse_args( (array) $item, array( 'image' => '', 'url' => '', 'alt' => '' ) );
		$index = absint( $index );
		?>
		<div class="dxp-repeater-row">
			<div class="dxp-repeater-fields">
				<div class="dxp-repeater-field dxp-image-field">
					<span class="dxp-repeater-label"><?php esc_html_e( 'Logo', 'devxpe-theme' ); ?></span>
					<div class="dxp-image-preview"><?php if ( $item['image'] ) : ?><img src="<?php echo esc_url( $item['image'] ); ?>" alt="" /><?php endif; ?></div>
					<div class="dxp-image-controls">
						<input type="text" name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][image]" autocomplete="off" aria-label="<?php esc_attr_e( 'Logo görseli URL', 'devxpe-theme' ); ?>" value="<?php echo esc_url( $item['image'] ); ?>" class="dxp-image-url" placeholder="https://" />
						<button type="button" class="dxp-image-upload"><?php esc_html_e( 'Resim Seç', 'devxpe-theme' ); ?></button>
						<?php if ( $item['image'] ) : ?>
						<button type="button" class="dxp-image-remove" onclick="this.closest('.dxp-image-field').querySelector('.dxp-image-url').value='';this.closest('.dxp-image-field').querySelector('.dxp-image-preview').innerHTML='';"><?php esc_html_e( 'Kaldır', 'devxpe-theme' ); ?></button>
						<?php endif; ?>
					</div>
				</div>
				<div class="dxp-repeater-field">
					<span class="dxp-repeater-label"><?php esc_html_e( 'Marka Adı', 'devxpe-theme' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][alt]" autocomplete="off" aria-label="<?php esc_attr_e( 'Marka adı', 'devxpe-theme' ); ?>" value="<?php echo esc_attr( $item['alt'] ); ?>" />
				</div>
				<div class="dxp-repeater-field">
					<span class="dxp-repeater-label"><?php esc_html_e( 'Bağlantı (URL)', 'devxpe-theme' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][url]" autocomplete="off" aria-label="<?php esc_attr_e( 'Logo bağlantısı', 'devxpe-theme' ); ?>" value="<?php echo esc_url( $item['url'] ); ?>" placeholder="https://" />
				</div>
			</div>
			<div class="dxp-repeater-actions">
				<button type="button" class="dxp-repeater-up" title="<?php esc_attr_e( 'Yukarı Taşı', 'devxpe-theme' ); ?>">&uarr;</button>
				<button type="button" class="dxp-repeater-down" title="<?php esc_attr_e( 'Aşağı Taşı', 'devxpe-theme' ); ?>">&darr;</button>
				<button type="button" class="dxp-repeater-remove" title="<?php esc_attr_e( 'Sil', 'devxpe-theme' ); ?>">&times;</button>
			</div>
		</div>
		<?php
	}

	/**
	 * Tekrarlanabilir "içerik tipi (CPT)" listesini çizer.
	 *
	 * Her satır bir özel içerik tipi tanımlar; kayıt functions.php'de init
	 * sırasında yapılır. Bu tipler bölümlerde kaynak olarak da kullanılır.
	 *
	 * @param string $id    Alan id'si.
	 * @param string $name  Input name'i.
	 * @param mixed  $value Kayıtlı satırlar (array).
	 * @return void
	 */
	private static function render_cpts_field( $id, $name, $value ) {
		$items = is_array( $value ) ? array_values( $value ) : array();

		/* Dashicon verisi şablonun dışında basılmalı (şablon DOM'a girmez). */
		self::print_dashicons_data();

		echo '<div class="dxp-repeater" data-repeater="' . esc_attr( $id ) . '">';
		echo '<div class="dxp-repeater-list">';
		$index = 0;
		foreach ( $items as $item ) {
			self::render_cpts_row( $name, $item, $index );
			$index++;
		}
		echo '</div>';
		echo '<button type="button" class="dxp-repeater-add">' . esc_html__( '+ İçerik Tipi Ekle', 'devxpe-theme' ) . '</button>';
		echo '<template class="dxp-repeater-template">';
		self::render_cpts_row( $name, array( 'name' => '', 'slug' => '', 'icon' => 'dashicons-admin-post', 'archive' => '1', 'template' => 'layout_1' ), 0 );
		echo '</template>';
		echo '</div>';
	}

	/**
	 * Tek bir içerik tipi satırını çizer.
	 *
	 * @param string $name  Input name ön eki.
	 * @param array  $item  name/slug/icon/archive değerleri.
	 * @param int    $index Satır indeksi.
	 * @return void
	 */
	private static function render_cpts_row( $name, $item, $index = 0 ) {
		$item  = wp_parse_args( (array) $item, array( 'name' => '', 'slug' => '', 'icon' => 'dashicons-admin-post', 'archive' => '1', 'template' => 'layout_1' ) );
		$index = absint( $index );
		?>
		<div class="dxp-repeater-row">
			<div class="dxp-repeater-fields">
				<div class="dxp-repeater-field">
					<span class="dxp-repeater-label"><?php esc_html_e( 'Ad (çoğul)', 'devxpe-theme' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][name]" autocomplete="off" aria-label="<?php esc_attr_e( 'İçerik tipi adı', 'devxpe-theme' ); ?>" value="<?php echo esc_attr( $item['name'] ); ?>" placeholder="<?php esc_attr_e( 'Hizmetler', 'devxpe-theme' ); ?>" />
				</div>
				<div class="dxp-repeater-field">
					<span class="dxp-repeater-label"><?php esc_html_e( 'Slug (URL)', 'devxpe-theme' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][slug]" autocomplete="off" aria-label="<?php esc_attr_e( 'İçerik tipi slug', 'devxpe-theme' ); ?>" value="<?php echo esc_attr( $item['slug'] ); ?>" placeholder="hizmetler" />
				</div>
				<div class="dxp-repeater-field">
					<span class="dxp-repeater-label"><?php esc_html_e( 'Menü İkonu', 'devxpe-theme' ); ?></span>
					<?php self::render_icon_field( $name . '_' . $index . '_icon', $name . '[' . $index . '][icon]', array( 'default' => 'dashicons-admin-post' ), $item['icon'] ); ?>
				</div>
				<div class="dxp-repeater-field">
					<span class="dxp-repeater-label"><?php esc_html_e( 'Arşiv Sayfası', 'devxpe-theme' ); ?></span>
					<select name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][archive]" aria-label="<?php esc_attr_e( 'Arşiv sayfası', 'devxpe-theme' ); ?>">
						<option value="1" <?php selected( $item['archive'], '1' ); ?>><?php esc_html_e( 'Olsun', 'devxpe-theme' ); ?></option>
						<option value="0" <?php selected( $item['archive'], '0' ); ?>><?php esc_html_e( 'Olmasın', 'devxpe-theme' ); ?></option>
					</select>
				</div>
				<div class="dxp-repeater-field">
					<span class="dxp-repeater-label"><?php esc_html_e( 'Varsayılan Şablon', 'devxpe-theme' ); ?></span>
					<select name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][template]" aria-label="<?php esc_attr_e( 'Varsayılan şablon', 'devxpe-theme' ); ?>">
						<?php foreach ( devxpe_template_labels() as $dxp_tpl_id => $dxp_tpl_label ) : ?>
						<option value="<?php echo esc_attr( $dxp_tpl_id ); ?>" <?php selected( devxpe_normalize_template( $item['template'] ), $dxp_tpl_id ); ?>><?php echo esc_html( $dxp_tpl_label ); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
			</div>
			<div class="dxp-repeater-actions">
				<button type="button" class="dxp-repeater-up" title="<?php esc_attr_e( 'Yukarı Taşı', 'devxpe-theme' ); ?>">&uarr;</button>
				<button type="button" class="dxp-repeater-down" title="<?php esc_attr_e( 'Aşağı Taşı', 'devxpe-theme' ); ?>">&darr;</button>
				<button type="button" class="dxp-repeater-remove" title="<?php esc_attr_e( 'Sil', 'devxpe-theme' ); ?>">&times;</button>
			</div>
		</div>
		<?php
	}

	/**
	 * İletişim formu alan türleri (palet ve satır seçimi için).
	 *
	 * @return array type => label
	 */
	private static function form_field_types() {
		return array(
			'input'    => __( 'Metin', 'devxpe-theme' ),
			'email'    => __( 'E-posta', 'devxpe-theme' ),
			'tel'      => __( 'Telefon', 'devxpe-theme' ),
			'number'   => __( 'Sayı', 'devxpe-theme' ),
			'date'     => __( 'Tarih', 'devxpe-theme' ),
			'url'      => __( 'Bağlantı', 'devxpe-theme' ),
			'textarea' => __( 'Uzun metin', 'devxpe-theme' ),
			'select'   => __( 'Açılır liste', 'devxpe-theme' ),
			'checkbox' => __( 'Onay kutusu', 'devxpe-theme' ),
			'file'     => __( 'Dosya', 'devxpe-theme' ),
		);
	}

	/**
	 * Hazır seçenek önerilerini (datalist) bir kez basar.
	 *
	 * Her satırdaki seçenek input'una bağlıdır; kullanıcı yazarken hazır
	 * değerler önerilir. Şablon setleri virgülle ayrılmış string olduğundan
	 * burada tek tek değerlere bölünür (tek satıra tam liste yazılmasın).
	 *
	 * @return void
	 */
	private static function print_option_templates() {
		static $printed = false;
		if ( $printed ) {
			return;
		}
		$printed = true;

		/* Aynı öneri birden çok sette geçebilir; tekrarsız topla. */
		$values = array();
		foreach ( devxpe_form_field_templates() as $options ) {
			foreach ( devxpe_lines( $options, ',' ) as $one ) {
				$values[ $one ] = true;
			}
		}

		echo '<datalist id="dxp-options-templates">';
		foreach ( array_keys( $values ) as $one ) {
			echo '<option value="' . esc_attr( $one ) . '"></option>';
		}
		echo '</datalist>';
	}

	/**
	 * Form alan listesi (tür/etiket/anahtar/…) tekrarlayıcısı.
	 *
	 * @param string $id    Alan id'si.
	 * @param string $name  Input name'i.
	 * @param mixed  $value Kayıtlı satırlar.
	 * @return void
	 */
	private static function render_form_fields_list( $id, $name, $value ) {
		$items = is_array( $value ) ? array_values( $value ) : array();

		/* Hazır seçenek şablonları: müşteri elle yazmak yerine datalist'ten seçer. */
		self::print_option_templates();

		echo '<div class="dxp-repeater" data-repeater="' . esc_attr( $id ) . '">';
		echo '<div class="dxp-repeater-list">';
		$index = 0;
		foreach ( $items as $item ) {
			self::render_form_fields_row( $name, $item, $index );
			$index++;
		}
		echo '</div>';
		echo '<button type="button" class="dxp-repeater-add">' . esc_html__( '+ Alan Ekle', 'devxpe-theme' ) . '</button>';
		echo '<template class="dxp-repeater-template">';
		self::render_form_fields_row( $name, array( 'type' => 'input', 'label' => '', 'key' => '', 'required' => '0', 'width' => 'full', 'placeholder' => '', 'options' => '', 'help' => '' ), 0 );
		echo '</template>';
		echo '</div>';
	}

	/**
	 * Tek bir form alanı satırını çizer.
	 *
	 * @param string $name  Input name ön eki.
	 * @param array  $item  type/label/key/required/width/placeholder/options.
	 * @param int    $index Satır indeksi.
	 * @return void
	 */
	private static function render_form_fields_row( $name, $item, $index = 0 ) {
		$item  = wp_parse_args( (array) $item, array( 'type' => 'input', 'label' => '', 'key' => '', 'required' => '0', 'width' => 'half', 'placeholder' => '', 'options' => '', 'help' => '' ) );
		$index = absint( $index );
		?>
		<div class="dxp-repeater-row" data-type="<?php echo esc_attr( $item['type'] ); ?>">
			<div class="dxp-repeater-fields">
				<div class="dxp-repeater-inline">
					<div class="dxp-repeater-field">
						<span class="dxp-repeater-label"><?php esc_html_e( 'Tür', 'devxpe-theme' ); ?></span>
						<select class="dxp-field-type" name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][type]" aria-label="<?php esc_attr_e( 'Alan türü', 'devxpe-theme' ); ?>">
							<?php foreach ( self::form_field_types() as $type_id => $type_label ) : ?>
							<option value="<?php echo esc_attr( $type_id ); ?>" <?php selected( $item['type'], $type_id ); ?>><?php echo esc_html( $type_label ); ?></option>
							<?php endforeach; ?>
						</select>
					</div>
					<div class="dxp-repeater-field">
						<span class="dxp-repeater-label"><?php esc_html_e( 'Genişlik', 'devxpe-theme' ); ?></span>
						<select name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][width]" aria-label="<?php esc_attr_e( 'Alan genişliği', 'devxpe-theme' ); ?>">
							<option value="half" <?php selected( $item['width'], 'half' ); ?>><?php esc_html_e( 'Yarım', 'devxpe-theme' ); ?></option>
							<option value="full" <?php selected( $item['width'], 'full' ); ?>><?php esc_html_e( 'Tam', 'devxpe-theme' ); ?></option>
						</select>
					</div>
					<div class="dxp-repeater-field">
						<span class="dxp-repeater-label"><?php esc_html_e( 'Zorunlu', 'devxpe-theme' ); ?></span>
						<label class="dxp-inline-check"><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][required]" value="1" <?php checked( $item['required'], '1' ); ?> /></label>
					</div>
				</div>
				<div class="dxp-repeater-field">
					<span class="dxp-repeater-label"><?php esc_html_e( 'Etiket', 'devxpe-theme' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][label]" autocomplete="off" aria-label="<?php esc_attr_e( 'Alan etiketi', 'devxpe-theme' ); ?>" value="<?php echo esc_attr( $item['label'] ); ?>" />
				</div>
				<div class="dxp-repeater-field">
					<span class="dxp-repeater-label"><?php esc_html_e( 'Anahtar', 'devxpe-theme' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][key]" autocomplete="off" aria-label="<?php esc_attr_e( 'Alan anahtarı', 'devxpe-theme' ); ?>" value="<?php echo esc_attr( $item['key'] ); ?>" placeholder="ad" />
				</div>
				<div class="dxp-repeater-field">
					<span class="dxp-repeater-label"><?php esc_html_e( 'Yer tutucu', 'devxpe-theme' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][placeholder]" autocomplete="off" aria-label="<?php esc_attr_e( 'Yer tutucu metin', 'devxpe-theme' ); ?>" value="<?php echo esc_attr( $item['placeholder'] ); ?>" />
				</div>
				<div class="dxp-repeater-field">
					<span class="dxp-repeater-label"><?php esc_html_e( 'Alt Not', 'devxpe-theme' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][help]" autocomplete="off" aria-label="<?php esc_attr_e( 'Alan altı açıklama', 'devxpe-theme' ); ?>" value="<?php echo esc_attr( $item['help'] ); ?>" />
				</div>
				<div class="dxp-repeater-field dxp-field-options">
					<span class="dxp-repeater-label"><?php esc_html_e( 'Seçenekler', 'devxpe-theme' ); ?></span>
					<?php
					/*
					 * Kamu Yüzeyi: `options` veri modeli virgülle ayrılmış STRING olarak
					 * kalır. Görselde satır satır (repeater) gösterilir; JS gizli input'a
					 * join(',') ile yazar. Sunucu tarafı bu string'i olduğu gibi taşır.
					 */
					$opt_values = devxpe_lines( $item['options'], ',' );
					?>
					<input type="hidden" class="dxp-opt-value" name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][options]" value="<?php echo esc_attr( $item['options'] ); ?>" />
					<div class="dxp-opt-list">
						<?php foreach ( $opt_values as $opt_value ) : ?>
						<div class="dxp-opt-item">
							<input type="text" class="dxp-opt-input" list="dxp-options-templates" autocomplete="off" aria-label="<?php esc_attr_e( 'Seçenek', 'devxpe-theme' ); ?>" value="<?php echo esc_attr( $opt_value ); ?>" />
							<button type="button" class="dxp-opt-up" title="<?php esc_attr_e( 'Yukarı Taşı', 'devxpe-theme' ); ?>">&uarr;</button>
							<button type="button" class="dxp-opt-down" title="<?php esc_attr_e( 'Aşağı Taşı', 'devxpe-theme' ); ?>">&darr;</button>
							<button type="button" class="dxp-opt-remove" title="<?php esc_attr_e( 'Sil', 'devxpe-theme' ); ?>">&times;</button>
						</div>
						<?php endforeach; ?>
					</div>
					<button type="button" class="dxp-opt-add"><?php esc_html_e( '+ Seçenek Ekle', 'devxpe-theme' ); ?></button>
					<small class="description"><?php esc_html_e( 'Seçenekleri tek tek ekleyin. Sıralamak için yukarı/aşağı oklarını kullanın. Virgül kullanmayın.', 'devxpe-theme' ); ?></small>
				</div>
			</div>
			<div class="dxp-repeater-actions">
				<button type="button" class="dxp-repeater-up" title="<?php esc_attr_e( 'Yukarı Taşı', 'devxpe-theme' ); ?>">&uarr;</button>
				<button type="button" class="dxp-repeater-down" title="<?php esc_attr_e( 'Aşağı Taşı', 'devxpe-theme' ); ?>">&darr;</button>
				<button type="button" class="dxp-repeater-remove" title="<?php esc_attr_e( 'Sil', 'devxpe-theme' ); ?>">&times;</button>
			</div>
		</div>
		<?php
	}

	/**
	 * Form listesi (ad + slug + buton) çizer.
	 *
	 * @param string $id   Alan id'si.
	 * @param string $name Input name'i.
	 * @param mixed  $value Kayıtlı satırlar.
	 * @return void
	 */
	private static function render_forms_field( $id, $name, $value ) {
		$items = is_array( $value ) ? array_values( $value ) : array();

		echo '<div class="dxp-repeater" data-repeater="' . esc_attr( $id ) . '">';
		echo '<div class="dxp-repeater-list">';
		$index = 0;
		foreach ( $items as $item ) {
			self::render_forms_row( $name, $item, $index );
			$index++;
		}
		echo '</div>';
		echo '<button type="button" class="dxp-repeater-add">' . esc_html__( '+ Form Ekle', 'devxpe-theme' ) . '</button>';
		echo '<template class="dxp-repeater-template">';
		self::render_forms_row( $name, array( 'name' => '', 'slug' => '', 'btn' => '' ), 0 );
		echo '</template>';
		echo '</div>';
	}

	/**
	 * Tek bir form satırını çizer.
	 *
	 * @param string $name  Input name ön eki.
	 * @param array  $item  name/slug/btn.
	 * @param int    $index Satır indeksi.
	 * @return void
	 */
	private static function render_forms_row( $name, $item, $index = 0 ) {
		$item  = wp_parse_args( (array) $item, array( 'name' => '', 'slug' => '', 'btn' => '' ) );
		$index = absint( $index );
		?>
		<div class="dxp-repeater-row">
			<div class="dxp-repeater-fields">
				<div class="dxp-repeater-field">
					<span class="dxp-repeater-label"><?php esc_html_e( 'Form Adı', 'devxpe-theme' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][name]" autocomplete="off" value="<?php echo esc_attr( $item['name'] ); ?>" />
				</div>
				<div class="dxp-repeater-field">
					<span class="dxp-repeater-label"><?php esc_html_e( 'Slug (URL/kısa kod)', 'devxpe-theme' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][slug]" autocomplete="off" value="<?php echo esc_attr( $item['slug'] ); ?>" placeholder="iletisim" />
				</div>
				<div class="dxp-repeater-field">
					<span class="dxp-repeater-label"><?php esc_html_e( 'Buton Yazısı', 'devxpe-theme' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][btn]" autocomplete="off" value="<?php echo esc_attr( $item['btn'] ); ?>" placeholder="<?php esc_attr_e( 'Mesaj Gönder', 'devxpe-theme' ); ?>" />
				</div>
			</div>
			<div class="dxp-repeater-actions">
				<button type="button" class="dxp-repeater-up" title="<?php esc_attr_e( 'Yukarı Taşı', 'devxpe-theme' ); ?>">&uarr;</button>
				<button type="button" class="dxp-repeater-down" title="<?php esc_attr_e( 'Aşağı Taşı', 'devxpe-theme' ); ?>">&darr;</button>
				<button type="button" class="dxp-repeater-remove" title="<?php esc_attr_e( 'Sil', 'devxpe-theme' ); ?>">&times;</button>
			</div>
		</div>
		<?php
	}

	/**
	 * Salt-okunur kısa kod alanı çizer (kopyala düğmeli).
	 *
	 * @param string $id    Alan id'si.
	 * @param string $value Gösterilecek kısa kod.
	 * @return void
	 */
	private static function render_shortcode_field( $id, $value, $field = array() ) {
		$tag = ! empty( $field['tag'] ) ? (string) $field['tag'] : ( '' !== (string) $value ? (string) $value : '[devxpe_form slug="' . devxpe_active_form_slug() . '"]' );

		echo '<div class="dxp-shortcode">';
		echo '<input type="text" id="dxp_' . esc_attr( $id ) . '" readonly value="' . esc_attr( $tag ) . '" class="regular-text" aria-label="' . esc_attr__( 'Kısa kod', 'devxpe-theme' ) . '" />';
		echo '<button type="button" class="button dxp-copy-btn" data-copy="' . esc_attr( $tag ) . '">' . esc_html__( 'Kopyala', 'devxpe-theme' ) . '</button>';
		echo '</div>';
	}

	/**
	 * Tekrarlanabilir "ikon + başlık + metin" listesi çizer.
	 *
	 * İkon seçimi boş bırakılabilir (adım listeleri numaralandırılır).
	 *
	 * @param string $id    Alan id'si.
	 * @param string $name  Input name'i.
	 * @param mixed  $value Kayıtlı satırlar (array).
	 * @param array  $field Alan tanımı (ikon seçenekleri için).
	 * @return void
	 */
	private static function render_rows_field( $id, $name, $value, $field = array() ) {
		$items    = is_array( $value ) ? array_values( $value ) : array();
		$icons    = isset( $field['icons'] ) ? (array) $field['icons'] : array();
		$long     = ! empty( $field['long_text'] );
		$with_url = ! empty( $field['with_url'] );

		/* Lucide verisi şablonun dışında basılmalı (şablon DOM'a girmez). */
		if ( $icons ) {
			self::print_lucide_data();
		}

		echo '<div class="dxp-repeater" data-repeater="' . esc_attr( $id ) . '">';
		echo '<div class="dxp-repeater-list">';
		$index = 0;
		foreach ( $items as $item ) {
			self::render_rows_row( $name, $item, $index, $icons, $long, $with_url );
			$index++;
		}
		echo '</div>';
		echo '<button type="button" class="dxp-repeater-add">' . esc_html__( '+ Satır Ekle', 'devxpe-theme' ) . '</button>';
		echo '<template class="dxp-repeater-template">';
		self::render_rows_row( $name, array( 'icon' => '', 'title' => '', 'text' => '', 'url' => '' ), 0, $icons, $long, $with_url );
		echo '</template>';
		echo '</div>';
	}

	/**
	 * Tek bir "ikon + başlık + metin" satırını çizer.
	 *
	 * @param string $name     Input name ön eki.
	 * @param array  $item     icon/title/text/url değerleri.
	 * @param int    $index    Satır indeksi.
	 * @param array  $icons    İkon seçenekleri (ad => ad).
	 * @param bool   $long     Metin alanı textarea olsun mu.
	 * @param bool   $with_url Bağlantı alanı gösterilsin mi.
	 * @return void
	 */
	private static function render_rows_row( $name, $item, $index = 0, $icons = array(), $long = false, $with_url = false ) {
		$item  = wp_parse_args( (array) $item, array( 'icon' => '', 'title' => '', 'text' => '', 'url' => '' ) );
		$index = absint( $index );
		?>
		<div class="dxp-repeater-row">
			<div class="dxp-repeater-fields">
				<?php if ( $icons ) : ?>
				<div class="dxp-repeater-field">
					<span class="dxp-repeater-label"><?php esc_html_e( 'İkon', 'devxpe-theme' ); ?></span>
					<?php self::render_lucide_picker( $name . '[' . $index . '][icon]', isset( $item['icon'] ) ? $item['icon'] : '' ); ?>
				</div>
				<?php endif; ?>
				<div class="dxp-repeater-field">
					<span class="dxp-repeater-label"><?php esc_html_e( 'Başlık', 'devxpe-theme' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][title]" autocomplete="off" aria-label="<?php esc_attr_e( 'Başlık', 'devxpe-theme' ); ?>" value="<?php echo esc_attr( $item['title'] ); ?>" />
				</div>
				<div class="dxp-repeater-field<?php echo $long ? ' dxp-repeater-field--wide' : ''; ?>">
					<span class="dxp-repeater-label"><?php esc_html_e( 'Metin', 'devxpe-theme' ); ?></span>
					<?php if ( $long ) : ?>
					<textarea name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][text]" rows="3" autocomplete="off" aria-label="<?php esc_attr_e( 'Metin', 'devxpe-theme' ); ?>"><?php echo esc_textarea( $item['text'] ); ?></textarea>
					<?php else : ?>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][text]" autocomplete="off" aria-label="<?php esc_attr_e( 'Metin', 'devxpe-theme' ); ?>" value="<?php echo esc_attr( $item['text'] ); ?>" />
					<?php endif; ?>
				</div>
				<?php if ( $with_url ) : ?>
				<div class="dxp-repeater-field">
					<span class="dxp-repeater-label"><?php esc_html_e( 'Bağlantı', 'devxpe-theme' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][url]" autocomplete="off" aria-label="<?php esc_attr_e( 'Bağlantı', 'devxpe-theme' ); ?>" value="<?php echo esc_attr( $item['url'] ); ?>" placeholder="tel: / mailto: / https://" />
				</div>
				<?php endif; ?>
			</div>
			<div class="dxp-repeater-actions">
				<button type="button" class="dxp-repeater-up" title="<?php esc_attr_e( 'Yukarı Taşı', 'devxpe-theme' ); ?>">&uarr;</button>
				<button type="button" class="dxp-repeater-down" title="<?php esc_attr_e( 'Aşağı Taşı', 'devxpe-theme' ); ?>">&darr;</button>
				<button type="button" class="dxp-repeater-remove" title="<?php esc_attr_e( 'Sil', 'devxpe-theme' ); ?>">&times;</button>
			</div>
		</div>
		<?php
	}

	/**
	 * Tekrarlanabilir "kart" listesini çizer (görsel + başlık + metin + link).
	 *
	 * @param string $id    Alan id'si.
	 * @param string $name  Input name'i.
	 * @param mixed  $value Kayıtlı satırlar (array).
	 * @return void
	 */
	private static function render_cards_field( $id, $name, $value ) {
		$items = is_array( $value ) ? array_values( $value ) : array();

		echo '<div class="dxp-repeater dxp-repeater--cards" data-repeater="' . esc_attr( $id ) . '">';
		echo '<div class="dxp-repeater-list">';
		$index = 0;
		foreach ( $items as $item ) {
			self::render_cards_row( $name, $item, $index );
			$index++;
		}
		echo '</div>';
		echo '<button type="button" class="dxp-repeater-add">' . esc_html__( '+ Kart Ekle', 'devxpe-theme' ) . '</button>';
		echo '<template class="dxp-repeater-template">';
		self::render_cards_row( $name, array( 'image' => '', 'title' => '', 'text' => '', 'url' => '' ), 0 );
		echo '</template>';
		echo '</div>';
	}

	/**
	 * Tek bir kart satırını çizer.
	 *
	 * @param string $name  Input name ön eki.
	 * @param array  $item  image/title/text/url değerleri.
	 * @param int    $index Satır indeksi.
	 * @return void
	 */
	private static function render_cards_row( $name, $item, $index = 0 ) {
		$item  = wp_parse_args( (array) $item, array( 'image' => '', 'title' => '', 'text' => '', 'url' => '' ) );
		$index = absint( $index );
		?>
		<div class="dxp-repeater-row">
			<div class="dxp-repeater-fields">
				<div class="dxp-repeater-field dxp-image-field">
					<span class="dxp-repeater-label"><?php esc_html_e( 'Görsel', 'devxpe-theme' ); ?></span>
					<div class="dxp-image-preview"><?php if ( $item['image'] ) : ?><img src="<?php echo esc_url( $item['image'] ); ?>" alt="" /><?php endif; ?></div>
					<div class="dxp-image-controls">
						<input type="text" name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][image]" autocomplete="off" aria-label="<?php esc_attr_e( 'Görsel URL', 'devxpe-theme' ); ?>" value="<?php echo esc_url( $item['image'] ); ?>" class="dxp-image-url" placeholder="https://" />
						<button type="button" class="dxp-image-upload"><?php esc_html_e( 'Resim Seç', 'devxpe-theme' ); ?></button>
						<?php if ( $item['image'] ) : ?>
						<button type="button" class="dxp-image-remove" onclick="this.closest('.dxp-image-field').querySelector('.dxp-image-url').value='';this.closest('.dxp-image-field').querySelector('.dxp-image-preview').innerHTML='';"><?php esc_html_e( 'Kaldır', 'devxpe-theme' ); ?></button>
						<?php endif; ?>
					</div>
				</div>
				<div class="dxp-repeater-field">
					<span class="dxp-repeater-label"><?php esc_html_e( 'Başlık', 'devxpe-theme' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][title]" autocomplete="off" aria-label="<?php esc_attr_e( 'Kart başlığı', 'devxpe-theme' ); ?>" value="<?php echo esc_attr( $item['title'] ); ?>" />
				</div>
				<div class="dxp-repeater-field">
					<span class="dxp-repeater-label"><?php esc_html_e( 'Metin', 'devxpe-theme' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][text]" autocomplete="off" aria-label="<?php esc_attr_e( 'Kart metni', 'devxpe-theme' ); ?>" value="<?php echo esc_attr( $item['text'] ); ?>" />
				</div>
				<div class="dxp-repeater-field">
					<span class="dxp-repeater-label"><?php esc_html_e( 'Bağlantı (URL)', 'devxpe-theme' ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][url]" autocomplete="off" aria-label="<?php esc_attr_e( 'Kart bağlantısı', 'devxpe-theme' ); ?>" value="<?php echo esc_url( $item['url'] ); ?>" placeholder="https://" />
				</div>
			</div>
			<div class="dxp-repeater-actions">
				<button type="button" class="dxp-repeater-up" title="<?php esc_attr_e( 'Yukarı Taşı', 'devxpe-theme' ); ?>">&uarr;</button>
				<button type="button" class="dxp-repeater-down" title="<?php esc_attr_e( 'Aşağı Taşı', 'devxpe-theme' ); ?>">&darr;</button>
				<button type="button" class="dxp-repeater-remove" title="<?php esc_attr_e( 'Sil', 'devxpe-theme' ); ?>">&times;</button>
			</div>
		</div>
		<?php
	}

	/**
	 * Sürükleyip sıralanabilen bölüm (iskelet) listesini çizer.
	 *
	 * Sıra, gizli bir input'ta virgülle ayrılmış bölüm id'leri olarak tutulur.
	 * Her satırın açık/kapalı durumu ilgili bölümün `_enable` alanından gelir;
	 * panel.js bu tike göre satırı canlı olarak soluklaştırır.
	 *
	 * @param string $id    Alan id'si.
	 * @param string $name  Input name'i.
	 * @param mixed  $value Kayıtlı sıra (string veya array).
	 * @return void
	 */
	private static function render_sections_field( $id, $name, $value ) {
		$order  = devxpe_home_sections_order();
		$splits = devxpe_home_section_splits();
		$labels = devxpe_home_section_labels();
		$on     = __( 'Görünür', 'devxpe-theme' );
		$off    = __( 'Kapalı', 'devxpe-theme' );

		echo '<div class="dxp-skeleton" data-skeleton="' . esc_attr( $id ) . '">';
		echo '<input type="hidden" class="dxp-skeleton-value" name="' . esc_attr( $name ) . '" value="' . esc_attr( implode( ',', $order ) ) . '" />';
		echo '<input type="hidden" class="dxp-skeleton-split" name="home_sections_split" value="' . esc_attr( implode( ',', $splits ) ) . '" />';
		echo '<ul class="dxp-skeleton-list">';

		foreach ( $order as $section_id ) {
			$enabled = ( '1' === self::get( $section_id . '_enable', '1' ) );
			$is_side = in_array( $section_id, $splits, true );

			echo '<li class="dxp-skeleton-item' . ( $enabled ? '' : ' is-off' ) . ( $is_side ? ' is-split' : '' ) . '" data-id="' . esc_attr( $section_id ) . '">';
			echo '<span class="dxp-skeleton-name">' . esc_html( isset( $labels[ $section_id ] ) ? $labels[ $section_id ] : $section_id ) . '</span>';
			echo '<span class="dxp-skeleton-state" data-on="' . esc_attr( $on ) . '" data-off="' . esc_attr( $off ) . '">' . esc_html( $enabled ? $on : $off ) . '</span>';
			echo '<button type="button" class="dxp-skeleton-up" title="' . esc_attr__( 'Yukarı Taşı', 'devxpe-theme' ) . '" aria-label="' . esc_attr__( 'Yukarı Taşı', 'devxpe-theme' ) . '">&uarr;</button>';
			echo '<button type="button" class="dxp-skeleton-down" title="' . esc_attr__( 'Aşağı Taşı', 'devxpe-theme' ) . '" aria-label="' . esc_attr__( 'Aşağı Taşı', 'devxpe-theme' ) . '">&darr;</button>';
			echo '<button type="button" class="dxp-skeleton-toggle" aria-pressed="' . ( $enabled ? 'true' : 'false' ) . '" data-show="' . esc_attr__( 'Göster', 'devxpe-theme' ) . '" data-hide="' . esc_attr__( 'Gizle', 'devxpe-theme' ) . '">' . esc_html( $enabled ? __( 'Gizle', 'devxpe-theme' ) : __( 'Göster', 'devxpe-theme' ) ) . '</button>';
			echo '<button type="button" class="dxp-skeleton-side" aria-pressed="' . ( $is_side ? 'true' : 'false' ) . '" title="' . esc_attr__( 'Komşu bölümle yan yana getir. Yan yana gelmeleri için iki komşunun da işaretli olması gerekir.', 'devxpe-theme' ) . '">' . esc_html__( 'Yan yana', 'devxpe-theme' ) . '</button>';
			echo '</li>';
		}

		echo '</ul>';
		echo '</div>';
	}

	/**
	 * Çoklu sayfa seçim alanını çizer (onay kutuları).
	 *
	 * Yayınlanmış tüm sayfaları listeler; seçilenler bir ID dizisi olarak
	 * saklanır. "Gösterileceği yer = Seçili sayfalar" olduğunda kullanılır.
	 *
	 * @param string $id    Alan id'si.
	 * @param string $name  Input name'i.
	 * @param mixed  $value Seçili sayfa ID'leri (array).
	 * @return void
	 */
	private static function render_pages_field( $id, $name, $value ) {
		$selected = array_map( 'absint', (array) $value );
		$pages    = get_pages( array( 'sort_column' => 'post_title', 'sort_order' => 'ASC' ) );

		echo '<div class="dxp-pages-field">';
		if ( empty( $pages ) ) {
			echo '<p class="description">' . esc_html__( 'Henüz sayfa yok.', 'devxpe-theme' ) . '</p>';
		} else {
			foreach ( $pages as $page ) {
				$uid = 'dxp_' . esc_attr( $id ) . '_' . absint( $page->ID );
				echo '<label class="dxp-pages-option" for="' . esc_attr( $uid ) . '">';
				echo '<input type="checkbox" id="' . esc_attr( $uid ) . '" name="' . esc_attr( $name ) . '[]" value="' . absint( $page->ID ) . '"' . checked( in_array( (int) $page->ID, $selected, true ), true, false ) . ' />';
				echo esc_html( $page->post_title );
				echo '</label>';
			}
		}
		echo '</div>';
	}

	/**
	 * Ülke kodları listesini döndürür (kod => ülke adı).
	 *
	 * @return array
	 */
	public static function country_list() {
		return array(
			'+90'  => 'Türkiye',
			'+44'  => 'United Kingdom',
			'+1'   => 'United States',
			'+49'  => 'Germany',
			'+33'  => 'France',
			'+39'  => 'Italy',
			'+34'  => 'Spain',
			'+31'  => 'Netherlands',
			'+32'  => 'Belgium',
			'+43'  => 'Austria',
			'+41'  => 'Switzerland',
			'+46'  => 'Sweden',
			'+47'  => 'Norway',
			'+45'  => 'Denmark',
			'+358' => 'Finland',
			'+353' => 'Ireland',
			'+351' => 'Portugal',
			'+30'  => 'Greece',
			'+48'  => 'Poland',
			'+420' => 'Czechia',
			'+421' => 'Slovakia',
			'+36'  => 'Hungary',
			'+40'  => 'Romania',
			'+359' => 'Bulgaria',
			'+385' => 'Croatia',
			'+386' => 'Slovenia',
			'+372' => 'Estonia',
			'+371' => 'Latvia',
			'+370' => 'Lithuania',
			'+352' => 'Luxembourg',
			'+356' => 'Malta',
			'+357' => 'Cyprus',
			'+7'   => 'Russia',
			'+380' => 'Ukraine',
			'+971' => 'United Arab Emirates',
			'+966' => 'Saudi Arabia',
			'+974' => 'Qatar',
			'+965' => 'Kuwait',
			'+973' => 'Bahrain',
			'+968' => 'Oman',
			'+962' => 'Jordan',
			'+961' => 'Lebanon',
			'+964' => 'Iraq',
			'+972' => 'Israel',
			'+98'  => 'Iran',
			'+20'  => 'Egypt',
			'+212' => 'Morocco',
			'+213' => 'Algeria',
			'+216' => 'Tunisia',
			'+218' => 'Libya',
			'+92'  => 'Pakistan',
			'+91'  => 'India',
			'+880' => 'Bangladesh',
			'+86'  => 'China',
			'+81'  => 'Japan',
			'+82'  => 'South Korea',
			'+66'  => 'Thailand',
			'+60'  => 'Malaysia',
			'+65'  => 'Singapore',
			'+62'  => 'Indonesia',
			'+63'  => 'Philippines',
			'+84'  => 'Vietnam',
			'+61'  => 'Australia',
			'+64'  => 'New Zealand',
			'+27'  => 'South Africa',
			'+234' => 'Nigeria',
			'+254' => 'Kenya',
			'+52'  => 'Mexico',
			'+55'  => 'Brazil',
			'+54'  => 'Argentina',
			'+56'  => 'Chile',
			'+57'  => 'Colombia',
			'+51'  => 'Peru',
		);
	}

	/**
	 * Ülke kodları çoklu seçim alanını çizer (aramalı dropdown).
	 *
	 * Kayıtlı değer "kod|Ad" satırlarıdır. Listede olmayan mevcut kayıtlar
	 * gizli input olarak basılır, böylece kaydetmede kaybolmazlar.
	 *
	 * @param string $name  Input name'i.
	 * @param mixed  $value Kayıtlı değer (satırlar \n ile birleşik).
	 * @return void
	 */
	private static function render_countries_field( $name, $value ) {
		$list = self::country_list();

		$saved = array();
		foreach ( explode( "\n", (string) $value ) as $line ) {
			$line = trim( $line );
			if ( '' === $line ) {
				continue;
			}
			$parts = explode( '|', $line, 2 );
			$code  = trim( $parts[0] );
			if ( '' === $code ) {
				continue;
			}
			$saved[ $code ] = isset( $parts[1] ) ? trim( $parts[1] ) : '';
		}

		/* Listede olmayan (legacy/özel) kayıtlar. */
		$extras = array();
		foreach ( $saved as $code => $label ) {
			if ( ! isset( $list[ $code ] ) ) {
				$extras[ $code ] = '' !== $label ? $label : $code;
			}
		}

		/* Başlangıç özeti: liste sırası, sonra özel kayıtlar. */
		$summary = array();
		foreach ( $list as $code => $label ) {
			if ( isset( $saved[ $code ] ) ) {
				$summary[] = $code . ' ' . $label;
			}
		}
		foreach ( $extras as $code => $label ) {
			$summary[] = $code . ' ' . $label;
		}

		echo '<div class="dxp-multiselect" data-placeholder="' . esc_attr__( 'Ülke seçin', 'devxpe-theme' ) . '">';
		echo '<button type="button" class="dxp-multiselect-trigger" aria-haspopup="listbox" aria-expanded="false">';
		echo '<span class="dxp-multiselect-summary">' . ( $summary ? esc_html( implode( ', ', $summary ) ) : esc_html__( 'Ülke seçin', 'devxpe-theme' ) ) . '</span>';
		echo '<span class="dxp-multiselect-count">' . ( $summary ? count( $summary ) : '' ) . '</span>';
		echo '<span class="dxp-multiselect-caret" aria-hidden="true">▾</span>';
		echo '</button>';
		echo '<div class="dxp-multiselect-menu" role="listbox" hidden>';
		echo '<input type="search" class="dxp-multiselect-search" placeholder="' . esc_attr__( 'Ülke ara…', 'devxpe-theme' ) . '" autocomplete="off" />';
		echo '<div class="dxp-multiselect-list">';
		foreach ( $list as $code => $label ) {
			echo '<label class="dxp-multiselect-item">';
			echo '<input type="checkbox" name="' . esc_attr( $name ) . '[]" value="' . esc_attr( $code ) . '"' . checked( isset( $saved[ $code ] ), true, false ) . ' />';
			echo '<span class="dxp-multiselect-code">' . esc_html( $code ) . '</span>';
			echo '<span class="dxp-multiselect-name">' . esc_html( $label ) . '</span>';
			echo '</label>';
		}
		echo '</div>';
		echo '<div class="dxp-multiselect-empty" hidden>' . esc_html__( 'Sonuç yok.', 'devxpe-theme' ) . '</div>';
		echo '</div>';

		foreach ( $extras as $code => $label ) {
			echo '<input type="hidden" name="' . esc_attr( $name ) . '[]" value="' . esc_attr( $code . '|' . $label ) . '" />';
		}

		echo '</div>';
	}

	/**
	 * WordPress dashicons kütüphanesindeki tüm ikon sınıflarını döndürür.
	 *
	 * Sınıf adları, çekirdekteki dashicons CSS dosyasından okunur; böylece
	 * elle liste tutmaya gerek kalmaz.
	 *
	 * @return array
	 */
	private static function get_dashicons() {
		static $icons = null;

		if ( null !== $icons ) {
			return $icons;
		}

		$file = ABSPATH . 'wp-includes/css/dashicons.min.css';
		if ( ! file_exists( $file ) ) {
			$file = ABSPATH . 'wp-includes/css/dashicons.css';
		}

		$css   = file_exists( $file ) ? file_get_contents( $file ) : '';
		$icons = array();

		if ( preg_match_all( '/\.(dashicons-[a-z0-9\-]+):before/i', $css, $m ) ) {
			$icons = array_values( array_unique( $m[1] ) );
			sort( $icons );
		}

		return $icons;
	}

	/**
	 * Dashicons verisini sayfaya bir kez gömer (JSON). Şablonda değil, gerçek
	 * DOM içinde basılması gerekir; bu yüzden çağrı yerleri bunu garanti eder.
	 *
	 * @return void
	 */
	private static function print_dashicons_data() {
		static $printed = false;

		if ( $printed ) {
			return;
		}

		echo '<script type="application/json" id="dxp-dashicons-data">' . wp_json_encode( self::get_dashicons() ) . '</script>';
		$printed = true;
	}

	/**
	 * Tüm dashicons kütüphanesini içeren açılır (arama filtreli) seçici çizer.
	 *
	 * @param string $id    Alan id'si.
	 * @param string $name  Input name'i.
	 * @param array  $field Alan tanımı.
	 * @param string $value Seçili ikon sınıfı.
	 * @return void
	 */
	private static function render_icon_field( $id, $name, $field, $value ) {
		$selected = $value ? $value : ( isset( $field['default'] ) ? $field['default'] : 'dashicons-star-filled' );

		/* İkon listesini sayfaya bir kez JSON olarak göm; grid JS ile üretilir. */
		self::print_dashicons_data();
		?>
		<div class="dxp-iconpick" data-icon-set="dashicons" data-empty-label="<?php esc_attr_e( 'İkon seç', 'devxpe-theme' ); ?>">
			<input type="hidden" class="dxp-iconpick-value" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $selected ); ?>" />
			<button type="button" class="dxp-iconpick-trigger" aria-haspopup="true" aria-expanded="false" title="<?php echo esc_attr( str_replace( 'dashicons-', '', $selected ) ); ?>">
				<span class="dxp-iconpick-visual"><span class="dashicons <?php echo esc_attr( $selected ); ?>"></span></span>
				<span class="dxp-iconpick-current"><?php echo esc_html( str_replace( 'dashicons-', '', $selected ) ); ?></span>
				<span class="dxp-iconpick-caret">▾</span>
			</button>
			<div class="dxp-iconpick-panel" hidden>
				<input type="search" class="dxp-iconpick-search" placeholder="<?php esc_attr_e( 'İkon ara…', 'devxpe-theme' ); ?>" aria-label="<?php esc_attr_e( 'İkon ara', 'devxpe-theme' ); ?>" autocomplete="off" />
				<div class="dxp-iconpick-grid" role="listbox"></div>
				<div class="dxp-iconpick-empty" hidden><?php esc_html_e( 'Sonuç yok.', 'devxpe-theme' ); ?></div>
			</div>
		</div>
		<?php
	}

	/**
	 * Lucide ikon verisini sayfaya bir kez gömer (JSON).
	 *
	 * @return void
	 */
	private static function print_lucide_data() {
		static $printed = false;

		if ( $printed ) {
			return;
		}

		echo '<script type="application/json" id="dxp-lucide-data">' . wp_json_encode( devxpe_lucide_icons() ) . '</script>';
		$printed = true;
	}

	/**
	 * Lucide ikon seçicisini SVG önizlemeli olarak çizer.
	 *
	 * Seçenekler devxpe_lucide_icons()'tan gelir; SVG verisi sayfaya bir kez
	 * JSON olarak gömülür, grid panel.js tarafından üretilir.
	 *
	 * @param string $name  Input name'i.
	 * @param string $value Seçili ikon adı.
	 * @return void
	 */
	private static function render_lucide_picker( $name, $value ) {
		$icons = devxpe_lucide_icons();
		/* Lucide adı ya da sınıf tabanlı ikon (Font Awesome / dashicons) geçerlidir. */
		if ( ! isset( $icons[ $value ] ) && ! devxpe_is_class_icon( $value ) ) {
			$value = '';
		}

		/* İkon listelerini sayfaya bir kez göm; grid JS ile üretilir. */
		self::print_lucide_data();
		self::print_fa_data();
		?>
		<div class="dxp-iconpick" data-icon-set="lucide" data-empty-label="<?php esc_attr_e( 'İkon seç', 'devxpe-theme' ); ?>">
			<input type="hidden" class="dxp-iconpick-value" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>" />
			<button type="button" class="dxp-iconpick-trigger" aria-haspopup="true" aria-expanded="false" title="<?php echo esc_attr( $value ? $value : __( 'İkon seç', 'devxpe-theme' ) ); ?>">
				<span class="dxp-iconpick-visual"><?php echo devxpe_lucide( $value ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
				<span class="dxp-iconpick-current"><?php echo $value ? esc_html( $value ) : esc_html__( 'İkon seç', 'devxpe-theme' ); ?></span>
				<span class="dxp-iconpick-caret">▾</span>
			</button>
			<div class="dxp-iconpick-panel" hidden>
				<div class="dxp-iconpick-sets" role="tablist">
					<button type="button" class="dxp-iconpick-set is-active" data-set="lucide">Lucide</button>
					<button type="button" class="dxp-iconpick-set" data-set="fa-solid">FA Solid</button>
					<button type="button" class="dxp-iconpick-set" data-set="fa-regular">FA Regular</button>
					<button type="button" class="dxp-iconpick-set" data-set="fa-brands">FA Brands</button>
				</div>
				<input type="search" class="dxp-iconpick-search" placeholder="<?php esc_attr_e( 'İkon ara…', 'devxpe-theme' ); ?>" aria-label="<?php esc_attr_e( 'İkon ara', 'devxpe-theme' ); ?>" autocomplete="off" />
				<div class="dxp-iconpick-grid" role="listbox"></div>
				<div class="dxp-iconpick-empty" hidden><?php esc_html_e( 'Sonuç yok.', 'devxpe-theme' ); ?></div>
			</div>
		</div>
		<?php
	}

	/**
	 * Font Awesome ikon listesini sayfaya bir kez gömer (JSON).
	 *
	 * @return void
	 */
	private static function print_fa_data() {
		static $printed = false;

		if ( $printed ) {
			return;
		}
		$printed = true;

		$icons = devxpe_fa_icons();
		if ( ! $icons ) {
			return;
		}

		echo '<script type="application/json" id="dxp-fa-data">' . wp_json_encode( $icons ) . '</script>';
	}

	/**
	 * Tekrarlanabilir "proje" listesini çizer (başlık + kapsam + malzeme + süre).
	 *
	 * @param string $id   Alan id'si.
	 * @param string $name Input name'i.
	 * @param mixed  $value Kayıtlı satırlar (array).
	 * @return void
	 */
	private static function render_projects_field( $id, $name, $value ) {
		$items = is_array( $value ) ? array_values( $value ) : array();

		echo '<div class="dxp-repeater" data-repeater="' . esc_attr( $id ) . '">';
		echo '<div class="dxp-repeater-list">';
		$index = 0;
		foreach ( $items as $item ) {
			self::render_projects_row( $name, $item, $index );
			$index++;
		}
		echo '</div>';
		echo '<button type="button" class="dxp-repeater-add">' . esc_html__( '+ Proje Ekle', 'devxpe-theme' ) . '</button>';
		echo '<template class="dxp-repeater-template">';
		self::render_projects_row( $name, array( 'title' => '', 'scope' => '', 'materials' => '', 'days' => '' ), 0 );
		echo '</template>';
		echo '</div>';
	}

	/**
	 * Tek bir proje satırını çizer.
	 *
	 * @param string $name  Input name ön eki.
	 * @param array  $item  title/scope/materials/days değerleri.
	 * @param int    $index Satır indeksi.
	 * @return void
	 */
	private static function render_projects_row( $name, $item, $index = 0 ) {
		$item  = wp_parse_args( (array) $item, array( 'title' => '', 'scope' => '', 'materials' => '', 'days' => '' ) );
		$index = absint( $index );
		$cells = array(
			'title'     => __( 'Başlık', 'devxpe-theme' ),
			'scope'     => __( 'Kapsam', 'devxpe-theme' ),
			'materials' => __( 'Malzemeler', 'devxpe-theme' ),
			'days'      => __( 'Süre (sahada)', 'devxpe-theme' ),
		);
		?>
		<div class="dxp-repeater-row">
			<div class="dxp-repeater-fields">
				<?php foreach ( $cells as $key => $label ) : ?>
				<div class="dxp-repeater-field<?php echo 'title' === $key ? ' dxp-repeater-field--wide' : ''; ?>">
					<span class="dxp-repeater-label"><?php echo esc_html( $label ); ?></span>
					<input type="text" name="<?php echo esc_attr( $name ); ?>[<?php echo $index; ?>][<?php echo esc_attr( $key ); ?>]" autocomplete="off" aria-label="<?php echo esc_attr( $label ); ?>" value="<?php echo esc_attr( $item[ $key ] ); ?>" />
				</div>
				<?php endforeach; ?>
			</div>
			<div class="dxp-repeater-actions">
				<button type="button" class="dxp-repeater-up" title="<?php esc_attr_e( 'Yukarı Taşı', 'devxpe-theme' ); ?>">&uarr;</button>
				<button type="button" class="dxp-repeater-down" title="<?php esc_attr_e( 'Aşağı Taşı', 'devxpe-theme' ); ?>">&darr;</button>
				<button type="button" class="dxp-repeater-remove" title="<?php esc_attr_e( 'Sil', 'devxpe-theme' ); ?>">&times;</button>
			</div>
		</div>
		<?php
	}
}

/**
 * Checkbox değerini temizler: yalnızca '1' kalır.
 *
 * @param mixed $value Ham değer.
 * @return string
 */
function devxpe_theme_sanitize_checkbox( $value ) {
	return ( '1' === $value ) ? '1' : '';
}

/**
 * Tarih-saat değerini 'YYYY-MM-DDTHH:MM' (datetime-local) biçimine getirir.
 *
 * Kabul edilen girdiler:
 *   'YYYY-MM-DD HH:MM' | 'YYYY-MM-DDTHH:MM' | 'YYYY-MM-DD HH:MM:SS' | 'YYYY-MM-DD'
 * Yalnızca tarih verilirse saat 00:00 kabul edilir. Geçersizse '' döner.
 *
 * @param mixed $value Ham değer.
 * @return string
 */
function devxpe_theme_sanitize_datetime( $value ) {
	$value = trim( (string) $value );
	if ( '' === $value ) {
		return '';
	}

	$value = str_replace( ' ', 'T', $value );
	$value = preg_replace( '/T(\d{2}:\d{2}):\d{2}$/', 'T$1', $value ); // saniyeleri at

	if ( preg_match( '/^(\d{4}-\d{2}-\d{2})(?:T(\d{2}:\d{2}))?/', $value, $m ) ) {
		$date = $m[1];
		$time = isset( $m[2] ) && '' !== $m[2] ? $m[2] : '00:00';
		return $date . 'T' . $time;
	}

	return '';
}

/**
 * Şifre alanını temizler.
 *
 * İçerik DEĞİŞTİRİLMEZ: SMTP şifreleri özel karakter içerebilir ve
 * sanitize_text_field bunları bozar. Değer yalnızca PHPMailer'a verilir ve
 * panelde esc_attr ile basılır.
 *
 * @param mixed $value Ham değer.
 * @return string
 */
function devxpe_theme_sanitize_password( $value ) {
	return is_string( $value ) ? $value : '';
}

/**
 * Admin-only kod alanlarını olduğu gibi saklar (header/footer injection).
 *
 * @param mixed $value Ham değer.
 * @return string
 */
function devxpe_theme_sanitize_scripts( $value ) {
	$value = wp_check_invalid_utf8( (string) $value );
	return str_replace( "\0", '', $value );
}

/**
 * Panel okuma yardımcıcısı: `echo devxpe_theme_get( 'phone' );`
 *
 * @param string $id      Alan id'si.
 * @param mixed  $default Varsayılan değer.
 * @return mixed
 */
function devxpe_theme_get( $id, $default = '' ) {
	return DEVXPE_Theme_Fields::get( $id, $default );
}

/**
 * Tipografi dizisini temizler.
 *
 * @param mixed $value
 * @return array
 */
function devxpe_theme_sanitize_typography( $value ) {
	if ( ! is_array( $value ) ) {
		return array();
	}
	return array(
		'family' => isset( $value['family'] ) ? sanitize_text_field( $value['family'] ) : '',
		'size'   => isset( $value['size'] ) ? sanitize_text_field( $value['size'] ) : '',
		'weight' => isset( $value['weight'] ) ? sanitize_text_field( $value['weight'] ) : '',
		'lh'     => isset( $value['lh'] ) ? sanitize_text_field( $value['lh'] ) : '',
		'ls'     => isset( $value['ls'] ) ? sanitize_text_field( $value['ls'] ) : '',
	);
}

/**
 * Yinelenen (repeater) satır temizleme iskeleti.
 *
 * `is_array` korumasını, döngüyü ve satırın dizi olma kontrolünü tek yerde
 * yapar. Her sanitize fonksiyonu yalnızca kendi alan işleme mantığını verir;
 * işlenen satırı atlamak için geri çağırım `null` döndürür.
 *
 * @param mixed    $value      Ham satır listesi.
 * @param callable $satir_isle Her satırı işleyip dizi (ya da null) döndüren geri çağırım.
 * @return array
 */
function devxpe_theme_map_rows( $value, callable $satir_isle ) {
	if ( ! is_array( $value ) ) {
		return array();
	}

	$out = array();
	foreach ( $value as $i => $item ) {
		if ( ! is_array( $item ) ) {
			continue;
		}

		$satir = $satir_isle( $item, $i );
		if ( null === $satir ) {
			continue;
		}

		$out[] = $satir;
	}

	return $out;
}

/**
 * Çalışan (team) tekrarlayıcısını temizler.
 *
 * Boş satırları atar, kalanları sırayla (name/image/role) döndürür.
 *
 * @param mixed $value Ham satır listesi.
 * @return array
 */
function devxpe_theme_sanitize_team( $value ) {
	return devxpe_theme_map_rows(
		$value,
		function ( $item ) {
			$name  = isset( $item['name'] ) ? sanitize_text_field( $item['name'] ) : '';
			$role  = isset( $item['role'] ) ? sanitize_text_field( $item['role'] ) : '';
			$image = isset( $item['image'] ) ? esc_url_raw( $item['image'] ) : '';

			if ( '' === $name && '' === $role && '' === $image ) {
				return null;
			}

			return array(
				'name'  => $name,
				'image' => $image,
				'role'  => $role,
			);
		}
	);
}

/**
 * Referans logo satırlarını temizler.
 *
 * Görseli olmayan satırlar atılır (logo olmadan gösterilecek bir şey yok).
 *
 * @param mixed $value Ham satır listesi.
 * @return array
 */
function devxpe_theme_sanitize_logos( $value ) {
	return devxpe_theme_map_rows(
		$value,
		function ( $item ) {
			$image = isset( $item['image'] ) ? esc_url_raw( $item['image'] ) : '';
			$url   = isset( $item['url'] ) ? esc_url_raw( $item['url'] ) : '';
			$alt   = isset( $item['alt'] ) ? sanitize_text_field( $item['alt'] ) : '';

			if ( '' === $image ) {
				return null;
			}

			return array(
				'image' => $image,
				'url'   => $url,
				'alt'   => $alt,
			);
		}
	);
}

/**
 * İçerik tipi (CPT) satırlarını temizler.
 *
 * Ad ve slug zorunludur. Ayrılmış (çekirdek) slug'lar, başka bir içerik
 * tipi/taksonomi ve aynı slug'lı kategori/etiket ile çakışan tanımlar
 * atılır; atlananlar bir transient'e yazılıp panelde uyarı olarak gösterilir.
 *
 * @param mixed $value Ham satır listesi.
 * @return array
 */
function devxpe_theme_sanitize_cpts( $value ) {
	if ( ! is_array( $value ) ) {
		return array();
	}

	$reserved = devxpe_cpt_reserved_slugs();
	$own      = wp_list_pluck( devxpe_custom_post_types(), 'slug' );

	$out     = array();
	$seen    = array();
	$skipped = array();

	foreach ( $value as $item ) {
		if ( ! is_array( $item ) ) {
			continue;
		}

		$name     = isset( $item['name'] ) ? sanitize_text_field( $item['name'] ) : '';
		$slug     = isset( $item['slug'] ) ? sanitize_title( $item['slug'] ) : '';
		$icon     = isset( $item['icon'] ) ? sanitize_text_field( $item['icon'] ) : '';
		$archive  = ( isset( $item['archive'] ) && '1' === $item['archive'] ) ? '1' : '0';
		$template = devxpe_normalize_template( isset( $item['template'] ) ? $item['template'] : '' );

		if ( '' === $name || '' === $slug ) {
			continue;
		}

		if ( in_array( $slug, $reserved, true ) ) {
			$skipped[] = $slug . ' — ' . __( 'ayrılmış (çekirdek) bir slug.', 'devxpe-theme' );
			continue;
		}
		if ( isset( $seen[ $slug ] ) ) {
			$skipped[] = $slug . ' — ' . __( 'aynı slug listede birden fazla.', 'devxpe-theme' );
			continue;
		}
		if ( post_type_exists( $slug ) && ! in_array( $slug, $own, true ) ) {
			$skipped[] = $slug . ' — ' . __( 'bu slug\'da bir içerik tipi zaten var.', 'devxpe-theme' );
			continue;
		}
		if ( taxonomy_exists( $slug ) ) {
			$skipped[] = $slug . ' — ' . __( 'bu slug bir taksonomi adıyla çakışıyor.', 'devxpe-theme' );
			continue;
		}
		if ( get_term_by( 'slug', $slug, 'category' ) || get_term_by( 'slug', $slug, 'post_tag' ) ) {
			$skipped[] = $slug . ' — ' . __( 'bu slug\'da bir kategori/etiket var. İçerik tipi yerine mevcut kategoriyi kullanın.', 'devxpe-theme' );
			continue;
		}

		if ( strlen( $slug ) > 20 ) {
			$slug = substr( $slug, 0, 20 );
		}

		$seen[ $slug ] = true;

		$out[] = array(
			'name'     => $name,
			'slug'     => $slug,
			'icon'     => $icon ? $icon : 'dashicons-admin-post',
			'archive'  => $archive,
			'template' => $template,
		);
	}

	if ( $skipped ) {
		set_transient( 'devxpe_cpt_skipped', $skipped, 60 );
	}

	return $out;
}

/**
 * "İkon + başlık + metin" satırlarını temizler.
 *
 * Başlığı ve metni olmayan satırlar atılır.
 *
 * @param mixed $value Ham satır listesi.
 * @return array
 */
function devxpe_theme_sanitize_rows( $value ) {
	return devxpe_theme_map_rows(
		$value,
		function ( $item ) {
			$icon  = isset( $item['icon'] ) ? sanitize_text_field( $item['icon'] ) : '';
			$title = isset( $item['title'] ) ? sanitize_text_field( $item['title'] ) : '';
			/*
			 * Metin, "long_text" alanlarında bir textarea'dır ve satır sonları
			 * anlamlıdır (örn. Teklif Formu → Hizmet Seçenekleri: her satır bir
			 * seçenek). sanitize_text_field() satır sonlarını TEK BOŞLUĞA çevirir,
			 * o yüzden textarea için tasarlanmış sanitize_textarea_field() kullanılır.
			 */
			$text  = isset( $item['text'] ) ? sanitize_textarea_field( $item['text'] ) : '';
			$url   = isset( $item['url'] ) ? esc_url_raw( $item['url'] ) : '';

			if ( '' === $title && '' === $text ) {
				return null;
			}

			return array(
				'icon'  => $icon,
				'title' => $title,
				'text'  => $text,
				'url'   => $url,
			);
		}
	);
}

/**
 * Kart satırlarını temizler.
 *
 * Başlığı ve görseli olmayan satırlar atılır.
 *
 * @param mixed $value Ham satır listesi.
 * @return array
 */
function devxpe_theme_sanitize_cards( $value ) {
	return devxpe_theme_map_rows(
		$value,
		function ( $item ) {
			$image = isset( $item['image'] ) ? esc_url_raw( $item['image'] ) : '';
			$title = isset( $item['title'] ) ? sanitize_text_field( $item['title'] ) : '';
			$text  = isset( $item['text'] ) ? sanitize_text_field( $item['text'] ) : '';
			$url   = isset( $item['url'] ) ? esc_url_raw( $item['url'] ) : '';

			if ( '' === $title && '' === $image ) {
				return null;
			}

			return array(
				'image' => $image,
				'title' => $title,
				'text'  => $text,
				'url'   => $url,
			);
		}
	);
}

/**
 * Proje satırlarını temizler (başlık + kapsam + malzeme + süre).
 *
 * Başlığı olmayan satırlar atılır.
 *
 * @param mixed $value Ham satır listesi.
 * @return array
 */
function devxpe_theme_sanitize_projects( $value ) {
	return devxpe_theme_map_rows(
		$value,
		function ( $item ) {
			$title = isset( $item['title'] ) ? sanitize_text_field( $item['title'] ) : '';

			if ( '' === $title ) {
				return null;
			}

			return array(
				'title'     => $title,
				'scope'     => isset( $item['scope'] ) ? sanitize_text_field( $item['scope'] ) : '',
				'materials' => isset( $item['materials'] ) ? sanitize_text_field( $item['materials'] ) : '',
				'days'      => isset( $item['days'] ) ? sanitize_text_field( $item['days'] ) : '',
			);
		}
	);
}

/**
 * İletişim formu alan satırlarını temizler.
 *
 * Etiketi olmayan satırlar atılır; anahtar boşsa sıraya göre üretilir.
 *
 * @param mixed $value Ham satır listesi.
 * @return array
 */
function devxpe_theme_sanitize_form_rows( $value ) {
	return devxpe_theme_map_rows(
		$value,
		function ( $item, $i ) {
			$types  = array( 'input', 'text', 'email', 'tel', 'url', 'number', 'date', 'textarea', 'select', 'checkbox', 'file' );
			$widths = array( 'half', 'full' );

			$label = isset( $item['label'] ) ? sanitize_text_field( $item['label'] ) : '';
			if ( '' === $label ) {
				return null;
			}

			$type = ( isset( $item['type'] ) && in_array( $item['type'], $types, true ) ) ? $item['type'] : 'input';
			if ( 'text' === $type ) {
				$type = 'input';
			}

			$key = isset( $item['key'] ) ? sanitize_key( $item['key'] ) : '';
			if ( '' === $key ) {
				$key = 'field_' . ( absint( $i ) + 1 );
			}

			return array(
				'type'        => $type,
				'label'       => $label,
				'key'         => $key,
				'required'    => ( isset( $item['required'] ) && '1' === $item['required'] ) ? '1' : '0',
				'width'       => ( isset( $item['width'] ) && in_array( $item['width'], $widths, true ) ) ? $item['width'] : 'half',
				'placeholder' => isset( $item['placeholder'] ) ? sanitize_text_field( $item['placeholder'] ) : '',
				'options'     => isset( $item['options'] ) ? sanitize_text_field( $item['options'] ) : '',
				'help'        => isset( $item['help'] ) ? sanitize_text_field( $item['help'] ) : '',
			);
		}
	);
}

/**
 * Eski form alanı temizleyicisi (geriye dönük uyumluluk).
 *
 * @param mixed $value Ham satır listesi.
 * @return array
 */
function devxpe_theme_sanitize_form_fields( $value ) {
	return devxpe_theme_sanitize_form_rows( $value );
}


/**
 * Form listesi satırlarını temizler (ad + slug + buton).
 *
 * @param mixed $value Ham satır listesi.
 * @return array
 */
function devxpe_theme_sanitize_forms( $value ) {
	$seen = array();

	return devxpe_theme_map_rows(
		$value,
		function ( $item ) use ( &$seen ) {
			$name = isset( $item['name'] ) ? sanitize_text_field( $item['name'] ) : '';
			$slug = isset( $item['slug'] ) ? sanitize_key( $item['slug'] ) : '';

			if ( '' === $name || '' === $slug || in_array( $slug, $seen, true ) ) {
				return null;
			}
			$seen[] = $slug;

			return array(
				'name' => $name,
				'slug' => $slug,
				'btn'  => isset( $item['btn'] ) ? sanitize_text_field( $item['btn'] ) : '',
			);
		}
	);
}

/**
 * Bölüm sırasını temizler: yalnızca bilinen bölüm id'leri, verilen sırayla.
 *
 * @param mixed $value Virgülle ayrılmış id listesi.
 * @return string
 */
function devxpe_theme_sanitize_section_order( $value ) {
	$valid = devxpe_home_section_ids();
	$ids   = devxpe_lines( $value, ',' );

	return implode( ',', array_values( array_intersect( $ids, $valid ) ) );
}

/**
 * Sayfa ID listesini temizler: yalnızca pozitif tamsayılar kalır.
 *
 * @param mixed $value Ham değer (array).
 * @return array
 */
function devxpe_theme_sanitize_pages( $value ) {
	if ( ! is_array( $value ) ) {
		return array();
	}

	return array_values( array_filter( array_map( 'absint', $value ) ) );
}

/**
 * Ülke kodlarını temizler: "kod|Ad" satırları, \n ile birleşik string.
 *
 * Gelen değerler "kod" ya da "kod|Ad" olabilir. Liste sırası korunur;
 * listede olmayan özel kayıtlar sona eklenir. Boş seçim boş string döner.
 *
 * @param mixed $value Ham değer (array).
 * @return string
 */
function devxpe_theme_sanitize_countries( $value ) {
	$list = DEVXPE_Theme_Fields::country_list();

	/* Eski biçim (satır satır string) içe aktarmada da bozulmasın. */
	if ( is_string( $value ) ) {
		$value = preg_split( '/\r\n|\r|\n/', $value );
	}

	if ( ! is_array( $value ) ) {
		$value = array( $value );
	}

	$picked = array();
	$extras = array();

	foreach ( $value as $item ) {
		if ( ! is_scalar( $item ) ) {
			continue;
		}

		$item = trim( (string) $item );
		if ( '' === $item ) {
			continue;
		}

		$parts = explode( '|', $item, 2 );
		$code  = preg_replace( '/[^0-9+]/', '', $parts[0] );
		$name  = isset( $parts[1] ) ? trim( $parts[1] ) : '';

		if ( '' === $code ) {
			continue;
		}
		if ( '+' !== substr( $code, 0, 1 ) ) {
			$code = '+' . $code;
		}

		if ( isset( $list[ $code ] ) ) {
			$picked[ $code ] = true;
		} else {
			$extras[ $code ] = '' !== $name ? $name : $code;
		}
	}

	$lines = array();

	foreach ( $list as $code => $name ) {
		if ( isset( $picked[ $code ] ) ) {
			$lines[] = $code . '|' . $name;
		}
	}

	foreach ( $extras as $code => $name ) {
		$lines[] = $code . '|' . $name;
	}

	return implode( "\n", $lines );
}

/*
 * Tema option'ı yazıldığında RAM önbelleğini temizle.
 * Panel kaydet, demo kur/kaldır/geri yükle — hepsi bu tek kancayla tazelenir.
 */
add_action( 'update_option_' . DEVXPE_Theme_Fields::OPTION_KEY, array( 'DEVXPE_Theme_Fields', 'flush' ) );
add_action( 'delete_option_' . DEVXPE_Theme_Fields::OPTION_KEY, array( 'DEVXPE_Theme_Fields', 'flush' ) );