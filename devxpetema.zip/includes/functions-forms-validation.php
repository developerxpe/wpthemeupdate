<?php
/**
 * DEVXPE form doÄŸrulama ve alan yardÄ±mcÄ±larÄ±.
 *
 * Form alÄ±cÄ±larÄ±, {alan} deÄŸiÅŸkenleri, doÄŸrulama mesajlarÄ±, Ã¼lke kodu ve
 * telefon uzunluÄŸu tablolarÄ±, e-posta uzantÄ± denetimi ile alan uzunluk/sayaÃ§
 * yardÄ±mcÄ±larÄ± buradadÄ±r. Bu kod daha Ã¶nce functions.php iÃ§indeydi; ayrÄ±
 * dosyaya alÄ±ndÄ±, davranÄ±ÅŸ birebir aynÄ±dÄ±r.
 *
 * Kamu YÃ¼zeyi: devxpe_form_* ve devxpe_field_maxlength_attr /
 * devxpe_render_field_counter fonksiyon adlarÄ± sÃ¶zleÅŸmedir; deÄŸiÅŸtirilmez.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Form bildirimlerinin gönderileceği alıcı listesi.
 *
 * Alıcı E-posta alanı virgülle ayrılmış birden fazla adres içerebilir;
 * geçersiz adresler atlanır. Hiç geçerli adres yoksa site yöneticisine düşer.
 *
 * @return array
 */
function devxpe_form_recipients() {
	$raw  = (string) devxpe_theme_get( 'form_recipient' );
	$list = array();

	foreach ( explode( ',', $raw ) as $one ) {
		$one = trim( $one );
		if ( is_email( $one ) ) {
			$list[] = $one;
		}
	}

	$list = array_values( array_unique( $list ) );

	if ( ! $list ) {
		$admin = (string) get_option( 'admin_email' );
		if ( is_email( $admin ) ) {
			$list[] = $admin;
		}
	}

	return $list;
}

/**
 * E-posta konusunda kullanılabilen {alan} değişkenleri.
 *
 * @return array array( array( 'token' => '{name}', 'label' => 'Ad Soyad' ), ... )
 */
function devxpe_form_token_options() {
	/*
	 * E-posta konusunda kullanılabilen {alan} çipleri.
	 *
	 * Yalnızca konu için anlamlı alanlar listelenir; formun her alanı
	 * (ör. "size ulaşabileceğimiz saat") konuya taşınmaz. Anahtarlar sabittir,
	 * etiketler panel diline göre gösterilir.
	 */
	$dil = class_exists( 'DEVXPE_Theme_Language' ) ? DEVXPE_Theme_Language::selected() : 'auto';

	if ( 'auto' === $dil ) {
		$dil = ( 0 === strpos( (string) get_locale(), 'tr' ) ) ? 'tr_TR' : 'en_US';
	}

	$tr = ( 'tr_TR' === $dil );

	$cipler = array(
		array( 'token' => '{no}',      'tr' => 'Kayıt no', 'en' => 'Record no' ),
		array( 'token' => '{name}',    'tr' => 'Ad Soyad', 'en' => 'Full name' ),
		array( 'token' => '{email}',   'tr' => 'E-posta',  'en' => 'Email' ),
		array( 'token' => '{phone}',   'tr' => 'Telefon',  'en' => 'Phone' ),
		array( 'token' => '{service}', 'tr' => 'Hizmet',   'en' => 'Service' ),
		array( 'token' => '{date}',    'tr' => 'Tarih',    'en' => 'Date' ),
	);

	$out = array();

	foreach ( $cipler as $cip ) {
		$out[] = array(
			'token' => $cip['token'],
			'label' => $tr ? $cip['tr'] : $cip['en'],
		);
	}

	return $out;
}

/**
 * Metindeki {alan} değişkenlerini gönderilen değerlerle doldurur.
 *
 * @param string $text   Metin (ör. e-posta konusu).
 * @param array  $values key => değer (service dahil).
 * @return string
 */
function devxpe_form_fill_tokens( $text, $values ) {
	$text = (string) $text;

	if ( '' === $text || false === strpos( $text, '{' ) ) {
		return $text;
	}

	$map = array();
	foreach ( (array) $values as $key => $value ) {
		$key = sanitize_key( $key );
		if ( '' !== $key && is_scalar( $value ) ) {
			$map[ '{' . $key . '}' ] = (string) $value;
		}
	}

	return strtr( $text, $map );
}

/**
 * Ortak form doğrulama mesajları.
 *
 * Teklif formu ve panelden tasarlanan tüm formlar aynı mesajları kullanır.
 *
 * @return array
 */
function devxpe_form_messages() {
	$tlds     = devxpe_form_email_tlds();
	$tld_msg  = $tlds
		? sprintf( __( 'Kabul edilen e-posta uzantıları: %s', 'devxpe-theme' ), implode( ', ', $tlds ) )
		: __( 'Geçerli bir e-posta adresi girin.', 'devxpe-theme' );

	return array(
		'required' => devxpe_theme_get( 'validate_msg_required', __( 'Bu alanı doldurun.', 'devxpe-theme' ) ),
		'email'    => devxpe_theme_get( 'validate_msg_email', __( 'Geçerli bir e-posta adresi girin.', 'devxpe-theme' ) ),
		'tld'      => $tld_msg,
		'phone'    => devxpe_theme_get( 'validate_msg_phone', __( 'Geçerli bir telefon numarası girin.', 'devxpe-theme' ) ),
		'min'      => devxpe_theme_get( 'validate_msg_min', __( 'Bu alan çok kısa.', 'devxpe-theme' ) ),
		'max'      => devxpe_theme_get( 'validate_msg_max', __( 'Bu alan çok uzun.', 'devxpe-theme' ) ),
		'number'   => devxpe_theme_get( 'validate_msg_number', __( 'Bu alana yalnızca sayı girebilirsiniz.', 'devxpe-theme' ) ),
		'invalid'  => __( 'Geçersiz değer.', 'devxpe-theme' ),
	);
}

/**
 * Telefon ülke kodları: paneldeki "kod|Ülke adı" satırlarından dizi.
 *
 * @return array code => label
 */
function devxpe_form_countries() {
	$out = array();

	foreach ( explode( "\n", (string) devxpe_theme_get( 'validate_countries' ) ) as $line ) {
		$line = trim( $line );
		if ( '' === $line ) {
			continue;
		}

		$parts = array_map( 'trim', explode( '|', $line ) );
		$code  = preg_replace( '/[^0-9+]/', '', $parts[0] );

		if ( '' === $code ) {
			continue;
		}
		if ( 0 !== strpos( $code, '+' ) ) {
			$code = '+' . $code;
		}

		$out[ $code ] = ( isset( $parts[1] ) && '' !== $parts[1] ) ? $parts[1] : $code;
	}

	return $out;
}

/**
 * Telefon alanı için ülke kodu seçici (ön yüz).
 *
 * @param string $field_key Alan anahtarı (POST adı dxp_cc_<key>).
 * @return void
 */
function devxpe_form_country_select( $field_key ) {
	if ( '1' !== devxpe_theme_get( 'validate_country_enable' ) ) {
		return;
	}

	$countries = devxpe_form_countries();
	if ( count( $countries ) < 1 ) {
		return;
	}

	$default = (string) devxpe_theme_get( 'validate_country_default', '+44' );
	if ( ! isset( $countries[ $default ] ) ) {
		$keys    = array_keys( $countries );
		$default = $keys[0];
	}

	echo '<select class="dxp-cc" name="dxp_cc_' . esc_attr( $field_key ) . '" aria-label="' . esc_attr__( 'Ülke kodu', 'devxpe-theme' ) . '">';
	foreach ( $countries as $code => $label ) {
		echo '<option value="' . esc_attr( $code ) . '"' . selected( $code, $default, false ) . '>' . esc_html( $label . ' (' . $code . ')' ) . '</option>';
	}
	echo '</select>';
}

/**
 * Ülke bazlı telefon rakam uzunluğu (yerleşik tablo).
 *
 * ITU/libphonenumber "national significant number" uzunluklarıdır; ülke
 * seçilince alan otomatik olarak o ülkenin uzunluğuna göre sınırlanır.
 * Değişken uzunluklu ülkelerde aralık geniş tutulur (yanlış ret olmasın).
 * Panelde satır "kod|Ülke|min-max" yazılırsa tablo değeri ezilir.
 *
 * @return array code => array( min, max )
 */
function devxpe_phone_length_table() {
	return array(
		'+1'   => array( 10, 10 ),
		'+7'   => array( 10, 10 ),
		'+20'  => array( 9, 10 ),
		'+27'  => array( 9, 9 ),
		'+30'  => array( 10, 10 ),
		'+31'  => array( 9, 9 ),
		'+32'  => array( 8, 9 ),
		'+33'  => array( 9, 9 ),
		'+34'  => array( 9, 9 ),
		'+36'  => array( 8, 9 ),
		'+39'  => array( 6, 11 ),
		'+40'  => array( 9, 9 ),
		'+41'  => array( 9, 9 ),
		'+43'  => array( 4, 13 ),
		'+44'  => array( 7, 10 ),
		'+45'  => array( 8, 8 ),
		'+46'  => array( 7, 9 ),
		'+47'  => array( 8, 8 ),
		'+48'  => array( 9, 9 ),
		'+49'  => array( 5, 11 ),
		'+51'  => array( 8, 9 ),
		'+52'  => array( 10, 10 ),
		'+54'  => array( 10, 10 ),
		'+55'  => array( 10, 11 ),
		'+56'  => array( 9, 9 ),
		'+57'  => array( 10, 10 ),
		'+60'  => array( 8, 10 ),
		'+61'  => array( 9, 9 ),
		'+62'  => array( 8, 12 ),
		'+63'  => array( 10, 10 ),
		'+64'  => array( 7, 9 ),
		'+65'  => array( 8, 8 ),
		'+66'  => array( 8, 9 ),
		'+81'  => array( 9, 10 ),
		'+82'  => array( 9, 10 ),
		'+84'  => array( 9, 10 ),
		'+86'  => array( 11, 11 ),
		'+90'  => array( 10, 10 ),
		'+91'  => array( 10, 10 ),
		'+92'  => array( 9, 10 ),
		'+98'  => array( 10, 10 ),
		'+212' => array( 9, 9 ),
		'+213' => array( 8, 9 ),
		'+216' => array( 8, 8 ),
		'+234' => array( 10, 10 ),
		'+254' => array( 9, 9 ),
		'+351' => array( 9, 9 ),
		'+352' => array( 8, 9 ),
		'+353' => array( 7, 9 ),
		'+358' => array( 8, 10 ),
		'+370' => array( 8, 8 ),
		'+371' => array( 8, 8 ),
		'+372' => array( 7, 8 ),
		'+380' => array( 9, 9 ),
		'+381' => array( 8, 9 ),
		'+385' => array( 8, 9 ),
		'+386' => array( 8, 8 ),
		'+420' => array( 9, 9 ),
		'+421' => array( 9, 9 ),
		'+966' => array( 9, 9 ),
		'+971' => array( 8, 9 ),
		'+972' => array( 8, 9 ),
	);
}

/**
 * Ülke listesi + yerleşik tablo birleşimi (panel ezmeleri geçerli).
 *
 * @return array code => array( min, max )
 */
function devxpe_form_country_ranges() {
	$ranges = devxpe_phone_length_table();

	foreach ( explode( "\n", (string) devxpe_theme_get( 'validate_countries' ) ) as $line ) {
		$parts = array_map( 'trim', explode( '|', trim( $line ) ) );
		if ( count( $parts ) < 3 ) {
			continue;
		}

		$code = preg_replace( '/[^0-9+]/', '', $parts[0] );
		if ( '' === $code ) {
			continue;
		}
		if ( 0 !== strpos( $code, '+' ) ) {
			$code = '+' . $code;
		}

		/* "10" ya da "10-11" */
		if ( preg_match( '/^(\d+)\s*(?:-\s*(\d+))?$/', $parts[2], $m ) ) {
			$lo = (int) $m[1];
			$hi = isset( $m[2] ) ? (int) $m[2] : $lo;
			$ranges[ $code ] = array( min( $lo, $hi ), max( $lo, $hi ) );
		}
	}

	return $ranges;
}

/**
 * Ön yüz doğrulama yapılandırması (JS'e aktarılır).
 *
 * @return array
 */
function devxpe_form_config() {
	return array(
		'enable'      => ( '1' === devxpe_theme_get( 'validate_enable', '1' ) ),
		'numbersOnly' => ( '1' === devxpe_theme_get( 'validate_numbers_only', '1' ) ),
		/*
		 * Telefon uzunluğu ülke tablosundan gelir (devxpe_phone_length_table).
		 * Bu iki değer yalnızca yedektir: ülke seçicisi kapalıysa ya da ülke
		 * tabloda yoksa geçerli olur.
		 */
		'phoneMin'    => 7,
		'phoneMax'    => 20,
		'textMin'     => (int) devxpe_theme_get( 'validate_min_len', '2' ),
		'textMax'     => (int) devxpe_theme_get( 'validate_max_len', '120' ),
		'areaMax'     => (int) devxpe_theme_get( 'validate_textarea_max', '500' ),
		'emailTlds'   => devxpe_form_email_tlds(),
		/*
		 * Ülke seçilince geçerli rakam aralığı. Yalnızca panel listesindeki
		 * ülkeler gönderilir; listede olmayan ülke genel min/max'a düşer.
		 */
		'phoneLengths' => devxpe_form_country_ranges(),
	);
}

/**
 * Kabul edilen e-posta uzantıları (panelden, virgülle ayrılmış).
 *
 * @return array Küçük harfli uzantı listesi.
 */
function devxpe_form_email_tlds() {
	$out = array();

	foreach ( explode( ',', (string) devxpe_theme_get( 'validate_email_tlds' ) ) as $tld ) {
		$tld = strtolower( ltrim( trim( $tld ), '.' ) );
		if ( '' !== $tld ) {
			$out[] = $tld;
		}
	}

	return array_values( array_unique( $out ) );
}

/**
 * E-posta uzantısı kabul ediliyor mu?
 *
 * @param string $email E-posta adresi.
 * @return bool
 */
function devxpe_form_email_allowed( $email ) {
	$tlds = devxpe_form_email_tlds();
	if ( ! $tlds ) {
		return true;
	}

	$email = strtolower( (string) $email );
	$at    = strrpos( $email, '@' );
	if ( false === $at ) {
		return false;
	}

	$domain = substr( $email, $at + 1 );

	foreach ( $tlds as $tld ) {
		/* Alan adı ya listeye eşit olmalı (hotmail.com) ya da onunla bitmeli (mail.hotmail.com). */
		if ( $domain === $tld || substr( $domain, -1 * ( strlen( $tld ) + 1 ) ) === '.' . $tld ) {
			return true;
		}
	}

	return false;
}

/**
 * Tek satırlık alanlar için maxlength özniteliği (panel ayarı).
 *
 * @param string $type Alan tipi.
 * @return string
 */
function devxpe_field_maxlength_attr( $type = 'text' ) {
	$cfg = devxpe_form_config();
	$max = ( 'textarea' === $type ) ? (int) $cfg['areaMax'] : (int) $cfg['textMax'];

	return ( $max > 0 ) ? ' maxlength="' . $max . '"' : '';
}

/**
 * Uzun metin alanı sayacı: "12 / 500".
 *
 * @param string $type Alan tipi (textarea için limit uygulanır).
 * @return void
 */
function devxpe_render_field_counter( $type = 'textarea' ) {
	if ( 'textarea' !== $type ) {
		return;
	}

	$max = (int) devxpe_theme_get( 'validate_textarea_max', '500' );
	if ( $max <= 0 ) {
		return;
	}

	echo '<small class="dxp-count" data-max="' . esc_attr( $max ) . '">0 / ' . esc_html( $max ) . '</small>';
}

/**
 * Telefon alanının başındaki ülke kodunu değere ekler.
 *
 * @param string $key   Alan anahtarı.
 * @param string $value Telefon değeri.
 * @return string
 */
function devxpe_form_apply_country( $key, $value ) {
	if ( ! isset( $_POST[ 'dxp_cc_' . $key ] ) ) {
		return $value;
	}

	$code = preg_replace( '/[^0-9+]/', '', wp_unslash( $_POST[ 'dxp_cc_' . $key ] ) );
	if ( '' === $code ) {
		return $value;
	}

	/* Numara zaten uluslararasıysa (+ ile başlıyorsa) dokunmayız. */
	if ( 0 === strpos( $value, '+' ) ) {
		return $value;
	}

	/* Baştaki ulusal 0 atılır: 07983 872023 → +44 7983 872023 */
	$rest = preg_replace( '/\s+/', ' ', trim( ltrim( $value, '0' ) ) );
	if ( '' === $rest ) {
		return $value;
	}

	return $code . ' ' . $rest;
}
