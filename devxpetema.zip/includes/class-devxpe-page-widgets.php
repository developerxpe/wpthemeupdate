<?php
/**
 * Sayfa içeriği widget kütüphanesi.
 *
 * Sayfa düzenleyicisindeki "Sayfa İçeriği" metabox'ında eklenen widget'lar
 * tek bir kaynaktan yönetilir: hangi widget var, hangi ayar alanları var,
 * veri nasıl temizlenir ve ön yüzde nasıl çizilir.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sayfa widget'ları (tanım + temizleme + ön yüz çizimi).
 */
class DEVXPE_Page_Widgets {

	/**
	 * Sayfa widget'larının saklandığı meta anahtarı (JSON dizesi).
	 */
	const META_KEY = '_dxp_page_widgets';

	/** Widget düzeni: tam genişlik | 2 sütun (nested). */
	const DUZEN_KEY = '_dxp_pw_duzen';

	/**
	 * Widget kapsamları: hangi sayfa tipinde kullanılabilir.
	 *
	 * @return array value => etiket
	 */
	public static function kapsam() {
		return array(
			'about'   => __( 'Hakkımızda', 'devxpe-theme' ),
			'contact' => __( 'İletişim', 'devxpe-theme' ),
		);
	}

	/**
	 * Widget editörünün tanıdığı tüm bağlamlar.
	 *
	 * Sayfa tipleri (about/contact) + panelde tanımlı her CPT slug'ı.
	 * Değer, seçim listelerinde görünen etikettir.
	 *
	 * @return array value => etiket
	 */
	public static function kapsamlar() {
		return array_merge( self::kapsam(), self::cpt_baglamlari() );
	}

	/**
	 * Panelde tanımlı içerik tiplerini slug => ad olarak döndürür.
	 *
	 * @return array
	 */
	private static function cpt_baglamlari() {
		$out = array();
		if ( ! function_exists( 'devxpe_custom_post_types' ) ) {
			return $out;
		}

		foreach ( devxpe_custom_post_types() as $cpt ) {
			if ( empty( $cpt['slug'] ) ) {
				continue;
			}
			$out[ $cpt['slug'] ] = ! empty( $cpt['name'] ) ? $cpt['name'] : $cpt['slug'];
		}

		return $out;
	}

	/**
	 * Bir içeriğin widget bağlamını bulur (sayfa tipi veya CPT slug'ı).
	 *
	 * @param int $post_id İçerik kimliği.
	 * @return string Bağlam kimliği; tanınmıyorsa ''.
	 */
	public static function baglam_bul( $post_id ) {
		$post_id = (int) $post_id;
		if ( ! $post_id ) {
			return '';
		}

		$post = get_post( $post_id );
		if ( ! $post ) {
			return '';
		}

		/* Sayfa: "Sayfa nedir?" seçimi (about/contact). */
		if ( 'page' === $post->post_type ) {
			$tip = (string) get_post_meta( $post_id, '_dxp_page_type', true );

			return array_key_exists( $tip, self::kapsam() ) ? $tip : '';
		}

		/* İçerik tipi: post_type zaten bir bağlam kimliğidir. */
		$cptler = self::cpt_baglamlari();

		return array_key_exists( $post->post_type, $cptler ) ? $post->post_type : '';
	}

	/**
	 * Sayfanın widget düzeni: tam genişlik mi, 2 sütun mu?
	 *
	 * @param int $post_id Sayfa kimliği.
	 * @return string 'full' | 'nested'
	 */
	public static function duzen( $post_id ) {
		$d = (string) get_post_meta( (int) $post_id, self::DUZEN_KEY, true );

		return ( 'nested' === $d ) ? 'nested' : 'full';
	}

	/**
	 * KAYITLI widget listesinde belirli bir tip var mı?
	 *
	 * @param int    $post_id Sayfa kimliği.
	 * @param string $tip     Widget tipi (ör. 'manset', 'iletisim_kart').
	 * @return bool
	 */
	public static function icerir( $post_id, $tip ) {
		$tip = sanitize_key( $tip );

		if ( '' === $tip ) {
			return false;
		}

		$post_id = (int) $post_id;
		$var     = array();

		foreach ( (array) self::veri( $post_id ) as $w ) {
			if ( is_array( $w ) && isset( $w['tip'] ) ) {
				$var[] = sanitize_key( $w['tip'] );
			}
		}

		/*
		 * Yerleşik blok göçü: eksik blok render anında widget gibi ekleniyorsa
		 * şablon onu tekrar çizmemeli (çift görünmesin).
		 */
		foreach ( self::eksik_yerlesik( $post_id, self::baglam_bul( $post_id ) ) as $w ) {
			$var[] = sanitize_key( $w['tip'] );
		}

		return in_array( $tip, $var, true );
	}

	/**
	 * Widget yerleşimini beyaz listeye göre temizler.
	 *
	 * @param string $ham Ham değer.
	 * @return string '' (otomatik) | 'sol' | 'sag' | 'tam'
	 */
	private static function yer_temizle( $ham ) {
		$ham = sanitize_key( $ham );

		return in_array( $ham, array( 'sol', 'sag', 'tam' ), true ) ? $ham : '';
	}

	/**
	 * Widget kaydının yerleşimi (nested düzende sütun ataması).
	 *
	 * @param array $widget Widget kaydı.
	 * @return string '' | 'sol' | 'sag' | 'tam'
	 */
	public static function yer( $widget ) {
		if ( ! is_array( $widget ) || ! isset( $widget['yer'] ) ) {
			return '';
		}

		return self::yer_temizle( $widget['yer'] );
	}

	/**
	 * Bir bağlama ait varsayılan widget sırasını döndürür.
	 *
	 * CPT'ler için ARC düzeni (hero → quote) kullanılır; bu sıra yalnızca
	 * meta boşken render sırasında uygulanır, sayfaya YAZILMAZ.
	 *
	 * @param string $baglam Bağlam kimliği.
	 * @return array tip listesi
	 */
	public static function varsayilan_dizilim( $baglam ) {
		$baglam = sanitize_key( $baglam );

		$sabit = array(
			'about'   => array( 'baslik', 'metin', 'stats', 'ekip', 'liste' ),
			'contact' => array( 'baslik', 'metin', 'iletisim_kart', 'harita', 'saatler', 'form' ),
		);

		if ( isset( $sabit[ $baglam ] ) ) {
			return $sabit[ $baglam ];
		}

		/* CPT bağlamı → ARC düzeni. */
		if ( array_key_exists( $baglam, self::cpt_baglamlari() ) ) {
			return array(
				'cpt_hero',
				'cpt_includes',
				'cpt_content',
				'cpt_projects',
				'cpt_services',
				'cpt_faq',
				'cpt_related',
				'cpt_quote',
			);
		}

		return array();
	}

	/**
	 * Tüm widget tanımları (ad + ikon + kapsam + ayar şeması).
	 *
	 * @return array
	 */
	public static function kutuphane() {
		$formlar = function_exists( 'devxpe_form_choice_options' ) ? devxpe_form_choice_options() : array( 'quote' => __( 'Teklif Formu', 'devxpe-theme' ) );

		$hiza  = array(
			'sol'  => __( 'Sol', 'devxpe-theme' ),
			'orta' => __( 'Orta', 'devxpe-theme' ),
			'sag'  => __( 'Sağ', 'devxpe-theme' ),
		);
		$kolon = array(
			'2' => '2',
			'3' => '3',
			'4' => '4',
		);

		$cpt_kapsam = array_keys( self::cpt_baglamlari() );

		$kutup = array(
			'baslik'        => array(
				'ad'      => __( 'Başlık', 'devxpe-theme' ),
				'ikon'    => 'dashicons-heading',
				'kapsam'  => array( 'about', 'contact' ),
				'ayarlar' => array(
					'metin'  => array( 'tip' => 'metin', 'etiket' => __( 'Metin', 'devxpe-theme' ), 'varsayilan' => '' ),
					'seviye' => array( 'tip' => 'secim', 'etiket' => __( 'Seviye', 'devxpe-theme' ), 'varsayilan' => 'h2', 'secenekler' => array( 'h1' => 'H1', 'h2' => 'H2', 'h3' => 'H3' ) ),
					'hiza'   => array( 'tip' => 'secim', 'etiket' => __( 'Hizalama', 'devxpe-theme' ), 'varsayilan' => 'sol', 'secenekler' => $hiza ),
				),
			),
			'manset'        => array(
				'ad'      => __( 'Sayfa Manşeti', 'devxpe-theme' ),
				'ikon'    => 'dashicons-cover-image',
				'kapsam'  => array( 'about', 'contact' ),
				'ayarlar' => array(
					'ustbaslik' => array( 'tip' => 'metin', 'etiket' => __( 'Üst başlık (eyebrow)', 'devxpe-theme' ), 'varsayilan' => '' ),
					'baslik'    => array( 'tip' => 'metin', 'etiket' => __( 'Başlık', 'devxpe-theme' ), 'varsayilan' => '' ),
					'metin'     => array( 'tip' => 'metinuzun', 'etiket' => __( 'Açıklama (manşet altı metni)', 'devxpe-theme' ), 'varsayilan' => '' ),
					'seviye'    => array( 'tip' => 'secim', 'etiket' => __( 'Başlık seviyesi', 'devxpe-theme' ), 'varsayilan' => 'h1', 'secenekler' => array( 'h1' => 'H1', 'h2' => 'H2', 'h3' => 'H3' ) ),
					'hiza'      => array( 'tip' => 'secim', 'etiket' => __( 'Hizalama', 'devxpe-theme' ), 'varsayilan' => 'sol', 'secenekler' => $hiza ),
				),
			),
			'metin'         => array(
				'ad'      => __( 'Metin', 'devxpe-theme' ),
				'ikon'    => 'dashicons-editor-paragraph',
				'kapsam'  => array( 'about', 'contact' ),
				'ayarlar' => array(
					'icerik' => array( 'tip' => 'metinuzun', 'etiket' => __( 'İçerik (HTML olabilir)', 'devxpe-theme' ), 'varsayilan' => '' ),
					'hiza'   => array( 'tip' => 'secim', 'etiket' => __( 'Hizalama', 'devxpe-theme' ), 'varsayilan' => 'sol', 'secenekler' => $hiza ),
				),
			),
			'gorsel'        => array(
				'ad'      => __( 'Görsel', 'devxpe-theme' ),
				'ikon'    => 'dashicons-format-image',
				'kapsam'  => array( 'about', 'contact' ),
				'ayarlar' => array(
					'gorsel'   => array( 'tip' => 'gorsel', 'etiket' => __( 'Görsel', 'devxpe-theme' ), 'varsayilan' => '' ),
					'genislik' => array( 'tip' => 'metin', 'etiket' => __( 'Genişlik (örn. 100% veya 480px)', 'devxpe-theme' ), 'varsayilan' => '' ),
					'alt'      => array( 'tip' => 'metin', 'etiket' => __( 'Alt metni', 'devxpe-theme' ), 'varsayilan' => '' ),
					'cerceve'  => array( 'tip' => 'onay', 'etiket' => __( 'Yuvarlak köşe', 'devxpe-theme' ), 'varsayilan' => '' ),
					'hiza'     => array( 'tip' => 'secim', 'etiket' => __( 'Hizalama', 'devxpe-theme' ), 'varsayilan' => 'sol', 'secenekler' => $hiza ),
				),
			),
			'buton'         => array(
				'ad'      => __( 'Buton', 'devxpe-theme' ),
				'ikon'    => 'dashicons-button',
				'kapsam'  => array( 'about', 'contact' ),
				'ayarlar' => array(
					'metin' => array( 'tip' => 'metin', 'etiket' => __( 'Buton yazısı', 'devxpe-theme' ), 'varsayilan' => '' ),
					'link'  => array( 'tip' => 'metin', 'etiket' => __( 'Bağlantı (URL)', 'devxpe-theme' ), 'varsayilan' => '' ),
					'stil'  => array( 'tip' => 'secim', 'etiket' => __( 'Stil', 'devxpe-theme' ), 'varsayilan' => 'birincil', 'secenekler' => array( 'birincil' => __( 'Birincil', 'devxpe-theme' ), 'ikincil' => __( 'İkincil', 'devxpe-theme' ), 'kenar' => __( 'Kenar', 'devxpe-theme' ) ) ),
					'hiza'  => array( 'tip' => 'secim', 'etiket' => __( 'Hizalama', 'devxpe-theme' ), 'varsayilan' => 'sol', 'secenekler' => $hiza ),
				),
			),
			'ikon_kutu'     => array(
				'ad'      => __( 'İkon Kutusu', 'devxpe-theme' ),
				'ikon'    => 'dashicons-lightbulb',
				'kapsam'  => array( 'about', 'contact' ),
				'ayarlar' => array(
					'ikon'  => array( 'tip' => 'ikon', 'etiket' => __( 'İkon', 'devxpe-theme' ), 'varsayilan' => '' ),
					'baslik' => array( 'tip' => 'metin', 'etiket' => __( 'Başlık', 'devxpe-theme' ), 'varsayilan' => '' ),
					'metin' => array( 'tip' => 'metinuzun', 'etiket' => __( 'Metin', 'devxpe-theme' ), 'varsayilan' => '' ),
					'hiza'  => array( 'tip' => 'secim', 'etiket' => __( 'Hizalama', 'devxpe-theme' ), 'varsayilan' => 'sol', 'secenekler' => $hiza ),
				),
			),
			'ikon_kutulari' => array(
				'ad'      => __( 'İkon Kutuları (çoklu)', 'devxpe-theme' ),
				'ikon'    => 'dashicons-grid-view',
				'kapsam'  => array( 'about', 'contact' ),
				'ayarlar' => array(
					'baslik'   => array( 'tip' => 'metin', 'etiket' => __( 'Başlık', 'devxpe-theme' ), 'varsayilan' => '' ),
					'kolon'    => array( 'tip' => 'secim', 'etiket' => __( 'Sütun', 'devxpe-theme' ), 'varsayilan' => '3', 'secenekler' => $kolon ),
					'satirlar' => array(
						'tip'        => 'satirlar',
						'etiket'     => __( 'Satırlar', 'devxpe-theme' ),
						'varsayilan' => '',
						'kolonlar'   => array(
							array( 'ad' => __( 'Ikon', 'devxpe-theme' ), 'tip' => 'ikon' ),
							array( 'ad' => __( 'Başlık', 'devxpe-theme' ), 'tip' => 'metin' ),
							array( 'ad' => __( 'Metin', 'devxpe-theme' ), 'tip' => 'metin' ),
						),
					),
					'hiza'     => array( 'tip' => 'secim', 'etiket' => __( 'Hizalama', 'devxpe-theme' ), 'varsayilan' => 'sol', 'secenekler' => $hiza ),
				),
			),
			'icerik'        => array(
				'ad'      => __( 'Sayfa İçeriği Metni', 'devxpe-theme' ),
				'ikon'    => 'dashicons-media-document',
				'kapsam'  => array( 'about', 'contact' ),
				'ayarlar' => array(
					'baslik' => array( 'tip' => 'metin', 'etiket' => __( 'Başlık (boşsa çizilmez)', 'devxpe-theme' ), 'varsayilan' => '' ),
					'seviye' => array( 'tip' => 'secim', 'etiket' => __( 'Başlık seviyesi', 'devxpe-theme' ), 'varsayilan' => 'h2', 'secenekler' => array( 'h1' => 'H1', 'h2' => 'H2', 'h3' => 'H3' ) ),
					'hiza'   => array( 'tip' => 'secim', 'etiket' => __( 'Hizalama', 'devxpe-theme' ), 'varsayilan' => 'sol', 'secenekler' => $hiza ),
				),
			),
			'ayrac'         => array(
				'ad'      => __( 'Ayraç', 'devxpe-theme' ),
				'ikon'    => 'dashicons-minus',
				'kapsam'  => array( 'about', 'contact' ),
				'ayarlar' => array(
					'stil'      => array( 'tip' => 'secim', 'etiket' => __( 'Stil', 'devxpe-theme' ), 'varsayilan' => 'cizgi', 'secenekler' => array( 'cizgi' => __( 'Çizgi', 'devxpe-theme' ), 'nokta' => __( 'Nokta', 'devxpe-theme' ), 'bosluk' => __( 'Boşluk', 'devxpe-theme' ) ) ),
					'yukseklik' => array( 'tip' => 'sayi', 'etiket' => __( 'Yükseklik (px)', 'devxpe-theme' ), 'varsayilan' => '24' ),
				),
			),
			'stats'         => array(
				'ad'      => __( 'İstatistikler', 'devxpe-theme' ),
				'ikon'    => 'dashicons-chart-bar',
				'kapsam'  => array( 'about', 'contact' ),
				'ayarlar' => array(
					'baslik'   => array( 'tip' => 'metin', 'etiket' => __( 'Başlık', 'devxpe-theme' ), 'varsayilan' => '' ),
					'kolon'    => array( 'tip' => 'secim', 'etiket' => __( 'Sütun', 'devxpe-theme' ), 'varsayilan' => '3', 'secenekler' => $kolon ),
					'satirlar' => array(
						'tip'        => 'satirlar',
						'etiket'     => __( 'Satırlar', 'devxpe-theme' ),
						'varsayilan' => '',
						'kolonlar'   => array(
							array( 'ad' => __( 'Ikon', 'devxpe-theme' ), 'tip' => 'ikon' ),
							array( 'ad' => __( 'Değer', 'devxpe-theme' ), 'tip' => 'metin' ),
							array( 'ad' => __( 'Etiket', 'devxpe-theme' ), 'tip' => 'metin' ),
						),
					),
				),
			),
			'ekip'          => array(
				'ad'      => __( 'Ekip', 'devxpe-theme' ),
				'ikon'    => 'dashicons-groups',
				'kapsam'  => array( 'about' ),
				'ayarlar' => array(
					'baslik'   => array( 'tip' => 'metin', 'etiket' => __( 'Başlık', 'devxpe-theme' ), 'varsayilan' => '' ),
					'kolon'    => array( 'tip' => 'secim', 'etiket' => __( 'Sütun', 'devxpe-theme' ), 'varsayilan' => '3', 'secenekler' => $kolon ),
					'satirlar' => array(
						'tip'        => 'satirlar',
						'etiket'     => __( 'Satırlar', 'devxpe-theme' ),
						'varsayilan' => '',
						'kolonlar'   => array(
							array( 'ad' => __( 'Fotoğraf', 'devxpe-theme' ), 'tip' => 'gorsel' ),
							array( 'ad' => __( 'Ad', 'devxpe-theme' ), 'tip' => 'metin' ),
							array( 'ad' => __( 'Ünvan', 'devxpe-theme' ), 'tip' => 'metin' ),
							array( 'ad' => __( 'Açıklama', 'devxpe-theme' ), 'tip' => 'metinuzun' ),
						),
					),
				),
			),
			'liste'         => array(
				'ad'      => __( 'Madde Listesi', 'devxpe-theme' ),
				'ikon'    => 'dashicons-editor-ul',
				'kapsam'  => array( 'about' ),
				'ayarlar' => array(
					'baslik'   => array( 'tip' => 'metin', 'etiket' => __( 'Başlık', 'devxpe-theme' ), 'varsayilan' => '' ),
					'satirlar' => array(
						'tip'        => 'satirlar',
						'etiket'     => __( 'Maddeler', 'devxpe-theme' ),
						'varsayilan' => '',
						'kolonlar'   => array(
							array( 'ad' => __( 'Madde', 'devxpe-theme' ), 'tip' => 'metin' ),
						),
					),
					'ikon'     => array( 'tip' => 'secim', 'etiket' => __( 'İşaret', 'devxpe-theme' ), 'varsayilan' => 'onayli', 'secenekler' => array( 'yok' => __( 'Yok', 'devxpe-theme' ), 'onayli' => __( 'Onaylı', 'devxpe-theme' ), 'nokta' => __( 'Nokta', 'devxpe-theme' ) ) ),
				),
			),
			'alinti'        => array(
				'ad'      => __( 'Alıntı', 'devxpe-theme' ),
				'ikon'    => 'dashicons-format-quote',
				'kapsam'  => array( 'about' ),
				'ayarlar' => array(
					'metin'  => array( 'tip' => 'metinuzun', 'etiket' => __( 'Alıntı metni', 'devxpe-theme' ), 'varsayilan' => '' ),
					'kaynak' => array( 'tip' => 'metin', 'etiket' => __( 'Kaynak / isim', 'devxpe-theme' ), 'varsayilan' => '' ),
					'avatar' => array( 'tip' => 'gorsel', 'etiket' => __( 'Avatar görseli', 'devxpe-theme' ), 'varsayilan' => '' ),
					'hiza'   => array( 'tip' => 'secim', 'etiket' => __( 'Hizalama', 'devxpe-theme' ), 'varsayilan' => 'sol', 'secenekler' => $hiza ),
				),
			),
			'harita'        => array(
				'ad'      => __( 'Google Harita', 'devxpe-theme' ),
				'ikon'    => 'dashicons-location',
				'kapsam'  => array( 'contact' ),
				'ayarlar' => array(
					'adres'     => array( 'tip' => 'metinuzun', 'etiket' => __( 'Konum (adres veya koordinat)', 'devxpe-theme' ), 'varsayilan' => '', 'onizleme' => 'harita' ),
					'yukseklik' => array( 'tip' => 'sayi', 'etiket' => __( 'Yükseklik (px)', 'devxpe-theme' ), 'varsayilan' => '320' ),
					'zoom'      => array( 'tip' => 'sayi', 'etiket' => __( 'Yakınlaştırma', 'devxpe-theme' ), 'varsayilan' => '14' ),
					'baslik'    => array( 'tip' => 'metin', 'etiket' => __( 'Başlık', 'devxpe-theme' ), 'varsayilan' => '' ),
				),
			),
			'saatler'       => array(
				'ad'      => __( 'Çalışma Saatleri', 'devxpe-theme' ),
				'ikon'    => 'dashicons-clock',
				'kapsam'  => array( 'contact' ),
				'ayarlar' => array(
					'baslik'   => array( 'tip' => 'metin', 'etiket' => __( 'Başlık', 'devxpe-theme' ), 'varsayilan' => __( 'Çalışma Saatleri', 'devxpe-theme' ) ),
					'satirlar' => array(
						'tip'        => 'satirlar',
						'etiket'     => __( 'Satırlar', 'devxpe-theme' ),
						'varsayilan' => '',
						'kolonlar'   => array(
							array( 'ad' => __( 'Gün', 'devxpe-theme' ), 'tip' => 'metin' ),
							array( 'ad' => __( 'Saat', 'devxpe-theme' ), 'tip' => 'metin' ),
						),
					),
					'not'      => array( 'tip' => 'metin', 'etiket' => __( 'Not', 'devxpe-theme' ), 'varsayilan' => '' ),
				),
			),
			'iletisim_kart' => array(
				'ad'      => __( 'İletişim Kartları', 'devxpe-theme' ),
				'ikon'    => 'dashicons-id',
				'kapsam'  => array( 'contact', 'about' ),
				'ayarlar' => array(
					'baslik'   => array( 'tip' => 'metin', 'etiket' => __( 'Başlık', 'devxpe-theme' ), 'varsayilan' => '' ),
					'kolon'    => array( 'tip' => 'secim', 'etiket' => __( 'Sütun', 'devxpe-theme' ), 'varsayilan' => '1', 'secenekler' => array( '1' => '1', '2' => '2', '3' => '3' ) ),
					'satirlar' => array(
						'tip'        => 'satirlar',
						'etiket'     => __( 'Satırlar', 'devxpe-theme' ),
						'varsayilan' => '',
						'kolonlar'   => array(
							array( 'ad' => __( 'Ikon', 'devxpe-theme' ), 'tip' => 'ikon' ),
							array( 'ad' => __( 'Başlık', 'devxpe-theme' ), 'tip' => 'metin' ),
							array( 'ad' => __( 'Değer', 'devxpe-theme' ), 'tip' => 'metin' ),
							array( 'ad' => __( 'Link', 'devxpe-theme' ), 'tip' => 'link' ),
						),
					),
				),
			),
			'form'          => array(
				'ad'      => __( 'İletişim Formu', 'devxpe-theme' ),
				'ikon'    => 'dashicons-email',
				'kapsam'  => array( 'contact' ),
				'ayarlar' => array(
					'baslik'   => array( 'tip' => 'metin', 'etiket' => __( 'Başlık', 'devxpe-theme' ), 'varsayilan' => '' ),
					'form_sec' => array( 'tip' => 'secim', 'etiket' => __( 'Form', 'devxpe-theme' ), 'varsayilan' => 'quote', 'secenekler' => $formlar ),
					'stil'     => array( 'tip' => 'secim', 'etiket' => __( 'Stil', 'devxpe-theme' ), 'varsayilan' => 'kart', 'secenekler' => array( 'kart' => __( 'Kart', 'devxpe-theme' ), 'duz' => __( 'Düz', 'devxpe-theme' ) ) ),
				),
			),
			'sosyal'        => array(
				'ad'      => __( 'Sosyal Medya', 'devxpe-theme' ),
				'ikon'    => 'dashicons-share',
				'kapsam'  => array( 'contact' ),
				'ayarlar' => array(
					'satirlar' => array(
						'tip'        => 'satirlar',
						'etiket'     => __( 'Satırlar', 'devxpe-theme' ),
						'varsayilan' => '',
						'kolonlar'   => array(
							array( 'ad' => __( 'Platform', 'devxpe-theme' ), 'tip' => 'metin' ),
							array( 'ad' => __( 'Adres', 'devxpe-theme' ), 'tip' => 'link' ),
						),
					),
					'hiza'     => array( 'tip' => 'secim', 'etiket' => __( 'Hizalama', 'devxpe-theme' ), 'varsayilan' => 'sol', 'secenekler' => $hiza ),
					'baslik'   => array( 'tip' => 'metin', 'etiket' => __( 'Başlık', 'devxpe-theme' ), 'varsayilan' => '' ),
				),
			),

			/* ── İçerik tipi (CPT) widget'ları — ARC düzeni ───────── */

			'cpt_hero'     => array(
				'ad'      => __( 'Manşet', 'devxpe-theme' ),
				'ikon'    => 'dashicons-cover-image',
				'kapsam'  => $cpt_kapsam,
				'ayarlar' => array(
					'rozet'         => array( 'tip' => 'metin', 'etiket' => __( 'Rozet (üst başlık)', 'devxpe-theme' ), 'varsayilan' => '' ),
					'baslik_kaynak' => array( 'tip' => 'secim', 'etiket' => __( 'Başlık kaynağı', 'devxpe-theme' ), 'varsayilan' => 'baslik', 'secenekler' => array( 'baslik' => __( 'İçerik başlığı', 'devxpe-theme' ), 'meta' => __( 'Manşet meta alanı', 'devxpe-theme' ) ) ),
					'lead'          => array( 'tip' => 'metinuzun', 'etiket' => __( 'Manşet altı metni', 'devxpe-theme' ), 'varsayilan' => '' ),
					'konum'         => array( 'tip' => 'metin', 'etiket' => __( 'Konum satırı', 'devxpe-theme' ), 'varsayilan' => '' ),
					'alan_adi'      => array( 'tip' => 'metin', 'etiket' => __( 'Bölge adı (kısa)', 'devxpe-theme' ), 'varsayilan' => '' ),
					'btn1_metin'    => array( 'tip' => 'metin', 'etiket' => __( '1. buton yazısı', 'devxpe-theme' ), 'varsayilan' => '' ),
					'btn1_link'     => array( 'tip' => 'metin', 'etiket' => __( '1. buton bağlantısı', 'devxpe-theme' ), 'varsayilan' => '' ),
					'btn2_metin'    => array( 'tip' => 'metin', 'etiket' => __( '2. buton yazısı', 'devxpe-theme' ), 'varsayilan' => '' ),
					'btn2_link'     => array( 'tip' => 'metin', 'etiket' => __( '2. buton bağlantısı', 'devxpe-theme' ), 'varsayilan' => '' ),
					'gorsel'        => array( 'tip' => 'gorsel', 'etiket' => __( 'Manşet görseli', 'devxpe-theme' ), 'varsayilan' => '' ),
					'rozetler'      => array(
						'tip'        => 'satirlar',
						'etiket'     => __( 'Rozetler', 'devxpe-theme' ),
						'varsayilan' => '',
						'kolonlar'   => array(
							array( 'ad' => __( 'Ikon', 'devxpe-theme' ), 'tip' => 'ikon' ),
							array( 'ad' => __( 'Değer', 'devxpe-theme' ), 'tip' => 'metin' ),
							array( 'ad' => __( 'Etiket', 'devxpe-theme' ), 'tip' => 'metin' ),
						),
					),
				),
			),
			'cpt_includes' => array(
				'ad'      => __( 'Neler Dahil', 'devxpe-theme' ),
				'ikon'    => 'dashicons-yes-alt',
				'kapsam'  => $cpt_kapsam,
				'ayarlar' => array(
					'baslik'   => array( 'tip' => 'metin', 'etiket' => __( 'Başlık', 'devxpe-theme' ), 'varsayilan' => '' ),
					'satirlar' => array(
						'tip'        => 'satirlar',
						'etiket'     => __( 'Maddeler', 'devxpe-theme' ),
						'varsayilan' => '',
						'kolonlar'   => array(
							array( 'ad' => __( 'Madde', 'devxpe-theme' ), 'tip' => 'metin' ),
						),
					),
					'gorsel'   => array( 'tip' => 'gorsel', 'etiket' => __( 'Görsel', 'devxpe-theme' ), 'varsayilan' => '' ),
					'stil'     => array( 'tip' => 'secim', 'etiket' => __( 'Stil', 'devxpe-theme' ), 'varsayilan' => 'liste', 'secenekler' => array( 'liste' => __( 'Liste', 'devxpe-theme' ), 'kart' => __( 'Kart', 'devxpe-theme' ) ) ),
				),
			),
			'cpt_content'  => array(
				'ad'      => __( 'İçerik', 'devxpe-theme' ),
				'ikon'    => 'dashicons-editor-paragraph',
				'kapsam'  => $cpt_kapsam,
				'ayarlar' => array(
					'baslik'        => array( 'tip' => 'metin', 'etiket' => __( 'Başlık', 'devxpe-theme' ), 'varsayilan' => '' ),
					'icerik_kaynak' => array( 'tip' => 'secim', 'etiket' => __( 'İçerik kaynağı', 'devxpe-theme' ), 'varsayilan' => 'editor', 'secenekler' => array( 'editor' => __( 'İçerik (editör)', 'devxpe-theme' ), 'meta' => __( 'Özel alan', 'devxpe-theme' ) ) ),
					'genislik'      => array( 'tip' => 'secim', 'etiket' => __( 'Genişlik', 'devxpe-theme' ), 'varsayilan' => 'normal', 'secenekler' => array( 'dar' => __( 'Dar', 'devxpe-theme' ), 'normal' => __( 'Normal', 'devxpe-theme' ), 'genis' => __( 'Geniş', 'devxpe-theme' ) ) ),
				),
			),
			'cpt_projects' => array(
				'ad'      => __( 'Projeler', 'devxpe-theme' ),
				'ikon'    => 'dashicons-portfolio',
				'kapsam'  => $cpt_kapsam,
				'ayarlar' => array(
					'baslik'   => array( 'tip' => 'metin', 'etiket' => __( 'Başlık', 'devxpe-theme' ), 'varsayilan' => '' ),
					'kaynak'   => array( 'tip' => 'secim', 'etiket' => __( 'Kaynak', 'devxpe-theme' ), 'varsayilan' => 'manuel', 'secenekler' => array( 'kategori' => __( 'Kategori (CPT)', 'devxpe-theme' ), 'manuel' => __( 'Manuel kartlar', 'devxpe-theme' ) ) ),
					'adet'     => array( 'tip' => 'sayi', 'etiket' => __( 'Adet', 'devxpe-theme' ), 'varsayilan' => '6' ),
					'kolon'    => array( 'tip' => 'secim', 'etiket' => __( 'Sütun', 'devxpe-theme' ), 'varsayilan' => '3', 'secenekler' => $kolon ),
					'satirlar' => array(
						'tip'        => 'satirlar',
						'etiket'     => __( 'Manuel kartlar', 'devxpe-theme' ),
						'varsayilan' => '',
						'kolonlar'   => array(
							array( 'ad' => __( 'Görsel', 'devxpe-theme' ), 'tip' => 'gorsel' ),
							array( 'ad' => __( 'Başlık', 'devxpe-theme' ), 'tip' => 'metin' ),
							array( 'ad' => __( 'Link', 'devxpe-theme' ), 'tip' => 'link' ),
						),
					),
				),
			),
			'cpt_services' => array(
				'ad'      => __( 'Hizmetler', 'devxpe-theme' ),
				'ikon'    => 'dashicons-hammer',
				'kapsam'  => $cpt_kapsam,
				'ayarlar' => array(
					'baslik'   => array( 'tip' => 'metin', 'etiket' => __( 'Başlık', 'devxpe-theme' ), 'varsayilan' => '' ),
					'kaynak'   => array( 'tip' => 'secim', 'etiket' => __( 'Kaynak', 'devxpe-theme' ), 'varsayilan' => 'kategori', 'secenekler' => array( 'kategori' => __( 'Kategori (CPT)', 'devxpe-theme' ), 'manuel' => __( 'Manuel kartlar', 'devxpe-theme' ) ) ),
					'adet'     => array( 'tip' => 'sayi', 'etiket' => __( 'Adet', 'devxpe-theme' ), 'varsayilan' => '' ),
					'kolon'    => array( 'tip' => 'secim', 'etiket' => __( 'Sütun', 'devxpe-theme' ), 'varsayilan' => '3', 'secenekler' => $kolon ),
					'satirlar' => array(
						'tip'        => 'satirlar',
						'etiket'     => __( 'Manuel kartlar', 'devxpe-theme' ),
						'varsayilan' => '',
						'kolonlar'   => array(
							array( 'ad' => __( 'Görsel', 'devxpe-theme' ), 'tip' => 'gorsel' ),
							array( 'ad' => __( 'Başlık', 'devxpe-theme' ), 'tip' => 'metin' ),
							array( 'ad' => __( 'Link', 'devxpe-theme' ), 'tip' => 'link' ),
						),
					),
				),
			),
			'cpt_faq'      => array(
				'ad'      => __( 'SSS', 'devxpe-theme' ),
				'ikon'    => 'dashicons-editor-help',
				'kapsam'  => $cpt_kapsam,
				'ayarlar' => array(
					'baslik'   => array( 'tip' => 'metin', 'etiket' => __( 'Başlık', 'devxpe-theme' ), 'varsayilan' => '' ),
					'satirlar' => array(
						'tip'        => 'satirlar',
						'etiket'     => __( 'Sorular', 'devxpe-theme' ),
						'varsayilan' => '',
						'kolonlar'   => array(
							array( 'ad' => __( 'Soru', 'devxpe-theme' ), 'tip' => 'metin' ),
							array( 'ad' => __( 'Cevap', 'devxpe-theme' ), 'tip' => 'metinuzun' ),
						),
					),
				),
			),
			'cpt_related'  => array(
				'ad'      => __( 'İlgili İçerikler', 'devxpe-theme' ),
				'ikon'    => 'dashicons-admin-links',
				'kapsam'  => $cpt_kapsam,
				'ayarlar' => array(
					'baslik' => array( 'tip' => 'metin', 'etiket' => __( 'Başlık', 'devxpe-theme' ), 'varsayilan' => '' ),
					'adet'   => array( 'tip' => 'sayi', 'etiket' => __( 'Adet', 'devxpe-theme' ), 'varsayilan' => '8' ),
					'kolon'  => array( 'tip' => 'secim', 'etiket' => __( 'Sütun', 'devxpe-theme' ), 'varsayilan' => '3', 'secenekler' => $kolon ),
					'kaynak' => array( 'tip' => 'secim', 'etiket' => __( 'Kaynak', 'devxpe-theme' ), 'varsayilan' => 'ayni', 'secenekler' => array( 'ayni' => __( 'Aynı içerik tipi', 'devxpe-theme' ), 'tumu' => __( 'Tüm içerik tipleri', 'devxpe-theme' ) ) ),
				),
			),
			'cpt_quote'    => array(
				'ad'      => __( 'Teklif Formu', 'devxpe-theme' ),
				'ikon'    => 'dashicons-feedback',
				'kapsam'  => $cpt_kapsam,
				'ayarlar' => array(
					'baslik'    => array( 'tip' => 'metin', 'etiket' => __( 'Başlık', 'devxpe-theme' ), 'varsayilan' => '' ),
					'ust_yazi'  => array( 'tip' => 'metin', 'etiket' => __( 'Üst yazı (eyebrow)', 'devxpe-theme' ), 'varsayilan' => '' ),
					'alt_metin' => array( 'tip' => 'metinuzun', 'etiket' => __( 'Alt metin', 'devxpe-theme' ), 'varsayilan' => '' ),
					'form_sec'  => array( 'tip' => 'secim', 'etiket' => __( 'Form', 'devxpe-theme' ), 'varsayilan' => 'quote', 'secenekler' => $formlar ),
				),
			),
		);

		/*
		 * ORTAK KÜTÜPHANE: Her widget tipi HER bağlamda (about, contact ve
		 * tüm CPT slug'ları) kullanılabilir. Kapsamlar tek yerden —
		 * kapsamlar() listesinden — türetilir; böylece yeni bir içerik tipi
		 * eklendiğinde 26 tanımı elle güncellemek gerekmez ve "bu tip şu
		 * bağlamda görünmez" ayrımı kalkar. Tek normalizasyon adımı:
		 *
		 * NOT: varsayilan_dizilim()/varsayilan_liste() kendi sabit
		 * listelerini kullanır; bu adımdan etkilenmez, sayfa varsayılanları
		 * (about/contact) aynen korunur.
		 */
		$ortak_kapsam = array_keys( self::kapsamlar() );
		foreach ( $kutup as $tip => $tanim ) {
			$kutup[ $tip ]['kapsam'] = $ortak_kapsam;
		}

		return $kutup;
	}

	/**
	 * Bir sayfa tipi için VARSAYILAN widget listesi.
	 *
	 * Şablonların (page-about.php / page-contact.php) mevcut düzenini
	 * birebir widget olarak üretir: manşet → sayfa içeriği → ikon/kart bloğu
	 * (+ iletişimde form). Değerler paneldeki mevcut ayarlardan gelir, böylece
	 * "zaten varmış gibi" görünür. Sayfa düzenleyicide liste BOŞSA önerilir;
	 * kullanıcı kaydedince kalıcı olur.
	 *
	 * @param string $tip about | contact.
	 * @return array Widget listesi ( tip + ayar ).
	 */
	public static function varsayilan_liste( $tip, $post_id = 0 ) {
		$tip     = sanitize_key( $tip );
		$post_id = (int) $post_id;

		if ( ! array_key_exists( $tip, self::kapsam() ) ) {
			return array();
		}

		/* Yeni widget üretici: tipin varsayılanları + verilen ayarlar. */
		$ekle = static function ( $t, array $ayar = array() ) {
			return array(
				'tip'  => $t,
				'ayar' => array_merge( self::varsayilan( $t ), $ayar ),
			);
		};

		/* Panel ayarı okuyucu (WP dışında boş döner). */
		$p = static function ( $k, $d = '' ) {
			return function_exists( 'devxpe_theme_get' ) ? (string) devxpe_theme_get( $k, $d ) : (string) $d;
		};

		/* Bir panel satır listesini "a|b|c|d" satırlarına çevirir. */
		$satirla = static function ( array $rows, array $alanlar ) {
			$out = array();

			foreach ( $rows as $r ) {
				if ( ! is_array( $r ) ) {
					continue;
				}

				$parcalar = array();
				$dolu     = false;

				foreach ( $alanlar as $alan ) {
					$v          = isset( $r[ $alan ] ) ? (string) $r[ $alan ] : '';
					$parcalar[] = $v;
					$dolu       = $dolu || ( '' !== trim( $v ) );
				}

				if ( $dolu ) {
					$out[] = implode( '|', $parcalar );
				}
			}

			return implode( "\n", $out );
		};

		$liste = array();

		if ( 'about' === $tip ) {
			$liste[] = $ekle( 'manset', array( 'ustbaslik' => __( 'Hakkımızda', 'devxpe-theme' ) ) );
			$liste[] = $ekle( 'icerik' );

			/* İstatistik satırları: sayfaya özel meta → panel → manşet rozetleri. */
			$sayfa_stats = ( $post_id && function_exists( 'get_post_meta' ) ) ? get_post_meta( $post_id, '_dxp_about_stats', true ) : array();
			$stats       = $satirla(
				( is_array( $sayfa_stats ) && $sayfa_stats ) ? $sayfa_stats : (array) ( function_exists( 'devxpe_theme_get' ) ? devxpe_theme_get( 'about_stats' ) : array() ),
				array( 'icon', 'title', 'text' )
			);

			if ( '' === $stats ) {
				$satirlar = array();

				for ( $i = 1; $i <= 4; $i++ ) {
					$deger = $p( 'hero_stat_' . $i . '_value' );

					if ( '' === $deger ) {
						continue;
					}

					$satirlar[] = $p( 'hero_stat_' . $i . '_icon', 'hammer' ) . '|' . $deger . '|' . $p( 'hero_stat_' . $i . '_label' );
				}

				$stats = implode( "\n", $satirlar );
			}

			if ( '' !== $stats ) {
				$dxp_kolon = $post_id ? absint( get_post_meta( $post_id, '_dxp_about_cols', true ) ) : 0;
				$liste[]   = $ekle( 'stats', array( 'satirlar' => $stats, 'kolon' => $dxp_kolon ? (string) $dxp_kolon : '3' ) );
			}

			return $liste;
		}

		/* İletişim: manşet → içerik → iletişim kartları → form. */
		$liste[] = $ekle( 'manset', array( 'ustbaslik' => __( 'İletişim', 'devxpe-theme' ) ) );
		$liste[] = $ekle( 'icerik' );

		$sayfa_kartlar = ( $post_id && function_exists( 'get_post_meta' ) ) ? get_post_meta( $post_id, '_dxp_contact_cards', true ) : array();
		$kartlar       = $satirla(
			( is_array( $sayfa_kartlar ) && $sayfa_kartlar ) ? $sayfa_kartlar : (array) ( function_exists( 'devxpe_theme_get' ) ? devxpe_theme_get( 'contact_cards' ) : array() ),
			array( 'icon', 'title', 'text', 'url' )
		);

		if ( '' === $kartlar ) {
			/* Şablondaki varsayılan kartlar (panel bilgisi varsa). */
			$tel = preg_replace( '/\s+/', '', $p( 'phone' ) );
			$wa  = preg_replace( '/[^0-9]/', '', $p( 'whatsapp' ) );
			$sat = array();

			if ( '' !== $p( 'phone' ) ) {
				$sat[] = 'phone|' . __( 'Ara', 'devxpe-theme' ) . '|' . $p( 'phone' ) . '|tel:' . $tel;
			}
			if ( '' !== $p( 'whatsapp' ) ) {
				$sat[] = 'message-circle|WhatsApp|' . $p( 'whatsapp' ) . '|https://wa.me/' . $wa;
			}
			if ( '' !== $p( 'email' ) ) {
				$sat[] = 'mail|' . __( 'E-posta', 'devxpe-theme' ) . '|' . $p( 'email' ) . '|mailto:' . $p( 'email' );
			}
			if ( '' !== $p( 'address' ) ) {
				$sat[] = 'map-pin|' . __( 'Hizmet bölgesi', 'devxpe-theme' ) . '|' . $p( 'address' ) . '|';
			}

			$kartlar = implode( "\n", $sat );
		}

		if ( '' !== $kartlar ) {
			$k_kolon = $post_id ? absint( get_post_meta( $post_id, '_dxp_contact_cols', true ) ) : 0;
			$liste[] = $ekle( 'iletisim_kart', array( 'satirlar' => $kartlar, 'kolon' => $k_kolon ? (string) $k_kolon : '1' ) );
		}

		/* Çalışma saatleri: panel bilgisinden tohumlanır (tek satır yeter). */
		$saatler = $p( 'working_hours' );

		if ( '' !== $saatler ) {
			$liste[] = $ekle( 'saatler', array( 'satirlar' => $saatler ) );
		}

		$liste[] = $ekle( 'form', array( 'form_sec' => $p( 'contact_form_choice', 'quote' ) ) );

		return $liste;
	}

	/**
	 * Sayfada eksik olan yerleşik blokları (ikonlu istatistikler, iletişim
	 * kartları) widget olarak döndürür.
	 *
	 * Düzenleyici, kayıtlı listesi olan bir sayfada bunları bir kez önerir;
	 * kaydedince kalıcı olur. Kullanıcı sonradan silerse tekrar eklenmez
	 * (`_dxp_pw_migrated` işareti).
	 *
	 * @param int    $post_id Sayfa kimliği.
	 * @param string $baglam  Bağlam (about | contact).
	 * @return array
	 */
	public static function eksik_yerlesik( $post_id, $baglam ) {
		$post_id = (int) $post_id;
		$baglam  = sanitize_key( $baglam );

		if ( ! $post_id || ! array_key_exists( $baglam, self::kapsam() ) ) {
			return array();
		}

		$tipler = array();

		foreach ( self::veri( $post_id ) as $w ) {
			if ( is_array( $w ) && ! empty( $w['tip'] ) ) {
				$tipler[] = sanitize_key( $w['tip'] );
			}
		}

		$liste = self::varsayilan_liste( $baglam, $post_id );
		$ekler = array();

		foreach ( $liste as $w ) {
			/* Yalnızca yerleşik görsel bloklar taşınır. */
			if ( ! in_array( $w['tip'], array( 'stats', 'ikon_kutulari', 'iletisim_kart' ), true ) ) {
				continue;
			}

			if ( in_array( $w['tip'], $tipler, true ) ) {
				continue;
			}

			/* stats ↔ ikon_kutulari birbirinin yerine geçer. */
			if ( 'stats' === $w['tip'] && in_array( 'ikon_kutulari', $tipler, true ) ) {
				continue;
			}

			if ( 'ikon_kutulari' === $w['tip'] && in_array( 'stats', $tipler, true ) ) {
				continue;
			}

			/* İçeriği boşsa taşımanın anlamı yok. */
			if ( empty( $w['ayar']['satirlar'] ) ) {
				continue;
			}

			$ekler[] = $w;
		}

		return $ekler;
	}

	/**
	 * Bir widget'ın ayar şemasını döndürür.
	 *
	 * @param string $tip Widget tipi.
	 * @return array
	 */
	public static function ayarlar( $tip ) {
		$kutup = self::kutuphane();
		$tip   = sanitize_key( $tip );

		return ( isset( $kutup[ $tip ]['ayarlar'] ) && is_array( $kutup[ $tip ]['ayarlar'] ) ) ? $kutup[ $tip ]['ayarlar'] : array();
	}

	/**
	 * Bir widget'ın varsayılan ayar dizisini döndürür.
	 *
	 * @param string $tip Widget tipi.
	 * @return array
	 */
	public static function varsayilan( $tip ) {
		$out = array();
		foreach ( self::ayarlar( $tip ) as $alan => $sema ) {
			$out[ $alan ] = isset( $sema['varsayilan'] ) ? $sema['varsayilan'] : '';
		}

		return $out;
	}

	/**
	 * Eski içerik meta alanlarını widget ayarlarına çevirir (yalnızca önizleme).
	 *
	 * `_dxp_page_widgets` boşken editörde gösterilir; meta'ya kendiliğinden
	 * YAZILMAZ. Kullanıcı kaydedince kalıcı olur. Eşleşen alan yoksa boş dizi
	 * döner (editör boş kalır).
	 *
	 * @param int $post_id İçerik kimliği.
	 * @return array Widget listesi ( tip + ayar ).
	 */
	public static function meta_aktar( $post_id ) {
		$post_id = (int) $post_id;
		$baglam  = self::baglam_bul( $post_id );

		if ( '' === $baglam || ! array_key_exists( $baglam, self::cpt_baglamlari() ) ) {
			return array();
		}

		$m = static function ( $key ) use ( $post_id ) {
			return get_post_meta( $post_id, $key, true );
		};

		/* Tekrarlayıcı dizi → "a|b|c" satırları. */
		$satirla = static function ( $rows, array $alanlar ) {
			$out = array();
			foreach ( (array) $rows as $r ) {
				if ( ! is_array( $r ) ) {
					continue;
				}
				$parcalar = array();
				$dolu     = false;
				foreach ( $alanlar as $alan ) {
					$v          = isset( $r[ $alan ] ) ? (string) $r[ $alan ] : '';
					$parcalar[] = $v;
					$dolu       = $dolu || ( '' !== trim( $v ) );
				}
				if ( $dolu ) {
					$out[] = implode( '|', $parcalar );
				}
			}

			return implode( "\n", $out );
		};

		$harita = array();
		$ekle   = static function ( $tip, $alan, $deger ) use ( &$harita ) {
			if ( '' !== trim( (string) $deger ) ) {
				$harita[ $tip ][ $alan ] = (string) $deger;
			}
		};

		/* Manşet. */
		$ekle( 'cpt_hero', 'rozet', $m( '_dxp_hero_badge' ) );
		$ekle( 'cpt_hero', 'lead', $m( '_dxp_hero_subtitle' ) );
		$ekle( 'cpt_hero', 'konum', $m( '_dxp_hero_location' ) );
		$ekle( 'cpt_hero', 'alan_adi', $m( '_dxp_area_name' ) );
		$ekle( 'cpt_hero', 'btn1_metin', $m( '_dxp_hero_btn_text' ) );
		$ekle( 'cpt_hero', 'btn1_link', $m( '_dxp_hero_btn_url' ) );
		$ekle( 'cpt_hero', 'btn2_metin', $m( '_dxp_hero_btn2_text' ) );
		$ekle( 'cpt_hero', 'btn2_link', $m( '_dxp_hero_btn2_url' ) );
		$ekle( 'cpt_hero', 'gorsel', $m( '_dxp_hero_image' ) );
		$ekle( 'cpt_hero', 'rozetler', $satirla( $m( '_dxp_hero_chips' ), array( 'icon', 'title', 'text' ) ) );

		/* Neler dahil. */
		$ekle( 'cpt_includes', 'baslik', $m( '_dxp_includes_title' ) );
		$ekle( 'cpt_includes', 'satirlar', $m( '_dxp_includes' ) );

		/* SSS / projeler / hizmetler / teklif başlıkları. */
		$ekle( 'cpt_faq', 'baslik', $m( '_dxp_faq_title' ) );
		$ekle( 'cpt_faq', 'satirlar', $satirla( $m( '_dxp_faq' ), array( 'title', 'text' ) ) );
		$ekle( 'cpt_projects', 'baslik', $m( '_dxp_projects_title' ) );
		$ekle( 'cpt_services', 'baslik', $m( '_dxp_services_title' ) );
		$ekle( 'cpt_services', 'adet', $m( '_dxp_services_limit' ) );
		$ekle( 'cpt_quote', 'baslik', $m( '_dxp_quote_title' ) );
		$ekle( 'cpt_quote', 'ust_yazi', $m( '_dxp_quote_eyebrow' ) );
		$ekle( 'cpt_quote', 'alt_metin', $m( '_dxp_quote_text' ) );

		if ( ! $harita ) {
			return array();
		}

		$liste = array();
		foreach ( self::varsayilan_dizilim( $baglam ) as $tip ) {
			$ayar = self::varsayilan( $tip );
			if ( isset( $harita[ $tip ] ) ) {
				$ayar = array_merge( $ayar, $harita[ $tip ] );
			}
			$liste[] = array(
				'tip'  => $tip,
				'ayar' => $ayar,
			);
		}

		return $liste;
	}

	/**
	 * Ham ayar dizisini tipine göre temizler (yalnızca şemadaki alanlar kalır).
	 *
	 * @param string $tip Widget tipi.
	 * @param mixed  $ham Ham ayar dizisi.
	 * @return array
	 */
	public static function temizle( $tip, $ham ) {
		$sema = self::ayarlar( $tip );
		if ( ! $sema ) {
			return array();
		}

		$ham = is_array( $ham ) ? $ham : array();
		$out = array();

		foreach ( $sema as $alan => $alan_sema ) {
			$val = array_key_exists( $alan, $ham ) ? $ham[ $alan ] : ( isset( $alan_sema['varsayilan'] ) ? $alan_sema['varsayilan'] : '' );
			$out[ $alan ] = self::temizle_alan( $alan, $alan_sema, $val );
		}

		return $out;
	}

	/**
	 * Tek bir alanı tanımına göre temizler.
	 *
	 * @param string $alan Alan anahtarı (link alanlarını ayırt etmek için).
	 * @param array  $sema Alan tanımı.
	 * @param mixed  $val  Ham değer.
	 * @return string
	 */
	private static function temizle_alan( $alan, $sema, $val ) {
		$tip = isset( $sema['tip'] ) ? $sema['tip'] : 'metin';
		$val = is_scalar( $val ) ? (string) $val : '';

		switch ( $tip ) {
			case 'metinuzun':
			case 'satirlar':
				/* satirlar: satır (\n) ve hücre (|) yapısı korunur; metinuzun ile aynı. */
				return wp_kses_post( $val );

			case 'gorsel':
				return esc_url_raw( $val );

			case 'renk':
				return self::temizle_renk( $val );

			case 'secim':
				$secenekler = ( isset( $sema['secenekler'] ) && is_array( $sema['secenekler'] ) ) ? $sema['secenekler'] : array();
				if ( array_key_exists( $val, $secenekler ) ) {
					return $val;
				}
				return isset( $sema['varsayilan'] ) ? (string) $sema['varsayilan'] : '';

			case 'onay':
				return ( '' !== $val && '0' !== $val && 'false' !== $val ) ? '1' : '';

			case 'sayi':
				return (string) absint( $val );

			case 'ikon':
			case 'metin':
			default:
				/* Link/URL alanları şema değiştirmeden esc_url_raw ile doğrulanır. */
				if ( preg_match( '/(^|_)(link|url)$/', (string) $alan ) ) {
					return esc_url_raw( $val );
				}
				return sanitize_text_field( $val );
		}
	}

	/**
	 * Renk değerini beyaz listeye göre temizler (hex / rgba / var()).
	 *
	 * @param string $val Ham renk.
	 * @return string
	 */
	private static function temizle_renk( $val ) {
		$val = trim( $val );
		if ( preg_match( '/^#[0-9a-fA-F]{3,8}$/', $val ) ) {
			return $val;
		}
		if ( preg_match( '/^rgba?\([0-9.,\s%]+\)$/', $val ) ) {
			return $val;
		}
		if ( preg_match( '/^var\(--[a-zA-Z0-9_-]+\)$/', $val ) ) {
			return $val;
		}

		return '';
	}

	/**
	 * Ham JSON dizesini güvenli widget listesi JSON'una çevirir.
	 *
	 * @param mixed $json Ham JSON dizesi.
	 * @return string Temiz JSON (boşsa '[]').
	 */
	public static function temizle_json( $json ) {
		if ( ! is_string( $json ) || '' === trim( $json ) ) {
			return '[]';
		}

		$data = json_decode( $json, true );
		if ( ! is_array( $data ) ) {
			return '[]';
		}

		$kutup = self::kutuphane();
		$out   = array();

		foreach ( $data as $widget ) {
			if ( ! is_array( $widget ) || empty( $widget['tip'] ) ) {
				continue;
			}
			$tip = sanitize_key( $widget['tip'] );
			if ( ! array_key_exists( $tip, $kutup ) ) {
				continue;
			}
			$kayit = array(
				'tip'  => $tip,
				'ayar' => self::temizle( $tip, isset( $widget['ayar'] ) ? $widget['ayar'] : array() ),
			);

			/* Yerleşim: yalnızca doluysa yazılır (eski kayıtlar bozulmaz). */
			$yer = self::yer_temizle( isset( $widget['yer'] ) ? $widget['yer'] : '' );
			if ( '' !== $yer ) {
				$kayit['yer'] = $yer;
			}

			$out[] = $kayit;
		}

		return wp_json_encode( $out );
	}

	/**
	 * İçerikte kayıtlı widget listesini (yalnızca meta) döndürür.
	 *
	 * cikti()'dan farklı olarak varsayılan dizilimi eklemez; boşsa array()
	 * döner. Tekil içerik şablonu (single.php) bu listeyi kendi yerleşimini
	 * (bant/ızgara) kurmak için kullanır.
	 *
	 * @param int $post_id İçerik kimliği.
	 * @return array
	 */
	public static function veri( $post_id ) {
		$post_id = (int) $post_id;
		if ( ! $post_id ) {
			return array();
		}

		$raw  = get_post_meta( $post_id, self::META_KEY, true );
		$data = ( is_string( $raw ) && '' !== trim( $raw ) ) ? json_decode( $raw, true ) : array();

		return is_array( $data ) ? $data : array();
	}

	/**
	 * Widget parçalarını kaydın düzen ayarına göre gruplar.
	 *
	 * Sayfa (cikti) ile CPT (single.php) çıktısı AYNI gruplamayı paylaşsın
	 * diye ortak render adımıdır. full düzende parçalar sırayla birleşir;
	 * nested düzende sol/sağ kolon yığınlarına ayrılır.
	 *
	 * @param int   $post_id  Kayıt kimliği (düzen meta'sı buradan okunur).
	 * @param array $parcalar array( array( 'html' => string, 'yer' => ''|'sol'|'sag'|'tam' ), ... )
	 * @return string
	 */
	public static function govde_sar( $post_id, array $parcalar ) {
		/* full: boş olmayan parçalar sırayla birleşir. */
		if ( 'nested' !== self::duzen( $post_id ) ) {
			$html = '';
			foreach ( $parcalar as $parca ) {
				$icerik = isset( $parca['html'] ) ? (string) $parca['html'] : '';
				if ( '' === trim( $icerik ) ) {
					continue;
				}
				$html .= $icerik;
			}

			return $html;
		}

		/* nested: sol/sağ sütunlar bağımsız yığınlar hâlinde akar. */
		$html   = '';
		$kuyruk = array( 'sol' => '', 'sag' => '' );

		foreach ( $parcalar as $parca ) {
			$icerik = isset( $parca['html'] ) ? (string) $parca['html'] : '';
			if ( '' === trim( $icerik ) ) {
				continue;
			}

			/* Boş/geçersiz yerleşim otomatik olarak sol kolona girer. */
			$yer = isset( $parca['yer'] ) ? self::yer_temizle( $parca['yer'] ) : '';

			/* Tam genişlik: açık satır kapanır, parça tek başına yazılır. */
			if ( 'tam' === $yer ) {
				$html  .= self::satir_html( $kuyruk['sol'], $kuyruk['sag'] );
				$kuyruk = array( 'sol' => '', 'sag' => '' );
				$html  .= $icerik;
				continue;
			}

			$kuyruk[ ( 'sag' === $yer ) ? 'sag' : 'sol' ] .= $icerik;
		}

		$html .= self::satir_html( $kuyruk['sol'], $kuyruk['sag'] );

		return $html;
	}

	/**
	 * Meta'daki widget'ları ön yüzde çizer.
	 *
	 * @param int $post_id Sayfa kimliği.
	 * @return string HTML.
	 */
	public static function cikti( $post_id ) {
		$post_id = (int) $post_id;
		if ( ! $post_id ) {
			return '';
		}

		$baglam = self::baglam_bul( $post_id );

		$data = self::veri( $post_id );

		/*
		 * Meta boşsa varsayılan dizilim render edilir. Bu dizilim sayfaya
		 * YAZILMAZ; yalnızca çıktı anında üretilir (kullanıcı kaydetmemiş
		 * olsa da meta dolu görünmez).
		 */
		if ( ! $data ) {
			foreach ( self::varsayilan_dizilim( $baglam ) as $tip ) {
				$data[] = array(
					'tip'  => $tip,
					'ayar' => self::varsayilan( $tip ),
				);
			}
		} else {
			/*
			 * Yerleşik blok (Hakkımızda istatistikleri / İletişim kartları)
			 * henüz widget olarak eklenmemişse render anında listenin SONUNA
			 * eklenir; düzenleyicideki sırayla aynı olsun (panel = ön yüz).
			 */
			$data = array_merge( $data, self::eksik_yerlesik( $post_id, $baglam ) );
		}

		/*
		 * Her widget'ı çiz ve yerleşimiyle birlikte ortak gruplamaya ver.
		 * Gruplama (nested/full, boş widget atlama) tek yerde yapılır.
		 */
		$parcalar = array();
		foreach ( $data as $widget ) {
			$parcalar[] = array(
				'html' => (string) self::ciz( $widget ),
				'yer'  => self::yer( $widget ),
			);
		}

		$html = self::govde_sar( $post_id, $parcalar );

		if ( '' === $html ) {
			return '';
		}

		$sinif = 'dxp-page-widgets';

		/* 2 sütun (nested) düzeni seçildiyse sarmalayıcıya sınıf eklenir. */
		if ( 'nested' === self::duzen( $post_id ) ) {
			$sinif .= ' dxp-page-widgets--nested';
		}

		return '<div class="' . esc_attr( $sinif ) . '">' . $html . '</div>';
	}

	/**
	 * Nested düzende bir kolon satırını üretir.
	 *
	 * Sol ve sağ sütunlar bağımsız yığınlardır; böylece satır yükseklikleri
	 * eşitlenmez ve kısa kolonda boşluk oluşmaz. Bir taraf boşsa yalnızca
	 * diğeri yazılır ve tek kolon tam genişliği kullanır.
	 *
	 * @param string $sol Sol kolon HTML'i.
	 * @param string $sag Sağ kolon HTML'i.
	 * @return string
	 */
	private static function satir_html( $sol, $sag ) {
		if ( '' === $sol && '' === $sag ) {
			return '';
		}

		return '<div class="dxp-pw-satir">'
			. ( '' !== $sol ? '<div class="dxp-pw-kolon">' . $sol . '</div>' : '' )
			. ( '' !== $sag ? '<div class="dxp-pw-kolon">' . $sag . '</div>' : '' )
			. '</div>';
	}

	/**
	 * Tek bir widget'ı ön yüzde çizer.
	 *
	 * Tüm tipler burada ele alınır; her widget kendi sarmalayıcısını
	 * (dxp-w dxp-w-<tip>) üretir ve veri yoksa boş string döner.
	 *
	 * @param array $widget Widget kaydı ( tip + ayar ).
	 * @return string HTML.
	 */
	public static function ciz( $widget ) {
		if ( ! is_array( $widget ) || empty( $widget['tip'] ) ) {
			return '';
		}

		$tip  = sanitize_key( $widget['tip'] );
		$ayar = ( isset( $widget['ayar'] ) && is_array( $widget['ayar'] ) ) ? $widget['ayar'] : array();

		switch ( $tip ) {
			case 'baslik':
				return self::ciz_baslik( $ayar );

			case 'manset':
				return self::ciz_manset( $ayar );

			case 'metin':
				return self::ciz_metin( $ayar );

			case 'icerik':
				return self::ciz_icerik( $ayar );

			case 'ayrac':
				return self::ciz_ayrac( $ayar );

			case 'gorsel':
				return self::ciz_gorsel( $ayar );

			case 'buton':
				return self::ciz_buton( $ayar );

			case 'ikon_kutu':
				return self::ciz_ikon_kutu( $ayar );

			case 'ikon_kutulari':
				return self::ciz_ikon_kutulari( $ayar );

			case 'stats':
				return self::ciz_stats( $ayar );

			case 'ekip':
				return self::ciz_ekip( $ayar );

			case 'liste':
				return self::ciz_liste( $ayar );

			case 'alinti':
				return self::ciz_alinti( $ayar );

			case 'harita':
				return self::ciz_harita( $ayar );

			case 'saatler':
				return self::ciz_saatler( $ayar );

			case 'iletisim_kart':
				return self::ciz_iletisim_kart( $ayar );

			case 'form':
				return self::ciz_form( $ayar );

			case 'sosyal':
				return self::ciz_sosyal( $ayar );

			/*
			 * İçerik tipi (CPT) widget'ları — ARC düzeni. Her biri mevcut
			 * single.php bölümünün HTML'ini üretir; veri yoksa boş döner.
			 */
			case 'cpt_hero':
				return self::ciz_cpt_hero( $ayar );

			case 'cpt_includes':
				return self::ciz_cpt_includes( $ayar );

			case 'cpt_content':
				return self::ciz_cpt_content( $ayar );

			case 'cpt_projects':
				return self::ciz_cpt_projects( $ayar );

			case 'cpt_services':
				return self::ciz_cpt_services( $ayar );

			case 'cpt_faq':
				return self::ciz_cpt_faq( $ayar );

			case 'cpt_related':
				return self::ciz_cpt_related( $ayar );

			case 'cpt_quote':
				return self::ciz_cpt_quote( $ayar );
		}

		return '';
	}

	/**
	 * Başlık widget'ı.
	 *
	 * @param array $ayar Ayarlar.
	 * @return string
	 */
	private static function ciz_baslik( $ayar ) {
		$metin = isset( $ayar['metin'] ) ? trim( (string) $ayar['metin'] ) : '';
		if ( '' === $metin ) {
			return '';
		}

		$seviye = isset( $ayar['seviye'] ) ? $ayar['seviye'] : 'h2';
		$seviye = in_array( $seviye, array( 'h1', 'h2', 'h3' ), true ) ? $seviye : 'h2';
		$hiza   = isset( $ayar['hiza'] ) ? $ayar['hiza'] : 'sol';

		return '<div class="dxp-w dxp-w-baslik ' . esc_attr( self::hiza_class( $hiza ) ) . '">'
			. '<' . $seviye . ' class="dxp-pw-baslik">'
			. esc_html( $metin )
			. '</' . $seviye . '></div>';
	}

	/**
	 * Metin widget'ı.
	 *
	 * @param array $ayar Ayarlar.
	 * @return string
	 */
	private static function ciz_metin( $ayar ) {
		$icerik = isset( $ayar['icerik'] ) ? (string) $ayar['icerik'] : '';
		$icerik = trim( $icerik );
		if ( '' === $icerik ) {
			return '';
		}

		return '<div class="dxp-w dxp-w-metin dxp-pw-metin ' . esc_attr( self::hiza_class( isset( $ayar['hiza'] ) ? $ayar['hiza'] : 'sol' ) ) . '">'
			. wp_kses_post( $ayar['icerik'] )
			. '</div>';
	}

	/**
	 * Ayraç widget'ı.
	 *
	 * @param array $ayar Ayarlar.
	 * @return string
	 */
	private static function ciz_ayrac( $ayar ) {
		$stil      = isset( $ayar['stil'] ) ? $ayar['stil'] : 'cizgi';
		$yukseklik = isset( $ayar['yukseklik'] ) && '' !== $ayar['yukseklik'] ? absint( $ayar['yukseklik'] ) : 24;

		if ( 'nokta' === $stil ) {
			$ic = '<div class="dxp-pw-ayrac dxp-pw-ayrac--nokta" aria-hidden="true"><span></span><span></span><span></span></div>';
		} elseif ( 'bosluk' === $stil ) {
			$ic = '<div class="dxp-pw-ayrac dxp-pw-ayrac--bosluk" style="height:' . absint( $yukseklik ) . 'px" aria-hidden="true"></div>';
		} else {
			$ic = '<hr class="dxp-pw-ayrac dxp-pw-ayrac--cizgi" />';
		}

		return '<div class="dxp-w dxp-w-ayrac">' . $ic . '</div>';
	}

	/**
	 * Görsel widget'ı.
	 *
	 * @param array $ayar Ayarlar.
	 * @return string
	 */
	private static function ciz_gorsel( $ayar ) {
		$url = isset( $ayar['gorsel'] ) ? trim( (string) $ayar['gorsel'] ) : '';
		if ( '' === $url ) {
			return '';
		}

		$alt    = isset( $ayar['alt'] ) ? (string) $ayar['alt'] : '';
		$cercek = ( isset( $ayar['cerceve'] ) && '1' === (string) $ayar['cerceve'] );
		$hiza   = isset( $ayar['hiza'] ) ? $ayar['hiza'] : 'sol';

		/* Genişlik yalnızca sayı + güvenli birim ise uygulanır. */
		$stil = '';
		$gen  = isset( $ayar['genislik'] ) ? trim( (string) $ayar['genislik'] ) : '';
		if ( '' !== $gen && preg_match( '/^\d+(\.\d+)?(%|px|rem|em|vw|vh)?$/', $gen ) ) {
			$stil = ' style="width:' . esc_attr( $gen ) . '"';
		}

		$sinif = 'dxp-w dxp-w-gorsel ' . self::hiza_class( $hiza ) . ( $cercek ? ' dxp-w-gorsel--cerceve' : '' );

		return '<div class="' . esc_attr( $sinif ) . '">'
			. '<img src="' . esc_url( $url ) . '" alt="' . esc_attr( $alt ) . '"' . $stil . ' loading="lazy" decoding="async" />'
			. '</div>';
	}

	/**
	 * Buton widget'ı.
	 *
	 * @param array $ayar Ayarlar.
	 * @return string
	 */
	private static function ciz_buton( $ayar ) {
		$metin = isset( $ayar['metin'] ) ? trim( (string) $ayar['metin'] ) : '';
		if ( '' === $metin ) {
			return '';
		}

		$link = isset( $ayar['link'] ) ? trim( (string) $ayar['link'] ) : '';
		$stil = isset( $ayar['stil'] ) ? $ayar['stil'] : 'birincil';
		$hiza = isset( $ayar['hiza'] ) ? $ayar['hiza'] : 'sol';

		$siniflar = array(
			'birincil' => 'dxp-btn--primary',
			'ikincil'  => 'dxp-btn--outline',
			'kenar'    => 'dxp-w-btn--kenar',
		);
		$buton = 'dxp-btn ' . ( isset( $siniflar[ $stil ] ) ? $siniflar[ $stil ] : $siniflar['birincil'] );

		if ( '' !== $link ) {
			$ic = '<a class="' . esc_attr( $buton ) . '" href="' . esc_url( $link ) . '">' . esc_html( $metin ) . '</a>';
		} else {
			$ic = '<span class="' . esc_attr( $buton ) . '">' . esc_html( $metin ) . '</span>';
		}

		return '<div class="dxp-w dxp-w-buton ' . esc_attr( self::hiza_class( $hiza ) ) . '">' . $ic . '</div>';
	}

	/**
	 * İkon kutusu widget'ı.
	 *
	 * @param array $ayar Ayarlar.
	 * @return string
	 */
	private static function ciz_ikon_kutu( $ayar ) {
		$ikon   = isset( $ayar['ikon'] ) ? trim( (string) $ayar['ikon'] ) : '';
		$baslik = isset( $ayar['baslik'] ) ? trim( (string) $ayar['baslik'] ) : '';
		$metin  = isset( $ayar['metin'] ) ? trim( (string) $ayar['metin'] ) : '';

		if ( '' === $ikon && '' === $baslik && '' === $metin ) {
			return '';
		}

		$hiza = isset( $ayar['hiza'] ) ? $ayar['hiza'] : 'sol';

		return '<div class="dxp-w dxp-w-ikon-kutu ' . esc_attr( self::hiza_class( $hiza ) ) . '">'
			. ( '' !== $ikon ? '<span class="dxp-w-ikon-ic">' . devxpe_lucide( $ikon ) . '</span>' : '' )
			. ( '' !== $baslik ? '<h2 class="dxp-w-ikon-baslik">' . esc_html( $baslik ) . '</h2>' : '' )
			. ( '' !== $metin ? '<div class="dxp-w-ikon-metin">' . wp_kses_post( $ayar['metin'] ) . '</div>' : '' )
			. '</div>';
	}

	/**
	 * Sayfa manşeti (hero) widget'ı.
	 *
	 * Şablonlardaki manşetle aynı sınıfları kullanır (dxp-eyebrow,
	 * dxp-page-title, dxp-page-lead) → görünüm birebir aynı olur.
	 *
	 * @param array $ayar Ayarlar.
	 * @return string
	 */
	private static function ciz_manset( $ayar ) {
		$ust   = isset( $ayar['ustbaslik'] ) ? trim( (string) $ayar['ustbaslik'] ) : '';
		$bas   = isset( $ayar['baslik'] ) ? trim( (string) $ayar['baslik'] ) : '';
		$metin = isset( $ayar['metin'] ) ? trim( (string) $ayar['metin'] ) : '';

		/* Şablon davranışı: başlık boşsa sayfa adı kullanılır. */
		if ( '' === $bas && function_exists( 'get_the_title' ) ) {
			$bas = trim( (string) get_the_title() );
		}

		if ( '' === $ust && '' === $bas && '' === $metin ) {
			return '';
		}

		$seviye = isset( $ayar['seviye'] ) ? $ayar['seviye'] : 'h1';
		$seviye = in_array( $seviye, array( 'h1', 'h2', 'h3' ), true ) ? $seviye : 'h1';
		$hiza   = isset( $ayar['hiza'] ) ? $ayar['hiza'] : 'sol';

		$html = '<div class="dxp-w dxp-w-manset ' . esc_attr( self::hiza_class( $hiza ) ) . '">';

		if ( '' !== $ust ) {
			$html .= '<div class="dxp-eyebrow">' . esc_html( $ust ) . '</div>';
		}
		if ( '' !== $bas ) {
			$html .= '<' . $seviye . ' class="dxp-page-title dxp-page-title--xl">' . esc_html( $bas ) . '</' . $seviye . '>';
		}
		if ( '' !== $metin ) {
			$html .= '<p class="dxp-page-lead">' . esc_html( $metin ) . '</p>';
		}

		return $html . '</div>';
	}

	/**
	 * Sayfa içeriği (the_content) widget'ı.
	 *
	 * @param array $ayar Ayarlar.
	 * @return string
	 */
	private static function ciz_icerik( $ayar ) {
		$id = function_exists( 'get_the_ID' ) ? (int) get_the_ID() : 0;

		if ( ! $id ) {
			return '';
		}

		$icerik = (string) get_post_field( 'post_content', $id );

		if ( '' === trim( $icerik ) ) {
			return '';
		}

		$baslik = isset( $ayar['baslik'] ) ? trim( (string) $ayar['baslik'] ) : '';
		$seviye = isset( $ayar['seviye'] ) ? $ayar['seviye'] : 'h2';
		$seviye = in_array( $seviye, array( 'h1', 'h2', 'h3' ), true ) ? $seviye : 'h2';
		$hiza   = isset( $ayar['hiza'] ) ? $ayar['hiza'] : 'sol';

		$html = '<div class="dxp-w dxp-w-icerik ' . esc_attr( self::hiza_class( $hiza ) ) . '">';

		if ( '' !== $baslik ) {
			$html .= '<' . $seviye . ' class="dxp-w-title">' . esc_html( $baslik ) . '</' . $seviye . '>';
		}

		/* the_content süzgeçleri güvenilirdir (WP çekirdek + eklentiler). */
		$html .= '<div class="dxp-page-content">' . apply_filters( 'the_content', $icerik ) . '</div>';

		return $html . '</div>';
	}

	/**
	 * Çoklu ikon kutuları widget'ı (grid).
	 *
	 * Satır biçimi: ikon|başlık|metin — bkz. ciz_ikon_kutu (tekli sürüm).
	 *
	 * @param array $ayar Ayarlar.
	 * @return string
	 */
	private static function ciz_ikon_kutulari( $ayar ) {
		$satirlar = self::satirlar( isset( $ayar['satirlar'] ) ? $ayar['satirlar'] : '' );

		if ( ! $satirlar ) {
			return '';
		}

		$baslik = isset( $ayar['baslik'] ) ? trim( (string) $ayar['baslik'] ) : '';
		$kolon  = self::kolon( isset( $ayar['kolon'] ) ? $ayar['kolon'] : 0, 3 );
		$hiza   = isset( $ayar['hiza'] ) ? $ayar['hiza'] : 'sol';
		$sinif  = 'dxp-w-ikon-kutu ' . self::hiza_class( $hiza );

		$kutular = '';

		foreach ( $satirlar as $satir ) {
			$ikon   = isset( $satir[0] ) ? trim( (string) $satir[0] ) : '';
			$b      = isset( $satir[1] ) ? trim( (string) $satir[1] ) : '';
			$m      = isset( $satir[2] ) ? trim( (string) $satir[2] ) : '';

			if ( '' === $b && '' === $m ) {
				continue;
			}

			$kutular .= '<div class="' . esc_attr( $sinif ) . '">'
				. ( '' !== $ikon ? '<span class="dxp-w-ikon-ic">' . devxpe_lucide( $ikon ) . '</span>' : '' )
				. ( '' !== $b ? '<h3 class="dxp-w-ikon-baslik">' . esc_html( $b ) . '</h3>' : '' )
				. ( '' !== $m ? '<div class="dxp-w-ikon-metin">' . esc_html( $m ) . '</div>' : '' )
				. '</div>';
		}

		if ( '' === $kutular ) {
			return '';
		}

		return '<div class="dxp-w dxp-w-ikon-kutulari ' . esc_attr( self::hiza_class( $hiza ) ) . '">'
			. ( '' !== $baslik ? '<h2 class="dxp-w-title">' . esc_html( $baslik ) . '</h2>' : '' )
			. '<div class="dxp-w-grid" style="--dxp-w-cols:' . absint( $kolon ) . '">' . $kutular . '</div>'
			. '</div>';
	}

	/**
	 * İstatistik kartları widget'ı.
	 *
	 * @param array $ayar Ayarlar.
	 * @return string
	 */
	private static function ciz_stats( $ayar ) {
		$satirlar = self::satirlar( isset( $ayar['satirlar'] ) ? $ayar['satirlar'] : '' );
		if ( ! $satirlar ) {
			return '';
		}

		$baslik = isset( $ayar['baslik'] ) ? trim( (string) $ayar['baslik'] ) : '';
		$kolon  = self::kolon( isset( $ayar['kolon'] ) ? $ayar['kolon'] : 0, 3 );

		$kartlar = '';
		foreach ( $satirlar as $satir ) {
			$ikon   = isset( $satir[0] ) ? $satir[0] : '';
			$deger  = isset( $satir[1] ) ? $satir[1] : '';
			$etiket = isset( $satir[2] ) ? $satir[2] : '';
			if ( '' === $deger && '' === $etiket ) {
				continue;
			}
			$kartlar .= '<div class="dxp-stat-card">'
				. ( '' !== $ikon ? devxpe_lucide( $ikon ) : '' )
				. '<div class="dxp-stat-value">' . esc_html( $deger ) . '</div>'
				. ( '' !== $etiket ? '<div class="dxp-stat-label">' . esc_html( $etiket ) . '</div>' : '' )
				. '</div>';
		}

		if ( '' === $kartlar ) {
			return '';
		}

		return '<div class="dxp-w dxp-w-stats">'
			. ( '' !== $baslik ? '<h2 class="dxp-w-title">' . esc_html( $baslik ) . '</h2>' : '' )
			. '<div class="dxp-stat-grid dxp-w-grid" style="--dxp-w-cols:' . absint( $kolon ) . '">' . $kartlar . '</div>'
			. '</div>';
	}

	/**
	 * Ekip üyeleri widget'ı.
	 *
	 * @param array $ayar Ayarlar.
	 * @return string
	 */
	private static function ciz_ekip( $ayar ) {
		$satirlar = self::satirlar( isset( $ayar['satirlar'] ) ? $ayar['satirlar'] : '' );
		if ( ! $satirlar ) {
			return '';
		}

		$baslik = isset( $ayar['baslik'] ) ? trim( (string) $ayar['baslik'] ) : '';
		$kolon  = self::kolon( isset( $ayar['kolon'] ) ? $ayar['kolon'] : 0, 3 );

		$kartlar = '';
		foreach ( $satirlar as $satir ) {
			$foto = isset( $satir[0] ) ? $satir[0] : '';
			$ad   = isset( $satir[1] ) ? $satir[1] : '';
			$unv  = isset( $satir[2] ) ? $satir[2] : '';
			$acik = isset( $satir[3] ) ? $satir[3] : '';
			if ( '' === $ad && '' === $unv && '' === $acik && '' === $foto ) {
				continue;
			}

			if ( '' !== $foto ) {
				$gorsel = '<img class="dxp-w-ekip-foto" src="' . esc_url( $foto ) . '" alt="' . esc_attr( $ad ) . '" loading="lazy" decoding="async" />';
			} else {
				$gorsel = '<span class="dxp-w-ekip-foto dxp-w-ekip-foto--bos">' . devxpe_lucide( 'users' ) . '</span>';
			}

			$kartlar .= '<article class="dxp-w-ekip-card">'
				. $gorsel
				. ( '' !== $ad ? '<h3 class="dxp-w-ekip-ad">' . esc_html( $ad ) . '</h3>' : '' )
				. ( '' !== $unv ? '<div class="dxp-w-ekip-unvan">' . esc_html( $unv ) . '</div>' : '' )
				. ( '' !== $acik ? '<p class="dxp-w-ekip-aciklama">' . esc_html( $acik ) . '</p>' : '' )
				. '</article>';
		}

		if ( '' === $kartlar ) {
			return '';
		}

		return '<div class="dxp-w dxp-w-ekip">'
			. ( '' !== $baslik ? '<h2 class="dxp-w-title">' . esc_html( $baslik ) . '</h2>' : '' )
			. '<div class="dxp-w-grid" style="--dxp-w-cols:' . absint( $kolon ) . '">' . $kartlar . '</div>'
			. '</div>';
	}

	/**
	 * Madde listesi widget'ı.
	 *
	 * @param array $ayar Ayarlar.
	 * @return string
	 */
	private static function ciz_liste( $ayar ) {
		$satirlar = self::metin_satirlari( isset( $ayar['satirlar'] ) ? $ayar['satirlar'] : '' );
		if ( ! $satirlar ) {
			return '';
		}

		$baslik = isset( $ayar['baslik'] ) ? trim( (string) $ayar['baslik'] ) : '';
		$ikon   = isset( $ayar['ikon'] ) ? $ayar['ikon'] : 'onayli';

		$maddeler = '';
		foreach ( $satirlar as $metin ) {
			if ( 'onayli' === $ikon ) {
				$isaret = '<span class="dxp-w-li-ic">' . devxpe_lucide( 'check' ) . '</span>';
			} elseif ( 'nokta' === $ikon ) {
				$isaret = '<span class="dxp-w-li-dot" aria-hidden="true"></span>';
			} else {
				$isaret = '';
			}
			$maddeler .= '<li>' . $isaret . '<span>' . esc_html( $metin ) . '</span></li>';
		}

		return '<div class="dxp-w dxp-w-liste">'
			. ( '' !== $baslik ? '<h2 class="dxp-w-title">' . esc_html( $baslik ) . '</h2>' : '' )
			. '<ul class="dxp-w-liste-items">' . $maddeler . '</ul>'
			. '</div>';
	}

	/**
	 * Alıntı widget'ı.
	 *
	 * @param array $ayar Ayarlar.
	 * @return string
	 */
	private static function ciz_alinti( $ayar ) {
		$metin = isset( $ayar['metin'] ) ? trim( (string) $ayar['metin'] ) : '';
		if ( '' === $metin ) {
			return '';
		}

		$kaynak = isset( $ayar['kaynak'] ) ? trim( (string) $ayar['kaynak'] ) : '';
		$avatar = isset( $ayar['avatar'] ) ? trim( (string) $ayar['avatar'] ) : '';
		$hiza   = isset( $ayar['hiza'] ) ? $ayar['hiza'] : 'sol';

		$av = ( '' !== $avatar )
			? '<img class="dxp-w-alinti-avatar" src="' . esc_url( $avatar ) . '" alt="' . esc_attr( $kaynak ) . '" loading="lazy" decoding="async" />'
			: '';

		return '<figure class="dxp-w dxp-w-alinti ' . esc_attr( self::hiza_class( $hiza ) ) . '">'
			. $av
			. '<blockquote class="dxp-w-alinti-metin">' . wp_kses_post( $ayar['metin'] ) . '</blockquote>'
			. ( '' !== $kaynak ? '<figcaption class="dxp-w-alinti-kaynak">' . esc_html( $kaynak ) . '</figcaption>' : '' )
			. '</figure>';
	}

	/**
	 * Harita widget'ı (Google Maps embed — API anahtarı gerektirmez).
	 *
	 * @param array $ayar Ayarlar.
	 * @return string
	 */
	private static function ciz_harita( $ayar ) {
		$adres = isset( $ayar['adres'] ) ? trim( wp_strip_all_tags( (string) $ayar['adres'] ) ) : '';

		/* Alan boşsa paneldeki adres kullanılır: harita "direkt" görünsün. */
		if ( '' === $adres && function_exists( 'devxpe_theme_get' ) ) {
			$adres = trim( (string) devxpe_theme_get( 'address' ) );
		}

		if ( '' === $adres ) {
			return '';
		}

		$baslik = isset( $ayar['baslik'] ) ? trim( (string) $ayar['baslik'] ) : '';

		$yukseklik = isset( $ayar['yukseklik'] ) && '' !== $ayar['yukseklik'] ? absint( $ayar['yukseklik'] ) : 320;
		if ( $yukseklik < 120 || $yukseklik > 1200 ) {
			$yukseklik = 320;
		}

		$zoom = isset( $ayar['zoom'] ) && '' !== $ayar['zoom'] ? absint( $ayar['zoom'] ) : 14;
		if ( $zoom < 1 || $zoom > 21 ) {
			$zoom = 14;
		}

		$src   = 'https://www.google.com/maps?q=' . rawurlencode( $adres ) . '&z=' . $zoom . '&output=embed';
		$title = ( '' !== $baslik ) ? $baslik : __( 'Harita', 'devxpe-theme' );

		return '<div class="dxp-w dxp-w-harita">'
			. ( '' !== $baslik ? '<h2 class="dxp-w-title">' . esc_html( $baslik ) . '</h2>' : '' )
			. '<div class="dxp-w-harita-kutu" style="height:' . absint( $yukseklik ) . 'px">'
			. '<iframe src="' . esc_url( $src ) . '" title="' . esc_attr( $title ) . '" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe>'
			. '</div></div>';
	}

	/**
	 * Çalışma saatleri tablosu widget'ı.
	 *
	 * @param array $ayar Ayarlar.
	 * @return string
	 */
	private static function ciz_saatler( $ayar ) {
		$satirlar = self::satirlar( isset( $ayar['satirlar'] ) ? $ayar['satirlar'] : '' );
		if ( ! $satirlar ) {
			return '';
		}

		$baslik = isset( $ayar['baslik'] ) ? trim( (string) $ayar['baslik'] ) : '';
		$not    = isset( $ayar['not'] ) ? trim( (string) $ayar['not'] ) : '';

		$tr = '';
		foreach ( $satirlar as $satir ) {
			$gun  = isset( $satir[0] ) ? $satir[0] : '';
			$saat = isset( $satir[1] ) ? $satir[1] : '';
			if ( '' === $gun && '' === $saat ) {
				continue;
			}

			/* Saat sütunu boşsa satır tek sütun olarak yayılır (tek değerli bilgi). */
			if ( '' === $saat ) {
				$tr .= '<tr><td colspan="2" class="dxp-w-saatler-tek">' . esc_html( $gun ) . '</td></tr>';
				continue;
			}

			$tr .= '<tr><th scope="row">' . esc_html( $gun ) . '</th><td>' . esc_html( $saat ) . '</td></tr>';
		}

		if ( '' === $tr ) {
			return '';
		}

		return '<div class="dxp-w dxp-w-saatler">'
			. ( '' !== $baslik ? '<h2 class="dxp-w-title">' . esc_html( $baslik ) . '</h2>' : '' )
			. '<table class="dxp-w-saatler-tablo"><tbody>' . $tr . '</tbody></table>'
			. ( '' !== $not ? '<p class="dxp-w-saatler-not">' . esc_html( $not ) . '</p>' : '' )
			. '</div>';
	}

	/**
	 * İletişim kartları widget'ı (tema kart sınıflarını yeniden kullanır).
	 *
	 * @param array $ayar Ayarlar.
	 * @return string
	 */
	private static function ciz_iletisim_kart( $ayar ) {
		$satirlar = self::satirlar( isset( $ayar['satirlar'] ) ? $ayar['satirlar'] : '' );
		if ( ! $satirlar ) {
			return '';
		}

		$baslik = isset( $ayar['baslik'] ) ? trim( (string) $ayar['baslik'] ) : '';
		$kolon  = self::kolon( isset( $ayar['kolon'] ) ? $ayar['kolon'] : 0, 2 );

		$li = '';
		foreach ( $satirlar as $satir ) {
			$ikon  = isset( $satir[0] ) ? $satir[0] : '';
			$b     = isset( $satir[1] ) ? $satir[1] : '';
			$deger = isset( $satir[2] ) ? $satir[2] : '';
			$link  = isset( $satir[3] ) ? $satir[3] : '';
			if ( '' === $b && '' === $deger ) {
				continue;
			}

			$kart = '<span class="dxp-contact-card">'
				. ( '' !== $ikon ? '<span class="dxp-contact-ic">' . devxpe_lucide( $ikon ) . '</span>' : '' )
				. '<span class="dxp-contact-body">'
				. ( '' !== $b ? '<span class="dxp-contact-label">' . esc_html( $b ) . '</span>' : '' )
				. ( '' !== $deger ? '<span class="dxp-contact-value">' . esc_html( $deger ) . '</span>' : '' )
				. '</span></span>';

			$li .= '<li>' . ( ( '' !== $link ) ? '<a href="' . esc_url( $link ) . '">' . $kart . '</a>' : '<span>' . $kart . '</span>' ) . '</li>';
		}

		if ( '' === $li ) {
			return '';
		}

		return '<div class="dxp-w dxp-w-iletisim-kart">'
			. ( '' !== $baslik ? '<h2 class="dxp-w-title">' . esc_html( $baslik ) . '</h2>' : '' )
			. '<ul class="dxp-contact-list dxp-w-grid" style="--dxp-w-cols:' . absint( $kolon ) . '">' . $li . '</ul>'
			. '</div>';
	}

	/**
	 * Form widget'ı — mevcut form seçim çıktısını yakalar.
	 *
	 * @param array $ayar Ayarlar.
	 * @return string
	 */
	private static function ciz_form( $ayar ) {
		if ( ! function_exists( 'devxpe_render_form_choice' ) ) {
			return '';
		}

		$sec    = isset( $ayar['form_sec'] ) ? (string) $ayar['form_sec'] : '';
		$stil   = isset( $ayar['stil'] ) ? $ayar['stil'] : 'kart';
		$baslik = isset( $ayar['baslik'] ) ? trim( (string) $ayar['baslik'] ) : '';

		ob_start();
		/*
		 * $bare = true → yalnızca FORM GÖVDESİ çizilir.
		 */
		devxpe_render_form_choice( $sec, true );
		$form = (string) ob_get_clean();

		/* Form gerçekten çizilemediyse boş kutu bırakma. */
		if ( '' === trim( $form ) ) {
			return '';
		}

		return '<div class="dxp-w dxp-w-form' . ( 'duz' === $stil ? ' dxp-w-form--duz' : ' dxp-w-form--kart' ) . '">'
			. ( '' !== $baslik ? '<h2 class="dxp-w-title">' . esc_html( $baslik ) . '</h2>' : '' )
			. '<div class="dxp-w-form-body">' . $form . '</div>'
			. '</div>';
	}

	/**
	 * Sosyal medya linkleri widget'ı.
	 *
	 * @param array $ayar Ayarlar.
	 * @return string
	 */
	private static function ciz_sosyal( $ayar ) {
		$satirlar = self::satirlar( isset( $ayar['satirlar'] ) ? $ayar['satirlar'] : '' );
		if ( ! $satirlar ) {
			return '';
		}

		$baslik = isset( $ayar['baslik'] ) ? trim( (string) $ayar['baslik'] ) : '';
		$hiza   = isset( $ayar['hiza'] ) ? $ayar['hiza'] : 'sol';

		$li = '';
		foreach ( $satirlar as $satir ) {
			$platform = isset( $satir[0] ) ? $satir[0] : '';
			$url      = isset( $satir[1] ) ? $satir[1] : '';
			if ( '' === $url ) {
				continue;
			}

			$ic = ( '' !== $platform ) ? '<span class="dxp-w-sosyal-ic">' . devxpe_lucide( self::sosyal_ikon( $platform ) ) . '</span>' : '';

			$li .= '<li><a href="' . esc_url( $url ) . '" target="_blank" rel="noopener noreferrer">'
				. $ic
				. '<span>' . esc_html( '' !== $platform ? $platform : $url ) . '</span>'
				. '</a></li>';
		}

		if ( '' === $li ) {
			return '';
		}

		return '<div class="dxp-w dxp-w-sosyal ' . esc_attr( self::hiza_class( $hiza ) ) . '">'
			. ( '' !== $baslik ? '<h2 class="dxp-w-title">' . esc_html( $baslik ) . '</h2>' : '' )
			. '<ul class="dxp-w-sosyal-list">' . $li . '</ul>'
			. '</div>';
	}

	/* ── İçerik tipi (CPT) widget'ları ─────────────────────────── */

	/**
	 * Manşet widget'ındaki "Bölge adı (kısa)" ayarını döndürür.
	 *
	 * @param int $post_id İçerik kimliği.
	 * @return string
	 */
	private static function hero_alan_adi( $post_id ) {
		foreach ( self::veri( $post_id ) as $w ) {
			if ( is_array( $w ) && isset( $w['tip'] ) && 'cpt_hero' === $w['tip'] && isset( $w['ayar']['alan_adi'] ) ) {
				return trim( (string) $w['ayar']['alan_adi'] );
			}
		}

		return '';
	}

	/**
	 * Çizim anındaki CPT bağlamını (id, tip, bölge adı, şablon) toplar.
	 *
	 * Bölge adı ve şablon meta'sı, single.php ile aynı kurallarla okunur;
	 * böylece widget çıktısı bölüm HTML'iyle birebir aynı davranır.
	 *
	 * @param int $post_id İçerik kimliği (0 → geçerli içerik).
	 * @return array
	 */
	private static function cpt_baglam( $post_id = 0 ) {
		$post_id = $post_id ? (int) $post_id : (int) get_the_ID();

		$tpl = (string) get_post_meta( $post_id, '_dxp_template', true );
		if ( '' === $tpl && function_exists( 'devxpe_custom_post_types' ) ) {
			$tip = (string) get_post_type( $post_id );
			foreach ( devxpe_custom_post_types() as $cpt ) {
				if ( isset( $cpt['slug'], $cpt['template'] ) && $cpt['slug'] === $tip ) {
					$tpl = (string) $cpt['template'];
					break;
				}
			}
		}

		/* Alan adı: manşet widget ayarı > eski meta > içerik başlığı. */
		$area = self::hero_alan_adi( $post_id );
		if ( '' === $area ) {
			$area = (string) get_post_meta( $post_id, '_dxp_area_name', true );
		}
		if ( '' === $area ) {
			$area = html_entity_decode( (string) get_the_title( $post_id ), ENT_QUOTES, 'UTF-8' );
		}

		return array(
			'id'     => $post_id,
			'tip'    => (string) get_post_type( $post_id ),
			'area'   => $area,
			'banded' => function_exists( 'devxpe_template_is_banded' ) ? devxpe_template_is_banded( $tpl ) : false,
		);
	}

	/**
	 * Manşet widget'ı — single-hero.php çıktısını yakalar.
	 *
	 * Ayarlar doluysa ilgili bölümü besler; boş olanlar hiç basılmaz
	 * (baslik_kaynak 'meta' ise _dxp_hero_title kullanılır).
	 *
	 * @param array $ayar Ayarlar.
	 * @return string
	 */
	private static function ciz_cpt_hero( $ayar ) {
		if ( ! function_exists( 'get_template_part' ) ) {
			return '';
		}

		$c    = self::cpt_baglam();
		$args = array(
			'banded'        => $c['banded'],
			'widget'        => true,
			'baslik_kaynak' => isset( $ayar['baslik_kaynak'] ) ? (string) $ayar['baslik_kaynak'] : 'baslik',
			'rozet'         => isset( $ayar['rozet'] ) ? (string) $ayar['rozet'] : '',
			'lead'          => isset( $ayar['lead'] ) ? (string) $ayar['lead'] : '',
			'konum'         => isset( $ayar['konum'] ) ? (string) $ayar['konum'] : '',
			'btn1_metin'    => isset( $ayar['btn1_metin'] ) ? (string) $ayar['btn1_metin'] : '',
			'btn1_link'     => isset( $ayar['btn1_link'] ) ? (string) $ayar['btn1_link'] : '',
			'btn2_metin'    => isset( $ayar['btn2_metin'] ) ? (string) $ayar['btn2_metin'] : '',
			'btn2_link'     => isset( $ayar['btn2_link'] ) ? (string) $ayar['btn2_link'] : '',
			'gorsel'        => isset( $ayar['gorsel'] ) ? (string) $ayar['gorsel'] : '',
			'rozetler'      => isset( $ayar['rozetler'] ) ? (string) $ayar['rozetler'] : '',
		);

		ob_start();
		get_template_part( 'template-parts/single-hero', null, $args );
		$html = trim( (string) ob_get_clean() );

		/* Bölüm moduyla birebir: dış sarmalayıcı yok (single.php kendi kabını açar). */
		return $html;
	}

	/**
	 * "Neler dahil" widget'ı.
	 *
	 * Bölge (bant) şablonunda kart düzeni, diğerinde madde düzeni çizilir;
	 * mevcut single.php markup'ıyla birebir aynıdır.
	 *
	 * @param array $ayar Ayarlar.
	 * @return string
	 */
	private static function ciz_cpt_includes( $ayar ) {
		$c = self::cpt_baglam();

		$items = self::metin_satirlari( isset( $ayar['satirlar'] ) ? $ayar['satirlar'] : '' );
		if ( ! $items ) {
			$raw   = (string) get_post_meta( $c['id'], '_dxp_includes', true );
			$items = devxpe_lines( $raw );
		}
		if ( ! $items ) {
			return '';
		}

		$baslik = isset( $ayar['baslik'] ) ? trim( (string) $ayar['baslik'] ) : '';
		if ( '' === $baslik ) {
			$baslik = (string) get_post_meta( $c['id'], '_dxp_includes_title', true );
		}
		if ( '' === $baslik ) {
			$baslik = __( 'Neler dahil', 'devxpe-theme' );
			if ( function_exists( 'devxpe_includes_heading' ) ) {
				$baslik = devxpe_includes_heading();
			}
		}

		$kart = $c['banded'] || ( isset( $ayar['stil'] ) && 'kart' === $ayar['stil'] );

		ob_start();
		if ( $kart ) :
			?>
			<section class="dxp-includes dxp-includes--area">
				<div class="dxp-includes-copy">
					<h2 class="dxp-includes-title"><?php echo esc_html( $baslik ); ?></h2>
					<?php if ( $c['banded'] && get_the_content() ) : ?>
					<div class="dxp-includes-intro"><?php the_content(); ?></div>
					<?php endif; ?>
				</div>
				<ul class="dxp-includes-cards">
					<?php foreach ( $items as $item ) : ?>
					<li class="dxp-include-card"><?php echo esc_html( $item ); ?></li>
					<?php endforeach; ?>
				</ul>
			</section>
			<?php
		else :
			?>
			<section class="dxp-includes">
				<h2 class="dxp-includes-title"><?php echo esc_html( $baslik ); ?></h2>
				<ul class="dxp-includes-grid">
					<?php foreach ( $items as $item ) : ?>
					<li class="dxp-include">
						<?php echo devxpe_lucide( 'circle-check' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
						<span><?php echo esc_html( $item ); ?></span>
					</li>
					<?php endforeach; ?>
				</ul>
			</section>
			<?php
		endif;
		$html = trim( (string) ob_get_clean() );

		return $html;
	}

	/**
	 * İçerik widget'ı (editör içeriği veya özel alan).
	 *
	 * Bölge şablonunda giriş metni "Neler dahil" bölümünde çizildiğinden
	 * boş döner (mevcut davranış korunur).
	 *
	 * @param array $ayar Ayarlar.
	 * @return string
	 */
	private static function ciz_cpt_content( $ayar ) {
		$c = self::cpt_baglam();

		if ( $c['banded'] ) {
			return '';
		}

		$kaynak = isset( $ayar['icerik_kaynak'] ) ? $ayar['icerik_kaynak'] : 'editor';
		$html   = '';

		if ( 'meta' === $kaynak ) {
			$icerik = (string) get_post_meta( $c['id'], '_dxp_content', true );
			if ( '' !== trim( $icerik ) ) {
				$html = wpautop( wp_kses_post( $icerik ) );
			}
		} else {
			if ( '' === trim( (string) get_the_content() ) ) {
				return '';
			}
			ob_start();
			the_content();
			$html = trim( (string) ob_get_clean() );
		}

		if ( '' === $html ) {
			return '';
		}

		$genislik = isset( $ayar['genislik'] ) ? $ayar['genislik'] : 'normal';
		$genislik = in_array( $genislik, array( 'dar', 'normal', 'genis' ), true ) ? $genislik : 'normal';
		/* Bölüm moduyla birebir: varsayılan "normal" için ek sınıf yok. */
		$sinif    = ( 'normal' === $genislik ) ? 'dxp-detail-content' : 'dxp-detail-content dxp-detail-content--' . $genislik;
		$baslik   = isset( $ayar['baslik'] ) ? trim( (string) $ayar['baslik'] ) : '';

		ob_start();
		?>
		<div class="dxp-detail-body">
			<?php devxpe_render_ad( 'post_top_ad' ); ?>
			<?php if ( '' !== $baslik ) : ?>
			<h2 class="dxp-band-title"><?php echo esc_html( $baslik ); ?></h2>
			<?php endif; ?>
			<div class="<?php echo esc_attr( $sinif ); ?>"><?php echo $html; // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
			<?php devxpe_render_ad( 'post_bottom_ad' ); ?>
		</div>
		<?php
		$out = trim( (string) ob_get_clean() );

		return $out;
	}

	/**
	 * Projeler widget'ı — mevcut _dxp_projects meta'sı ya da manuel kartlar.
	 *
	 * @param array $ayar Ayarlar.
	 * @return string
	 */
	private static function ciz_cpt_projects( $ayar ) {
		$c        = self::cpt_baglam();
		$projeler = array();

		/* Bölüm modu projeleri yalnızca bant (bölge) şablonunda çizer. */
		if ( ! $c['banded'] ) {
			return '';
		}

		$rows = get_post_meta( $c['id'], '_dxp_projects', true );
		if ( is_array( $rows ) ) {
			foreach ( $rows as $row ) {
				if ( is_array( $row ) && ! empty( $row['title'] ) ) {
					$projeler[] = $row;
				}
			}
		}

		/* Manuel kartlar (gorsel|baslik|link) — meta boşsa. */
		$manuel = array();
		if ( ! $projeler ) {
			foreach ( self::satirlar( isset( $ayar['satirlar'] ) ? $ayar['satirlar'] : '' ) as $satir ) {
				$b = isset( $satir[1] ) ? trim( (string) $satir[1] ) : '';
				if ( '' === $b ) {
					continue;
				}
				$manuel[] = array(
					'image' => isset( $satir[0] ) ? $satir[0] : '',
					'title' => $b,
					'link'  => isset( $satir[2] ) ? $satir[2] : '',
				);
			}
		}

		if ( ! $projeler && ! $manuel ) {
			return '';
		}

		$baslik = isset( $ayar['baslik'] ) ? trim( (string) $ayar['baslik'] ) : '';
		if ( '' === $baslik ) {
			$baslik = (string) get_post_meta( $c['id'], '_dxp_projects_title', true );
		}
		if ( '' === $baslik ) {
			$baslik = 'Recent %s projects';
		}
		$baslik = sprintf( $baslik, $c['area'] );

		$satir_etiket = array(
			'scope'     => __( 'Kapsam', 'devxpe-theme' ),
			'materials' => __( 'Malzemeler', 'devxpe-theme' ),
			'days'      => __( 'Sahada', 'devxpe-theme' ),
		);

		ob_start();
		?>
		<h2 class="dxp-band-title"><?php echo esc_html( $baslik ); ?></h2>
		<div class="dxp-proj-grid">
			<?php if ( $projeler ) : ?>
				<?php foreach ( $projeler as $p ) : ?>
				<article class="dxp-proj">
					<h3 class="dxp-proj-title"><?php echo esc_html( $p['title'] ); ?></h3>
					<dl class="dxp-proj-dl">
						<?php foreach ( $satir_etiket as $k => $etiket ) : ?>
							<?php
							if ( empty( $p[ $k ] ) ) {
								continue;
							}
							?>
						<div class="dxp-proj-row">
							<dt><?php echo esc_html( $etiket ); ?></dt>
							<dd><?php echo esc_html( $p[ $k ] ); ?></dd>
						</div>
						<?php endforeach; ?>
					</dl>
				</article>
				<?php endforeach; ?>
			<?php else : ?>
				<?php foreach ( $manuel as $p ) : ?>
				<article class="dxp-proj">
					<?php if ( ! empty( $p['image'] ) ) : ?>
					<img class="dxp-proj-img" src="<?php echo esc_url( $p['image'] ); ?>" alt="<?php echo esc_attr( $p['title'] ); ?>" loading="lazy" decoding="async" />
					<?php endif; ?>
					<h3 class="dxp-proj-title">
						<?php if ( ! empty( $p['link'] ) ) : ?>
						<a href="<?php echo esc_url( $p['link'] ); ?>"><?php echo esc_html( $p['title'] ); ?></a>
						<?php else : ?>
						<?php echo esc_html( $p['title'] ); ?>
						<?php endif; ?>
					</h3>
				</article>
				<?php endforeach; ?>
			<?php endif; ?>
		</div>
		<?php
		$html = trim( (string) ob_get_clean() );

		return $html;
	}

	/**
	 * Hizmetler widget'ı — manuel kartlar ya da kaynak sorgusu.
	 *
	 * @param array $ayar Ayarlar.
	 * @return string
	 */
	private static function ciz_cpt_services( $ayar ) {
		$c       = self::cpt_baglam();
		$kartlar = array();

		/* Bölüm modu hizmetleri yalnızca bant (bölge) şablonunda çizer. */
		if ( ! $c['banded'] ) {
			return '';
		}

		foreach ( self::satirlar( isset( $ayar['satirlar'] ) ? $ayar['satirlar'] : '' ) as $satir ) {
			$b = isset( $satir[1] ) ? trim( (string) $satir[1] ) : '';
			if ( '' === $b ) {
				continue;
			}
			$kartlar[] = array(
				'image' => isset( $satir[0] ) ? $satir[0] : '',
				'title' => $b,
				'text'  => '',
				'url'   => isset( $satir[2] ) ? $satir[2] : '',
			);
		}

		if ( ! $kartlar ) {
			$kaynak = isset( $ayar['kaynak'] ) ? (string) $ayar['kaynak'] : 'kategori';
			$src    = (string) get_post_meta( $c['id'], '_dxp_services_source', true );

			if ( '' === $src && 'manuel' !== $kaynak ) {
				$src = ( 'services' === $c['tip'] ) ? 'none' : 'cpt:services';
			}
			if ( 'none' === $src ) {
				return '';
			}

			$adet = isset( $ayar['adet'] ) && '' !== $ayar['adet'] ? absint( $ayar['adet'] ) : 0;
			if ( $adet < 1 ) {
				$adet = (string) get_post_meta( $c['id'], '_dxp_services_limit', true );
			}
			$adet = ( '' === (string) $adet ) ? 12 : absint( $adet );

			$kartlar = function_exists( 'devxpe_cards_from_source' ) ? devxpe_cards_from_source( $src, $adet ) : array();
		}

		if ( ! $kartlar ) {
			return '';
		}

		$baslik = isset( $ayar['baslik'] ) ? trim( (string) $ayar['baslik'] ) : '';
		if ( '' === $baslik ) {
			$baslik = (string) get_post_meta( $c['id'], '_dxp_services_title', true );
		}
		if ( '' === $baslik ) {
			$baslik = 'Services available in %s';
		}
		$baslik = sprintf( $baslik, $c['area'] );

		ob_start();
		?>
		<h2 class="dxp-band-title"><?php echo esc_html( $baslik ); ?></h2>
		<div class="dxp-svc-grid">
			<?php foreach ( $kartlar as $svc ) : ?>
				<?php if ( ! empty( $svc['url'] ) ) : ?>
				<a class="dxp-svc" href="<?php echo esc_url( $svc['url'] ); ?>">
					<h3><?php echo esc_html( $svc['title'] ); ?></h3>
					<?php if ( ! empty( $svc['text'] ) ) : ?>
					<p><?php echo esc_html( wp_trim_words( $svc['text'], 20, '…' ) ); ?></p>
					<?php endif; ?>
					<span class="dxp-svc-link">
						<?php esc_html_e( 'Daha fazla', 'devxpe-theme' ); ?>
						<?php echo devxpe_lucide( 'arrow-right' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
					</span>
				</a>
				<?php else : ?>
				<div class="dxp-svc">
					<h3><?php echo esc_html( $svc['title'] ); ?></h3>
					<?php if ( ! empty( $svc['text'] ) ) : ?>
					<p><?php echo esc_html( wp_trim_words( $svc['text'], 20, '…' ) ); ?></p>
					<?php endif; ?>
				</div>
				<?php endif; ?>
			<?php endforeach; ?>
		</div>
		<?php
		$html = trim( (string) ob_get_clean() );

		return $html;
	}

	/**
	 * SSS widget'ı — mevcut akordeon markup'ı ve JS sınıfları korunur.
	 *
	 * @param array $ayar Ayarlar.
	 * @return string
	 */
	private static function ciz_cpt_faq( $ayar ) {
		$c = self::cpt_baglam();

		$rows = get_post_meta( $c['id'], '_dxp_faq', true );
		$rows = is_array( $rows ) ? array_values(
			array_filter(
				$rows,
				function ( $r ) {
					return is_array( $r ) && ( ! empty( $r['title'] ) || ! empty( $r['text'] ) );
				}
			)
		) : array();

		/* Widget satırları (soru|cevap) meta'yı geçersiz kılar. */
		$widget_rows = array();
		foreach ( self::satirlar( isset( $ayar['satirlar'] ) ? $ayar['satirlar'] : '' ) as $satir ) {
			$soru  = isset( $satir[0] ) ? trim( (string) $satir[0] ) : '';
			$cevap = isset( $satir[1] ) ? trim( (string) $satir[1] ) : '';
			if ( '' === $soru && '' === $cevap ) {
				continue;
			}
			$widget_rows[] = array( 'title' => $soru, 'text' => $cevap );
		}
		if ( $widget_rows ) {
			$rows = $widget_rows;
		}

		if ( ! $rows ) {
			return '';
		}

		$baslik = isset( $ayar['baslik'] ) ? trim( (string) $ayar['baslik'] ) : '';
		if ( '' === $baslik && $c['banded'] ) {
			$baslik = (string) get_post_meta( $c['id'], '_dxp_faq_title', true );
			if ( '' === $baslik ) {
				$baslik = '%s questions we get asked';
			}
			$baslik = sprintf( $baslik, $c['area'] );
		}
		if ( '' === $baslik ) {
			$baslik = __( 'Sıkça sorulan sorular', 'devxpe-theme' );
		}

		ob_start();
		if ( $c['banded'] ) {
			echo '<h2 class="dxp-band-title">' . esc_html( $baslik ) . '</h2>';
		} else {
			echo '<section class="dxp-faq dxp-faq--detail">';
			echo '<h2 class="dxp-faq-head">' . esc_html( $baslik ) . '</h2>';
		}
		?>
		<div class="dxp-accordion">
			<?php foreach ( $rows as $row ) : ?>
			<details class="dxp-acc">
				<summary class="dxp-acc-btn">
					<span><?php echo esc_html( isset( $row['title'] ) ? $row['title'] : '' ); ?></span>
					<?php echo devxpe_lucide( 'chevron-down', 'dxp-acc-chev' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				</summary>
				<?php if ( ! empty( $row['text'] ) ) : ?>
				<div class="dxp-acc-panel"><p><?php echo esc_html( $row['text'] ); ?></p></div>
				<?php endif; ?>
			</details>
			<?php endforeach; ?>
		</div>
		<?php
		if ( ! $c['banded'] ) {
			echo '</section>';
		}
		$html = trim( (string) ob_get_clean() );

		return $html;
	}

	/**
	 * İlgili içerikler widget'ı.
	 *
	 * @param array $ayar Ayarlar.
	 * @return string
	 */
	private static function ciz_cpt_related( $ayar ) {
		$c        = self::cpt_baglam();
		$src_meta = (string) get_post_meta( $c['id'], '_dxp_related_source', true );
		$kaynak   = isset( $ayar['kaynak'] ) ? (string) $ayar['kaynak'] : 'ayni';

		$adet = isset( $ayar['adet'] ) && '' !== $ayar['adet'] ? absint( $ayar['adet'] ) : 8;
		if ( $adet < 1 ) {
			$adet = 8;
		}

		$related = array();

		/* ARC: bölge sayfalarında kaynak seçilmemişse ilgili içerik yoktur. */
		if ( ! ( $c['banded'] && '' === $src_meta ) ) {

			foreach ( get_posts(
				array(
					'post_type'    => $c['tip'],
					'post_status'  => 'publish',
					'post__not_in' => array( $c['id'] ),
					'numberposts'  => $adet,
					'orderby'      => 'menu_order date',
					'order'        => 'ASC',
				)
			) as $sib ) {
				$related[] = array(
					'title' => get_the_title( $sib ),
					'url'   => get_permalink( $sib ),
				);
			}

			if ( ! $related ) {
				if ( 'tumu' === $kaynak ) {
					foreach ( get_posts(
						array(
							'post_type'    => 'any',
							'post_status'  => 'publish',
							'post__not_in' => array( $c['id'] ),
							'numberposts'  => $adet,
						)
					) as $it ) {
						$related[] = array(
							'title' => get_the_title( $it ),
							'url'   => get_permalink( $it ),
						);
					}
				} elseif ( 'none' !== $src_meta ) {
					$src = $src_meta;
					if ( '' === $src ) {
						$src = function_exists( 'devxpe_theme_get' ) ? devxpe_theme_get( 'related_source', 'page' ) : 'page';
					}
					if ( 'none' !== $src && function_exists( 'devxpe_items_list' ) ) {
						$related = devxpe_items_list( $src, $adet );
						$self    = get_permalink( $c['id'] );
						$related = array_values(
							array_filter(
								$related,
								function ( $item ) use ( $self ) {
									return isset( $item['url'] ) && $item['url'] !== $self;
								}
							)
						);
					}
				}
			}
		}

		$related = array_values(
			array_filter(
				$related,
				function ( $item ) {
					return isset( $item['title'] ) && '' !== trim( (string) $item['title'] );
				}
			)
		);

		if ( ! $related ) {
			return '';
		}

		$baslik = isset( $ayar['baslik'] ) ? trim( (string) $ayar['baslik'] ) : '';
		if ( '' === $baslik ) {
			$baslik = __( 'İlgili içerikler', 'devxpe-theme' );
		}

		ob_start();
		?>
		<section class="dxp-related">
			<h3 class="dxp-related-title"><?php echo esc_html( $baslik ); ?></h3>
			<div class="dxp-tagrow">
				<?php foreach ( $related as $item ) : ?>
					<?php echo devxpe_item_link( $item ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				<?php endforeach; ?>
			</div>
		</section>
		<?php
		$html = trim( (string) ob_get_clean() );

		return $html;
	}

	/**
	 * Teklif formu widget'ı.
	 *
	 * Bant şablonunda tam (full), diğerinde kompakt (compact) varyant çizilir;
	 * form seçimi form_sec ayarından gelir.
	 *
	 * @param array $ayar Ayarlar.
	 * @return string
	 */
	private static function ciz_cpt_quote( $ayar ) {
		if ( ! function_exists( 'devxpe_quote_form_args' ) ) {
			return '';
		}

		$sec     = isset( $ayar['form_sec'] ) ? (string) $ayar['form_sec'] : 'quote';
		$formlar = function_exists( 'devxpe_form_choice_options' ) ? devxpe_form_choice_options() : array();

		/* Farklı bir form seçildiyse onu çiz. */
		if ( 'quote' !== $sec && '' !== $sec ) {
			if ( ! function_exists( 'devxpe_render_form_choice' ) || ! array_key_exists( $sec, $formlar ) ) {
				return '';
			}
			ob_start();
			devxpe_render_form_choice( $sec, false );
			$html = trim( (string) ob_get_clean() );

			return $html;
		}

		$args = devxpe_quote_form_args();
		if ( empty( $args['groups'] ) ) {
			return '';
		}

		$c = self::cpt_baglam();

		if ( $c['banded'] ) {
			$args['variant'] = 'full';

			$title = isset( $ayar['baslik'] ) ? trim( (string) $ayar['baslik'] ) : '';
			if ( '' === $title ) {
				$title = (string) get_post_meta( $c['id'], '_dxp_quote_title', true );
			}
			if ( '' === $title ) {
				$title = function_exists( 'devxpe_theme_get' ) ? devxpe_theme_get( 'form_title', 'Get your free %s quote' ) : 'Get your free %s quote';
			}
			$args['title'] = str_replace( '%s', $c['area'], $title );

			$eyebrow = (string) get_post_meta( $c['id'], '_dxp_quote_eyebrow', true );
			if ( isset( $ayar['ust_yazi'] ) && '' !== trim( (string) $ayar['ust_yazi'] ) ) {
				$eyebrow = trim( (string) $ayar['ust_yazi'] );
			}
			if ( '' !== $eyebrow ) {
				$args['eyebrow'] = $eyebrow;
			}

			$benefits = devxpe_lines( get_post_meta( $c['id'], '_dxp_quote_benefits', true ) );
			if ( $benefits ) {
				$args['benefits'] = $benefits;
			}

			$sub = (string) get_post_meta( $c['id'], '_dxp_quote_text', true );
			if ( '' !== $sub ) {
				$args['subtitle'] = $sub;
			}
			if ( isset( $ayar['alt_metin'] ) && '' !== trim( (string) $ayar['alt_metin'] ) ) {
				$args['subtitle'] = trim( (string) $ayar['alt_metin'] );
			}
		} else {
			$args['variant'] = 'compact';
			if ( isset( $ayar['baslik'] ) && '' !== trim( (string) $ayar['baslik'] ) ) {
				$args['mini_title'] = trim( (string) $ayar['baslik'] );
			}
			if ( isset( $ayar['alt_metin'] ) && '' !== trim( (string) $ayar['alt_metin'] ) ) {
				$args['mini_subtitle'] = trim( (string) $ayar['alt_metin'] );
			}
		}

		ob_start();
		get_template_part( 'template-parts/quote-form', null, $args );
		$html = trim( (string) ob_get_clean() );

		return $html;
	}

	/**
	 * satirlar alanını satır/parça dizisine çevirir ("a|b|c").
	 *
	 * Boş satırlar atlanır; eksik parçalar güvenli şekilde tolere edilir.
	 *
	 * @param string $ham Ham metin.
	 * @return array Her öğe bir parça dizisi.
	 */
	private static function satirlar( $ham ) {
		$out = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) $ham ) as $satir ) {
			$satir = trim( $satir );
			if ( '' === $satir ) {
				continue;
			}
			$out[] = array_map( 'trim', explode( '|', $satir ) );
		}

		return $out;
	}

	/**
	 * satirlar alanını düz satır dizisine çevirir (parça ayırmadan).
	 *
	 * @param string $ham Ham metin.
	 * @return array
	 */
	private static function metin_satirlari( $ham ) {
		$out = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) $ham ) as $satir ) {
			$satir = trim( $satir );
			if ( '' !== $satir ) {
				$out[] = $satir;
			}
		}

		return $out;
	}

	/**
	 * Sütun sayısını 1–4 aralığına sıkıştırır.
	 *
	 * @param mixed $ham        Ham değer.
	 * @param int   $varsayilan Geçersizse kullanılacak değer.
	 * @return int
	 */
	private static function kolon( $ham, $varsayilan = 3 ) {
		$n = absint( $ham );
		if ( $n < 1 || $n > 4 ) {
			$n = (int) $varsayilan;
		}

		return $n;
	}

	/**
	 * Sosyal platform adını ikon değerine çevirir (marka ikonu yoksa küre).
	 *
	 * @param string $platform Platform adı.
	 * @return string
	 */
	private static function sosyal_ikon( $platform ) {
		$harita = array(
			'facebook'  => 'fa-brands fa-facebook-f',
			'instagram' => 'fa-brands fa-instagram',
			'twitter'   => 'fa-brands fa-x-twitter',
			'x'         => 'fa-brands fa-x-twitter',
			'youtube'   => 'fa-brands fa-youtube',
			'linkedin'  => 'fa-brands fa-linkedin-in',
			'whatsapp'  => 'fa-brands fa-whatsapp',
			'tiktok'    => 'fa-brands fa-tiktok',
			'pinterest' => 'fa-brands fa-pinterest',
			'telegram'  => 'fa-brands fa-telegram',
			'github'    => 'fa-brands fa-github',
			'eposta'    => 'mail',
			'e-posta'   => 'mail',
		);

		$p = strtolower( trim( (string) $platform ) );

		return isset( $harita[ $p ] ) ? $harita[ $p ] : 'globe';
	}

	/**
	 * Hizalama değerini güvenli sınıf adına çevirir.
	 *
	 * @param string $hiza sol | orta | sag.
	 * @return string
	 */
	private static function hiza_class( $hiza ) {
		$hiza = in_array( $hiza, array( 'sol', 'orta', 'sag' ), true ) ? $hiza : 'sol';

		return 'dxp-pw--hiza-' . $hiza;
	}
}
