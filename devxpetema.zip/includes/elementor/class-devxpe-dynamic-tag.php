<?php
/**
 * Elementor Dinamik Etiket Entegrasyonu
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Elementor aktif değilse çık
if ( ! did_action( 'elementor/loaded' ) ) {
	return;
}

/**
 * DEVXPE Ayarları Dinamik Etiketi
 */
class DEVXPE_Dynamic_Tag extends \Elementor\Core\DynamicTags\Tag {

	/**
	 * Etiketin sistem adı.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'devxpe_theme_option';
	}

	/**
	 * Etiketin görünen adı.
	 *
	 * @return string
	 */
	public function get_title() {
		return __( 'DEVXPE Ayarları', 'devxpe-theme' );
	}

	/**
	 * Etiketin bulunduğu grup.
	 *
	 * @return string
	 */
	public function get_group() {
		return 'site';
	}

	/**
	 * Etiketin kullanılabileceği alanlar (metin, URL vb.)
	 *
	 * @return array
	 */
	public function get_categories() {
		return array(
			\Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY,
			\Elementor\Modules\DynamicTags\Module::URL_CATEGORY,
			\Elementor\Modules\DynamicTags\Module::IMAGE_CATEGORY,
		);
	}

	/**
	 * Panelde gösterilecek ayar anahtarı.
	 *
	 * @return string
	 */
	public function get_panel_template_setting_key() {
		return 'option_key';
	}

	/**
	 * Kontrolleri (seçenekleri) kaydet.
	 *
	 * @return void
	 */
	protected function register_controls() {

		$options = array();
		
		// Eğer tema fonksiyonumuz ve alanlarımız mevcutsa panel alanlarını çekelim
		if ( class_exists( 'DEVXPE_Theme_Fields' ) ) {
			$fields = DEVXPE_Theme_Fields::all();
			foreach ( $fields as $id => $field ) {
				$options[ $id ] = $field['label'] ?? $id;
			}
		}

		$this->add_control(
			'option_key',
			array(
				'label'   => __( 'Ayar Seçin', 'devxpe-theme' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => $options,
				'default' => 'phone',
			)
		);
	}

	/**
	 * Çıktıyı oluşturur.
	 *
	 * @return void
	 */
	public function render() {
		$key = $this->get_settings( 'option_key' );

		if ( empty( $key ) || ! function_exists( 'devxpe_theme_get' ) ) {
			return;
		}

		$value = devxpe_theme_get( $key );

		/*
		 * Yapılandırılmış alanlar (team tekrarlayıcı, typography, pages)
		 * dinamik etikette anlamlı tek bir değer üretmez; sessizce boş dön.
		 */
		if ( is_array( $value ) ) {
			return;
		}

		echo wp_kses_post( (string) $value );
	}
}

/**
 * Dinamik etiketleri Elementor'a kaydet.
 */
add_action( 'elementor/dynamic_tags/register', function( $dynamic_tags ) {
	$dynamic_tags->register_tag( 'DEVXPE_Dynamic_Tag' );
} );
