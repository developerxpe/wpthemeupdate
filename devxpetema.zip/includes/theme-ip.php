<?php
/**
 * İstemci IP çözümleme (proxy farkındalıklı).
 *
 * X-Forwarded-For ve CF-Connecting-IP başlıkları istemcinin elindedir.
 * Bu yüzden istek GÜVENİLİR bir proxy'den gelmiyorsa bu başlıklar YOK
 * SAYILIR; yalnızca REMOTE_ADDR kullanılır. Aksi hâlde her istekte farklı
 * başlık göndererek hız sınırı atlatılabilir.
 *
 * Güvenilir proxy listesi: `devxpe_trusted_proxies` filtresi (IP veya
 * IPv4 CIDR dizisi). Site yalnız Cloudflare üzerinden erişiliyorsa
 * `devxpe_trust_proxy_headers` filtresi `true` döndürebilir.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * IP, verilen kuralın (tam IP veya CIDR) içinde mi?
 *
 * @param string $ip    Denetlenen IP.
 * @param string $kural IP ya da `a.b.c.d/ön ek`.
 * @return bool
 */
function devxpe_ip_in_range( $ip, $kural ) {
	$ip    = trim( (string) $ip );
	$kural = trim( (string) $kural );

	if ( '' === $ip || '' === $kural ) {
		return false;
	}

	if ( false === strpos( $kural, '/' ) ) {
		return 0 === strcasecmp( $ip, $kural );
	}

	list( $alt, $maske ) = array_pad( explode( '/', $kural, 2 ), 2, '' );
	$maske     = (int) $maske;
	$ip_bin    = @inet_pton( $ip );
	$alt_bin   = @inet_pton( $alt );

	if ( false === $ip_bin || false === $alt_bin || strlen( $ip_bin ) !== strlen( $alt_bin ) ) {
		return false;
	}

	$tam_bayt = intdiv( $maske, 8 );
	$kalan    = $maske % 8;

	if ( $tam_bayt > 0 && 0 !== substr_compare( $ip_bin, $alt_bin, 0, $tam_bayt ) ) {
		return false;
	}

	if ( 0 === $kalan ) {
		return true;
	}

	$maske_bayt = chr( ( 0xFF << ( 8 - $kalan ) ) & 0xFF );

	return ( ord( $ip_bin[ $tam_bayt ] ) & ord( $maske_bayt ) ) === ( ord( $alt_bin[ $tam_bayt ] ) & ord( $maske_bayt ) );
}

/**
 * Proxy başlıklarına güvenilebilir mi?
 *
 * @param string       $ip      İsteğin geldiği adres (REMOTE_ADDR).
 * @param array|bool|null $trusted true: tümüne güven; dizi: güvenilir proxy listesi; null: filtrelerden oku.
 * @return bool
 */
function devxpe_ip_is_trusted( $ip, $trusted = null ) {
	if ( true === $trusted ) {
		return true;
	}

	if ( null === $trusted ) {
		$trusted = apply_filters( 'devxpe_trusted_proxies', array() );

		if ( apply_filters( 'devxpe_trust_proxy_headers', false ) ) {
			return true;
		}
	}

	foreach ( (array) $trusted as $kural ) {
		if ( devxpe_ip_in_range( $ip, $kural ) ) {
			return true;
		}
	}

	return false;
}

/**
 * İstemci IP'si.
 *
 * Başlıklar yalnızca güvenilir proxy arkasındaysa dikkate alınır; aksi
 * hâlde doğrudan `REMOTE_ADDR` döner. Geçersizse '0'.
 *
 * @param array           $server  $_SERVER benzeri dizi.
 * @param array|bool|null $trusted Güvenilir proxy listesi (bkz. devxpe_ip_is_trusted).
 * @return string
 */
function devxpe_client_ip( $server, $trusted = null ) {
	$server = (array) $server;

	$remote = isset( $server['REMOTE_ADDR'] ) ? trim( (string) $server['REMOTE_ADDR'] ) : '';
	$remote = ( '' !== $remote && filter_var( $remote, FILTER_VALIDATE_IP ) ) ? $remote : '';

	if ( devxpe_ip_is_trusted( $remote, $trusted ) ) {
		/* Cloudflare bu başlığı kendisi yazar; istemci değeri ezilir. */
		if ( ! empty( $server['HTTP_CF_CONNECTING_IP'] ) ) {
			$cf = trim( (string) $server['HTTP_CF_CONNECTING_IP'] );

			if ( '' !== $cf && filter_var( $cf, FILTER_VALIDATE_IP ) ) {
				return $cf;
			}
		}

		/*
		 * X-Forwarded-For SOLDAN SAĞA güvenilmez: istemci kendi değerini
		 * yazabilir, proxy gerçek IP'yi sona ekler. Bu yüzden sağdan sola
		 * yürünür ve güvenilir proxy olmayan ilk geçerli IP istemcidir.
		 */
		if ( ! empty( $server['HTTP_X_FORWARDED_FOR'] ) ) {
			$parcalar = array_reverse( explode( ',', (string) $server['HTTP_X_FORWARDED_FOR'] ) );

			foreach ( $parcalar as $a ) {
				$a = trim( $a );

				if ( '' === $a || ! filter_var( $a, FILTER_VALIDATE_IP ) ) {
					continue;
				}

				if ( is_array( $trusted ) && devxpe_ip_is_trusted( $a, $trusted ) ) {
					continue;
				}

				return $a;
			}
		}
	}

	return '' !== $remote ? $remote : '0';
}
