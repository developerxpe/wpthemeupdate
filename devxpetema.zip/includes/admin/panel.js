/**
 * DEVXPE Panel — JavaScript
 *
 * Sol menüden section/subsection geçişi (hash tabanlı routing),
 * arama filtresi, arama içi gezinme ve import/export yardımcıları.
 */

( function () {
	'use strict';

	/* ── Durum ────────────────────────────────────────────── */
	let currentSubsection = '';

	/* ── DOM kısayolları ──────────────────────────────────── */
	function $( sel, ctx ) {
		return ( ctx || document ).querySelector( sel );
	}
	function $$( sel, ctx ) {
		return Array.from( ( ctx || document ).querySelectorAll( sel ) );
	}

	/* Güvenilir statik HTML/SVG'yi DOM düğümüne çevirir (innerHTML kullanmaz). */
	function htmlNode( markup ) {
		const belge = new DOMParser().parseFromString( markup, 'text/html' );
		return document.importNode( belge.body.firstElementChild, true );
	}

	/*
	 * Slug üretir: Türkçe karakterleri ASCII karşılığına çevirir, küçük harfe
	 * indirir, geçersiz karakterleri tireye çevirir ve baş/son tireyi temizler.
	 * Sunucudaki sanitize_title() ile aynı sonucu verir
	 * (ı→i, İ→i, ğ→g, Ş→s, ç→c, ö→o, ü→u).
	 */
	function turkceSlug( deger ) {
		const harita = {
			'ı': 'i', 'İ': 'i', 'ğ': 'g', 'Ğ': 'g', 'ş': 's', 'Ş': 's',
			'ç': 'c', 'Ç': 'c', 'ö': 'o', 'Ö': 'o', 'ü': 'u', 'Ü': 'u',
			'â': 'a', 'Â': 'a', 'î': 'i', 'Î': 'i', 'û': 'u', 'Û': 'u'
		};
		return String( deger )
			.replace( /[ıİğĞşŞçÇöÖüÜâÂîÎûÛ]/g, function ( k ) { return harita[ k ]; } )
			.toLowerCase()
			.replace( /[^a-z0-9]+/g, '-' )
			.replace( /^-+|-+$/g, '' );
	}

	/* ── Hash okuma ───────────────────────────────────────── */
	function getHash() {
		return ( window.location.hash || '' ).replace( '#', '' ) || '';
	}

	/* ── URL yazma ────────────────────────────────────────── */
	function setHash( hash ) {
		if ( history.replaceState ) {
			history.replaceState( null, '', '#' + hash );
		} else {
			window.location.hash = hash;
		}
	}

	/* ── Aktif section ve subsection'ı göster ─────────────── */
	/*
	 * openParent === false: sol menüdeki üst öğeyi zorla açma.
	 * (Menü başlığına tıklayınca accordion aç/kapa bindMenu tarafından yönetilir.)
	 */
	function showSection( sectionId, subsectionId, openParent ) {
		/* Section'ları gizle */
		$$( '.dxp-section' ).forEach( function ( el ) {
			el.classList.remove( 'active' );
		} );

		/* Hedef section'ı göster */
		let targetSection = $( '#dxp-section-' + sectionId );
		if ( ! targetSection ) {
			/* Fallback: ilk section */
			const first = $( '.dxp-section' );
			if ( first ) {
				sectionId = first.id.replace( 'dxp-section-', '' );
				targetSection = first;
			}
		}
		if ( targetSection ) {
			targetSection.classList.add( 'active' );
		}

		/* Sol menüde aktif item — aynı anda yalnızca BİR menü açık kalsın. */
		$$( '#devxpe-panel-left .dxp-nav > li' ).forEach( function ( li ) {
			li.classList.remove( 'active' );

			/*
			 * Menü tıklaması (openParent === false) kendi aç/kapa mantığını
			 * kullanır; diğer durumlarda (sayfa yükü, hash değişimi) açık
			 * menüler kapatılır ki sunucunun açtığı bölümle çakışmasın.
			 */
			if ( false !== openParent ) {
				li.classList.remove( 'open' );
			}
		} );

		const activeNavItem = $( '#devxpe-panel-left .dxp-nav > li[data-section="' + sectionId + '"]' );
		if ( activeNavItem ) {
			activeNavItem.classList.add( 'active' );
			/* Alt menü varsa aç (menü tıklaması hariç). */
			if ( false !== openParent && $( '.dxp-submenu', activeNavItem ) ) {
				activeNavItem.classList.add( 'open' );
			}
		}

		/* Subsection geçişi */
		if ( subsectionId ) {
			showSubsection( sectionId, subsectionId );
		} else {
			/* Subsection yoksa ya da belirtilmemişse ilkini göster */
			const firstSub = $( '#dxp-section-' + sectionId + ' .dxp-subsection' );
			if ( firstSub ) {
				const firstSubId = firstSub.id.replace( 'dxp-subsection-', '' ).replace( sectionId + '-', '' );
				showSubsection( sectionId, firstSubId );
			}
		}

		/* Başlık güncelle */
		updateTopbarTitle( sectionId, subsectionId );

		currentSubsection = subsectionId || '';

		/* Sayfa yenilesinde doğru bölümün flash'sız yüklenmesi için cookie yaz. */
		const last = sectionId + ( currentSubsection ? '--' + currentSubsection : '' );
		document.cookie = 'dxp_panel_last=' + last + ';path=/;max-age=31536000;SameSite=Strict';
	}

	/* ── Subsection göster ────────────────────────────────── */
	function showSubsection( sectionId, subsectionId ) {
		const sectionEl = $( '#dxp-section-' + sectionId );
		if ( ! sectionEl ) return;

		$$( '.dxp-subsection', sectionEl ).forEach( function ( el ) {
			el.classList.remove( 'active' );
		} );

		const target = $( '#dxp-subsection-' + sectionId + '-' + subsectionId, sectionEl );
		if ( target ) {
			target.classList.add( 'active' );
		}

		/* Sol menü submenu item */
		$$( '.dxp-submenu li' ).forEach( function ( li ) {
			li.classList.remove( 'active' );
		} );
		const activeSubNav = $( '.dxp-submenu li[data-subsection="' + sectionId + '-' + subsectionId + '"]' );
		if ( activeSubNav ) {
			activeSubNav.classList.add( 'active' );
		}
	}

	/* ── Topbar başlığını güncelle ────────────────────────── */
	function updateTopbarTitle( sectionId, subsectionId ) {
		const titleEl = $( '.dxp-page-title' );
		if ( ! titleEl ) return;

		const navItem = $( '.dxp-nav > li[data-section="' + sectionId + '"]' );
		let label   = navItem ? ( navItem.querySelector( '.dxp-nav-label' ) || {} ).textContent || '' : sectionId;

		if ( subsectionId ) {
			const subItem = $( '.dxp-submenu li[data-subsection="' + sectionId + '-' + subsectionId + '"]' );
			if ( subItem ) {
				/* Rozet metni ("Yeni" / okunmadı) başlığa karışmasın: yalnızca etiket okunur. */
				const subLabel = $( '.dxp-sub-label', subItem );
				label += ' › ' + ( ( subLabel || subItem ).textContent || '' ).trim();
			}
		}

		titleEl.textContent = label.trim();
	}

	/* ── Hash'ten section/subsection ayır ─────────────────── */
	function parseHash( hash ) {
		if ( ! hash ) return { section: '', sub: '' };
		const parts = hash.split( '--' );
		return { section: parts[0] || '', sub: parts[1] || '' };
	}

	/* ── Menü tıklamaları ─────────────────────────────────── */
	function bindMenu() {
		/* Ana menü öğeleri */
		$$( '#devxpe-panel-left .dxp-nav > li > a' ).forEach( function ( link ) {
			link.addEventListener( 'click', function ( e ) {
				e.preventDefault();
				const li        = this.closest( 'li' );
				const sectionId = li.dataset.section;
				const submenu   = $( '.dxp-submenu', li );

				if ( submenu ) {
					/* Açılır/kapanır */
					const isOpen = li.classList.contains( 'open' );
					$$( '.dxp-nav > li' ).forEach( function ( el ) {
						el.classList.remove( 'open' );
					} );
					if ( ! isOpen ) {
						li.classList.add( 'open' );
					}
				}

				if ( sectionId ) {
					setHash( sectionId );
					showSection( sectionId, '', false );
				}
			} );
		} );

		/* Alt menü öğeleri */
		$$( '#devxpe-panel-left .dxp-submenu li > a' ).forEach( function ( link ) {
			link.addEventListener( 'click', function ( e ) {
				e.preventDefault();
				const li        = this.closest( 'li' );
				const compound  = li.dataset.subsection || ''; /* format: section-sub */
				const parts     = compound.split( '-' );
				const sectionId = parts[0];
				const subId     = parts.slice( 1 ).join( '-' );

				if ( sectionId && subId ) {
					setHash( sectionId + '--' + subId );
					showSection( sectionId, subId );
				}
			} );
		} );
	}

	/* ── Arama: yalnız MENÜ BAŞLIKLARINDA ────────────────── */
	/*
	 * Ayar satırları filtrelenmez. Sonuç listesi soldaki menünün
	 * başlıklarından üretilir; parça eşleşmesi olur, en yakın önce gelir.
	 * Eşleşme yoksa liste boş kalır (hiç açılmaz).
	 */
	function bindSearch() {
		const input = $( '#dxp-search' );
		if ( ! input ) { return; }

		const box = $( '#dxp-search-results' );
		let nav   = $( '#devxpe-panel-left' );
		if ( ! box || ! nav ) { return; }

		/* Türkçe harfleri sadeleştir: "dogrulama" → "doğrulama". */
		function katla( s ) {
			return String( s ).toLocaleLowerCase( 'tr' )
				.replace( /ı/g, 'i' ).replace( /ğ/g, 'g' ).replace( /ü/g, 'u' )
				.replace( /ş/g, 's' ).replace( /ö/g, 'o' ).replace( /ç/g, 'c' )
				.replace( /â/g, 'a' ).replace( /î/g, 'i' ).replace( /û/g, 'u' )
				.replace( /\s+/g, ' ' )
				.trim();
		}

		/* Bağlantı metni; "Yeni" rozeti ve ikonlar hariç. */
		function etiket( a ) {
			const k = a.cloneNode( true );
			Array.prototype.forEach.call(
				k.querySelectorAll( '.dxp-new-badge, .dxp-new-dot, .dashicons' ),
				function ( x ) { x.remove(); }
			);
			return k.textContent.replace( /[▾▸▴]/g, '' ).replace( /\s+/g, ' ' ).trim();
		}

		/* Menü başlıklarını topla (bölüm + alt bölüm). */
		function kayitlar() {
			const out = [];

			Array.prototype.forEach.call( nav.querySelectorAll( '.dxp-nav > li[data-section]' ), function ( li ) {
				const a = li.querySelector( 'a' );
				const ad = a ? etiket( a ) : '';

				if ( ad ) {
					out.push( { metin: ad, ust: '', a: a } );
				}

				Array.prototype.forEach.call( li.querySelectorAll( '.dxp-submenu li[data-subsection]' ), function ( sli ) {
					const sa = sli.querySelector( 'a' );
					const sad = sa ? etiket( sa ) : '';
					if ( sad ) {
						out.push( { metin: sad, ust: ad, a: sa } );
					}
				} );
			} );

			return out;
		}

		/* Puan: 0 tam, 1 baştan, 2 kelime başı, 3 içinde. */
		function bul( term ) {
			const t = katla( term );
			if ( '' === t ) { return []; }

			return kayitlar()
				.map( function ( r ) {
					const m = katla( r.metin );
					let puan = -1;

					if ( m === t ) { puan = 0; }
					else if ( 0 === m.indexOf( t ) ) { puan = 1; }
					else if ( m.indexOf( ' ' + t ) !== -1 ) { puan = 2; }
					else if ( m.indexOf( t ) !== -1 ) { puan = 3; }

					return puan < 0 ? null : { r: r, puan: puan, uzunluk: m.length };
				} )
				.filter( Boolean )
				.sort( function ( a, b ) { return a.puan - b.puan || a.uzunluk - b.uzunluk; } )
				.slice( 0, 8 )
				.map( function ( x ) { return x.r; } );
		}

		function kapat() {
			box.hidden = true;
			box.replaceChildren();
		}

		input.addEventListener( 'input', function () {
			const sonuc = bul( this.value );

			if ( ! sonuc.length ) {
				kapat();
				return;
			}

			box.replaceChildren();

			sonuc.forEach( function ( r ) {
				const b = document.createElement( 'button' );
				b.type = 'button';

				if ( r.ust ) {
					const p = document.createElement( 'span' );
					p.className = 'dxp-sr-parent';
					p.textContent = r.ust;
					b.appendChild( p );
				}

				b.appendChild( document.createTextNode( r.metin ) );

				b.addEventListener( 'click', function () {
					if ( r.a ) { r.a.click(); }
					input.value = '';
					kapat();
				} );

				box.appendChild( b );
			} );

			box.hidden = false;
		} );

		/* Dışarı tıklama ve Esc: listeyi kapat. */
		document.addEventListener( 'click', function ( e ) {
			if ( ! e.target.closest( '#devxpe-panel-left .dxp-search' ) ) { kapat(); }
		} );

		document.addEventListener( 'keydown', function ( e ) {
			if ( 'Escape' === e.key ) { kapat(); }
		} );
	}

	/* ── Import butonu ────────────────────────────────────── */
	function bindTools() {
		const copyBtn = $( '#dxp-copy-export' );
		if ( copyBtn ) {
			copyBtn.addEventListener( 'click', function () {
				const ta = $( '#dxp-export-data' );
				if ( ta ) {
					ta.select();
					document.execCommand( 'copy' );
					copyBtn.textContent = '✓ Kopyalandı';
					setTimeout( function () { copyBtn.textContent = 'Kopyala'; }, 2000 );
				}
			} );
		}

		/* Dışa aktarımı JSON dosyası olarak indir. */
		const dlBtn = $( '#dxp-download-export' );
		if ( dlBtn ) {
			dlBtn.addEventListener( 'click', function () {
				const ta = $( '#dxp-export-data' );
				if ( ! ta ) { return; }
				const blob = new Blob( [ ta.value ], { type: 'application/json' } );
				const url  = URL.createObjectURL( blob );
				const link = document.createElement( 'a' );
				link.href = url;
				link.download = 'devxpe-ayarlar.json';
				document.body.appendChild( link );
				link.click();
				link.remove();
				URL.revokeObjectURL( url );
			} );
		}

		/* Seçilen JSON dosyasını textarea'ya yükle (normal POST ile gider). */
		const fileInput = $( '#dxp-import-file' );
		if ( fileInput ) {
			const fileName = $( '#dxp-import-file-name' );
			const bosMetin = fileName ? fileName.textContent : '';

			fileInput.addEventListener( 'change', function () {
				const file = fileInput.files && fileInput.files[ 0 ];

				if ( ! file ) {
					if ( fileName ) { fileName.textContent = bosMetin; }
					return;
				}

				if ( fileName ) { fileName.textContent = file.name; }

				const reader = new FileReader();
				reader.onload = function () {
					const ta = document.querySelector( '[name="devxpe_theme_import_data"]' );
					if ( ta ) { ta.value = String( reader.result || '' ); }
				};
				reader.readAsText( file );
			} );
		}
	}

	/* ── Demo paketi: kaldırma onay penceresi ─────────────── */
	/* ── Demo kurulumu: kilit + %0→%100 ilerleme ──────────── */

	/*
	 * Kurulum adım adım (AJAX) yürür: her adım kısa bir istek, panel kilitli
	 * kalır ve ilerleme çubuğu gerçek yüzdeyle güncellenir. Görseller
	 * internetten indirildiği için işlem uzun sürebilir.
	 */
	function bindDemoInstall() {
		const btn   = $( '#dxp-demo-install-btn' );
		const kilit = $( '#dxp-demo-lock' );
		if ( ! btn || ! kilit ) return;

		const fill    = $( '#dxp-demo-lock-fill' );
		const yuzdeEl = $( '#dxp-demo-lock-yuzde' );
		const mesajEl = $( '#dxp-demo-lock-mesaj' );
		const hataEl  = $( '#dxp-demo-lock-error' );
		const retry   = $( '#dxp-demo-lock-retry' );
		const baslik  = kilit.querySelector( '.dxp-demo-lock-title' );
		const modal   = $( '#dxp-demo-install-modal' );
		const onay    = $( '#dxp-demo-install-confirm' );

		/* Metinler PHP'den çeviriyle gelir (DXPDEMO). */
		const D   = window.DXPDEMO || {};
		const soz = function ( k, y ) { return D[ k ] ? D[ k ] : y; };

		let adim      = 'hazirlik';
		let calisiyor = false;

		function yuzdeAyarla( n ) {
			n = Math.max( 0, Math.min( 100, parseInt( n, 10 ) || 0 ) );

			if ( fill ) { fill.style.width = n + '%'; }
			if ( yuzdeEl ) { yuzdeEl.textContent = n + '%'; }
		}

		function hataGoster( mesaj ) {
			calisiyor = false;
			if ( hataEl ) { hataEl.hidden = false; hataEl.textContent = mesaj; }
			if ( retry ) { retry.hidden = false; }
		}

		function bitir() {
			calisiyor = false;
			if ( baslik ) { baslik.textContent = soz( 'tamamlandi', 'Tamamlandı' ) + ' ✓'; }
			yuzdeAyarla( 100 );
			if ( mesajEl ) { mesajEl.textContent = soz( 'yenileniyor', 'Demo kurulumu tamamlandı, sayfa yenileniyor…' ); }
			setTimeout( function () { window.location.reload(); }, 1200 );
		}

		/* Seçili demo: radyo seçici → yoksa kur butonunun data-demo'su. */
		function seciliDemo() {
			const r = document.querySelector( '#dxp-demo-pick input[name="dxp_demo_pick"]:checked' );
			if ( r && r.value ) { return r.value; }

			return btn.getAttribute( 'data-demo' ) || '';
		}

		function sor( a ) {
			const fd = new FormData();
			fd.append( 'action', 'devxpe_demo_step' );
			fd.append( 'nonce', btn.getAttribute( 'data-nonce' ) || '' );
			fd.append( 'lang', btn.getAttribute( 'data-lang' ) || '' );
			fd.append( 'demo', seciliDemo() );
			fd.append( 'adim', a );

			fetch( window.ajaxurl, { method: 'POST', credentials: 'same-origin', body: fd } )
				.then( function ( r ) { return r.json(); } )
				.then( function ( d ) {
					const v = ( d && d.data ) ? d.data : {};

					if ( ! d || ! d.success || ! v.ok ) {
						hataGoster( v.mesaj || soz( 'adimHata', 'Kurulum adımı başarısız oldu.' ) );
						return;
					}

					yuzdeAyarla( v.yuzde );
					if ( mesajEl ) { mesajEl.textContent = v.mesaj || ''; }

					if ( ! v.sonraki ) { bitir(); return; }

					adim = v.sonraki;
					sor( adim );
				} )
				.catch( function () { hataGoster( soz( 'baglanti', 'Bağlantı hatası. Tekrar deneyin.' ) ); } );
		}

		function basla() {
			if ( calisiyor ) { return; }

			calisiyor = true;
			if ( hataEl ) { hataEl.hidden = true; }
			if ( retry ) { retry.hidden = true; }
			if ( baslik ) { baslik.textContent = soz( 'kuruluyor', 'Demo kuruluyor' ); }

			yuzdeAyarla( 0 );
			kilit.hidden = false;
			document.documentElement.style.overflow = 'hidden';
			sor( adim );
		}

		function modalKapat() {
			if ( modal ) { modal.hidden = true; }
		}

		btn.addEventListener( 'click', function ( e ) {
			e.preventDefault(); /* JS varsa eski POST akışına düşülmez */

			/* Önce "emin misin?" onayı istenir. */
			if ( modal ) {
				modal.hidden = false;
				return;
			}

			adim = 'hazirlik';
			basla();
		} );

		if ( onay ) {
			onay.addEventListener( 'click', function () {
				modalKapat();
				adim = 'hazirlik';
				basla();
			} );
		}

		if ( modal ) {
			$$( '[data-dxp-demo-install-close]' ).forEach( function ( el ) {
				el.addEventListener( 'click', modalKapat );
			} );

			document.addEventListener( 'keydown', function ( e ) {
				if ( 'Escape' === e.key && ! modal.hidden ) { modalKapat(); }
			} );
		}

		/* Hata olunca çıkan buton: kurulumu İPTAL eder (kilit kapanır, sayfa yenilenir). */
		if ( retry ) {
			retry.addEventListener( 'click', function () {
				calisiyor = false;
				document.documentElement.style.overflow = '';
				if ( kilit ) { kilit.hidden = true; }
				window.location.reload();
			} );
		}

		window.addEventListener( 'beforeunload', function ( e ) {
			if ( calisiyor ) { e.preventDefault(); e.returnValue = ''; }
		} );
	}

	function bindDemoModal() {
		const btn   = $( '#dxp-demo-remove-btn' );
		const modal = $( '#dxp-demo-modal' );
		if ( ! btn || ! modal ) return;

		const confirmBtn = $( '#dxp-demo-confirm' );

		function open() {
			if ( confirmBtn ) { confirmBtn.setAttribute( 'href', btn.getAttribute( 'data-remove-url' ) || '#' ); }
			modal.hidden = false;
			document.body.classList.add( 'dxp-modal-open' );
			if ( confirmBtn ) { confirmBtn.focus(); }
		}

		function close() {
			modal.hidden = true;
			document.body.classList.remove( 'dxp-modal-open' );
		}

		btn.addEventListener( 'click', open );
		modal.addEventListener( 'click', function ( e ) {
			if ( e.target.closest( '[data-dxp-demo-close]' ) ) { close(); }
		} );
		document.addEventListener( 'keydown', function ( e ) {
			if ( 'Escape' === e.key && ! modal.hidden ) { close(); }
		} );
	}

	/* ── Önerilen eklenti mağaza önizlemesi ───────────────── */
	function bindPluginPreview() {
		if ( ! document.getElementById( 'devxpe-panel' ) ) {
			return;
		}

		document.addEventListener( 'click', function ( e ) {
			const btn = e.target.closest ? e.target.closest( '.dxp-plugin-preview' ) : null;
			if ( ! btn ) {
				return;
			}
			e.preventDefault();
			ac( btn );
		} );

		function kapat( modal ) {
			document.body.classList.remove( 'dxp-modal-open' );
			if ( modal && modal.parentNode ) {
				modal.parentNode.removeChild( modal );
			}
		}

		function ac( btn ) {
			const eski = document.getElementById( 'dxp-plugin-modal' );
			if ( eski ) {
				kapat( eski );
			}

			const slug = btn.getAttribute( 'data-slug' ) || '';
			const ad   = btn.getAttribute( 'data-ad' ) || 'Eklenti';

			const modal = document.createElement( 'div' );
			modal.className = 'dxp-modal';
			modal.id = 'dxp-plugin-modal';

			const backdrop = document.createElement( 'div' );
			backdrop.className = 'dxp-modal-backdrop';

			const box = document.createElement( 'div' );
			box.className = 'dxp-modal-box dxp-plugin-preview-box';
			box.setAttribute( 'role', 'dialog' );
			box.setAttribute( 'aria-modal', 'true' );
			box.setAttribute( 'aria-labelledby', 'dxp-plugin-modal-title' );

			const baslik = document.createElement( 'h2' );
			baslik.className = 'dxp-modal-title';
			baslik.id = 'dxp-plugin-modal-title';
			baslik.textContent = ad;

			const govde = document.createElement( 'div' );
			govde.className = 'dxp-modal-body';
			govde.textContent = 'Mağaza bilgisi yükleniyor…';

			const aksiyon = document.createElement( 'div' );
			aksiyon.className = 'dxp-modal-actions';

			const link = document.createElement( 'a' );
			link.className = 'button';
			link.target = '_blank';
			link.rel = 'noopener noreferrer';
			link.href = 'https://wordpress.org/plugins/' + encodeURIComponent( slug ) + '/';
			link.textContent = 'Mağazada aç';

			const kapatBtn = document.createElement( 'button' );
			kapatBtn.type = 'button';
			kapatBtn.className = 'button button-primary';
			kapatBtn.textContent = 'Kapat';

			aksiyon.appendChild( link );
			aksiyon.appendChild( kapatBtn );
			box.appendChild( baslik );
			box.appendChild( govde );
			box.appendChild( aksiyon );
			modal.appendChild( backdrop );
			modal.appendChild( box );
			document.body.appendChild( modal );
			document.body.classList.add( 'dxp-modal-open' );

			const kapatBeni = function () { kapat( modal ); };
			const escKapat = function ( e ) {
				if ( 'Escape' === e.key ) {
					document.removeEventListener( 'keydown', escKapat );
					kapatBeni();
				}
			};

			backdrop.addEventListener( 'click', kapatBeni );
			kapatBtn.addEventListener( 'click', kapatBeni );
			document.addEventListener( 'keydown', escKapat );

			const veri = new FormData();
			veri.append( 'action', 'devxpe_plugin_preview' );
			veri.append( 'nonce', btn.getAttribute( 'data-nonce' ) || '' );
			veri.append( 'slug', slug );

			fetch( window.ajaxurl || '/wp-admin/admin-ajax.php', {
				method: 'POST',
				credentials: 'same-origin',
				body: veri
			} ).then( function ( r ) { return r.json(); } ).then( function ( res ) {
				if ( ! res || ! res.success || ! res.data ) {
					govde.textContent = ( res && res.data && res.data.mesaj ) ? res.data.mesaj : 'Mağaza bilgisi alınamadı.';
					return;
				}

				const d = res.data;
				govde.replaceChildren();

				const meta = document.createElement( 'p' );
				meta.className = 'dxp-desc';
				meta.textContent = 'Sürüm ' + ( d.surum || '?' )
					+ ' · Puan ' + ( d.puan || 0 ) + '/100'
					+ ' · ' + ( d.kurulum || 0 ) + ' aktif kurulum'
					+ ( d.son ? ' · Güncelleme: ' + d.son : '' );
				govde.appendChild( meta );

				if ( d.kisa ) {
					const aciklama = document.createElement( 'p' );
					aciklama.textContent = d.kisa;
					govde.appendChild( aciklama );
				}

				if ( d.ekran ) {
					const gorsel = document.createElement( 'img' );
					gorsel.className = 'dxp-plugin-preview-img';
					gorsel.src = d.ekran;
					gorsel.alt = '';
					gorsel.loading = 'lazy';
					govde.appendChild( gorsel );
				}
			} ).catch( function () {
				govde.textContent = 'Bağlantı hatası; mağazayı yeni sekmede açabilirsiniz.';
			} );
		}
	}

	/* ── Mobil sidebar toggle ─────────────────────────────── */
	function bindMobileToggle() {
		const toggleBtn = $( '.dxp-menu-toggle' );
		const sidebar   = $( '#devxpe-panel-left' );
		const overlay   = $( '.dxp-overlay' );

		if ( ! toggleBtn || ! sidebar ) return;

		function openSidebar() {
			sidebar.classList.add( 'open' );
			if ( overlay ) overlay.classList.add( 'active' );
			toggleBtn.setAttribute( 'aria-expanded', 'true' );
			toggleBtn.setAttribute( 'aria-label', 'Menüyü Kapat' );
			toggleBtn.textContent = '✕';
		}

		function closeSidebar() {
			sidebar.classList.remove( 'open' );
			if ( overlay ) overlay.classList.remove( 'active' );
			toggleBtn.setAttribute( 'aria-expanded', 'false' );
			toggleBtn.setAttribute( 'aria-label', 'Menüyü Aç' );
			toggleBtn.textContent = '☰';
		}

		toggleBtn.addEventListener( 'click', function () {
			if ( sidebar.classList.contains( 'open' ) ) {
				closeSidebar();
			} else {
				openSidebar();
			}
		} );

		/*
		 * Menü açıkken bir bölüm seçilse bile kapanmaz; yalnızca çarpıya
		 * (toggle) ya da boş alana (overlay) basınca kapanır.
		 */
		if ( overlay ) {
			overlay.addEventListener( 'click', closeSidebar );
		}
	}

	/* ── E-posta konusu: {alan} değişkenini tıklayınca input'a ekle ── */
	function bindTokens() {
		const input = document.getElementById( 'dxp_form_subject' );
		if ( ! input ) return;

		document.addEventListener( 'click', function ( e ) {
			const chip = e.target.closest ? e.target.closest( '.dxp-token' ) : null;
			if ( ! chip ) return;

			e.preventDefault();

			const token = chip.getAttribute( 'data-token' ) || '';
			if ( ! token ) return;

			const val   = input.value;
			const start = input.selectionStart;
			const end   = input.selectionEnd;

			if ( 'number' !== typeof start ) {
				/* Konum bilgisi yoksa sonuna ekle. */
				input.value = val + token;
			} else {
				input.value = val.slice( 0, start ) + token + val.slice( end );
				const pos = start + token.length;
				input.setSelectionRange( pos, pos );
			}

			/* Manuel yazmaya devam edilebilsin: odak input'ta kalır. */
			input.focus();
			input.dispatchEvent( new Event( 'input', { bubbles: true } ) );
		} );
	}

	/* ── Yazı boyutu ölçeği: [−] Aaⁿ [+] (5 kademe, ortası varsayılan) ── */
	function bindScale() {
		const panel = document.getElementById( 'devxpe-panel' );
		const wrap  = document.querySelector( '.dxp-scale' );
		if ( ! panel || ! wrap ) return;

		const steps = [ 0.8, 0.9, 1, 1.12, 1.25 ];
		const label = wrap.querySelector( '.dxp-scale-value small' );
		const down  = wrap.querySelector( '[data-dxp-scale="-1"]' );
		const up    = wrap.querySelector( '[data-dxp-scale="1"]' );
		let level = parseInt( localStorage.getItem( 'devxpe_panel_scale' ), 10 );

		if ( isNaN( level ) || level < 0 || level > steps.length - 1 ) { level = 2; }

		function apply( next ) {
			level = Math.min( Math.max( next, 0 ), steps.length - 1 );
			panel.style.setProperty( '--dxp-scale', steps[ level ] );
			if ( label ) { label.textContent = level + 1; }
			if ( down ) { down.disabled = ( 0 === level ); }
			if ( up ) { up.disabled = ( level === steps.length - 1 ); }
			localStorage.setItem( 'devxpe_panel_scale', level );
		}

		if ( down ) { down.addEventListener( 'click', function () { apply( level - 1 ); } ); }
		if ( up ) { up.addEventListener( 'click', function () { apply( level + 1 ); } ); }

		apply( level );
	}

	/* ── Formu AJAX ile kaydetme (bayat form korumalı) ───────── */
	function bindFormSubmit() {
		const form = $( '#devxpe-panel-form' );
		if ( ! form ) return;

		/*
		 * Bayat form koruması.
		 *
		 * Panel başka bir sekmede de açıkken orada kaydedilirse, bu sekmedeki
		 * form eski değerleri taşır. Tüm formu göndermek dokunulmamış alanların
		 * üzerine eski değerleri yazar. Bunu önlemek için yalnızca kullanıcının
		 * DEĞİŞTİRDİĞİ alanlar gönderilir; sunucu da gönderilmeyenleri korur.
		 */
		let baseline = {};

		function fieldId( name ) {
			const i = name.indexOf( '[' );
			return ( i === -1 ) ? name : name.substring( 0, i );
		}

		function collect() {
			const map = {};

			function push( name, value ) {
				const id = fieldId( name );
				if ( ! map[ id ] ) { map[ id ] = []; }
				map[ id ].push( name + '\u0000' + value );
			}

			Array.prototype.forEach.call( form.elements, function ( el ) {
				if ( ! el.name || el.tagName === 'BUTTON' ) { return; }

				if ( el.type === 'checkbox' ) {
					push( el.name, el.checked ? ( el.value || '1' ) : '' );
				} else if ( el.type === 'radio' ) {
					if ( el.checked ) { push( el.name, el.value ); }
				} else if ( el.tagName === 'SELECT' ) {
					Array.prototype.forEach.call( el.options, function ( o ) {
						if ( o.selected ) { push( el.name, o.value ); }
					} );
				} else {
					push( el.name, el.value );
				}
			} );

			const sig = {};
			Object.keys( map ).forEach( function ( id ) {
				sig[ id ] = map[ id ].slice().sort().join( '|' );
			} );

			return { map: map, sig: sig };
		}

		function takeBaseline() {
			baseline = collect().sig;
		}

		function dirtyFormData() {
			const now   = collect();
			const fd    = new FormData();
			let count = 0;

			Object.keys( now.sig ).forEach( function ( id ) {
				if ( baseline[ id ] === now.sig[ id ] ) { return; }
				now.map[ id ].forEach( function ( pair ) {
					const sep = pair.indexOf( '\u0000' );
					fd.append( pair.substring( 0, sep ), pair.substring( sep + 1 ) );
					count++;
				} );
			} );

			/* Tamamen boşalan alan: tüm satırları silinen repeater, tüm
			   seçimi kaldırılan sayfa kutusu vb. Bu durumda alan artık
			   DOM'da eleman üretmediği için sig'de de yoktur; sunucu
			   "gönderilmeyen korunur" devreye girip eski değeri tutar.
			   Bunu engellemek için alanı bilinçli olarak BOŞ gönder. */
			Object.keys( baseline ).forEach( function ( id ) {
				if ( now.sig[ id ] !== undefined ) { return; }
				fd.append( id, '' );
				count++;
			} );

			return { fd: fd, count: count };
		}

		takeBaseline();

		/*
		 * Kaydetme AJAX DEĞİL: sunucuya kalıcı veri yazan işlemler normal
		 * POST + PRG (Post-Redirect-Get) ile gider. Yalnızca DEĞİŞEN alanlar
		 * gizli bir formla gönderilir (bayat form koruması); sunucu
		 * gönderilmeyen alanları korur.
		 */
		form.addEventListener( 'submit', function ( e ) {
			// Import, eklenti kurulumu ve formaction'lı butonlar (ör. SMTP testi)
			// kendi normal POST'uyla gitsin; onlara dokunma.
			if ( e.submitter && ( 'devxpe_theme_import' === e.submitter.name || 'devxpe_plugin_install' === e.submitter.name || e.submitter.hasAttribute( 'formaction' ) ) ) {
				return;
			}

			e.preventDefault();

			const saveBtn = $( '.dxp-save-btn' );
			const dirty   = dirtyFormData();

			if ( ! dirty.count ) {
				if ( saveBtn ) {
					const orig = saveBtn.textContent;
					saveBtn.textContent = 'Değişiklik yok';
					setTimeout( function () { saveBtn.textContent = orig; }, 1500 );
				}
				return;
			}

			/*
			 * Değişen alanları gizli bir forma koy; tarayıcının NORMAL POST'u
			 * ile gönder. Sunucu işleyip PRG ile panele geri yönlendirir.
			 * (fetch/XHR yok.)
			 */
			const native = document.createElement( 'form' );
			native.method  = 'post';
			native.action  = form.getAttribute( 'action' ) || window.location.href;
			native.style.display = 'none';

			function addField( name, value ) {
				const input = document.createElement( 'input' );
				input.type  = 'hidden';
				input.name  = name;
				input.value = value;
				native.appendChild( input );
			}

			dirty.fd.forEach( function ( value, name ) {
				addField( name, value );
			} );
			addField( 'devxpe_theme_save', '1' );

			const nonceEl = form.querySelector( '[name="devxpe_theme_nonce"]' );
			if ( nonceEl ) {
				addField( 'devxpe_theme_nonce', nonceEl.value );
			}

			document.body.appendChild( native );
			native.submit();
		} );
	}

	/* ── Dark Mode Toggle ─────────────────────────────────── */
	function bindDarkMode() {
		const panel = document.getElementById( 'devxpe-panel' );
		const toggle = document.querySelector( '.dxp-dark-mode-toggle' );
		if ( ! panel || ! toggle ) return;

		const isDark = localStorage.getItem( 'devxpe_panel_dark' ) === '1';
		if ( isDark ) {
			panel.classList.add( 'dxp-dark-mode' );
		}

		toggle.addEventListener( 'click', function () {
			panel.classList.toggle( 'dxp-dark-mode' );
			const darkActive = panel.classList.contains( 'dxp-dark-mode' );
			localStorage.setItem( 'devxpe_panel_dark', darkActive ? '1' : '0' );
		} );
	}

	/* ── Renk Uyumu: tick açıkken tonları önizle, manuel alanları gizle ── */
	function bindColorHarmony() {
		const form = $( '#devxpe-panel-form' );
		if ( ! form ) return;

		const cb = form.querySelector( '[name="harmonize_colors"]' );
		if ( ! cb ) return;

		const primary    = form.querySelector( '[name="primary_color"]' );
		const hoverInput = form.querySelector( '[name="primary_hover"]' );
		const focusInput = form.querySelector( '[name="primary_focus"]' );
		const hoverRow   = hoverInput ? hoverInput.closest( '.dxp-row' ) : null;
		const focusRow   = focusInput ? focusInput.closest( '.dxp-row' ) : null;

		const preview = document.createElement( 'div' );
		preview.className = 'dxp-tone-preview';
		const harmRow = cb.closest( '.dxp-row' );
		const insertTarget = harmRow ? harmRow.children[ 1 ] : null;
		if ( insertTarget ) {
			insertTarget.appendChild( preview );
		} else if ( harmRow ) {
			harmRow.appendChild( preview );
		} else {
			form.appendChild( preview );
		}

		function renderPreview( val ) {
			preview.textContent = '';
			val = ( val || '' ).trim();
			if ( ! val ) return;

			[ [ 'Açık', 'white', 'hover' ], [ 'Koyu', 'black', 'focus' ] ].forEach( function ( item ) {
				const tile = document.createElement( 'div' );
				tile.className = 'dxp-tone-tile';

				const sw = document.createElement( 'span' );
				sw.className = 'dxp-tone-swatch';
				sw.style.background = 'color-mix(in srgb, ' + val + ', ' + item[ 1 ] + ' 18%)';

				const lbl = document.createElement( 'span' );
				lbl.className = 'dxp-tone-name';
				lbl.textContent = item[ 0 ] + ' · ' + item[ 2 ];

				tile.appendChild( sw );
				tile.appendChild( lbl );
				preview.appendChild( tile );
			} );
		}

		function update() {
			const on = cb.checked;
			if ( hoverRow ) hoverRow.classList.toggle( 'dxp-hidden-manual', on );
			if ( focusRow ) focusRow.classList.toggle( 'dxp-hidden-manual', on );
			preview.classList.toggle( 'dxp-hidden-manual', ! on );
			if ( on ) {
				renderPreview( primary ? primary.value : '' );
			}
		}

		cb.addEventListener( 'change', update );
		if ( primary ) primary.addEventListener( 'input', update );

		/* Renk seçici / şeffaflık slider'ı metin alanını günceller; onları da dinle. */
		[ 'clr_dxp_primary_color', 'opc_dxp_primary_color' ].forEach( function ( id ) {
			const el = document.getElementById( id );
			if ( el ) el.addEventListener( 'input', update );
		} );

		update();
	}

	/* ── Link / header rengi: uyum açıkken manuel renk satırını gizle ── */
	function bindColorFieldHarmony() {
		const form = $( '#devxpe-panel-form' );
		if ( ! form ) return;

		function bind( checkboxName, targetField ) {
			const cb    = form.querySelector( '[name="' + checkboxName + '"]' );
			const input = form.querySelector( '[name="' + targetField + '"]' );
			if ( ! cb || ! input ) return;

			const row = input.closest( '.dxp-row' );
			if ( ! row ) return;

			function update() {
				row.classList.toggle( 'dxp-hidden-manual', cb.checked );
			}

			cb.addEventListener( 'change', update );
			update();
		}

		bind( 'link_harmonize', 'link_color' );
		bind( 'header_text_harmonize', 'header_text' );
	}

	/* ── Radio-image seçim vurgusu ────────────────────────── */
	function bindRadioImages() {
		const form = $( '#devxpe-panel-form' );
		if ( ! form ) return;

		form.addEventListener( 'change', function ( e ) {
			const input = e.target;
			if ( ! input.classList || ! input.classList.contains( 'dxp-radio-image-input' ) ) return;
			$$( '.dxp-radio-image-input[name="' + input.name + '"]', form ).forEach( function ( i ) {
				i.closest( '.dxp-radio-image-label' ).classList.toggle( 'is-selected', i.checked );
			} );
		} );
	}

	/* ── Açılır ikon seçici (tüm dashicons, tembel üretim) ── */
	function bindIconPick() {
		const form = $( '#devxpe-panel-form' );
		if ( ! form ) return;

		const dataEl = document.getElementById( 'dxp-dashicons-data' );
		let icons  = [];
		try { icons = dataEl ? JSON.parse( dataEl.textContent ) : []; } catch { icons = []; }

		const lucideEl = document.getElementById( 'dxp-lucide-data' );
		let lucide   = {};
		try { lucide = lucideEl ? JSON.parse( lucideEl.textContent ) : {}; } catch { lucide = {}; }

		/* Font Awesome 6 ikon adları: { solid: [...], regular: [...], brands: [...] } */
		const faEl = document.getElementById( 'dxp-fa-data' );
		let fa   = {};
		try { fa = faEl ? JSON.parse( faEl.textContent ) : {}; } catch { fa = {}; }

		/* Lucide ikonunu <svg> olarak döndür (devxpe_lucide ile aynı biçim). */
		function lucideSvg( name ) {
			if ( ! lucide[ name ] ) return '';
			return '<svg class="dxp-ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + lucide[ name ] + '</svg>';
		}

		/* Aktif ikon seti: lucide | fa-solid | fa-regular | fa-brands | dashicons */
		function setOf( pick ) {
			return pick.getAttribute( 'data-active-set' )
				|| ( 'lucide' === pick.getAttribute( 'data-icon-set' ) ? 'lucide' : 'dashicons' );
		}

		function build( pick, force ) {
			const grid = pick.querySelector( '.dxp-iconpick-grid' );
			if ( ! grid ) return;
			if ( grid.childElementCount && ! force ) return;

			const set   = setOf( pick );
			const isLuc = ( 'lucide' === set );
			const names = isLuc
				? [ '' ].concat( Object.keys( lucide ) )
				: [ '' ].concat( fa[ set.replace( 'fa-', '' ) ] || icons );
			const val   = pick.querySelector( '.dxp-iconpick-value' ).value;
			const frag  = document.createDocumentFragment();

			grid.replaceChildren();

			names.forEach( function ( name ) {
				const b = document.createElement( 'button' );
				b.type = 'button';
				b.className = 'dxp-iconpick-item';
				b.setAttribute( 'data-icon', name || '' );
				b.title = name || '—';

				if ( ! name ) {
					b.setAttribute( 'data-value', '' );
					const none = document.createElement( 'span' );
					none.className = 'dxp-iconpick-none';
					none.textContent = '—';
					b.appendChild( none );
				} else if ( isLuc ) {
					b.setAttribute( 'data-value', name );
					b.replaceChildren( htmlNode( lucideSvg( name ) ) );
				} else if ( 'dashicons' === set ) {
					b.setAttribute( 'data-value', name );
					const s = document.createElement( 'span' );
					s.className = 'dashicons ' + name;
					b.appendChild( s );
				} else {
					const cls = 'fa-' + set.replace( 'fa-', '' ) + ' fa-' + name;
					b.setAttribute( 'data-value', cls );
					const i = document.createElement( 'i' );
					i.className = cls;
					i.setAttribute( 'aria-hidden', 'true' );
					b.appendChild( i );
				}

				if ( ( b.getAttribute( 'data-value' ) || '' ) === val ) {
					b.classList.add( 'is-selected' );
				}
				frag.appendChild( b );
			} );

			grid.appendChild( frag );
		}

		function closeAll() {
			$$( '.dxp-iconpick-panel', form ).forEach( function ( p ) { p.hidden = true; } );
			$$( '.dxp-iconpick-trigger', form ).forEach( function ( t ) { t.setAttribute( 'aria-expanded', 'false' ); } );
		}

		bindMenuAutoClose( closeAll );

		function filter( pick, term ) {
			if ( ! pick ) return;
			const terms = term ? term.toLowerCase().split( /\s+/ ).filter( Boolean ) : [];
			let shown = 0;

			$$( '.dxp-iconpick-item', pick ).forEach( function ( it ) {
				const name = ( it.getAttribute( 'data-icon' ) || '' ).toLowerCase();

				/* Yazılan tüm kelimeler ikon adında geçmeli (sırasız). */
				const match = ! terms.length || terms.every( function ( t ) {
					return name.indexOf( t ) !== -1;
				} );

				it.hidden = ! match;
				if ( match ) shown++;
			} );

			const empty = pick.querySelector( '.dxp-iconpick-empty' );
			if ( empty ) empty.hidden = shown > 0;
		}

		form.addEventListener( 'click', function ( e ) {
			const trigger = e.target.closest( '.dxp-iconpick-trigger' );
			if ( trigger ) {
				const pick   = trigger.closest( '.dxp-iconpick' );
				const panel  = pick.querySelector( '.dxp-iconpick-panel' );
				const isOpen = ! panel.hidden;
				closeAll();
				if ( ! isOpen ) {
					build( pick );
					panel.hidden = false;
					trigger.setAttribute( 'aria-expanded', 'true' );
					floatMenu( panel, trigger, false );
					const s = panel.querySelector( '.dxp-iconpick-search' );
					if ( s ) { s.value = ''; filter( pick, '' ); s.focus(); }
				}
				return;
			}

			/* İkon seti değiştir (Lucide / FA Solid / FA Regular / FA Brands) */
			const setBtn = e.target.closest( '.dxp-iconpick-set' );
			if ( setBtn ) {
				const pickS = setBtn.closest( '.dxp-iconpick' );
				$$( '.dxp-iconpick-set', pickS ).forEach( function ( b ) {
					b.classList.toggle( 'is-active', b === setBtn );
				} );
				pickS.setAttribute( 'data-active-set', setBtn.getAttribute( 'data-set' ) );
				build( pickS, true );
				const search = pickS.querySelector( '.dxp-iconpick-search' );
				if ( search ) { search.value = ''; filter( pickS, '' ); }
				return;
			}

			const item = e.target.closest( '.dxp-iconpick-item' );
			if ( item ) {
				const pick2 = item.closest( '.dxp-iconpick' );
				let val   = item.getAttribute( 'data-value' );
				const icon  = item.getAttribute( 'data-icon' ) || '';

				if ( null === val ) { val = icon; }

				pick2.querySelector( '.dxp-iconpick-value' ).value = val;

				const visWrap = pick2.querySelector( '.dxp-iconpick-trigger .dxp-iconpick-visual' );
				if ( visWrap ) {
					if ( ! val ) {
						visWrap.replaceChildren();
					} else if ( lucide[ val ] ) {
						visWrap.replaceChildren( htmlNode( lucideSvg( val ) ) );
					} else if ( 0 === val.indexOf( 'dashicons-' ) ) {
						const s = document.createElement( 'span' );
						s.className = 'dashicons ' + val;
						visWrap.replaceChildren( s );
					} else {
						const i = document.createElement( 'i' );
						i.className = val;
						i.setAttribute( 'aria-hidden', 'true' );
						visWrap.replaceChildren( i );
					}
				}

				const lbl = pick2.querySelector( '.dxp-iconpick-current' );
				if ( lbl ) {
					lbl.textContent = icon
						? icon.replace( 'dashicons-', '' )
						: ( pick2.getAttribute( 'data-empty-label' ) || '' );
				}
				const trg = pick2.querySelector( '.dxp-iconpick-trigger' );
				if ( trg ) {
					trg.title = lbl ? lbl.textContent : '';
				}
				$$( '.dxp-iconpick-item', pick2 ).forEach( function ( i ) {
					i.classList.toggle( 'is-selected', i === item );
				} );
				closeAll();
			}
		} );

		form.addEventListener( 'input', function ( e ) {
			const s = e.target;
			if ( s.classList && s.classList.contains( 'dxp-iconpick-search' ) ) {
				filter( s.closest( '.dxp-iconpick' ), s.value.trim().toLowerCase() );
			}
		} );

		document.addEventListener( 'click', function ( e ) {
			if ( ! e.target.closest( '.dxp-iconpick' ) ) {
				closeAll();
			}
		} );
	}

	/* ── Alan grubu sekmeleri (Manşet rozetleri): mobil/tablette 1 2 3 4 ── */
	/*
	 * Masaüstünde rozet kartları yan yana kalır (CSS). Dar ekranda
	 * (≤1100px) numaralı sekmeler görünür ve yalnızca seçili kart açılır.
	 * Ekle/sil YOKTUR: rozet sayısı sabittir (boş rozet de sekmede durur).
	 */
	function bindGroupTabs() {
		$$( '.dxp-card-groups' ).forEach( function ( box ) {
			const cards = $$( '.dxp-stat-card[data-tab-label]', box );
			if ( cards.length < 2 ) { return; }

			const tabs = document.createElement( 'div' );
			tabs.className = 'dxp-group-tabs';
			tabs.setAttribute( 'role', 'tablist' );
			box.insertBefore( tabs, box.firstChild );

			let active = cards[ 0 ];

			const refresh = function () {
				tabs.replaceChildren();
				cards.forEach( function ( card, i ) {
					const b = document.createElement( 'button' );
					b.type = 'button';
					b.className = 'dxp-repeater-tab';
					b.textContent = card.getAttribute( 'data-tab-label' ) || String( i + 1 );
					b.setAttribute( 'aria-selected', card === active ? 'true' : 'false' );
					if ( card === active ) { b.classList.add( 'is-active' ); }
					b.addEventListener( 'click', function () { active = card; refresh(); } );
					tabs.appendChild( b );
					card.classList.toggle( 'is-active', card === active );
				} );
			};

			refresh();
		} );
	}

	/* ── Teklif formu: seçime göre sekmeler (kaydetmeden) ── */
	/*
	 * "Form Seç" neyi seçtiyse yalnız onun sekmeleri görünür:
	 * adımlı teklif formu → 1..4. adım, özel form → o formun sekmesi.
	 * Sekmeler `data-choice` taşır; kaydetmeye gerek yoktur.
	 */
	function bindFormChoiceTabs() {
		/* "Form Seç" özel select'tir: gizli input'u dinle (id yok, name var). */
		const sel = document.querySelector( '[name="home_form_choice"]' ) || document.getElementById( 'dxp_home_form_choice' );
		if ( ! sel ) { return; }

		const root = document.getElementById( 'dxp-subsection-home-quote' ) || document;

		const apply = function () {
			const value = sel.value || 'quote';

			$$( '.dxp-tabs-nav .dxp-tab[data-choice]', root ).forEach( function ( btn ) {
				const show  = ( btn.getAttribute( 'data-choice' ) === value );
				const panel = $( '.dxp-tab-panel[data-tab-panel="' + btn.getAttribute( 'data-tab' ) + '"]', root );

				btn.style.display = show ? '' : 'none';
				if ( panel ) { panel.style.display = show ? '' : 'none'; }
			} );

			/* "Adım ekle" düğmesi de seçime bağlıdır. */
			$$( '.dxp-qstep-add[data-choice]', root ).forEach( function ( btn ) {
				btn.style.display = ( btn.getAttribute( 'data-choice' ) === value ) ? '' : 'none';
			} );

			/* Açık sekme gizlendiyse ilk görünür sekmeye geç. */
			const nav = $( '.dxp-tabs-nav', root );
			if ( nav ) {
				const active = $( '.dxp-tab.active', nav );
				if ( active && 'none' === active.style.display ) {
					const first = $$( '.dxp-tab', nav ).filter( function ( b ) {
						return 'none' !== b.style.display;
					} );
					if ( first.length ) { first[ 0 ].click(); }
				}
			}

			syncBuilderMounts();
		};

		sel.addEventListener( 'change', apply );
		apply();

		/*
		 * Bölüm / alt bölüm / sekme değişiminde taşımayı tazele.
		 * Yalnız sınıf değişimi izlenir; düğüm taşıma döngü yaratmaz.
		 */
		if ( window.MutationObserver ) {
			let plan = 0;
			const gozle = new MutationObserver( function () {
				if ( plan ) { return; }
				plan = requestAnimationFrame( function () {
					plan = 0;
					syncBuilderMounts();
				} );
			} );
			gozle.observe( document.getElementById( 'devxpe-panel' ) || document.body, {
				attributes: true,
				attributeFilter: [ 'class' ],
				subtree: true,
			} );
		}
	}

	/*
	 * Özel form alan oluşturucusu panelde TEK kez çizilir
	 * (Form → İletişim Formu). Teklif formu sekmesi açıkken aynı düğüm buraya
	 * taşınır, sekme kapandığında yerine geri konur. Böylece aynı alan iki kez
	 * gönderilmez; iki yer her zaman aynı veriyi gösterir.
	 */
	function syncBuilderMounts() {
		$$( '[data-dxp-builder-mount]' ).forEach( function ( mount ) {
			const slug = mount.getAttribute( 'data-dxp-builder-mount' );
			const wrap = document.querySelector( '[data-repeater="form_builder_' + slug + '"]' );
			if ( ! wrap ) { return; }

			const field = wrap.closest( '.dxp-row' ) || wrap;
			const panel = mount.closest( '.dxp-tab-panel' );
			const sub   = mount.closest( '.dxp-subsection' );
			const sec   = mount.closest( '.dxp-section' );

			/* display:none olan atanın içindeki düğümün offsetParent'i null olur. */
			const open = ( ! panel || null !== panel.offsetParent )
				&& ( ! sub || null !== sub.offsetParent )
				&& ( ! sec || null !== sec.offsetParent );

			if ( open ) {
				if ( field.parentNode !== mount ) {
					if ( ! mount.dxpGeri ) {
						mount.dxpGeri = document.createComment( 'dxp-builder-' + slug );
						field.parentNode.insertBefore( mount.dxpGeri, field );
					}
					mount.appendChild( field );
				}
				return;
			}

			if ( field.parentNode === mount && mount.dxpGeri && mount.dxpGeri.parentNode ) {
				mount.dxpGeri.parentNode.insertBefore( field, mount.dxpGeri.nextSibling );
			}
		} );
	}

	/* ── Çalışan (team) tekrarlayıcı: ekle/sil/sırala ─────── */
	function bindTeamRepeater() {
		$$( '.dxp-repeater' ).forEach( function ( wrap ) {
			/* Adım oluşturucu sonradan kopyalanan bloklar için yeniden çağırır. */
			if ( wrap.dxpBound ) { return; }
			wrap.dxpBound = true;

			const list     = wrap.querySelector( '.dxp-repeater-list' );
			const addBtn   = wrap.querySelector( '.dxp-repeater-add' );
			const template = wrap.querySelector( '.dxp-repeater-template' );
			if ( ! list || ! template ) return;

			/*
			 * İç içe tekrarlayıcılar: `data-prefix` varsa yalnızca o önekin
			 * hemen ardındaki indeks güncellenir (adım → alan iç içe yapısı).
			 */
			function reindex() {
				const prefix = wrap.getAttribute( 'data-prefix' ) || '';
				const esc    = prefix.replace( /[.*+?^${}()|[\]\\]/g, '\\$&' );
				const re     = prefix ? new RegExp( '^(' + esc + ')\\[\\d+\\]' ) : null;

				Array.from( list.children ).forEach( function ( row, i ) {
					row.querySelectorAll( '[name]' ).forEach( function ( input ) {
						const name = input.getAttribute( 'name' ) || '';
						input.setAttribute( 'name', re
							? name.replace( re, '$1[' + i + ']' )
							: name.replace( /\[\d+\]/, '[' + i + ']' ) );
					} );
				} );
			}

			function addRow() {
				const node = template.content.firstElementChild.cloneNode( true );
				node.querySelectorAll( 'input[type="text"], textarea' ).forEach( function ( i ) { i.value = ''; } );
				const prev = node.querySelector( '.dxp-image-preview' );
				if ( prev ) prev.replaceChildren();
				list.appendChild( node );
				reindex();
			}

			/* Tekrarlanan alanlar (repeater) bu kancaları kullanır. */
			wrap.dxpReindex = reindex;
			wrap.dxpAddRow  = addRow;

			list.addEventListener( 'click', function ( e ) {
				const row = e.target.closest( '.dxp-repeater-row' );
				if ( ! row ) return;
				const moving = e.target.closest( '.dxp-repeater-up, .dxp-repeater-down' );
				const animate = moving && wrap.dataset.repeater === 'custom_post_types'
					&& typeof row.animate === 'function'
					&& ! window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
				const positions = animate ? Array.from( list.children ).map( function ( item ) {
					const top = item.getBoundingClientRect().top;
					if ( item.dxpMoveAnimation ) item.dxpMoveAnimation.cancel();
					return { item: item, top: top };
				} ) : [];
				if ( e.target.closest( '.dxp-repeater-remove' ) ) {
					row.remove();
					reindex();
				} else if ( e.target.closest( '.dxp-repeater-up' ) ) {
					const p = row.previousElementSibling;
					if ( p ) { list.insertBefore( row, p ); reindex(); }
				} else if ( e.target.closest( '.dxp-repeater-down' ) ) {
					const n = row.nextElementSibling;
					if ( n ) { list.insertBefore( n, row ); reindex(); }
				}
				if ( moving ) moving.focus( { preventScroll: true } );
				positions.forEach( function ( entry ) {
					const distance = entry.top - entry.item.getBoundingClientRect().top;
					if ( ! distance ) return;
					entry.item.dxpMoveAnimation = entry.item.animate(
						[ { transform: 'translateY(' + distance + 'px)' }, { transform: 'translateY(0)' } ],
						{ duration: 200, easing: 'ease-out' }
					);
				} );
			} );

			if ( addBtn ) addBtn.addEventListener( 'click', addRow );

			/*
			 * Alan türü değişince satırın data-type'ını güncelle; "Açılır liste"
			 * seçilince Seçenekler kutusu görünür (bkz. panel.css).
			 */
			list.addEventListener( 'change', function ( e ) {
				if ( e.target.classList && e.target.classList.contains( 'dxp-field-type' ) ) {
					const row = e.target.closest( '.dxp-repeater-row' );
					if ( row ) row.setAttribute( 'data-type', e.target.value );
				}
			} );

			/*
			 * İçerik tipi (CPT) slug'ı: yazarken Türkçe karakterleri otomatik
			 * çevir; ne görünüyorsa o kaydedilir. Yalnızca CPT tekrarlayıcısında.
			 */
			if ( 'custom_post_types' === wrap.getAttribute( 'data-repeater' ) ) {
				list.addEventListener( 'input', function ( e ) {
					const el = e.target;
					if ( ! el || 'INPUT' !== el.tagName || ! String( el.name || '' ).endsWith( '[slug]' ) ) return;

					const onceki = el.value;
					const sonraki = turkceSlug( onceki );
					if ( sonraki === onceki ) return;

					/* İmleci koru: uzunluk değişimini kaydır. */
					let imlec = typeof el.selectionStart === 'number' ? el.selectionStart : onceki.length;
					if ( imlec > onceki.length ) imlec = onceki.length;
					el.value = sonraki;
					const hedef = Math.max( 0, imlec + ( sonraki.length - onceki.length ) );
					try { el.setSelectionRange( hedef, hedef ); } catch {}
				} );
			}

			/*
			 * Sekmeli tekrarlayıcılar:
			 *  - Manuel Projeler / Yorumlar / SSS / Hizmetler: her öğe bir SEKMEDE
			 *    (1 2 3 4 …). Sayaç çubuğu (− N +) ALAN BAŞLIĞININ KARŞISINDA
			 *    (sağda) durur; + ekler, − seçiliyi siler ("Kart/Satır Ekle" yok).
			 *  - Neden Biz maddeleri + Nasıl Çalışır adımları: SABİT 1..5 sekme
			 *    (eksikler boş satırla tamamlanır); ekle/sil butonu YOKTUR
			 *    (5'e kadar doldurulur).
			 * Yalnızca seçili öğe görünür → sayfa aşağı uzamaz.
			 */
			const repId        = wrap.getAttribute( 'data-repeater' );
			const tabbedList   = ( 'projects_items' === repId || 'reviews_items' === repId || 'faq_items' === repId || 'services_cards' === repId );
			const tabbedFixed  = ( 'features_items' === repId || 'steps_items' === repId ); /* sabit 1..5, ekle/sil yok */
			if ( tabbedList || tabbedFixed ) {
				const withMove = tabbedList; /* + / − yalnız liste tipinde */

				const tabs = document.createElement( 'div' );
				tabs.className = 'dxp-repeater-tabs';
				tabs.setAttribute( 'role', 'tablist' );
				list.parentNode.insertBefore( tabs, list );

				/*
				 * Sayaç çubuğu (− N +): ALAN BAŞLIĞININ KARŞISINDA (sağda) durur.
				 */
				let topBar = null;
				if ( withMove ) {
					topBar = document.createElement( 'div' );
					topBar.className = 'dxp-repeater-tabbar';
					const rowEl   = wrap.closest( '.dxp-row' );
					const labelEl = rowEl ? rowEl.querySelector( '.dxp-label' ) : null;
					if ( labelEl ) {
						labelEl.classList.add( 'dxp-label--with-tabs' );
						labelEl.appendChild( topBar );
					} else {
						list.parentNode.insertBefore( topBar, tabs );
					}
				}

				let activeRow = null;

				const rowsOf = function () {
					return Array.prototype.filter.call( list.children, function ( r ) {
						return r.classList && r.classList.contains( 'dxp-repeater-row' );
					} );
				};

				/* Şablondan boş bir satır üretir. */
				const bosSatir = function () {
					const node = template.content.firstElementChild.cloneNode( true );
					node.querySelectorAll( 'input[type="text"], textarea' ).forEach( function ( inp ) { inp.value = ''; } );
					const prev = node.querySelector( '.dxp-image-preview' );
					if ( prev ) { prev.replaceChildren(); }
					return node;
				};

				/* Yeni satır ekle (sonuna) ve onu seç. */
				const ekle = function () {
					const node = bosSatir();
					list.appendChild( node );
					activeRow = node;
					reindex();
					refresh();
				};

				/* Seçili satırı (yoksa sonuncuyu) sil. */
				const sil = function () {
					const mevcut = rowsOf();
					if ( ! mevcut.length ) { return; }
					const row = ( activeRow && mevcut.indexOf( activeRow ) !== -1 ) ? activeRow : mevcut[ mevcut.length - 1 ];
					const idx = mevcut.indexOf( row );
					row.remove();
					reindex();
					const kalan = rowsOf();
					activeRow = kalan.length ? kalan[ Math.min( idx, kalan.length - 1 ) ] : null;
					refresh();
				};

				/* Küçük yuvarlak buton üretici (+, − ve benzeri). */
				const kucukBtn = function ( metin, sinif, etiket, fn, kapali ) {
					const b = document.createElement( 'button' );
					b.type = 'button';
					b.className = sinif;
					b.textContent = metin;
					b.title = etiket;
					b.setAttribute( 'aria-label', etiket );
					b.disabled = !! kapali;
					b.addEventListener( 'click', fn );
					return b;
				};

				const refresh = function () {
					/* Neden Biz + Nasıl Çalışır: sabit 1..5 — eksikleri boş satırla
					   tamamla (ekle/sil yok; ön yüz boş maddeleri göstermez). */
					if ( tabbedFixed ) {
						let n = rowsOf().length;
						if ( n < 5 ) {
							while ( n < 5 ) { list.appendChild( bosSatir() ); n++; }
							reindex();
						}
					}

					const rows = rowsOf();
					tabs.replaceChildren();
					if ( topBar ) { topBar.replaceChildren(); }

					if ( rows.length && ( ! activeRow || rows.indexOf( activeRow ) === -1 ) ) { activeRow = rows[ 0 ]; }
					if ( ! rows.length ) { activeRow = null; }

					rows.forEach( function ( row, i ) {
						const b = document.createElement( 'button' );
						b.type = 'button';
						b.className = 'dxp-repeater-tab';
						b.textContent = String( i + 1 );
						b.setAttribute( 'aria-selected', row === activeRow ? 'true' : 'false' );
						if ( row === activeRow ) { b.classList.add( 'is-active' ); }
						b.addEventListener( 'click', function () { activeRow = row; refresh(); } );
						tabs.appendChild( b );
						row.classList.toggle( 'is-active', row === activeRow );
					} );

					/* + / − yalnız liste tipinde (maddeler/adımlar sabit: ekle/sil yok). */
					if ( ! withMove || ! topBar ) { return; }

					/* Sayaç çubuğu: −  N  +  (alan başlığının karşısında). */
					topBar.appendChild( kucukBtn( '−', 'dxp-repeater-count-btn dxp-repeater-count-btn--minus', 'Seçiliyi sil', sil, ! rows.length ) );
					const sayi = document.createElement( 'span' );
					sayi.className = 'dxp-repeater-count';
					sayi.textContent = String( rows.length );
					topBar.appendChild( sayi );
					topBar.appendChild( kucukBtn( '+', 'dxp-repeater-count-btn dxp-repeater-count-btn--plus', 'Yeni ekle', ekle, false ) );
				};

				new MutationObserver( refresh ).observe( list, { childList: true } );
				wrap.dxpRefreshTabs = refresh;

				/* Liste tipinde ekleme + butonundan yapılır; eski "ekle" butonu gizlenir.
				   Adımlarda normal "+ Adım Ekle"; Neden Biz'de ekle/sil yoktur. */
				if ( ( withMove || tabbedFixed ) && addBtn ) { addBtn.hidden = true; }
			}

			/* Yükleme sonrası indeksleri düzelt (sunucudan gelen satırlar için) */
			reindex();
			if ( wrap.dxpRefreshTabs ) { wrap.dxpRefreshTabs(); }
		} );
	}

	/* ── Teklif formu adım oluşturucusu (Genel | 1 2 3 | +) ── */
	function bindQuoteSteps() {
		$$( '.dxp-qbuilder' ).forEach( function ( root ) {
			if ( root.dxpBound ) { return; }
			root.dxpBound = true;

			const nav       = $( '.dxp-tabs-nav', root );
			const addBtn    = $( '.dxp-qstep-add', root );
			const panelsBox = $( '.dxp-qstep-panels', root );
			const tabTpl    = $( '.dxp-qstep-tab-template', root );
			const panelTpl  = $( '.dxp-qstep-panel-template', root );
			if ( ! nav || ! panelsBox ) { return; }

			/*
			 * Şablon içeriği dâhil tüm düğümleri gezer. Adım şablonu kopyalanınca
			 * içindeki alan oluşturucu şablonunun adları da güncellenmelidir.
			 */
			function eachNode( node, fn ) {
				const walk = function ( cur ) {
					if ( ! cur ) { return; }
					if ( 1 === cur.nodeType ) {
						fn( cur );
						if ( 'TEMPLATE' === cur.tagName && cur.content ) { walk( cur.content ); }
					}
					Array.prototype.forEach.call( cur.childNodes || [], function ( child ) {
						if ( 1 === child.nodeType || 11 === child.nodeType ) { walk( child ); }
					} );
				};
				walk( node );
			}

			function replaceToken( node, token, deger ) {
				eachNode( node, function ( el ) {
					Array.prototype.forEach.call( el.attributes || [], function ( attr ) {
						if ( attr.value.indexOf( token ) !== -1 ) {
							attr.value = attr.value.split( token ).join( deger );
						}
					} );
				} );
			}

			function stepTabs() { return $$( '.dxp-tab[data-step]', nav ); }
			function stepPanels() { return $$( '.dxp-tab-panel[data-step]', panelsBox ); }

			/* Buton yazıları yalnızca son adım sekmesinde durur. */
			function moveButtons() {
				const block  = $( '[data-dxp-step-buttons]', root );
				const panels = stepPanels();
				const last   = panels[ panels.length - 1 ];
				if ( block && last && block.parentNode !== last ) { last.appendChild( block ); }
			}

			function reindex() {
				stepPanels().forEach( function ( panel, i ) {
					panel.setAttribute( 'data-step', String( i ) );
					panel.setAttribute( 'data-tab-panel', 'step' + i );

					eachNode( panel, function ( el ) {
						if ( el.hasAttribute( 'name' ) ) {
							el.setAttribute( 'name', el.getAttribute( 'name' ).replace( /\[form_steps\]\[[^\]]+\]/, '[form_steps][' + i + ']' ) );
						}
						if ( el.hasAttribute( 'data-prefix' ) ) {
							el.setAttribute( 'data-prefix', el.getAttribute( 'data-prefix' ).replace( /\[form_steps\]\[[^\]]+\]/, '[form_steps][' + i + ']' ) );
						}
					} );
				} );

				const tabs = stepTabs();
				tabs.forEach( function ( tab, i ) {
					tab.setAttribute( 'data-step', String( i ) );
					tab.setAttribute( 'data-tab', 'step' + i );
					const n = $( '.dxp-qstep-num', tab );
					if ( n ) { n.textContent = String( i + 1 ); }
					const d = $( '.dxp-qstep-del', tab );
					if ( d ) { d.classList.toggle( 'is-disabled', tabs.length <= 1 ); }
				} );

				moveButtons();
			}

			if ( addBtn && tabTpl && panelTpl ) {
				addBtn.addEventListener( 'click', function () {
					const mevcut = stepPanels();
					const sekmeler = stepTabs();
					const i       = mevcut.length;
					const tab     = tabTpl.content.firstElementChild.cloneNode( true );
					const panel   = panelTpl.content.firstElementChild.cloneNode( true );

					replaceToken( tab, '__STEP__', String( i ) );
					replaceToken( panel, '__STEP__', String( i ) );

					/*
					 * Son adım (özet/gönder) her zaman son kalır; yeni adım ondan
					 * ÖNCE eklenir. Böylece buton yazıları son adımda sabit kalır.
					 */
					const sonSekme = sekmeler.length ? sekmeler[ sekmeler.length - 1 ] : null;
					const sonPanel = mevcut.length ? mevcut[ mevcut.length - 1 ] : null;

					if ( sonSekme ) {
						nav.insertBefore( tab, sonSekme );
					} else {
						nav.insertBefore( tab, addBtn );
					}

					if ( sonPanel ) {
						panelsBox.insertBefore( panel, sonPanel );
					} else {
						panelsBox.appendChild( panel );
					}

					reindex();

					/* Yeni adımın alan oluşturucusunu bağla (yalnızca yeni blok). */
					bindTeamRepeater();
					tab.click();

					const title = $( '[data-dxp-step-title]', panel );
					if ( title ) { title.focus(); }
				} );
			}

			nav.addEventListener( 'click', function ( e ) {
				const del = e.target.closest( '.dxp-qstep-del' );
				if ( ! del ) { return; }
				e.preventDefault();
				e.stopPropagation();

				const tabs = stepTabs();
				if ( tabs.length <= 1 || del.classList.contains( 'is-disabled' ) ) { return; }

				const tab = del.closest( '.dxp-tab[data-step]' );

				/* Son adım (Son/Last) her zaman son kalır ve silinemez. */
				if ( ! tab || tab === tabs[ tabs.length - 1 ] ) { return; }

				const panel     = tab ? $( '.dxp-tab-panel[data-step="' + tab.getAttribute( 'data-step' ) + '"]', panelsBox ) : null;
				const wasActive = tab && tab.classList.contains( 'active' );
				const fallback  = tab && tab.nextElementSibling && tab.nextElementSibling.matches( '.dxp-tab[data-step]' )
					? tab.nextElementSibling
					: ( tab ? tab.previousElementSibling : null );

				/* Buton yazıları son adımla birlikte silinmesin: önce ayır. */
				const buttons = panel ? $( '[data-dxp-step-buttons]', panel ) : null;
				if ( buttons && buttons.parentNode ) { buttons.parentNode.removeChild( buttons ); }

				if ( tab ) { tab.remove(); }
				if ( panel ) { panel.remove(); }

				/* Ayırılan buton yazılarını yeni son adıma bağla. */
				if ( buttons ) {
					const kalan = stepPanels();
					const son   = kalan[ kalan.length - 1 ];
					if ( son ) { son.appendChild( buttons ); }
				}

				reindex();

				if ( wasActive && fallback ) {
					fallback.click();
				} else if ( ! $( '.dxp-tab[data-step].active', nav ) ) {
					const first = $( '.dxp-tab[data-step]', nav );
					if ( first ) { first.click(); } else { const g = $( '.dxp-tab', nav ); if ( g ) { g.click(); } }
				}
			} );

			/* Klavye ile adım silme (× role=button). */
			nav.addEventListener( 'keydown', function ( e ) {
				const del = e.target.closest( '.dxp-qstep-del' );
				if ( del && ( 'Enter' === e.key || ' ' === e.key ) ) {
					e.preventDefault();
					del.click();
				}
			} );

			reindex();
		} );
	}

	/* ── Seçenek alt-tekrarlayıcısı: ekle/sil/sırala ─────────────── */
	/*
	 * Her satır bir öneri. Görsel liste üzerinde çalışılır; gerçek değer
	 * gizli `.dxp-opt-value` input'una virgülle ayrılmış string olarak yazılır
	 * (veri modeli değişmez). Olay delegasyonu olduğu için sonradan eklenen
	 * dış satırlar da otomatik çalışır.
	 */
	function syncOptions( field ) {
		if ( ! field ) return;
		const hidden = field.querySelector( '.dxp-opt-value' );
		if ( ! hidden ) return;

		const values = $$( '.dxp-opt-input', field )
			.map( function ( input ) { return input.value.replace( /,/g, ' ' ).trim(); } )
			.filter( function ( v ) { return '' !== v; } );

		hidden.value = values.join( ',' );
	}

	function makeOptItem() {
		const item = document.createElement( 'div' );
		item.className = 'dxp-opt-item';

		const input = document.createElement( 'input' );
		input.type = 'text';
		input.className = 'dxp-opt-input';
		input.setAttribute( 'list', 'dxp-options-templates' );
		input.autocomplete = 'off';

		const yukari = document.createElement( 'button' );
		yukari.type = 'button';
		yukari.className = 'dxp-opt-up';
		yukari.title = 'Yukarı Taşı';
		yukari.textContent = '↑';

		const asagi = document.createElement( 'button' );
		asagi.type = 'button';
		asagi.className = 'dxp-opt-down';
		asagi.title = 'Aşağı Taşı';
		asagi.textContent = '↓';

		const sil = document.createElement( 'button' );
		sil.type = 'button';
		sil.className = 'dxp-opt-remove';
		sil.title = 'Sil';
		sil.textContent = '×';

		item.append( input, yukari, asagi, sil );
		return item;
	}

	function bindOptionsRepeaters() {
		document.addEventListener( 'click', function ( e ) {
			const add = e.target.closest( '.dxp-opt-add' );
			if ( add ) {
				const field = add.closest( '.dxp-field-options' );
				if ( ! field ) return;
				const list = field.querySelector( '.dxp-opt-list' );
				const item = makeOptItem();
				list.appendChild( item );
				item.querySelector( '.dxp-opt-input' ).focus();
				syncOptions( field );
				return;
			}

			const remove = e.target.closest( '.dxp-opt-remove' );
			if ( remove ) {
				const field = remove.closest( '.dxp-field-options' );
				const item  = remove.closest( '.dxp-opt-item' );
				if ( field && item ) { item.remove(); syncOptions( field ); }
				return;
			}

			const up = e.target.closest( '.dxp-opt-up' );
			if ( up ) {
				const field = up.closest( '.dxp-field-options' );
				const item  = up.closest( '.dxp-opt-item' );
				if ( field && item && item.previousElementSibling ) {
					field.querySelector( '.dxp-opt-list' ).insertBefore( item, item.previousElementSibling );
					syncOptions( field );
				}
				return;
			}

			const down = e.target.closest( '.dxp-opt-down' );
			if ( down ) {
				const field = down.closest( '.dxp-field-options' );
				const item  = down.closest( '.dxp-opt-item' );
				if ( field && item && item.nextElementSibling ) {
					field.querySelector( '.dxp-opt-list' ).insertBefore( item.nextElementSibling, item );
					syncOptions( field );
				}
			}
		} );

		/* Yazarken virgülü engelle (virgül ayırıcıdır) ve gizli değeri güncelle. */
		document.addEventListener( 'input', function ( e ) {
			const input = e.target;
			if ( ! input.classList || ! input.classList.contains( 'dxp-opt-input' ) ) return;
			if ( input.value.indexOf( ',' ) !== -1 ) {
				input.value = input.value.replace( /,/g, ' ' );
			}
			syncOptions( input.closest( '.dxp-field-options' ) );
		} );

		/* Sunucudan gelen görsel satırları gizli değerle eşitle. */
		$$( '.dxp-field-options' ).forEach( syncOptions );
	}

	/* ── Kart başlığına tıklayınca daralt / genişlet ─────── */
	function bindCollapse() {
		const form = $( '#devxpe-panel-form' );
		if ( ! form ) return;

		form.addEventListener( 'click', function ( e ) {
			const header = e.target.closest( '.dxp-card-header' );
			if ( ! header ) return;
			const card = header.closest( '.dxp-card' );
			if ( ! card ) return;
			const collapsed = card.classList.toggle( 'is-collapsed' );
			header.setAttribute( 'aria-expanded', collapsed ? 'false' : 'true' );
		} );
	}

	/* ── Sekmeli bölüm (Header | Footer) ──────────────────── */
	function bindTabs() {
		const form = $( '#devxpe-panel-form' );
		if ( ! form ) return;

		form.addEventListener( 'click', function ( e ) {
			const btn = e.target.closest( '.dxp-tab' );
			if ( ! btn ) return;
			const wrap = btn.closest( '.dxp-tabs' );
			if ( ! wrap ) return;
			const id = btn.getAttribute( 'data-tab' );
			/*
			 * İç içe sekmeler (ör. Footer → Genel | 2. Sütun | 3. Sütun):
			 * yalnızca BU sarmalayıcıya ait sekmeler/paneller değişir; alt
			 * seviye sekmeler etkilenmez (closest ile kapsam sınırlanır).
			 */
			$$( '.dxp-tab', wrap ).forEach( function ( b ) {
				if ( b.closest( '.dxp-tabs' ) !== wrap ) return;
				b.classList.toggle( 'active', b === btn );
			} );
			$$( '.dxp-tab-panel', wrap ).forEach( function ( p ) {
				if ( p.closest( '.dxp-tabs' ) !== wrap ) return;
				p.classList.toggle( 'active', p.getAttribute( 'data-tab-panel' ) === id );
			} );
		} );
	}

	/* ── Sayfa çoklu seçim: seçilenler önce + sıralama ─────── */
	function bindPagesOrder() {
		const form = $( '#devxpe-panel-form' );
		if ( ! form ) return;

		/* Seçilenler grubuna taşı (yeni işaretlenen en sona eklenir). */
		function toSelected( row ) {
			const list = row.parentElement;
			const sel  = $$( '.dxp-pages-option.is-selected', list );
			const last = sel[ sel.length - 1 ];
			if ( last && last !== row ) {
				list.insertBefore( row, last.nextSibling );
			}
		}

		form.addEventListener( 'change', function ( e ) {
			const cb = e.target;
			if ( ! cb.matches || ! cb.matches( '.dxp-pages-option input[type="checkbox"]' ) ) return;
			const row = cb.closest( '.dxp-pages-option' );
			if ( ! row ) return;
			row.classList.toggle( 'is-selected', cb.checked );
			if ( cb.checked ) { toSelected( row ); }
		} );

		form.addEventListener( 'click', function ( e ) {
			const btn = e.target.closest( '.dxp-pages-up, .dxp-pages-down' );
			if ( ! btn ) return;
			e.preventDefault();
			const row = btn.closest( '.dxp-pages-option' );
			if ( ! row ) return;
			const list = row.parentElement;
			const sel  = $$( '.dxp-pages-option.is-selected', list );
			const i    = sel.indexOf( row );
			if ( i < 0 ) return;
			const isUp = btn.classList.contains( 'dxp-pages-up' );
			const j    = i + ( isUp ? -1 : 1 );
			if ( j < 0 || j >= sel.length ) return;
			const other = sel[ j ];
			if ( isUp ) {
				list.insertBefore( row, other );
			} else {
				list.insertBefore( other, row );
			}
		} );
	}

	/* ── Menü kaynağı: "Görünecek Öğeler" listesini anında yenile ── */
	function bindNavItems() {
		const form = $( '#devxpe-panel-form' );
		if ( ! form ) return;

		function refresh( input ) {
			if ( ! input || ! input.name || ! /_source\]?$/.test( input.name ) ) return;

			const id = input.name
				.replace( /^devxpe_theme_options\[/, '' )
				.replace( /\]$/, '' )
				.replace( /_source$/, '_items' );
			if ( ! /^[a-z0-9_]+$/i.test( id ) ) return;
			const wrap = form.querySelector( '[data-nav-items="' + id + '"]' );
			if ( ! wrap ) return;

			/*
			 * Menü listeleri önceden basılmıştır: yalnız görünür paneli
			 * değiştir. Böylece kaydetmeden anında geçiş olur.
			 */
			const panels = wrap.querySelectorAll( '.dxp-nav-panel' );
			let eslesti   = false;
			panels.forEach( function ( p ) {
				const on = p.getAttribute( 'data-nav-source' ) === input.value;
				p.style.display = on ? '' : 'none';
				/* Gizli kaynağın seçimleri kayda karışmasın. */
				p.querySelectorAll( 'input' ).forEach( function ( i ) { i.disabled = ! on; } );
				if ( on ) eslesti = true;
			} );
			if ( eslesti ) return;

			const nonceEl = form.querySelector( '[name="devxpe_theme_nonce"]' );
			const fd      = new FormData();
			fd.append( 'action', 'devxpe_nav_items' );
			fd.append( 'nonce', nonceEl ? nonceEl.value : '' );
			fd.append( 'field', id );
			fd.append( 'source', input.value );

			wrap.classList.add( 'is-loading' );
			wrap.setAttribute( 'aria-busy', 'true' );

			fetch( window.ajaxurl, { method: 'POST', credentials: 'same-origin', body: fd } )
				.then( function ( r ) { return r.json(); } )
				.then( function ( res ) {
					if ( ! res || ! res.success || ! res.data || ! res.data.html ) return;
					wrap.outerHTML = res.data.html;
				} )
				.catch( function () {
					if ( window.console ) { console.warn( 'Menü öğeleri yüklenemedi.' ); }
				} )
				.finally( function () {
					const yeni = form.querySelector( '[data-nav-items="' + id + '"]' );
					if ( yeni ) {
						yeni.classList.remove( 'is-loading' );
						yeni.removeAttribute( 'aria-busy' );
					}
				} );
		}

		form.addEventListener( 'change', function ( e ) { refresh( e.target ); } );

		/* Özel dropdown tıklaması: değer yazıldıktan sonra bir kez daha senkronla. */
		form.addEventListener( 'click', function ( e ) {
			const item = e.target.closest( '.dxp-select-item' );
			if ( ! item ) return;

			const box  = item.closest( '.dxp-select' );
			const valEl = box ? box.querySelector( '.dxp-select-value' ) : null;
			if ( ! valEl ) return;

			window.setTimeout( function () { refresh( valEl ); }, 0 );
		} );
	}

	/* ── Dil değiştirici (özel dropdown) ──────────────────── */
	function bindLangSwitch() {
		const sw = $( '.dxp-lang-switch' );
		if ( ! sw ) return;

		const trigger = sw.querySelector( '.dxp-lang-trigger' );
		const menu    = sw.querySelector( '.dxp-lang-menu' );
		const value   = sw.querySelector( '.dxp-lang-value' );
		if ( ! trigger || ! menu || ! value ) return;

		trigger.addEventListener( 'click', function ( e ) {
			e.stopPropagation();
			menu.hidden = ! menu.hidden;
			trigger.setAttribute( 'aria-expanded', menu.hidden ? 'false' : 'true' );
		} );

		menu.addEventListener( 'click', function ( e ) {
			const item = e.target.closest( '.dxp-lang-item' );
			if ( ! item ) return;
			value.value = item.getAttribute( 'data-lang' );
			if ( sw.submit ) { sw.submit(); }
		} );

		document.addEventListener( 'click', function ( e ) {
			if ( ! e.target.closest( '.dxp-lang-switch' ) ) {
				menu.hidden = true;
				trigger.setAttribute( 'aria-expanded', 'false' );
			}
		} );
	}

	/*
	 * Açılır menüyü görünüme sabitler (position: fixed). Böylece kartların
	 * overflow:hidden'ı ve içerik scroll alanı menüyü kırpmaz. Sığmazsa
	 * menüyü tetikleyicinin üstüne yerleştirir.
	 */
	function floatMenu( menu, trigger, matchWidth ) {
		if ( ! menu || ! trigger ) return;

		const r  = trigger.getBoundingClientRect();
		const mh = menu.offsetHeight;
		const mw = menu.offsetWidth;
		const vh = window.innerHeight;
		const vw = window.innerWidth;

		let top = r.bottom + 4;
		if ( top + mh > vh - 8 ) {
			top = r.top - mh - 4;
		}
		if ( top < 8 ) top = 8;

		let left = r.left;
		if ( left + mw > vw - 8 ) left = vw - mw - 8;
		if ( left < 8 ) left = 8;

		menu.classList.add( 'dxp-floating' );
		menu.style.position  = 'fixed';
		menu.style.top       = top + 'px';
		menu.style.left      = left + 'px';
		menu.style.zIndex    = '100000';
		menu.style.maxHeight = Math.max( 160, vh - top - 12 ) + 'px';
		if ( matchWidth ) menu.style.minWidth = r.width + 'px';
	}

	/*
	 * Açık menüleri, içerik alanı kaydırılınca veya pencere yeniden
	 * boyutlandırılınca kapatır (konum bayatlamasın).
	 */
	function bindMenuAutoClose( closeAll ) {
		const scroller = document.querySelector( '#devxpe-panel-right .dxp-content' );
		if ( scroller ) scroller.addEventListener( 'scroll', closeAll, { passive: true } );
		window.addEventListener( 'resize', closeAll );
	}

	/* ── Özel açılır menüler (native select yerine) ───────── */
	function bindSelects() {
		const form = $( '#devxpe-panel-form' );
		if ( ! form ) return;

		function closeAll() {
			$$( '.dxp-select-menu', form ).forEach( function ( m ) { m.hidden = true; } );
			$$( '.dxp-select-trigger', form ).forEach( function ( t ) { t.setAttribute( 'aria-expanded', 'false' ); } );
		}

		bindMenuAutoClose( closeAll );

		form.addEventListener( 'click', function ( e ) {
			const trigger = e.target.closest( '.dxp-select-trigger' );
			if ( trigger ) {
				const wrap = trigger.closest( '.dxp-select' );
				const menu = wrap.querySelector( '.dxp-select-menu' );
				const isOpen = ! menu.hidden;
				closeAll();
				if ( ! isOpen ) {
					menu.hidden = false;
					trigger.setAttribute( 'aria-expanded', 'true' );
					floatMenu( menu, trigger, true );
				}
				return;
			}

			const item = e.target.closest( '.dxp-select-item' );
			if ( item ) {
				const wrap2 = item.closest( '.dxp-select' );
				const val   = item.getAttribute( 'data-value' );

				const valEl = wrap2.querySelector( '.dxp-select-value' );
				if ( valEl ) {
					valEl.value = val;
					/* Koşul kaynağı alanlar (bindConditionSubmit) bu olayı dinler. */
					valEl.dispatchEvent( new Event( 'change', { bubbles: true } ) );
				}

				const target = wrap2.getAttribute( 'data-target' );
				if ( target ) {
					const t = document.getElementById( target );
					if ( t ) t.value = val;
				}

				const cur = wrap2.querySelector( '.dxp-select-current' );
				if ( cur ) cur.textContent = item.textContent.trim();

				$$( '.dxp-select-item', wrap2 ).forEach( function ( i ) {
					i.classList.toggle( 'is-selected', i === item );
					i.setAttribute( 'aria-selected', i === item ? 'true' : 'false' );
				} );
				closeAll();
			}
		} );

		document.addEventListener( 'click', function ( e ) {
			if ( ! e.target.closest( '.dxp-select' ) ) {
				closeAll();
			}
		} );
	}

	
	/* ── Kısa kod kopyala düğmeleri ───────────────────────── */
	/* ── Çoklu seçim (ülke) ────────────────────────────────────────── */
	function bindMultiselect() {
		const form = $( '#devxpe-panel-form' );
		if ( ! form ) return;

		function closeAll() {
			$$( '.dxp-multiselect-menu', form ).forEach( function ( m ) { m.hidden = true; } );
			$$( '.dxp-multiselect-trigger', form ).forEach( function ( t ) { t.setAttribute( 'aria-expanded', 'false' ); } );
		}

		bindMenuAutoClose( closeAll );

		/*
		 * Seçili onay kutularından ve listede olmayan gizli (legacy/özel)
		 * kayıtlardan özet + sayı üret. Menü açıkken de çağrılır; kapanmaz.
		 */
		function update( wrap ) {
			if ( ! wrap ) return;
			const parts = [];

			$$( 'input[type="checkbox"]:checked', wrap ).forEach( function ( cb ) {
				const item = cb.closest( '.dxp-multiselect-item' );
				const nameEl = item ? item.querySelector( '.dxp-multiselect-name' ) : null;
				const name = nameEl ? nameEl.textContent.trim() : '';
				parts.push( cb.value + ( name ? ' ' + name : '' ) );
			} );

			/* Gizli değer biçimi: "kod|Ad". */
			$$( 'input[type="hidden"]', wrap ).forEach( function ( h ) {
				const raw  = h.value || '';
				const sep  = raw.indexOf( '|' );
				const code = sep === -1 ? raw : raw.slice( 0, sep );
				const name = sep === -1 ? '' : raw.slice( sep + 1 );
				parts.push( code + ( name ? ' ' + name : '' ) );
			} );

			const summary = wrap.querySelector( '.dxp-multiselect-summary' );
			const count   = wrap.querySelector( '.dxp-multiselect-count' );
			const empty   = wrap.getAttribute( 'data-placeholder' ) || '';

			if ( summary ) summary.textContent = parts.length ? parts.join( ', ' ) : empty;
			if ( count ) count.textContent = parts.length ? String( parts.length ) : '';
		}

		function filter( wrap, term ) {
			const terms = term ? term.toLowerCase().split( /\s+/ ).filter( Boolean ) : [];
			let shown = 0;

			$$( '.dxp-multiselect-item', wrap ).forEach( function ( it ) {
				const codeEl = it.querySelector( '.dxp-multiselect-code' );
				const nameEl = it.querySelector( '.dxp-multiselect-name' );
				const hay = ( ( codeEl ? codeEl.textContent : '' ) + ' ' + ( nameEl ? nameEl.textContent : '' ) ).toLowerCase();

				/* Yazılan tüm kelimeler kod veya ad içinde geçmeli (sırasız). */
				const match = ! terms.length || terms.every( function ( t ) {
					return hay.indexOf( t ) !== -1;
				} );

				it.hidden = ! match;
				if ( match ) shown++;
			} );

			const empty = wrap.querySelector( '.dxp-multiselect-empty' );
			if ( empty ) empty.hidden = shown > 0;
		}

		form.addEventListener( 'click', function ( e ) {
			const trigger = e.target.closest( '.dxp-multiselect-trigger' );
			if ( ! trigger ) return;

			const wrap   = trigger.closest( '.dxp-multiselect' );
			const menu   = wrap.querySelector( '.dxp-multiselect-menu' );
			const isOpen = ! menu.hidden;
			closeAll();
			if ( ! isOpen ) {
				menu.hidden = false;
				trigger.setAttribute( 'aria-expanded', 'true' );
				floatMenu( menu, trigger, true );
				const s = menu.querySelector( '.dxp-multiselect-search' );
				if ( s ) { s.value = ''; filter( wrap, '' ); s.focus(); }
			}
		} );

		/* Onay kutusu değişimi: özet/sayı güncelle, menüyü KAPATMA. */
		form.addEventListener( 'change', function ( e ) {
			if ( e.target.matches && e.target.matches( '.dxp-multiselect-list input[type="checkbox"]' ) ) {
				update( e.target.closest( '.dxp-multiselect' ) );
			}
		} );

		form.addEventListener( 'input', function ( e ) {
			const s = e.target;
			if ( s.classList && s.classList.contains( 'dxp-multiselect-search' ) ) {
				filter( s.closest( '.dxp-multiselect' ), s.value.trim().toLowerCase() );
			}
		} );

		document.addEventListener( 'click', function ( e ) {
			if ( ! e.target.closest( '.dxp-multiselect' ) ) {
				closeAll();
			}
		} );

		document.addEventListener( 'keydown', function ( e ) {
			if ( 'Escape' === e.key ) {
				closeAll();
			}
		} );

		/* Sunucudan gelen başlangıç durumunu DOM ile eşitle. */
		$$( '.dxp-multiselect', form ).forEach( update );
	}

	/*
	 * Panoya kopyalama: güvenli bağlamda (HTTPS/localhost) Clipboard API;
	 * aksi hâlde (ör. HTTP IP adresi) gizli textarea + execCommand yedeği.
	 * Yedek olmadan HTTP sitelerde buton sessizce hiçbir şey yapmıyordu.
	 */
	function copyText( text ) {
		text = String( text || '' );

		if ( navigator.clipboard && window.isSecureContext && navigator.clipboard.writeText ) {
			return navigator.clipboard.writeText( text );
		}

		return new Promise( function ( resolve, reject ) {
			const ta = document.createElement( 'textarea' );
			ta.value = text;
			ta.setAttribute( 'readonly', '' );
			ta.style.position = 'fixed';
			ta.style.top      = '-1000px';
			ta.style.opacity  = '0';
			document.body.appendChild( ta );
			ta.select();

			let ok = false;
			try { ok = document.execCommand( 'copy' ); } catch { ok = false; }

			document.body.removeChild( ta );
			if ( ok ) { resolve(); } else { reject( new Error( 'copy-unsupported' ) ); }
		} );
	}

	function bindCopyButtons() {
		$$( '.dxp-copy-btn' ).forEach( function ( btn ) {
			if ( btn.dataset.bound ) { return; }
			btn.dataset.bound = '1';
			btn.addEventListener( 'click', function () {
				const old = btn.textContent;
				copyText( btn.getAttribute( 'data-copy' ) ).then( function () {
					btn.textContent = '✓ ' + old;
					setTimeout( function () { btn.textContent = old; }, 1200 );
				} ).catch( function () {
					btn.textContent = '⚠ ' + old;
					setTimeout( function () { btn.textContent = old; }, 1600 );
				} );
			} );
		} );
	}

	/* ── Karakter sayacı (maxlength'li alanlar) ───────────── */
	function bindCharCount() {
		const counters = $$( '.dxp-charcount' );
		if ( ! counters.length ) return;

		counters.forEach( function ( el ) {
			const field = document.getElementById( el.getAttribute( 'data-for' ) );
			const max   = parseInt( el.getAttribute( 'data-max' ), 10 ) || 0;
			if ( ! field || ! max ) return;

			function update() {
				const len = field.value.length;
				el.textContent = len + ' / ' + max;
				el.classList.toggle( 'is-over', len >= max );
			}

			field.addEventListener( 'input', update );
			update();
		} );
	}

	/* ── Anasayfa iskeleti (sürükle-bırak sıralama) ───────── */
	/* ── İskelet yerleşimi: yan yana bölümler yarım genişlikte ─ */
	function layoutSkeleton( list, splitIds ) {
		Array.from( list.querySelectorAll( '.dxp-skeleton-slot' ) ).forEach( function ( slot ) { slot.remove(); } );

		const items = Array.from( list.children ).filter( function ( el ) {
			return el.classList.contains( 'dxp-skeleton-item' );
		} );

		items.forEach( function ( li ) {
			li.classList.remove( 'is-half' );
			li.style.flex = '';
		} );

		const gap  = 6;
		const half = 'calc((100% - ' + gap + 'px) / 2)';
		let i    = 0;

		while ( i < items.length ) {
			const group  = [ items[ i ] ];
			let cursor = i;

			/* Yalnızca işaretli komşular gruba katılır. */
			if ( splitIds.indexOf( items[ i ].getAttribute( 'data-id' ) ) !== -1 ) {
				while ( cursor + 1 < items.length && splitIds.indexOf( items[ cursor + 1 ].getAttribute( 'data-id' ) ) !== -1 ) {
					cursor++;
					group.push( items[ cursor ] );
				}
			}

			const size = group.length;

			if ( size > 1 ) {
				const basis = 'calc((100% - ' + ( ( size - 1 ) * gap ) + 'px) / ' + size + ')';
				group.forEach( function ( li ) {
					li.classList.add( 'is-half' );
					li.style.flex = '0 0 ' + basis;
				} );
			} else if ( splitIds.indexOf( group[0].getAttribute( 'data-id' ) ) !== -1 ) {
				/* İşaretli ama yanına gelecek bölüm yok: sağ yarıya boş yuva koy. */
				group[0].classList.add( 'is-half' );
				group[0].style.flex = '0 0 ' + half;

				const slot = document.createElement( 'li' );
				slot.className = 'dxp-skeleton-slot';
				slot.setAttribute( 'aria-hidden', 'true' );
				slot.textContent = '+';
				list.insertBefore( slot, group[0].nextElementSibling );
			}

			i = cursor + 1;
		}
	}

	function bindSkeleton() {
		$$( '.dxp-skeleton' ).forEach( function ( wrap ) {
			const list       = wrap.querySelector( '.dxp-skeleton-list' );
			const value      = wrap.querySelector( '.dxp-skeleton-value' );
			const splitInput = wrap.querySelector( '.dxp-skeleton-split' );
			if ( ! list || ! value ) return;

			let splitIds = ( splitInput && splitInput.value ) ? splitInput.value.split( ',' ) : [];

			function layout() {
				layoutSkeleton( list, splitIds );
			}

			function sync() {
				const ids = [];
				Array.from( list.querySelectorAll( '.dxp-skeleton-item' ) ).forEach( function ( li ) {
					ids.push( li.getAttribute( 'data-id' ) );
				} );
				value.value = ids.join( ',' );
			}

			/* Sürükle-bırak devre dışı: sıralama yukarı/aşağı düğmeleriyle yapılır. */

			/* CPT iskeleti: bölümü aç / kapa */
			const offInput = wrap.querySelector( '.dxp-skeleton-off' );
			if ( offInput ) {
				list.addEventListener( 'click', function ( e ) {
					const btn = e.target.closest( '.dxp-skeleton-toggle' );
					if ( ! btn ) return;
					const li = btn.closest( '.dxp-skeleton-item' );
					if ( ! li ) return;

					const itemId = li.getAttribute( 'data-id' );
					const ids    = offInput.value ? offInput.value.split( ',' ) : [];
					const at     = ids.indexOf( itemId );
					const turned = ( at === -1 );

					if ( turned ) { ids.push( itemId ); } else { ids.splice( at, 1 ); }

					offInput.value = ids.join( ',' );
					li.classList.toggle( 'is-off', turned );
					btn.setAttribute( 'aria-pressed', turned ? 'false' : 'true' );
					btn.textContent = turned ? btn.getAttribute( 'data-show' ) : btn.getAttribute( 'data-hide' );
					const st = li.querySelector( '.dxp-skeleton-state' );
					if ( st ) st.textContent = turned ? st.getAttribute( 'data-off' ) : st.getAttribute( 'data-on' );
				} );
			}

			/* "Yan yana": sonraki bölümle aynı satırı paylaş */
			if ( splitInput ) {
				list.addEventListener( 'click', function ( e ) {
					const btn = e.target.closest( '.dxp-skeleton-side' );
					if ( ! btn ) return;
					const li = btn.closest( '.dxp-skeleton-item' );
					if ( ! li ) return;

					const itemId = li.getAttribute( 'data-id' );
					const ids    = splitInput.value ? splitInput.value.split( ',' ) : [];
					const at     = ids.indexOf( itemId );
					const turned = ( at === -1 );

					if ( turned ) { ids.push( itemId ); } else { ids.splice( at, 1 ); }

					splitInput.value = ids.join( ',' );
					splitIds         = ids;
					li.classList.toggle( 'is-split', turned );
					btn.setAttribute( 'aria-pressed', turned ? 'true' : 'false' );
					layout();
				} );
			}

			/* Yukarı / aşağı taşıma (sürüklemenin yanında güvenli alternatif) */
			list.addEventListener( 'click', function ( e ) {
				const upBtn   = e.target.closest( '.dxp-skeleton-up' );
				const downBtn = e.target.closest( '.dxp-skeleton-down' );
				if ( ! upBtn && ! downBtn ) return;
				const li = e.target.closest( '.dxp-skeleton-item' );
				if ( ! li ) return;

				if ( upBtn ) {
					let prev = li.previousElementSibling;
					while ( prev && ! prev.classList.contains( 'dxp-skeleton-item' ) ) { prev = prev.previousElementSibling; }
					if ( prev ) list.insertBefore( li, prev );
				} else {
					let next = li.nextElementSibling;
					while ( next && ! next.classList.contains( 'dxp-skeleton-item' ) ) { next = next.nextElementSibling; }
					if ( next ) list.insertBefore( next, li );
				}

				sync();
				layout();
			} );

			sync();
			layout();
		} );

		/*
		 * Anasayfa iskeleti: bölümün ön yüzde görünürlüğü hem "Bölüm Aktif"
		 * tikine hem "Gösterileceği Yer" seçimine bağlıdır. İkisi değişince
		 * iskelet satırını canlı güncelle (sayfadaki durumla senkron).
		 * CPT/Hakkımızda iskeletleri kendi "kapalı" listesini kullanır; bu
		 * yüzden yalnızca "yan yana" (split) alanı olan anasayfa iskeletine uygula.
		 */
		$$( '.dxp-skeleton' ).forEach( function ( wrap ) {
			if ( ! wrap.querySelector( '.dxp-skeleton-split' ) ) return;

			wrap.querySelectorAll( '.dxp-skeleton-item' ).forEach( function ( li ) {
				const id       = li.getAttribute( 'data-id' );
				const checkbox = document.getElementById( 'dxp_' + id + '_enable' );

				const toggle = li.querySelector( '.dxp-skeleton-toggle' );

				function apply() {
					const off = ( checkbox && ! checkbox.checked );
					li.classList.toggle( 'is-off', off );
					const state = li.querySelector( '.dxp-skeleton-state' );
					if ( state ) {
						state.textContent = off ? state.getAttribute( 'data-off' ) : state.getAttribute( 'data-on' );
					}
					if ( toggle ) {
						toggle.setAttribute( 'aria-pressed', off ? 'false' : 'true' );
						toggle.textContent = off ? toggle.getAttribute( 'data-show' ) : toggle.getAttribute( 'data-hide' );
					}
				}

				if ( checkbox ) checkbox.addEventListener( 'change', apply );
				apply();

				/* İskelet üzerinden "Bölüm Aktif" tikini aç/kapa */
				if ( toggle && checkbox ) {
					toggle.addEventListener( 'click', function () {
						checkbox.checked = ! checkbox.checked;
						checkbox.dispatchEvent( new Event( 'change', { bubbles: true } ) );
					} );
				}
			} );
		} );
	}

	/* ── "Bu Bölümü Göster" tikine göre alt satırları gizle ─ */
	function bindSectionEnable() {
		$$( 'input[id^="dxp_"][id$="_enable"]' ).forEach( function ( cb ) {
			const sectionId = cb.id.slice( 4, -7 );
			const rows      = [];

			[ '[name="' + sectionId + '_show"]', '[name="' + sectionId + '_pages[]"]' ].forEach( function ( sel ) {
				const el = document.querySelector( sel );
				if ( ! el ) return;
				const row = el.closest( '.dxp-row' );
				if ( row ) rows.push( row );
			} );

			if ( ! rows.length ) return;

			function toggle() {
				rows.forEach( function ( row ) { row.hidden = ! cb.checked; } );
			}

			cb.addEventListener( 'change', toggle );
			toggle();
		} );
	}

	/* ── Koşul kaynağı alanlar: kaydet ve yeniden çiz ─────── */
	/*
	 * Görünürlük kararı artık sunucuda (DEVXPE_Theme_Conditions). Bir koşul
	 * kaynağı alan değişince form normal POST ile gönderilir; PHP yeni
	 * değerlerle görünürlüğü yeniden hesaplar. AJAX yok, display:none yok.
	 * Kaynak alan listesi PHP'den data-dxp-condition-sources ile gelir.
	 */
	function bindConditionSubmit() {
		const form = $( '#devxpe-panel-form' );
		if ( ! form ) return;

		const sources = ( form.getAttribute( 'data-dxp-condition-sources' ) || '' )
			.split( ',' )
			.filter( function ( s ) { return s; } );
		if ( ! sources.length ) return;

		form.addEventListener( 'change', function ( e ) {
			if ( ! e.target || ! e.target.name ) return;

			const id = e.target.name.split( '[' )[ 0 ];
			if ( sources.indexOf( id ) === -1 ) return;

			/* Programatik submit event tetiklemesin (AJAX kaydı atlanır). */
			if ( ! form.querySelector( 'input[name="devxpe_theme_save"]' ) ) {
				const trigger   = document.createElement( 'input' );
				trigger.type    = 'hidden';
				trigger.name    = 'devxpe_theme_save';
				trigger.value   = '1';
				form.appendChild( trigger );
			}
			form.submit();
		} );
	}

	/* ── Gelen Mesajlar: detay (odak) görünümü ───────────── */
	/*
	 * Satıra tıklayınca liste aynı kart içinde detayla değişir; "← Geri"
	 * veya Esc listeye döner. Detay verisi satırdaki data-msg (JSON)
	 * alanından okunur; içerik DOM API'siyle kurulur (kullanıcı verisi
	 * innerHTML ile yazılmaz → XSS yok).
	 */
	function bindInbox() {
		const inbox = $( '#dxp-inbox' );
		if ( ! inbox ) return;

		const list   = inbox.querySelector( '.dxp-inbox-list' );
		const detail = inbox.querySelector( '.dxp-inbox-detail' );
		const inner  = inbox.querySelector( '.dxp-inbox-detail-inner' );
		const back   = inbox.querySelector( '.dxp-inbox-back' );
		if ( ! list || ! detail || ! inner || ! back ) return;

		let lastItem = null;

		function el( tag, cls, text ) {
			const node = document.createElement( tag );
			if ( cls ) { node.className = cls; }
			if ( text !== undefined && text !== null ) { node.textContent = text; }
			return node;
		}

		function section( title ) {
			const wrap = el( 'div', 'dxp-inbox-detail-section' );
			wrap.appendChild( el( 'div', 'dxp-inbox-detail-section-title', title ) );
			return wrap;
		}

		function fieldRow( label, value ) {
			const row = el( 'div', 'dxp-inbox-detail-field' );
			row.appendChild( el( 'span', 'dxp-inbox-detail-label', label ) );
			const val = el( 'span', 'dxp-inbox-detail-value' );
			if ( value instanceof Node ) {
				val.appendChild( value );
			} else {
				val.textContent = ( value === undefined || value === null ) ? '—' : String( value );
			}
			row.appendChild( val );
			return row;
		}

		function link( href, text ) {
			const a = el( 'a', '', text );
			a.href = href;
			return a;
		}

		function close() {
			inbox.classList.remove( 'is-open' );
			$$( '.dxp-inbox-item', list ).forEach( function ( it ) {
				it.setAttribute( 'aria-expanded', 'false' );
			} );
			if ( lastItem ) { lastItem.focus(); }
		}

		/* Rozetleri (menü + kart başlığı) verilen sayıyla günceller. */
		function badgeGuncelle( sayi ) {
			if ( 'number' !== typeof sayi ) { return; }

			$$( '.dxp-count-badge' ).forEach( function ( b ) {
				if ( sayi > 0 ) {
					b.textContent = String( sayi );
					b.hidden = false;
					b.style.display = 'inline-block';
				} else {
					b.hidden = true;
					b.style.display = 'none';
				}
			} );
		}

		/* Rozetteki sayıyı okur (yoksa 0). */
		function badgeSayi() {
			const b = $( '.dxp-count-badge' );
			return b ? ( parseInt( b.textContent, 10 ) || 0 ) : 0;
		}

		/* Satırın okundu/okunmadı görünümünü ve bağlantısını günceller. */
		function satirDurum( item, okundu ) {
			item.classList.toggle( 'is-unread', ! okundu );

			const link = item.querySelector( '.dxp-inbox-read' );
			if ( link ) {
				link.textContent = okundu ? 'Okundu' : 'Okunmadı';
				link.href = link.href.replace( /okundu=[01]/, okundu ? 'okundu=0' : 'okundu=1' );
			}
		}

		/*
		 * Detayı açılan mesaj ANINDA okundu sayılır: satır ve rozetler
		 * beklemeden güncellenir, sunucu sonra doğrular (senkron hareket).
		 */
		function markRead( item ) {
			satirDurum( item, true );
			badgeGuncelle( Math.max( 0, badgeSayi() - 1 ) );

			const url   = inbox.getAttribute( 'data-read-url' );
			const nonce = inbox.getAttribute( 'data-read-nonce' );
			const id    = item.getAttribute( 'data-id' );

			if ( ! url || ! nonce || ! id ) { return; }

			const fd = new FormData();
			fd.append( 'action', 'devxpe_form_read_ajax' );
			fd.append( 'nonce', nonce );
			fd.append( 'id', id );

			fetch( url, { method: 'POST', credentials: 'same-origin', body: fd } )
				.then( function ( r ) { return r.json(); } )
				.then( function ( d ) {
					if ( d && d.success && d.data && 'number' === typeof d.data.unread ) {
						badgeGuncelle( d.data.unread );
					}
				} )
				.catch( function () {} );
		}

		function open( item ) {
			let msg = {};
			try { msg = JSON.parse( item.getAttribute( 'data-msg' ) || '{}' ) || {}; } catch { msg = {}; }

			lastItem = item;
			inner.textContent = '';

			/* Başlık: gönderilen mailin konusu. */
			inner.appendChild( el(
				'h4',
				'dxp-inbox-detail-subject',
				msg.mail_subject ? msg.mail_subject : 'Konu kaydı yok'
			) );

			/* Meta: tarih/saat · servis · IP. */
			const meta = el( 'div', 'dxp-inbox-detail-meta' );
			[ msg.time, msg.service, msg.ip ? 'IP: ' + msg.ip : '' ].forEach( function ( part ) {
				if ( part ) { meta.appendChild( el( 'span', '', part ) ); }
			} );
			if ( meta.childElementCount ) { inner.appendChild( meta ); }

			/* Gönderen bilgileri. */
			const senderFields = el( 'div', 'dxp-inbox-detail-fields' );
			if ( msg.name ) { senderFields.appendChild( fieldRow( 'Ad Soyad', msg.name ) ); }
			if ( msg.email ) { senderFields.appendChild( fieldRow( 'E-posta', link( 'mailto:' + msg.email, msg.email ) ) ); }
			if ( msg.phone ) { senderFields.appendChild( fieldRow( 'Telefon', link( 'tel:' + String( msg.phone ).replace( /\s+/g, '' ), msg.phone ) ) ); }
			if ( senderFields.childElementCount ) {
				const senderSec = section( 'Gönderen' );
				senderSec.appendChild( senderFields );
				inner.appendChild( senderSec );
			}

			/* Tüm form alanları: etiket → değer. */
			const fieldsSec   = section( 'Form Alanları' );
			const fieldsWrap  = el( 'div', 'dxp-inbox-detail-fields' );
			const fields      = msg.fields || [];

			fields.forEach( function ( f ) {
				let value = f.value;
				if ( 'file' === f.key && f.value ) {
					value = link( f.value, f.value );
					value.target = '_blank';
					value.rel    = 'noopener noreferrer';
				}
				fieldsWrap.appendChild( fieldRow( f.label || f.key, value ) );
			} );

			if ( fields.length ) {
				fieldsSec.appendChild( fieldsWrap );
			} else {
				fieldsSec.appendChild( el( 'p', 'dxp-inbox-detail-empty', '—' ) );
			}
			inner.appendChild( fieldsSec );

			/* Gönderilen mailin gövdesi (düz metin, satır sonları korunur). */
			const mailSec = section( 'Gönderilen Mail' );
			if ( msg.mail_body ) {
				const pre = el( 'pre', 'dxp-inbox-detail-mail' );
				pre.textContent = msg.mail_body;
				mailSec.appendChild( pre );
			} else {
				mailSec.appendChild( el( 'p', 'dxp-inbox-detail-empty', '—' ) );
			}
			inner.appendChild( mailSec );

			inbox.classList.add( 'is-open' );
			item.setAttribute( 'aria-expanded', 'true' );
			back.focus();

			/* Açılan mesaj okundu sayılır. */
			if ( item.classList.contains( 'is-unread' ) ) {
				markRead( item );
			}
		}

		/* Satır tıklaması: yalnızca metne tıklayınca aç; iç bağlantılar
		   (Sil / mailto / tel) kendi davranışını korusun. */
		list.addEventListener( 'click', function ( e ) {
			if ( e.target.closest( 'a' ) ) { return; }
			const item = e.target.closest( '.dxp-inbox-item' );
			if ( item ) { open( item ); }
		} );

		/* Klavye: Enter / Space ile aç (role="button"). */
		list.addEventListener( 'keydown', function ( e ) {
			if ( 'Enter' !== e.key && ' ' !== e.key && 'Spacebar' !== e.key ) { return; }
			if ( e.target.closest( 'a' ) ) { return; }
			const item = e.target.closest( '.dxp-inbox-item' );
			if ( ! item ) { return; }
			e.preventDefault();
			open( item );
		} );

		back.addEventListener( 'click', close );

		document.addEventListener( 'keydown', function ( e ) {
			if ( 'Escape' === e.key && inbox.classList.contains( 'is-open' ) ) { close(); }
		} );
	}

	/* ── İlk section id ───────────────────────────────────── */
	function getFirstSectionId() {
		const first = $( '.dxp-section' );
		return first ? first.id.replace( 'dxp-section-', '' ) : '';
	}

	/* ── Başlangıç ────────────────────────────────────────── */
	/*
	 * Demo seçici: seçilen demoyu "kur" butonuna yansıtır.
	 *
	 * JS'li akışta seciliDemo() radyoyu doğrudan okur; burada ayrıca kartın
	 * görsel durumu ve JS'siz yedek link (href) güncellenir.
	 */
	function bindDemoPick() {
		const pick = document.getElementById( 'dxp-demo-pick' );
		const btn  = document.getElementById( 'dxp-demo-install-btn' );
		if ( ! pick || ! btn ) { return; }

		pick.addEventListener( 'change', function ( e ) {
			const radio = ( e.target && e.target.name === 'dxp_demo_pick' ) ? e.target : null;
			if ( ! radio ) { return; }

			pick.querySelectorAll( '.dxp-demo-pick-item' ).forEach( function ( item ) {
				const r = item.querySelector( 'input[name="dxp_demo_pick"]' );
				item.classList.toggle( 'is-active', !!( r && r.checked ) );
			} );

			btn.setAttribute( 'data-demo', radio.value );

			/* JS'siz yedek: buton linkinin demo parametresini güncelle. */
			try {
				const u = new URL( btn.href, window.location.origin );
				u.searchParams.set( 'demo', radio.value );
				btn.href = u.toString();
			} catch {
				/* URL yoksa yedek link güncellenemez; sorun değil. */
			}
		} );
	}

	/*
	 * Tarih/saat alanı: kutunun herhangi bir yerine tıklanınca takvim açılsın.
	 *
	 * Native <input type="datetime-local"> yalnızca sağdaki küçük takvim
	 * ikonuna basınca açılır. Kullanıcı kutunun tamamına tıklayabilsin diye
	 * showPicker() çağırıyoruz. İkonun kendi açma davranışını da
	 * preventDefault() ile kapatırız ki çift açılma (açılıp hemen kapanma)
	 * olmasın. showPicker() desteklenmiyorsa hiç karışmayız; o zaman
	 * tarayıcının native davranışı aynen kalır.
	 */
	function bindDatePickers() {
		const alanlar = document.querySelectorAll(
			'input[type="datetime-local"], input[type="date"], input[type="time"]'
		);

		alanlar.forEach( function ( el ) {
			if ( 'function' !== typeof el.showPicker ) { return; }
			if ( el.dataset.dxpPickerBagli ) { return; }
			el.dataset.dxpPickerBagli = '1';

			el.addEventListener( 'click', function ( e ) {
				e.preventDefault();

				try {
					el.showPicker();
				} catch {
					/* Kullanıcı etkileşimi yoksa veya izin verilmiyorsa sessizce geç. */
				}
			} );
		} );
	}

	/* ── Toast bildirimleri ──────────────────────────────────
	 * Başarı/bilgi toast'ı birkaç saniye sonra kendiliğinden kaybolur;
	 * hata ve uyarı toast'ı elle kapatılana kadar ekranda kalır.
	 * Üzerine gelince sayaç durur; kapanınca boş kalan kap da silinir.
	 */
	function bindToasts() {
		const GORUNME = 4500; /* ekranda kalma süresi (ms) */
		const SOLMA   = 300;  /* kaybolma geçişi (ms) */

		$$( '.dxp-toast' ).forEach( function ( toast ) {
			let sayac = null;

			function kapat() {
				toast.classList.add( 'dxp-toast-gone' );
				window.setTimeout( function () {
					const kap = toast.parentNode;
					if ( ! kap ) {
						return;
					}
					kap.removeChild( toast );
					/* Son toast da gittiyse boş kap kalmasın. */
					if ( ! kap.children.length && kap.parentNode ) {
						kap.parentNode.removeChild( kap );
					}
				}, SOLMA );
			}

			function baslat() {
				window.clearTimeout( sayac );
				sayac = window.setTimeout( kapat, GORUNME );
			}

			const kapatDugmesi = $( '.dxp-toast-close', toast );
			if ( kapatDugmesi ) {
				kapatDugmesi.addEventListener( 'click', function () {
					window.clearTimeout( sayac );
					kapat();
				} );
			}

			/* Hata/uyarı: yalnızca elle kapanır. */
			if ( toast.classList.contains( 'dxp-toast--error' ) || toast.classList.contains( 'dxp-toast--warning' ) ) {
				return;
			}

			toast.addEventListener( 'mouseenter', function () {
				window.clearTimeout( sayac );
			} );
			toast.addEventListener( 'mouseleave', baslat );

			baslat();
		} );
	}

	function init() {
		/*
		 * Bir bağlayıcı hata verirse diğerlerini (iskelet sürükleme, tekrarlayıcı,
		 * açılır menüler...) engellememesi için her birini ayrı ayrı çalıştır.
		 */
		function safe( fn ) {
			try {
				fn();
			} catch ( err ) {
				if ( window.console && console.error ) {
					console.error( 'DEVXPE panel binder hatası:', err );
				}
			}
		}

		/*
		 * Panel sayfasında değilsek (ör. yazı düzenleme ekranındaki meta box)
		 * yalnızca yeniden kullanılabilir bileşenleri bağla; panel'e özel
		 * routing/binder'ları çalıştırma.
		 */
		if ( ! document.getElementById( 'devxpe-panel' ) ) {
			safe( bindGroupTabs );
			safe( bindTeamRepeater );
			safe( bindOptionsRepeaters );
			safe( bindCharCount );
			safe( bindSkeleton );
			safe( bindCopyButtons );
			safe( bindDatePickers );
			return;
		}

		const hash   = getHash();
		const parsed = parseHash( hash );

		/*
		 * Öncelik: URL hash'i → sunucunun açtığı bölüm → ilk bölüm.
		 * (Hash boşsa sunucunun çizdiği bölüm korunur; aksi hâlde sayfa
		 * yenilemesinde başka bir bölüme atlar.)
		 */
		const navActive = $( '#devxpe-panel-left .dxp-nav > li.active' );
		const subActive = $( '#devxpe-panel-left .dxp-submenu li.active' );
		const subAdi    = subActive ? ( subActive.dataset.subsection || '' ).split( '-' ).slice( 1 ).join( '-' ) : '';

		const section = parsed.section || ( navActive ? navActive.dataset.section : '' ) || getFirstSectionId();
		const sub     = parsed.sub || subAdi || '';

		/*
		 * Açık menü durumunu showSection() yönetir (tek menü açık kalır).
		 * Burada zorla "ilk menüyü aç" YAPILMAZ; aksi hâlde sunucunun açık
		 * bıraktığı bölümle birlikte iki menü açık görünür (glitch).
		 */

		safe( function () { showSection( section, sub ); } );

		[
			bindMenu,
			bindSearch,
			bindTools,
			bindDemoModal,
			bindPluginPreview,
			bindDemoInstall,
			bindDemoPick,
			bindMobileToggle,
			bindFormSubmit,
			bindDarkMode,
			bindScale,
			bindTokens,
			bindColorHarmony,
			bindColorFieldHarmony,
			bindRadioImages,
			bindIconPick,
			bindCollapse,
			bindTabs,
			bindPagesOrder,
			bindNavItems,
			bindLangSwitch,
			bindSelects,
			bindMultiselect,
			bindCharCount,
			bindSkeleton,
			bindSectionEnable,
			bindConditionSubmit,
			bindGroupTabs,
			bindFormChoiceTabs,
			bindTeamRepeater,
			bindQuoteSteps,
			bindOptionsRepeaters,
			bindCopyButtons,
			bindInbox,
			bindToasts,
			bindDatePickers
		].forEach( safe );
	}

	/* ── DOM hazır ────────────────────────────────────────── */
	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}

	/* ── Tarayıcı geri/ileri ──────────────────────────────── */
	window.addEventListener( 'hashchange', function () {
		const parsed = parseHash( getHash() );
		if ( parsed.section ) {
			showSection( parsed.section, parsed.sub );
		}
	} );

	/* ── WebP toplu dönüştürme ── */
	document.addEventListener( 'click', function ( e ) {
		const btn = e.target && e.target.closest ? e.target.closest( '.dxp-webp-convert' ) : null;
		if ( ! btn ) {
			return;
		}
		e.preventDefault();

		const status = btn.parentNode ? btn.parentNode.querySelector( '.dxp-webp-status' ) : null;
		const nonce = btn.getAttribute( 'data-nonce' );
		btn.disabled = true;

		let offset = 0;
		let done = 0;

		const run = function () {
			const fd = new FormData();
			fd.append( 'action', 'devxpe_webp_bulk' );
			fd.append( 'nonce', nonce );
			fd.append( 'offset', offset );

			fetch( ajaxurl, { method: 'POST', credentials: 'same-origin', body: fd } )
				.then( function ( r ) { return r.json(); } )
				.then( function ( res ) {
					if ( ! res || ! res.success ) {
						throw new Error( 'webp' );
					}
					const d = res.data;
					offset = d.next;
					done += d.processed;
					if ( status ) {
						status.textContent = done + ' / ' + d.total;
					}
					if ( d.finished ) {
						btn.disabled = false;
						if ( status ) {
							status.textContent = done + ' / ' + d.total + ' ✓';
						}
						const geri = btn.parentNode ? btn.parentNode.querySelector( '.dxp-webp-revert' ) : null;
						if ( geri ) {
							geri.hidden = false;
						}
						return;
					}
					run();
				} )
				.catch( function () {
					btn.disabled = false;
					if ( status ) {
						status.textContent = btn.getAttribute( 'data-msg-error' ) || 'Hata';
					}
				} );
		};

		run();
	} );

	/* ── WebP geri alma: üretilmiş .webp kardeşlerini sil ── */
	document.addEventListener( 'click', function ( e ) {
		const btn = e.target && e.target.closest ? e.target.closest( '.dxp-webp-revert' ) : null;
		if ( ! btn ) {
			return;
		}
		e.preventDefault();

		const status = btn.parentNode ? btn.parentNode.querySelector( '.dxp-webp-status' ) : null;
		btn.disabled = true;
		if ( status ) {
			status.textContent = btn.getAttribute( 'data-msg-running' ) || '';
		}

		const fd = new FormData();
		fd.append( 'action', 'devxpe_webp_revert' );
		fd.append( 'nonce', btn.getAttribute( 'data-nonce' ) );

		fetch( ajaxurl, { method: 'POST', credentials: 'same-origin', body: fd } )
			.then( function ( r ) { return r.json(); } )
			.then( function ( res ) {
				btn.disabled = false;
				if ( ! res || ! res.success ) {
					throw new Error( 'webp' );
				}
				const adet = ( res.data && res.data.deleted ) ? res.data.deleted : 0;
				if ( status ) {
					const kalip = btn.getAttribute( 'data-msg-reverted' ) || '%d';
					status.textContent = kalip.replace( '%d', adet ) + ' ✓';
				}
				btn.hidden = true;
			} )
			.catch( function () {
				btn.disabled = false;
				if ( status ) {
					status.textContent = btn.getAttribute( 'data-msg-error' ) || 'Hata';
				}
			} );
	} );

	/* ── Tema kütüphanesi: galeri modalı ── */
	( function () {
		const modal = document.getElementById( 'dxp-design-modal' );
		if ( ! modal ) {
			return;
		}
		const img = modal.querySelector( '.dxp-design-modal-img' );
		let list = [];
		let idx = 0;

		const show = function () {
			if ( list.length ) {
				img.src = list[ idx ];
			}
		};
		const close = function () {
			modal.hidden = true;
			img.src = '';
		};

		document.addEventListener( 'click', function ( e ) {
			const cov = e.target.closest ? e.target.closest( '.dxp-design-cover[data-gallery]' ) : null;
			if ( cov ) {
				try {
					list = JSON.parse( cov.getAttribute( 'data-gallery' ) );
					idx = 0;
					show();
					modal.hidden = false;
				} catch {}
				return;
			}
			if ( e.target.closest && e.target.closest( '[data-close]' ) ) {
				close();
				return;
			}
			const nav = e.target.closest ? e.target.closest( '.dxp-design-modal-nav' ) : null;
			if ( nav && list.length ) {
				idx = ( idx + parseInt( nav.getAttribute( 'data-dir' ), 10 ) + list.length ) % list.length;
				show();
			}
		} );

		document.addEventListener( 'keydown', function ( e ) {
			if ( modal.hidden ) {
				return;
			}
			if ( e.key === 'Escape' ) {
				close();
			}
			if ( e.key === 'ArrowRight' && list.length ) {
				idx = ( idx + 1 ) % list.length;
				show();
			}
			if ( e.key === 'ArrowLeft' && list.length ) {
				idx = ( idx - 1 + list.length ) % list.length;
				show();
			}
		} );
	} )();

} )();
