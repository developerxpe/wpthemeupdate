/**
 * DEVXPE Panel — JavaScript
 *
 * Sol menüden section/subsection geçişi (hash tabanlı routing),
 * arama filtresi, arama içi gezinme ve import/export yardımcıları.
 */

( function () {
	'use strict';

	/* ── Durum ────────────────────────────────────────────── */
	let currentSection    = '';
	let currentSubsection = '';

	/* ── DOM kısayolları ──────────────────────────────────── */
	function $( sel, ctx ) {
		return ( ctx || document ).querySelector( sel );
	}
	function $$( sel, ctx ) {
		return Array.from( ( ctx || document ).querySelectorAll( sel ) );
	}

	/* ── Hash okuma ───────────────────────────────────────── */
	function getHash() {
		return ( window.location.hash || '' ).replace( '#', '' ) || '';
	}

	/* ── URL yazma ────────────────────────────────────────── */
	function setHash( hash ) {
		if ( history.replaceState ) {
			history.replaceState( null, '', '#' + hash );
		} else {
			window.location.hash = hash;
		}
	}

	/* ── Aktif section ve subsection'ı göster ─────────────── */
	/*
	 * openParent === false: sol menüdeki üst öğeyi zorla açma.
	 * (Menü başlığına tıklayınca accordion aç/kapa bindMenu tarafından yönetilir.)
	 */
	function showSection( sectionId, subsectionId, openParent ) {
		/* Section'ları gizle */
		$$( '.dxp-section' ).forEach( function ( el ) {
			el.classList.remove( 'active' );
		} );

		/* Hedef section'ı göster */
		let targetSection = $( '#dxp-section-' + sectionId );
		if ( ! targetSection ) {
			/* Fallback: ilk section */
			const first = $( '.dxp-section' );
			if ( first ) {
				sectionId = first.id.replace( 'dxp-section-', '' );
				targetSection = first;
			}
		}
		if ( targetSection ) {
			targetSection.classList.add( 'active' );
		}

		/* Sol menüde aktif item — aynı anda yalnızca BİR menü açık kalsın. */
		$$( '#devxpe-panel-left .dxp-nav > li' ).forEach( function ( li ) {
			li.classList.remove( 'active' );

			/*
			 * Menü tıklaması (openParent === false) kendi aç/kapa mantığını
			 * kullanır; diğer durumlarda (sayfa yükü, hash değişimi) açık
			 * menüler kapatılır ki sunucunun açtığı bölümle çakışmasın.
			 */
			if ( false !== openParent ) {
				li.classList.remove( 'open' );
			}
		} );

		const activeNavItem = $( '#devxpe-panel-left .dxp-nav > li[data-section="' + sectionId + '"]' );
		if ( activeNavItem ) {
			activeNavItem.classList.add( 'active' );
			/* Alt menü varsa aç (menü tıklaması hariç). */
			if ( false !== openParent && $( '.dxp-submenu', activeNavItem ) ) {
				activeNavItem.classList.add( 'open' );
			}
		}

		/* Subsection geçişi */
		if ( subsectionId ) {
			showSubsection( sectionId, subsectionId );
		} else {
			/* Subsection yoksa ya da belirtilmemişse ilkini göster */
			const firstSub = $( '#dxp-section-' + sectionId + ' .dxp-subsection' );
			if ( firstSub ) {
				const firstSubId = firstSub.id.replace( 'dxp-subsection-', '' ).replace( sectionId + '-', '' );
				showSubsection( sectionId, firstSubId );
			}
		}

		/* Başlık güncelle */
		updateTopbarTitle( sectionId, subsectionId );

		currentSection    = sectionId;
		currentSubsection = subsectionId || '';

		/* Sayfa yenilesinde doğru bölümün flash'sız yüklenmesi için cookie yaz. */
		const last = sectionId + ( currentSubsection ? '--' + currentSubsection : '' );
		document.cookie = 'dxp_panel_last=' + last + ';path=/;max-age=31536000;SameSite=Strict';
	}

	/* ── Subsection göster ────────────────────────────────── */
	function showSubsection( sectionId, subsectionId ) {
		const sectionEl = $( '#dxp-section-' + sectionId );
		if ( ! sectionEl ) return;

		$$( '.dxp-subsection', sectionEl ).forEach( function ( el ) {
			el.classList.remove( 'active' );
		} );

		const target = $( '#dxp-subsection-' + sectionId + '-' + subsectionId, sectionEl );
		if ( target ) {
			target.classList.add( 'active' );
		}

		/* Sol menü submenu item */
		$$( '.dxp-submenu li' ).forEach( function ( li ) {
			li.classList.remove( 'active' );
		} );
		const activeSubNav = $( '.dxp-submenu li[data-subsection="' + sectionId + '-' + subsectionId + '"]' );
		if ( activeSubNav ) {
			activeSubNav.classList.add( 'active' );
		}
	}

	/* ── Topbar başlığını güncelle ────────────────────────── */
	function updateTopbarTitle( sectionId, subsectionId ) {
		const titleEl = $( '.dxp-page-title' );
		if ( ! titleEl ) return;

		const navItem = $( '.dxp-nav > li[data-section="' + sectionId + '"]' );
		let label   = navItem ? ( navItem.querySelector( '.dxp-nav-label' ) || {} ).textContent || '' : sectionId;

		if ( subsectionId ) {
			const subItem = $( '.dxp-submenu li[data-subsection="' + sectionId + '-' + subsectionId + '"]' );
			if ( subItem ) {
				label += ' › ' + ( subItem.textContent || '' ).trim();
			}
		}

		titleEl.textContent = label.trim();
	}

	/* ── Hash'ten section/subsection ayır ─────────────────── */
	function parseHash( hash ) {
		if ( ! hash ) return { section: '', sub: '' };
		const parts = hash.split( '--' );
		return { section: parts[0] || '', sub: parts[1] || '' };
	}

	/* ── Menü tıklamaları ─────────────────────────────────── */
	function bindMenu() {
		/* Ana menü öğeleri */
		$$( '#devxpe-panel-left .dxp-nav > li > a' ).forEach( function ( link ) {
			link.addEventListener( 'click', function ( e ) {
				e.preventDefault();
				const li        = this.closest( 'li' );
				const sectionId = li.dataset.section;
				const submenu   = $( '.dxp-submenu', li );

				if ( submenu ) {
					/* Açılır/kapanır */
					const isOpen = li.classList.contains( 'open' );
					$$( '.dxp-nav > li' ).forEach( function ( el ) {
						el.classList.remove( 'open' );
					} );
					if ( ! isOpen ) {
						li.classList.add( 'open' );
					}
				}

				if ( sectionId ) {
					setHash( sectionId );
					showSection( sectionId, '', false );
				}
			} );
		} );

		/* Alt menü öğeleri */
		$$( '#devxpe-panel-left .dxp-submenu li > a' ).forEach( function ( link ) {
			link.addEventListener( 'click', function ( e ) {
				e.preventDefault();
				const li        = this.closest( 'li' );
				const compound  = li.dataset.subsection || ''; /* format: section-sub */
				const parts     = compound.split( '-' );
				const sectionId = parts[0];
				const subId     = parts.slice( 1 ).join( '-' );

				if ( sectionId && subId ) {
					setHash( sectionId + '--' + subId );
					showSection( sectionId, subId );
				}
			} );
		} );
	}

	/* ── Arama ────────────────────────────────────────────── */
	function bindSearch() {
		const searchInput = $( '#dxp-search' );
		if ( ! searchInput ) return;

		searchInput.addEventListener( 'input', function () {
			const term = this.value.trim().toLowerCase();

			if ( ! term ) {
				/* Arama temizlendi — önceki section'a dön */
				$$( '.dxp-row' ).forEach( function ( row ) {
					row.classList.remove( 'dxp-hidden-search' );
				} );
				$( '.dxp-no-results' ) && ( $( '.dxp-no-results' ).style.display = '' );
				showSection( currentSection || getFirstSectionId(), currentSubsection );
				return;
			}

			/* Tüm section'ları göster arama sırasında */
			$$( '.dxp-section' ).forEach( function ( s ) { s.classList.add( 'active' ); } );
			$$( '.dxp-subsection' ).forEach( function ( s ) { s.classList.add( 'active' ); } );

			let anyVisible = false;

			$$( '.dxp-row' ).forEach( function ( row ) {
				const text = row.textContent.toLowerCase();
				if ( text.indexOf( term ) !== -1 ) {
					row.classList.remove( 'dxp-hidden-search' );
					anyVisible = true;
				} else {
					row.classList.add( 'dxp-hidden-search' );
				}
			} );

			const noResults = $( '.dxp-no-results' );
			if ( noResults ) {
				noResults.style.display = anyVisible ? 'none' : 'block';
			}
		} );
	}

	/* ── Import butonu ────────────────────────────────────── */
	function bindTools() {
		const copyBtn = $( '#dxp-copy-export' );
		if ( copyBtn ) {
			copyBtn.addEventListener( 'click', function () {
				const ta = $( '#dxp-export-data' );
				if ( ta ) {
					ta.select();
					document.execCommand( 'copy' );
					copyBtn.textContent = '✓ Kopyalandı';
					setTimeout( function () { copyBtn.textContent = 'Kopyala'; }, 2000 );
				}
			} );
		}

		/* Dışa aktarımı JSON dosyası olarak indir. */
		const dlBtn = $( '#dxp-download-export' );
		if ( dlBtn ) {
			dlBtn.addEventListener( 'click', function () {
				const ta = $( '#dxp-export-data' );
				if ( ! ta ) { return; }
				const blob = new Blob( [ ta.value ], { type: 'application/json' } );
				const url  = URL.createObjectURL( blob );
				const link = document.createElement( 'a' );
				link.href = url;
				link.download = 'devxpe-ayarlar.json';
				document.body.appendChild( link );
				link.click();
				link.remove();
				URL.revokeObjectURL( url );
			} );
		}

		/* Seçilen JSON dosyasını textarea'ya yükle (normal POST ile gider). */
		const fileInput = $( '#dxp-import-file' );
		if ( fileInput ) {
			const fileName = $( '#dxp-import-file-name' );
			const bosMetin = fileName ? fileName.textContent : '';

			fileInput.addEventListener( 'change', function () {
				const file = fileInput.files && fileInput.files[ 0 ];

				if ( ! file ) {
					if ( fileName ) { fileName.textContent = bosMetin; }
					return;
				}

				if ( fileName ) { fileName.textContent = file.name; }

				const reader = new FileReader();
				reader.onload = function () {
					const ta = document.querySelector( '[name="devxpe_theme_import_data"]' );
					if ( ta ) { ta.value = String( reader.result || '' ); }
				};
				reader.readAsText( file );
			} );
		}
	}

	/* ── Demo paketi: kaldırma onay penceresi ─────────────── */
	function bindDemoModal() {
		const btn   = $( '#dxp-demo-remove-btn' );
		const modal = $( '#dxp-demo-modal' );
		if ( ! btn || ! modal ) return;

		const confirmBtn = $( '#dxp-demo-confirm' );

		function open() {
			if ( confirmBtn ) { confirmBtn.setAttribute( 'href', btn.getAttribute( 'data-remove-url' ) || '#' ); }
			modal.hidden = false;
			document.body.classList.add( 'dxp-modal-open' );
			if ( confirmBtn ) { confirmBtn.focus(); }
		}

		function close() {
			modal.hidden = true;
			document.body.classList.remove( 'dxp-modal-open' );
		}

		btn.addEventListener( 'click', open );
		modal.addEventListener( 'click', function ( e ) {
			if ( e.target.closest( '[data-dxp-demo-close]' ) ) { close(); }
		} );
		document.addEventListener( 'keydown', function ( e ) {
			if ( 'Escape' === e.key && ! modal.hidden ) { close(); }
		} );
	}

	/* ── Mobil sidebar toggle ─────────────────────────────── */
	function bindMobileToggle() {
		const toggleBtn = $( '.dxp-menu-toggle' );
		const sidebar   = $( '#devxpe-panel-left' );
		const overlay   = $( '.dxp-overlay' );

		if ( ! toggleBtn || ! sidebar ) return;

		function openSidebar() {
			sidebar.classList.add( 'open' );
			if ( overlay ) overlay.classList.add( 'active' );
			toggleBtn.setAttribute( 'aria-expanded', 'true' );
			toggleBtn.setAttribute( 'aria-label', 'Menüyü Kapat' );
			toggleBtn.textContent = '✕';
		}

		function closeSidebar() {
			sidebar.classList.remove( 'open' );
			if ( overlay ) overlay.classList.remove( 'active' );
			toggleBtn.setAttribute( 'aria-expanded', 'false' );
			toggleBtn.setAttribute( 'aria-label', 'Menüyü Aç' );
			toggleBtn.textContent = '☰';
		}

		toggleBtn.addEventListener( 'click', function () {
			sidebar.classList.contains( 'open' ) ? closeSidebar() : openSidebar();
		} );

		/*
		 * Menü açıkken bir bölüm seçilse bile kapanmaz; yalnızca çarpıya
		 * (toggle) ya da boş alana (overlay) basınca kapanır.
		 */
		if ( overlay ) {
			overlay.addEventListener( 'click', closeSidebar );
		}
	}

	/* ── E-posta konusu: {alan} değişkenini tıklayınca input'a ekle ── */
	function bindTokens() {
		const input = document.getElementById( 'dxp_form_subject' );
		if ( ! input ) return;

		document.addEventListener( 'click', function ( e ) {
			const chip = e.target.closest ? e.target.closest( '.dxp-token' ) : null;
			if ( ! chip ) return;

			e.preventDefault();

			const token = chip.getAttribute( 'data-token' ) || '';
			if ( ! token ) return;

			const val   = input.value;
			const start = input.selectionStart;
			const end   = input.selectionEnd;

			if ( 'number' !== typeof start ) {
				/* Konum bilgisi yoksa sonuna ekle. */
				input.value = val + token;
			} else {
				input.value = val.slice( 0, start ) + token + val.slice( end );
				const pos = start + token.length;
				input.setSelectionRange( pos, pos );
			}

			/* Manuel yazmaya devam edilebilsin: odak input'ta kalır. */
			input.focus();
			input.dispatchEvent( new Event( 'input', { bubbles: true } ) );
		} );
	}

	/* ── Yazı boyutu ölçeği: [−] Aaⁿ [+] (5 kademe, ortası varsayılan) ── */
	function bindScale() {
		const panel = document.getElementById( 'devxpe-panel' );
		const wrap  = document.querySelector( '.dxp-scale' );
		if ( ! panel || ! wrap ) return;

		const steps = [ 0.8, 0.9, 1, 1.12, 1.25 ];
		const label = wrap.querySelector( '.dxp-scale-value small' );
		const down  = wrap.querySelector( '[data-dxp-scale="-1"]' );
		const up    = wrap.querySelector( '[data-dxp-scale="1"]' );
		let level = parseInt( localStorage.getItem( 'devxpe_panel_scale' ), 10 );

		if ( isNaN( level ) || level < 0 || level > steps.length - 1 ) { level = 2; }

		function apply( next ) {
			level = Math.min( Math.max( next, 0 ), steps.length - 1 );
			panel.style.setProperty( '--dxp-scale', steps[ level ] );
			if ( label ) { label.textContent = level + 1; }
			if ( down ) { down.disabled = ( 0 === level ); }
			if ( up ) { up.disabled = ( level === steps.length - 1 ); }
			localStorage.setItem( 'devxpe_panel_scale', level );
		}

		if ( down ) { down.addEventListener( 'click', function () { apply( level - 1 ); } ); }
		if ( up ) { up.addEventListener( 'click', function () { apply( level + 1 ); } ); }

		apply( level );
	}

	/* ── Formu AJAX ile kaydetme (bayat form korumalı) ───────── */
	function bindFormSubmit() {
		const form = $( '#devxpe-panel-form' );
		if ( ! form ) return;

		/*
		 * Bayat form koruması.
		 *
		 * Panel başka bir sekmede de açıkken orada kaydedilirse, bu sekmedeki
		 * form eski değerleri taşır. Tüm formu göndermek dokunulmamış alanların
		 * üzerine eski değerleri yazar. Bunu önlemek için yalnızca kullanıcının
		 * DEĞİŞTİRDİĞİ alanlar gönderilir; sunucu da gönderilmeyenleri korur.
		 */
		let baseline = {};

		function fieldId( name ) {
			const i = name.indexOf( '[' );
			return ( i === -1 ) ? name : name.substring( 0, i );
		}

		function collect() {
			const map = {};

			function push( name, value ) {
				const id = fieldId( name );
				if ( ! map[ id ] ) { map[ id ] = []; }
				map[ id ].push( name + '\u0000' + value );
			}

			Array.prototype.forEach.call( form.elements, function ( el ) {
				if ( ! el.name || el.tagName === 'BUTTON' ) { return; }

				if ( el.type === 'checkbox' ) {
					push( el.name, el.checked ? ( el.value || '1' ) : '' );
				} else if ( el.type === 'radio' ) {
					if ( el.checked ) { push( el.name, el.value ); }
				} else if ( el.tagName === 'SELECT' ) {
					Array.prototype.forEach.call( el.options, function ( o ) {
						if ( o.selected ) { push( el.name, o.value ); }
					} );
				} else {
					push( el.name, el.value );
				}
			} );

			const sig = {};
			Object.keys( map ).forEach( function ( id ) {
				sig[ id ] = map[ id ].slice().sort().join( '|' );
			} );

			return { map: map, sig: sig };
		}

		function takeBaseline() {
			baseline = collect().sig;
		}

		function dirtyFormData() {
			const now   = collect();
			const fd    = new FormData();
			let count = 0;

			Object.keys( now.sig ).forEach( function ( id ) {
				if ( baseline[ id ] === now.sig[ id ] ) { return; }
				now.map[ id ].forEach( function ( pair ) {
					const sep = pair.indexOf( '\u0000' );
					fd.append( pair.substring( 0, sep ), pair.substring( sep + 1 ) );
					count++;
				} );
			} );

			/* Tamamen boşalan alan: tüm satırları silinen repeater, tüm
			   seçimi kaldırılan sayfa kutusu vb. Bu durumda alan artık
			   DOM'da eleman üretmediği için sig'de de yoktur; sunucu
			   "gönderilmeyen korunur" devreye girip eski değeri tutar.
			   Bunu engellemek için alanı bilinçli olarak BOŞ gönder. */
			Object.keys( baseline ).forEach( function ( id ) {
				if ( now.sig[ id ] !== undefined ) { return; }
				fd.append( id, '' );
				count++;
			} );

			return { fd: fd, count: count };
		}

		takeBaseline();

		/*
		 * Kaydetme AJAX DEĞİL: sunucuya kalıcı veri yazan işlemler normal
		 * POST + PRG (Post-Redirect-Get) ile gider. Yalnızca DEĞİŞEN alanlar
		 * gizli bir formla gönderilir (bayat form koruması); sunucu
		 * gönderilmeyen alanları korur.
		 */
		form.addEventListener( 'submit', function ( e ) {
			// Import, eklenti kurulumu ve formaction'lı butonlar (ör. SMTP testi)
			// kendi normal POST'uyla gitsin; onlara dokunma.
			if ( e.submitter && ( 'devxpe_theme_import' === e.submitter.name || 'devxpe_plugin_install' === e.submitter.name || e.submitter.hasAttribute( 'formaction' ) ) ) {
				return;
			}

			e.preventDefault();

			const saveBtn = $( '.dxp-save-btn' );
			const dirty   = dirtyFormData();

			if ( ! dirty.count ) {
				if ( saveBtn ) {
					const orig = saveBtn.textContent;
					saveBtn.textContent = 'Değişiklik yok';
					setTimeout( function () { saveBtn.textContent = orig; }, 1500 );
				}
				return;
			}

			/*
			 * Değişen alanları gizli bir forma koy; tarayıcının NORMAL POST'u
			 * ile gönder. Sunucu işleyip PRG ile panele geri yönlendirir.
			 * (fetch/XHR yok.)
			 */
			const native = document.createElement( 'form' );
			native.method  = 'post';
			native.action  = form.getAttribute( 'action' ) || window.location.href;
			native.style.display = 'none';

			function addField( name, value ) {
				const input = document.createElement( 'input' );
				input.type  = 'hidden';
				input.name  = name;
				input.value = value;
				native.appendChild( input );
			}

			dirty.fd.forEach( function ( value, name ) {
				addField( name, value );
			} );
			addField( 'devxpe_theme_save', '1' );

			const nonceEl = form.querySelector( '[name="devxpe_theme_nonce"]' );
			if ( nonceEl ) {
				addField( 'devxpe_theme_nonce', nonceEl.value );
			}

			document.body.appendChild( native );
			native.submit();
		} );
	}

	/* ── Dark Mode Toggle ─────────────────────────────────── */
	function bindDarkMode() {
		const panel = document.getElementById( 'devxpe-panel' );
		const toggle = document.querySelector( '.dxp-dark-mode-toggle' );
		if ( ! panel || ! toggle ) return;

		const isDark = localStorage.getItem( 'devxpe_panel_dark' ) === '1';
		if ( isDark ) {
			panel.classList.add( 'dxp-dark-mode' );
		}

		toggle.addEventListener( 'click', function () {
			panel.classList.toggle( 'dxp-dark-mode' );
			const darkActive = panel.classList.contains( 'dxp-dark-mode' );
			localStorage.setItem( 'devxpe_panel_dark', darkActive ? '1' : '0' );
		} );
	}

	/* ── Renk Uyumu: tick açıkken tonları önizle, manuel alanları gizle ── */
	function bindColorHarmony() {
		const form = $( '#devxpe-panel-form' );
		if ( ! form ) return;

		const cb = form.querySelector( '[name="harmonize_colors"]' );
		if ( ! cb ) return;

		const primary    = form.querySelector( '[name="primary_color"]' );
		const hoverInput = form.querySelector( '[name="primary_hover"]' );
		const focusInput = form.querySelector( '[name="primary_focus"]' );
		const hoverRow   = hoverInput ? hoverInput.closest( '.dxp-row' ) : null;
		const focusRow   = focusInput ? focusInput.closest( '.dxp-row' ) : null;

		const preview = document.createElement( 'div' );
		preview.className = 'dxp-tone-preview';
		const harmRow = cb.closest( '.dxp-row' );
		const insertTarget = harmRow ? harmRow.children[ 1 ] : null;
		if ( insertTarget ) {
			insertTarget.appendChild( preview );
		} else if ( harmRow ) {
			harmRow.appendChild( preview );
		} else {
			form.appendChild( preview );
		}

		function renderPreview( val ) {
			preview.textContent = '';
			val = ( val || '' ).trim();
			if ( ! val ) return;

			[ [ 'Açık', 'white', 'hover' ], [ 'Koyu', 'black', 'focus' ] ].forEach( function ( item ) {
				const tile = document.createElement( 'div' );
				tile.className = 'dxp-tone-tile';

				const sw = document.createElement( 'span' );
				sw.className = 'dxp-tone-swatch';
				sw.style.background = 'color-mix(in srgb, ' + val + ', ' + item[ 1 ] + ' 18%)';

				const lbl = document.createElement( 'span' );
				lbl.className = 'dxp-tone-name';
				lbl.textContent = item[ 0 ] + ' · ' + item[ 2 ];

				tile.appendChild( sw );
				tile.appendChild( lbl );
				preview.appendChild( tile );
			} );
		}

		function update() {
			const on = cb.checked;
			if ( hoverRow ) hoverRow.classList.toggle( 'dxp-hidden-manual', on );
			if ( focusRow ) focusRow.classList.toggle( 'dxp-hidden-manual', on );
			preview.classList.toggle( 'dxp-hidden-manual', ! on );
			if ( on ) {
				renderPreview( primary ? primary.value : '' );
			}
		}

		cb.addEventListener( 'change', update );
		if ( primary ) primary.addEventListener( 'input', update );

		/* Renk seçici / şeffaflık slider'ı metin alanını günceller; onları da dinle. */
		[ 'clr_dxp_primary_color', 'opc_dxp_primary_color' ].forEach( function ( id ) {
			const el = document.getElementById( id );
			if ( el ) el.addEventListener( 'input', update );
		} );

		update();
	}

	/* ── Link / header rengi: uyum açıkken manuel renk satırını gizle ── */
	function bindColorFieldHarmony() {
		const form = $( '#devxpe-panel-form' );
		if ( ! form ) return;

		function bind( checkboxName, targetField ) {
			const cb    = form.querySelector( '[name="' + checkboxName + '"]' );
			const input = form.querySelector( '[name="' + targetField + '"]' );
			if ( ! cb || ! input ) return;

			const row = input.closest( '.dxp-row' );
			if ( ! row ) return;

			function update() {
				row.classList.toggle( 'dxp-hidden-manual', cb.checked );
			}

			cb.addEventListener( 'change', update );
			update();
		}

		bind( 'link_harmonize', 'link_color' );
		bind( 'header_text_harmonize', 'header_text' );
	}

	/* ── Radio-image seçim vurgusu ────────────────────────── */
	function bindRadioImages() {
		const form = $( '#devxpe-panel-form' );
		if ( ! form ) return;

		form.addEventListener( 'change', function ( e ) {
			const input = e.target;
			if ( ! input.classList || ! input.classList.contains( 'dxp-radio-image-input' ) ) return;
			$$( '.dxp-radio-image-input[name="' + input.name + '"]', form ).forEach( function ( i ) {
				i.closest( '.dxp-radio-image-label' ).classList.toggle( 'is-selected', i.checked );
			} );
		} );
	}

	/* ── Açılır ikon seçici (tüm dashicons, tembel üretim) ── */
	function bindIconPick() {
		const form = $( '#devxpe-panel-form' );
		if ( ! form ) return;

		const dataEl = document.getElementById( 'dxp-dashicons-data' );
		let icons  = [];
		try { icons = dataEl ? JSON.parse( dataEl.textContent ) : []; } catch ( err ) { icons = []; }

		const lucideEl = document.getElementById( 'dxp-lucide-data' );
		let lucide   = {};
		try { lucide = lucideEl ? JSON.parse( lucideEl.textContent ) : {}; } catch ( err ) { lucide = {}; }

		/* Font Awesome 6 ikon adları: { solid: [...], regular: [...], brands: [...] } */
		const faEl = document.getElementById( 'dxp-fa-data' );
		let fa   = {};
		try { fa = faEl ? JSON.parse( faEl.textContent ) : {}; } catch ( err ) { fa = {}; }

		/* Lucide ikonunu <svg> olarak döndür (devxpe_lucide ile aynı biçim). */
		function lucideSvg( name ) {
			if ( ! lucide[ name ] ) return '';
			return '<svg class="dxp-ic" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + lucide[ name ] + '</svg>';
		}

		/* Aktif ikon seti: lucide | fa-solid | fa-regular | fa-brands | dashicons */
		function setOf( pick ) {
			return pick.getAttribute( 'data-active-set' )
				|| ( 'lucide' === pick.getAttribute( 'data-icon-set' ) ? 'lucide' : 'dashicons' );
		}

		function build( pick, force ) {
			const grid = pick.querySelector( '.dxp-iconpick-grid' );
			if ( ! grid ) return;
			if ( grid.childElementCount && ! force ) return;

			const set   = setOf( pick );
			const isLuc = ( 'lucide' === set );
			const names = isLuc
				? [ '' ].concat( Object.keys( lucide ) )
				: [ '' ].concat( fa[ set.replace( 'fa-', '' ) ] || icons );
			const val   = pick.querySelector( '.dxp-iconpick-value' ).value;
			const frag  = document.createDocumentFragment();

			grid.innerHTML = '';

			names.forEach( function ( name ) {
				const b = document.createElement( 'button' );
				b.type = 'button';
				b.className = 'dxp-iconpick-item';
				b.setAttribute( 'data-icon', name || '' );
				b.title = name || '—';

				if ( ! name ) {
					b.setAttribute( 'data-value', '' );
					b.innerHTML = '<span class="dxp-iconpick-none">—</span>';
				} else if ( isLuc ) {
					b.setAttribute( 'data-value', name );
					b.innerHTML = lucideSvg( name );
				} else if ( 'dashicons' === set ) {
					b.setAttribute( 'data-value', name );
					const s = document.createElement( 'span' );
					s.className = 'dashicons ' + name;
					b.appendChild( s );
				} else {
					const cls = 'fa-' + set.replace( 'fa-', '' ) + ' fa-' + name;
					b.setAttribute( 'data-value', cls );
					b.innerHTML = '<i class="' + cls + '" aria-hidden="true"></i>';
				}

				if ( ( b.getAttribute( 'data-value' ) || '' ) === val ) {
					b.classList.add( 'is-selected' );
				}
				frag.appendChild( b );
			} );

			grid.appendChild( frag );
		}

		function closeAll() {
			$$( '.dxp-iconpick-panel', form ).forEach( function ( p ) { p.hidden = true; } );
			$$( '.dxp-iconpick-trigger', form ).forEach( function ( t ) { t.setAttribute( 'aria-expanded', 'false' ); } );
		}

		bindMenuAutoClose( closeAll );

		function filter( pick, term ) {
			if ( ! pick ) return;
			const terms = term ? term.toLowerCase().split( /\s+/ ).filter( Boolean ) : [];
			let shown = 0;

			$$( '.dxp-iconpick-item', pick ).forEach( function ( it ) {
				const name = ( it.getAttribute( 'data-icon' ) || '' ).toLowerCase();

				/* Yazılan tüm kelimeler ikon adında geçmeli (sırasız). */
				const match = ! terms.length || terms.every( function ( t ) {
					return name.indexOf( t ) !== -1;
				} );

				it.hidden = ! match;
				if ( match ) shown++;
			} );

			const empty = pick.querySelector( '.dxp-iconpick-empty' );
			if ( empty ) empty.hidden = shown > 0;
		}

		form.addEventListener( 'click', function ( e ) {
			const trigger = e.target.closest( '.dxp-iconpick-trigger' );
			if ( trigger ) {
				const pick   = trigger.closest( '.dxp-iconpick' );
				const panel  = pick.querySelector( '.dxp-iconpick-panel' );
				const isOpen = ! panel.hidden;
				closeAll();
				if ( ! isOpen ) {
					build( pick );
					panel.hidden = false;
					trigger.setAttribute( 'aria-expanded', 'true' );
					floatMenu( panel, trigger, false );
					const s = panel.querySelector( '.dxp-iconpick-search' );
					if ( s ) { s.value = ''; filter( pick, '' ); s.focus(); }
				}
				return;
			}

			/* İkon seti değiştir (Lucide / FA Solid / FA Regular / FA Brands) */
			const setBtn = e.target.closest( '.dxp-iconpick-set' );
			if ( setBtn ) {
				const pickS = setBtn.closest( '.dxp-iconpick' );
				$$( '.dxp-iconpick-set', pickS ).forEach( function ( b ) {
					b.classList.toggle( 'is-active', b === setBtn );
				} );
				pickS.setAttribute( 'data-active-set', setBtn.getAttribute( 'data-set' ) );
				build( pickS, true );
				const search = pickS.querySelector( '.dxp-iconpick-search' );
				if ( search ) { search.value = ''; filter( pickS, '' ); }
				return;
			}

			const item = e.target.closest( '.dxp-iconpick-item' );
			if ( item ) {
				const pick2 = item.closest( '.dxp-iconpick' );
				let val   = item.getAttribute( 'data-value' );
				const icon  = item.getAttribute( 'data-icon' ) || '';

				if ( null === val ) { val = icon; }

				pick2.querySelector( '.dxp-iconpick-value' ).value = val;

				const visWrap = pick2.querySelector( '.dxp-iconpick-trigger .dxp-iconpick-visual' );
				if ( visWrap ) {
					if ( ! val ) {
						visWrap.innerHTML = '';
					} else if ( lucide[ val ] ) {
						visWrap.innerHTML = lucideSvg( val );
					} else if ( 0 === val.indexOf( 'dashicons-' ) ) {
						visWrap.innerHTML = '<span class="dashicons ' + val + '"></span>';
					} else {
						visWrap.innerHTML = '<i class="' + val + '" aria-hidden="true"></i>';
					}
				}

				const lbl = pick2.querySelector( '.dxp-iconpick-current' );
				if ( lbl ) {
					lbl.textContent = icon
						? icon.replace( 'dashicons-', '' )
						: ( pick2.getAttribute( 'data-empty-label' ) || '' );
				}
				const trg = pick2.querySelector( '.dxp-iconpick-trigger' );
				if ( trg ) {
					trg.title = lbl ? lbl.textContent : '';
				}
				$$( '.dxp-iconpick-item', pick2 ).forEach( function ( i ) {
					i.classList.toggle( 'is-selected', i === item );
				} );
				closeAll();
			}
		} );

		form.addEventListener( 'input', function ( e ) {
			const s = e.target;
			if ( s.classList && s.classList.contains( 'dxp-iconpick-search' ) ) {
				filter( s.closest( '.dxp-iconpick' ), s.value.trim().toLowerCase() );
			}
		} );

		document.addEventListener( 'click', function ( e ) {
			if ( ! e.target.closest( '.dxp-iconpick' ) ) {
				closeAll();
			}
		} );
	}

	/* ── Çalışan (team) tekrarlayıcı: ekle/sil/sırala ─────── */
	function bindTeamRepeater() {
		$$( '.dxp-repeater' ).forEach( function ( wrap ) {
			const list     = wrap.querySelector( '.dxp-repeater-list' );
			const addBtn   = wrap.querySelector( '.dxp-repeater-add' );
			const template = wrap.querySelector( '.dxp-repeater-template' );
			if ( ! list || ! template ) return;

			function reindex() {
				Array.from( list.children ).forEach( function ( row, i ) {
					row.querySelectorAll( '[name]' ).forEach( function ( input ) {
						input.setAttribute( 'name', input.getAttribute( 'name' ).replace( /\[\d+\]/, '[' + i + ']' ) );
					} );
				} );
			}

			function addRow() {
				const node = template.content.firstElementChild.cloneNode( true );
				node.querySelectorAll( 'input[type="text"], textarea' ).forEach( function ( i ) { i.value = ''; } );
				const prev = node.querySelector( '.dxp-image-preview' );
				if ( prev ) prev.innerHTML = '';
				list.appendChild( node );
				reindex();
			}

			/* Tekrarlanan alanlar (repeater) bu kancaları kullanır. */
			wrap.dxpReindex = reindex;
			wrap.dxpAddRow  = addRow;

			list.addEventListener( 'click', function ( e ) {
				const row = e.target.closest( '.dxp-repeater-row' );
				if ( ! row ) return;
				if ( e.target.closest( '.dxp-repeater-remove' ) ) {
					row.remove();
					reindex();
				} else if ( e.target.closest( '.dxp-repeater-up' ) ) {
					const p = row.previousElementSibling;
					if ( p ) { list.insertBefore( row, p ); reindex(); }
				} else if ( e.target.closest( '.dxp-repeater-down' ) ) {
					const n = row.nextElementSibling;
					if ( n ) { list.insertBefore( n, row ); reindex(); }
				}
			} );

			if ( addBtn ) addBtn.addEventListener( 'click', addRow );

			/*
			 * Alan türü değişince satırın data-type'ını güncelle; "Açılır liste"
			 * seçilince Seçenekler kutusu görünür (bkz. panel.css).
			 */
			list.addEventListener( 'change', function ( e ) {
				if ( e.target.classList && e.target.classList.contains( 'dxp-field-type' ) ) {
					const row = e.target.closest( '.dxp-repeater-row' );
					if ( row ) row.setAttribute( 'data-type', e.target.value );
				}
			} );

			/* Yükleme sonrası indeksleri düzelt (sunucudan gelen satırlar için) */
			reindex();
		} );
	}

	/* ── Seçenek alt-tekrarlayıcısı: ekle/sil/sırala ─────────────── */
	/*
	 * Her satır bir öneri. Görsel liste üzerinde çalışılır; gerçek değer
	 * gizli `.dxp-opt-value` input'una virgülle ayrılmış string olarak yazılır
	 * (veri modeli değişmez). Olay delegasyonu olduğu için sonradan eklenen
	 * dış satırlar da otomatik çalışır.
	 */
	function syncOptions( field ) {
		if ( ! field ) return;
		const hidden = field.querySelector( '.dxp-opt-value' );
		if ( ! hidden ) return;

		const values = $$( '.dxp-opt-input', field )
			.map( function ( input ) { return input.value.replace( /,/g, ' ' ).trim(); } )
			.filter( function ( v ) { return '' !== v; } );

		hidden.value = values.join( ',' );
	}

	function makeOptItem() {
		const item = document.createElement( 'div' );
		item.className = 'dxp-opt-item';
		item.innerHTML =
			'<input type="text" class="dxp-opt-input" list="dxp-options-templates" autocomplete="off" />' +
			'<button type="button" class="dxp-opt-up" title="Yukarı Taşı">&uarr;</button>' +
			'<button type="button" class="dxp-opt-down" title="Aşağı Taşı">&darr;</button>' +
			'<button type="button" class="dxp-opt-remove" title="Sil">&times;</button>';
		return item;
	}

	function bindOptionsRepeaters() {
		document.addEventListener( 'click', function ( e ) {
			const add = e.target.closest( '.dxp-opt-add' );
			if ( add ) {
				const field = add.closest( '.dxp-field-options' );
				if ( ! field ) return;
				const list = field.querySelector( '.dxp-opt-list' );
				const item = makeOptItem();
				list.appendChild( item );
				item.querySelector( '.dxp-opt-input' ).focus();
				syncOptions( field );
				return;
			}

			const remove = e.target.closest( '.dxp-opt-remove' );
			if ( remove ) {
				const field = remove.closest( '.dxp-field-options' );
				const item  = remove.closest( '.dxp-opt-item' );
				if ( field && item ) { item.remove(); syncOptions( field ); }
				return;
			}

			const up = e.target.closest( '.dxp-opt-up' );
			if ( up ) {
				const field = up.closest( '.dxp-field-options' );
				const item  = up.closest( '.dxp-opt-item' );
				if ( field && item && item.previousElementSibling ) {
					field.querySelector( '.dxp-opt-list' ).insertBefore( item, item.previousElementSibling );
					syncOptions( field );
				}
				return;
			}

			const down = e.target.closest( '.dxp-opt-down' );
			if ( down ) {
				const field = down.closest( '.dxp-field-options' );
				const item  = down.closest( '.dxp-opt-item' );
				if ( field && item && item.nextElementSibling ) {
					field.querySelector( '.dxp-opt-list' ).insertBefore( item.nextElementSibling, item );
					syncOptions( field );
				}
			}
		} );

		/* Yazarken virgülü engelle (virgül ayırıcıdır) ve gizli değeri güncelle. */
		document.addEventListener( 'input', function ( e ) {
			const input = e.target;
			if ( ! input.classList || ! input.classList.contains( 'dxp-opt-input' ) ) return;
			if ( input.value.indexOf( ',' ) !== -1 ) {
				input.value = input.value.replace( /,/g, ' ' );
			}
			syncOptions( input.closest( '.dxp-field-options' ) );
		} );

		/* Sunucudan gelen görsel satırları gizli değerle eşitle. */
		$$( '.dxp-field-options' ).forEach( syncOptions );
	}

	/* ── Kart başlığına tıklayınca daralt / genişlet ─────── */
	function bindCollapse() {
		const form = $( '#devxpe-panel-form' );
		if ( ! form ) return;

		form.addEventListener( 'click', function ( e ) {
			const header = e.target.closest( '.dxp-card-header' );
			if ( ! header ) return;
			const card = header.closest( '.dxp-card' );
			if ( ! card ) return;
			const collapsed = card.classList.toggle( 'is-collapsed' );
			header.setAttribute( 'aria-expanded', collapsed ? 'false' : 'true' );
		} );
	}

	/* ── Sekmeli bölüm (Header | Footer) ──────────────────── */
	function bindTabs() {
		const form = $( '#devxpe-panel-form' );
		if ( ! form ) return;

		form.addEventListener( 'click', function ( e ) {
			const btn = e.target.closest( '.dxp-tab' );
			if ( ! btn ) return;
			const wrap = btn.closest( '.dxp-tabs' );
			if ( ! wrap ) return;
			const id = btn.getAttribute( 'data-tab' );
			$$( '.dxp-tab', wrap ).forEach( function ( b ) { b.classList.toggle( 'active', b === btn ); } );
			$$( '.dxp-tab-panel', wrap ).forEach( function ( p ) {
				p.classList.toggle( 'active', p.getAttribute( 'data-tab-panel' ) === id );
			} );
		} );
	}

	/* ── Dil değiştirici (özel dropdown) ──────────────────── */
	function bindLangSwitch() {
		const sw = $( '.dxp-lang-switch' );
		if ( ! sw ) return;

		const trigger = sw.querySelector( '.dxp-lang-trigger' );
		const menu    = sw.querySelector( '.dxp-lang-menu' );
		const value   = sw.querySelector( '.dxp-lang-value' );
		if ( ! trigger || ! menu || ! value ) return;

		trigger.addEventListener( 'click', function ( e ) {
			e.stopPropagation();
			menu.hidden = ! menu.hidden;
			trigger.setAttribute( 'aria-expanded', menu.hidden ? 'false' : 'true' );
		} );

		menu.addEventListener( 'click', function ( e ) {
			const item = e.target.closest( '.dxp-lang-item' );
			if ( ! item ) return;
			value.value = item.getAttribute( 'data-lang' );
			if ( sw.submit ) { sw.submit(); }
		} );

		document.addEventListener( 'click', function ( e ) {
			if ( ! e.target.closest( '.dxp-lang-switch' ) ) {
				menu.hidden = true;
				trigger.setAttribute( 'aria-expanded', 'false' );
			}
		} );
	}

	/*
	 * Açılır menüyü görünüme sabitler (position: fixed). Böylece kartların
	 * overflow:hidden'ı ve içerik scroll alanı menüyü kırpmaz. Sığmazsa
	 * menüyü tetikleyicinin üstüne yerleştirir.
	 */
	function floatMenu( menu, trigger, matchWidth ) {
		if ( ! menu || ! trigger ) return;

		const r  = trigger.getBoundingClientRect();
		const mh = menu.offsetHeight;
		const mw = menu.offsetWidth;
		const vh = window.innerHeight;
		const vw = window.innerWidth;

		let top = r.bottom + 4;
		if ( top + mh > vh - 8 ) {
			top = r.top - mh - 4;
		}
		if ( top < 8 ) top = 8;

		let left = r.left;
		if ( left + mw > vw - 8 ) left = vw - mw - 8;
		if ( left < 8 ) left = 8;

		menu.classList.add( 'dxp-floating' );
		menu.style.position  = 'fixed';
		menu.style.top       = top + 'px';
		menu.style.left      = left + 'px';
		menu.style.zIndex    = '100000';
		menu.style.maxHeight = Math.max( 160, vh - top - 12 ) + 'px';
		if ( matchWidth ) menu.style.minWidth = r.width + 'px';
	}

	/*
	 * Açık menüleri, içerik alanı kaydırılınca veya pencere yeniden
	 * boyutlandırılınca kapatır (konum bayatlamasın).
	 */
	function bindMenuAutoClose( closeAll ) {
		const scroller = document.querySelector( '#devxpe-panel-right .dxp-content' );
		if ( scroller ) scroller.addEventListener( 'scroll', closeAll, { passive: true } );
		window.addEventListener( 'resize', closeAll );
	}

	/* ── Özel açılır menüler (native select yerine) ───────── */
	function bindSelects() {
		const form = $( '#devxpe-panel-form' );
		if ( ! form ) return;

		function closeAll() {
			$$( '.dxp-select-menu', form ).forEach( function ( m ) { m.hidden = true; } );
			$$( '.dxp-select-trigger', form ).forEach( function ( t ) { t.setAttribute( 'aria-expanded', 'false' ); } );
		}

		bindMenuAutoClose( closeAll );

		form.addEventListener( 'click', function ( e ) {
			const trigger = e.target.closest( '.dxp-select-trigger' );
			if ( trigger ) {
				const wrap = trigger.closest( '.dxp-select' );
				const menu = wrap.querySelector( '.dxp-select-menu' );
				const isOpen = ! menu.hidden;
				closeAll();
				if ( ! isOpen ) {
					menu.hidden = false;
					trigger.setAttribute( 'aria-expanded', 'true' );
					floatMenu( menu, trigger, true );
				}
				return;
			}

			const item = e.target.closest( '.dxp-select-item' );
			if ( item ) {
				const wrap2 = item.closest( '.dxp-select' );
				const val   = item.getAttribute( 'data-value' );

				const valEl = wrap2.querySelector( '.dxp-select-value' );
				if ( valEl ) {
					valEl.value = val;
					/* Koşul kaynağı alanlar (bindConditionSubmit) bu olayı dinler. */
					valEl.dispatchEvent( new Event( 'change', { bubbles: true } ) );
				}

				const target = wrap2.getAttribute( 'data-target' );
				if ( target ) {
					const t = document.getElementById( target );
					if ( t ) t.value = val;
				}

				const cur = wrap2.querySelector( '.dxp-select-current' );
				if ( cur ) cur.textContent = item.textContent.trim();

				$$( '.dxp-select-item', wrap2 ).forEach( function ( i ) {
					i.classList.toggle( 'is-selected', i === item );
					i.setAttribute( 'aria-selected', i === item ? 'true' : 'false' );
				} );
				closeAll();
			}
		} );

		document.addEventListener( 'click', function ( e ) {
			if ( ! e.target.closest( '.dxp-select' ) ) {
				closeAll();
			}
		} );
	}

	
	/* ── Kısa kod kopyala düğmeleri ───────────────────────── */
	/* ── Çoklu seçim (ülke) ────────────────────────────────────────── */
	function bindMultiselect() {
		const form = $( '#devxpe-panel-form' );
		if ( ! form ) return;

		function closeAll() {
			$$( '.dxp-multiselect-menu', form ).forEach( function ( m ) { m.hidden = true; } );
			$$( '.dxp-multiselect-trigger', form ).forEach( function ( t ) { t.setAttribute( 'aria-expanded', 'false' ); } );
		}

		bindMenuAutoClose( closeAll );

		/*
		 * Seçili onay kutularından ve listede olmayan gizli (legacy/özel)
		 * kayıtlardan özet + sayı üret. Menü açıkken de çağrılır; kapanmaz.
		 */
		function update( wrap ) {
			if ( ! wrap ) return;
			const parts = [];

			$$( 'input[type="checkbox"]:checked', wrap ).forEach( function ( cb ) {
				const item = cb.closest( '.dxp-multiselect-item' );
				const nameEl = item ? item.querySelector( '.dxp-multiselect-name' ) : null;
				const name = nameEl ? nameEl.textContent.trim() : '';
				parts.push( cb.value + ( name ? ' ' + name : '' ) );
			} );

			/* Gizli değer biçimi: "kod|Ad". */
			$$( 'input[type="hidden"]', wrap ).forEach( function ( h ) {
				const raw  = h.value || '';
				const sep  = raw.indexOf( '|' );
				const code = sep === -1 ? raw : raw.slice( 0, sep );
				const name = sep === -1 ? '' : raw.slice( sep + 1 );
				parts.push( code + ( name ? ' ' + name : '' ) );
			} );

			const summary = wrap.querySelector( '.dxp-multiselect-summary' );
			const count   = wrap.querySelector( '.dxp-multiselect-count' );
			const empty   = wrap.getAttribute( 'data-placeholder' ) || '';

			if ( summary ) summary.textContent = parts.length ? parts.join( ', ' ) : empty;
			if ( count ) count.textContent = parts.length ? String( parts.length ) : '';
		}

		function filter( wrap, term ) {
			const terms = term ? term.toLowerCase().split( /\s+/ ).filter( Boolean ) : [];
			let shown = 0;

			$$( '.dxp-multiselect-item', wrap ).forEach( function ( it ) {
				const codeEl = it.querySelector( '.dxp-multiselect-code' );
				const nameEl = it.querySelector( '.dxp-multiselect-name' );
				const hay = ( ( codeEl ? codeEl.textContent : '' ) + ' ' + ( nameEl ? nameEl.textContent : '' ) ).toLowerCase();

				/* Yazılan tüm kelimeler kod veya ad içinde geçmeli (sırasız). */
				const match = ! terms.length || terms.every( function ( t ) {
					return hay.indexOf( t ) !== -1;
				} );

				it.hidden = ! match;
				if ( match ) shown++;
			} );

			const empty = wrap.querySelector( '.dxp-multiselect-empty' );
			if ( empty ) empty.hidden = shown > 0;
		}

		form.addEventListener( 'click', function ( e ) {
			const trigger = e.target.closest( '.dxp-multiselect-trigger' );
			if ( ! trigger ) return;

			const wrap   = trigger.closest( '.dxp-multiselect' );
			const menu   = wrap.querySelector( '.dxp-multiselect-menu' );
			const isOpen = ! menu.hidden;
			closeAll();
			if ( ! isOpen ) {
				menu.hidden = false;
				trigger.setAttribute( 'aria-expanded', 'true' );
				floatMenu( menu, trigger, true );
				const s = menu.querySelector( '.dxp-multiselect-search' );
				if ( s ) { s.value = ''; filter( wrap, '' ); s.focus(); }
			}
		} );

		/* Onay kutusu değişimi: özet/sayı güncelle, menüyü KAPATMA. */
		form.addEventListener( 'change', function ( e ) {
			if ( e.target.matches && e.target.matches( '.dxp-multiselect-list input[type="checkbox"]' ) ) {
				update( e.target.closest( '.dxp-multiselect' ) );
			}
		} );

		form.addEventListener( 'input', function ( e ) {
			const s = e.target;
			if ( s.classList && s.classList.contains( 'dxp-multiselect-search' ) ) {
				filter( s.closest( '.dxp-multiselect' ), s.value.trim().toLowerCase() );
			}
		} );

		document.addEventListener( 'click', function ( e ) {
			if ( ! e.target.closest( '.dxp-multiselect' ) ) {
				closeAll();
			}
		} );

		document.addEventListener( 'keydown', function ( e ) {
			if ( 'Escape' === e.key ) {
				closeAll();
			}
		} );

		/* Sunucudan gelen başlangıç durumunu DOM ile eşitle. */
		$$( '.dxp-multiselect', form ).forEach( update );
	}

	function bindCopyButtons() {
		$$( '.dxp-copy-btn' ).forEach( function ( btn ) {
			if ( btn.dataset.bound ) { return; }
			btn.dataset.bound = '1';
			btn.addEventListener( 'click', function () {
				const text = btn.getAttribute( 'data-copy' ) || '';
				if ( navigator.clipboard && navigator.clipboard.writeText ) {
					navigator.clipboard.writeText( text ).then( function () {
						const old = btn.textContent;
						btn.textContent = '✓';
						setTimeout( function () { btn.textContent = old; }, 1200 );
					} );
				}
			} );
		} );
	}

	/* ── Karakter sayacı (maxlength'li alanlar) ───────────── */
	function bindCharCount() {
		const counters = $$( '.dxp-charcount' );
		if ( ! counters.length ) return;

		counters.forEach( function ( el ) {
			const field = document.getElementById( el.getAttribute( 'data-for' ) );
			const max   = parseInt( el.getAttribute( 'data-max' ), 10 ) || 0;
			if ( ! field || ! max ) return;

			function update() {
				const len = field.value.length;
				el.textContent = len + ' / ' + max;
				el.classList.toggle( 'is-over', len >= max );
			}

			field.addEventListener( 'input', update );
			update();
		} );
	}

	/* ── Anasayfa iskeleti (sürükle-bırak sıralama) ───────── */
	/* ── İskelet yerleşimi: yan yana bölümler yarım genişlikte ─ */
	function layoutSkeleton( list, splitIds ) {
		Array.from( list.querySelectorAll( '.dxp-skeleton-slot' ) ).forEach( function ( slot ) { slot.remove(); } );

		const items = Array.from( list.children ).filter( function ( el ) {
			return el.classList.contains( 'dxp-skeleton-item' );
		} );

		items.forEach( function ( li ) {
			li.classList.remove( 'is-half' );
			li.style.flex = '';
		} );

		const gap  = 6;
		const half = 'calc((100% - ' + gap + 'px) / 2)';
		let i    = 0;

		while ( i < items.length ) {
			const group  = [ items[ i ] ];
			let cursor = i;

			/* Yalnızca işaretli komşular gruba katılır. */
			if ( splitIds.indexOf( items[ i ].getAttribute( 'data-id' ) ) !== -1 ) {
				while ( cursor + 1 < items.length && splitIds.indexOf( items[ cursor + 1 ].getAttribute( 'data-id' ) ) !== -1 ) {
					cursor++;
					group.push( items[ cursor ] );
				}
			}

			const size = group.length;

			if ( size > 1 ) {
				const basis = 'calc((100% - ' + ( ( size - 1 ) * gap ) + 'px) / ' + size + ')';
				group.forEach( function ( li ) {
					li.classList.add( 'is-half' );
					li.style.flex = '0 0 ' + basis;
				} );
			} else if ( splitIds.indexOf( group[0].getAttribute( 'data-id' ) ) !== -1 ) {
				/* İşaretli ama yanına gelecek bölüm yok: sağ yarıya boş yuva koy. */
				group[0].classList.add( 'is-half' );
				group[0].style.flex = '0 0 ' + half;

				const slot = document.createElement( 'li' );
				slot.className = 'dxp-skeleton-slot';
				slot.setAttribute( 'aria-hidden', 'true' );
				slot.textContent = '+';
				list.insertBefore( slot, group[0].nextElementSibling );
			}

			i = cursor + 1;
		}
	}

	function bindSkeleton() {
		$$( '.dxp-skeleton' ).forEach( function ( wrap ) {
			const list       = wrap.querySelector( '.dxp-skeleton-list' );
			const value      = wrap.querySelector( '.dxp-skeleton-value' );
			const splitInput = wrap.querySelector( '.dxp-skeleton-split' );
			if ( ! list || ! value ) return;

			let splitIds = ( splitInput && splitInput.value ) ? splitInput.value.split( ',' ) : [];

			function layout() {
				layoutSkeleton( list, splitIds );
			}

			function sync() {
				const ids = [];
				Array.from( list.querySelectorAll( '.dxp-skeleton-item' ) ).forEach( function ( li ) {
					ids.push( li.getAttribute( 'data-id' ) );
				} );
				value.value = ids.join( ',' );
			}

			/* Sürükle-bırak devre dışı: sıralama yukarı/aşağı düğmeleriyle yapılır. */

			/* CPT iskeleti: bölümü aç / kapa */
			const offInput = wrap.querySelector( '.dxp-skeleton-off' );
			if ( offInput ) {
				list.addEventListener( 'click', function ( e ) {
					const btn = e.target.closest( '.dxp-skeleton-toggle' );
					if ( ! btn ) return;
					const li = btn.closest( '.dxp-skeleton-item' );
					if ( ! li ) return;

					const itemId = li.getAttribute( 'data-id' );
					const ids    = offInput.value ? offInput.value.split( ',' ) : [];
					const at     = ids.indexOf( itemId );
					const turned = ( at === -1 );

					if ( turned ) { ids.push( itemId ); } else { ids.splice( at, 1 ); }

					offInput.value = ids.join( ',' );
					li.classList.toggle( 'is-off', turned );
					btn.setAttribute( 'aria-pressed', turned ? 'false' : 'true' );
					btn.textContent = turned ? btn.getAttribute( 'data-show' ) : btn.getAttribute( 'data-hide' );
					const st = li.querySelector( '.dxp-skeleton-state' );
					if ( st ) st.textContent = turned ? st.getAttribute( 'data-off' ) : st.getAttribute( 'data-on' );
				} );
			}

			/* "Yan yana": sonraki bölümle aynı satırı paylaş */
			if ( splitInput ) {
				list.addEventListener( 'click', function ( e ) {
					const btn = e.target.closest( '.dxp-skeleton-side' );
					if ( ! btn ) return;
					const li = btn.closest( '.dxp-skeleton-item' );
					if ( ! li ) return;

					const itemId = li.getAttribute( 'data-id' );
					const ids    = splitInput.value ? splitInput.value.split( ',' ) : [];
					const at     = ids.indexOf( itemId );
					const turned = ( at === -1 );

					if ( turned ) { ids.push( itemId ); } else { ids.splice( at, 1 ); }

					splitInput.value = ids.join( ',' );
					splitIds         = ids;
					li.classList.toggle( 'is-split', turned );
					btn.setAttribute( 'aria-pressed', turned ? 'true' : 'false' );
					layout();
				} );
			}

			/* Yukarı / aşağı taşıma (sürüklemenin yanında güvenli alternatif) */
			list.addEventListener( 'click', function ( e ) {
				const upBtn   = e.target.closest( '.dxp-skeleton-up' );
				const downBtn = e.target.closest( '.dxp-skeleton-down' );
				if ( ! upBtn && ! downBtn ) return;
				const li = e.target.closest( '.dxp-skeleton-item' );
				if ( ! li ) return;

				if ( upBtn ) {
					let prev = li.previousElementSibling;
					while ( prev && ! prev.classList.contains( 'dxp-skeleton-item' ) ) { prev = prev.previousElementSibling; }
					if ( prev ) list.insertBefore( li, prev );
				} else {
					let next = li.nextElementSibling;
					while ( next && ! next.classList.contains( 'dxp-skeleton-item' ) ) { next = next.nextElementSibling; }
					if ( next ) list.insertBefore( next, li );
				}

				sync();
				layout();
			} );

			sync();
			layout();
		} );

		/*
		 * Anasayfa iskeleti: bölümün ön yüzde görünürlüğü hem "Bölüm Aktif"
		 * tikine hem "Gösterileceği Yer" seçimine bağlıdır. İkisi değişince
		 * iskelet satırını canlı güncelle (sayfadaki durumla senkron).
		 * CPT/Hakkımızda iskeletleri kendi "kapalı" listesini kullanır; bu
		 * yüzden yalnızca "yan yana" (split) alanı olan anasayfa iskeletine uygula.
		 */
		$$( '.dxp-skeleton' ).forEach( function ( wrap ) {
			if ( ! wrap.querySelector( '.dxp-skeleton-split' ) ) return;

			wrap.querySelectorAll( '.dxp-skeleton-item' ).forEach( function ( li ) {
				const id       = li.getAttribute( 'data-id' );
				const checkbox = document.getElementById( 'dxp_' + id + '_enable' );

				const toggle = li.querySelector( '.dxp-skeleton-toggle' );

				function apply() {
					const off = ( checkbox && ! checkbox.checked );
					li.classList.toggle( 'is-off', off );
					const state = li.querySelector( '.dxp-skeleton-state' );
					if ( state ) {
						state.textContent = off ? state.getAttribute( 'data-off' ) : state.getAttribute( 'data-on' );
					}
					if ( toggle ) {
						toggle.setAttribute( 'aria-pressed', off ? 'false' : 'true' );
						toggle.textContent = off ? toggle.getAttribute( 'data-show' ) : toggle.getAttribute( 'data-hide' );
					}
				}

				if ( checkbox ) checkbox.addEventListener( 'change', apply );
				apply();

				/* İskelet üzerinden "Bölüm Aktif" tikini aç/kapa */
				if ( toggle && checkbox ) {
					toggle.addEventListener( 'click', function () {
						checkbox.checked = ! checkbox.checked;
						checkbox.dispatchEvent( new Event( 'change', { bubbles: true } ) );
					} );
				}
			} );
		} );
	}

	/* ── "Bu Bölümü Göster" tikine göre alt satırları gizle ─ */
	function bindSectionEnable() {
		$$( 'input[id^="dxp_"][id$="_enable"]' ).forEach( function ( cb ) {
			const sectionId = cb.id.slice( 4, -7 );
			const rows      = [];

			[ '[name="' + sectionId + '_show"]', '[name="' + sectionId + '_pages[]"]' ].forEach( function ( sel ) {
				const el = document.querySelector( sel );
				if ( ! el ) return;
				const row = el.closest( '.dxp-row' );
				if ( row ) rows.push( row );
			} );

			if ( ! rows.length ) return;

			function toggle() {
				rows.forEach( function ( row ) { row.hidden = ! cb.checked; } );
			}

			cb.addEventListener( 'change', toggle );
			toggle();
		} );
	}

	/* ── Koşul kaynağı alanlar: kaydet ve yeniden çiz ─────── */
	/*
	 * Görünürlük kararı artık sunucuda (DEVXPE_Theme_Conditions). Bir koşul
	 * kaynağı alan değişince form normal POST ile gönderilir; PHP yeni
	 * değerlerle görünürlüğü yeniden hesaplar. AJAX yok, display:none yok.
	 * Kaynak alan listesi PHP'den data-dxp-condition-sources ile gelir.
	 */
	function bindConditionSubmit() {
		const form = $( '#devxpe-panel-form' );
		if ( ! form ) return;

		const sources = ( form.getAttribute( 'data-dxp-condition-sources' ) || '' )
			.split( ',' )
			.filter( function ( s ) { return s; } );
		if ( ! sources.length ) return;

		form.addEventListener( 'change', function ( e ) {
			if ( ! e.target || ! e.target.name ) return;

			const id = e.target.name.split( '[' )[ 0 ];
			if ( sources.indexOf( id ) === -1 ) return;

			/* Programatik submit event tetiklemesin (AJAX kaydı atlanır). */
			if ( ! form.querySelector( 'input[name="devxpe_theme_save"]' ) ) {
				const trigger   = document.createElement( 'input' );
				trigger.type    = 'hidden';
				trigger.name    = 'devxpe_theme_save';
				trigger.value   = '1';
				form.appendChild( trigger );
			}
			form.submit();
		} );
	}

	/* ── Gelen Mesajlar: detay (odak) görünümü ───────────── */
	/*
	 * Satıra tıklayınca liste aynı kart içinde detayla değişir; "← Geri"
	 * veya Esc listeye döner. Detay verisi satırdaki data-msg (JSON)
	 * alanından okunur; içerik DOM API'siyle kurulur (kullanıcı verisi
	 * innerHTML ile yazılmaz → XSS yok).
	 */
	function bindInbox() {
		const inbox = $( '#dxp-inbox' );
		if ( ! inbox ) return;

		const list   = inbox.querySelector( '.dxp-inbox-list' );
		const detail = inbox.querySelector( '.dxp-inbox-detail' );
		const inner  = inbox.querySelector( '.dxp-inbox-detail-inner' );
		const back   = inbox.querySelector( '.dxp-inbox-back' );
		if ( ! list || ! detail || ! inner || ! back ) return;

		let lastItem = null;

		function el( tag, cls, text ) {
			const node = document.createElement( tag );
			if ( cls ) { node.className = cls; }
			if ( text !== undefined && text !== null ) { node.textContent = text; }
			return node;
		}

		function section( title ) {
			const wrap = el( 'div', 'dxp-inbox-detail-section' );
			wrap.appendChild( el( 'div', 'dxp-inbox-detail-section-title', title ) );
			return wrap;
		}

		function fieldRow( label, value ) {
			const row = el( 'div', 'dxp-inbox-detail-field' );
			row.appendChild( el( 'span', 'dxp-inbox-detail-label', label ) );
			const val = el( 'span', 'dxp-inbox-detail-value' );
			if ( value instanceof Node ) {
				val.appendChild( value );
			} else {
				val.textContent = ( value === undefined || value === null ) ? '—' : String( value );
			}
			row.appendChild( val );
			return row;
		}

		function link( href, text ) {
			const a = el( 'a', '', text );
			a.href = href;
			return a;
		}

		function close() {
			inbox.classList.remove( 'is-open' );
			$$( '.dxp-inbox-item', list ).forEach( function ( it ) {
				it.setAttribute( 'aria-expanded', 'false' );
			} );
			if ( lastItem ) { lastItem.focus(); }
		}

		/* Rozetleri (menü + kart başlığı) verilen sayıyla günceller. */
		function badgeGuncelle( sayi ) {
			if ( 'number' !== typeof sayi ) { return; }

			$$( '.dxp-count-badge' ).forEach( function ( b ) {
				if ( sayi > 0 ) {
					b.textContent = String( sayi );
					b.hidden = false;
					b.style.display = 'inline-block';
				} else {
					b.hidden = true;
					b.style.display = 'none';
				}
			} );
		}

		/* Rozetteki sayıyı okur (yoksa 0). */
		function badgeSayi() {
			const b = $( '.dxp-count-badge' );
			return b ? ( parseInt( b.textContent, 10 ) || 0 ) : 0;
		}

		/* Satırın okundu/okunmadı görünümünü ve bağlantısını günceller. */
		function satirDurum( item, okundu ) {
			item.classList.toggle( 'is-unread', ! okundu );

			const link = item.querySelector( '.dxp-inbox-read' );
			if ( link ) {
				link.textContent = okundu ? 'Okundu' : 'Okunmadı';
				link.href = link.href.replace( /okundu=[01]/, okundu ? 'okundu=0' : 'okundu=1' );
			}
		}

		/*
		 * Detayı açılan mesaj ANINDA okundu sayılır: satır ve rozetler
		 * beklemeden güncellenir, sunucu sonra doğrular (senkron hareket).
		 */
		function markRead( item ) {
			satirDurum( item, true );
			badgeGuncelle( Math.max( 0, badgeSayi() - 1 ) );

			const url   = inbox.getAttribute( 'data-read-url' );
			const nonce = inbox.getAttribute( 'data-read-nonce' );
			const id    = item.getAttribute( 'data-id' );

			if ( ! url || ! nonce || ! id ) { return; }

			const fd = new FormData();
			fd.append( 'action', 'devxpe_form_read_ajax' );
			fd.append( 'nonce', nonce );
			fd.append( 'id', id );

			fetch( url, { method: 'POST', credentials: 'same-origin', body: fd } )
				.then( function ( r ) { return r.json(); } )
				.then( function ( d ) {
					if ( d && d.success && d.data && 'number' === typeof d.data.unread ) {
						badgeGuncelle( d.data.unread );
					}
				} )
				.catch( function () {} );
		}

		function open( item ) {
			let msg = {};
			try { msg = JSON.parse( item.getAttribute( 'data-msg' ) || '{}' ) || {}; } catch ( err ) { msg = {}; }

			lastItem = item;
			inner.textContent = '';

			/* Başlık: gönderilen mailin konusu. */
			inner.appendChild( el(
				'h4',
				'dxp-inbox-detail-subject',
				msg.mail_subject ? msg.mail_subject : 'Konu kaydı yok'
			) );

			/* Meta: tarih/saat · servis · IP. */
			const meta = el( 'div', 'dxp-inbox-detail-meta' );
			[ msg.time, msg.service, msg.ip ? 'IP: ' + msg.ip : '' ].forEach( function ( part ) {
				if ( part ) { meta.appendChild( el( 'span', '', part ) ); }
			} );
			if ( meta.childElementCount ) { inner.appendChild( meta ); }

			/* Gönderen bilgileri. */
			const senderFields = el( 'div', 'dxp-inbox-detail-fields' );
			if ( msg.name ) { senderFields.appendChild( fieldRow( 'Ad Soyad', msg.name ) ); }
			if ( msg.email ) { senderFields.appendChild( fieldRow( 'E-posta', link( 'mailto:' + msg.email, msg.email ) ) ); }
			if ( msg.phone ) { senderFields.appendChild( fieldRow( 'Telefon', link( 'tel:' + String( msg.phone ).replace( /\s+/g, '' ), msg.phone ) ) ); }
			if ( senderFields.childElementCount ) {
				const senderSec = section( 'Gönderen' );
				senderSec.appendChild( senderFields );
				inner.appendChild( senderSec );
			}

			/* Tüm form alanları: etiket → değer. */
			const fieldsSec   = section( 'Form Alanları' );
			const fieldsWrap  = el( 'div', 'dxp-inbox-detail-fields' );
			const fields      = msg.fields || [];

			fields.forEach( function ( f ) {
				let value = f.value;
				if ( 'file' === f.key && f.value ) {
					value = link( f.value, f.value );
					value.target = '_blank';
					value.rel    = 'noopener noreferrer';
				}
				fieldsWrap.appendChild( fieldRow( f.label || f.key, value ) );
			} );

			if ( fields.length ) {
				fieldsSec.appendChild( fieldsWrap );
			} else {
				fieldsSec.appendChild( el( 'p', 'dxp-inbox-detail-empty', '—' ) );
			}
			inner.appendChild( fieldsSec );

			/* Gönderilen mailin gövdesi (düz metin, satır sonları korunur). */
			const mailSec = section( 'Gönderilen Mail' );
			if ( msg.mail_body ) {
				const pre = el( 'pre', 'dxp-inbox-detail-mail' );
				pre.textContent = msg.mail_body;
				mailSec.appendChild( pre );
			} else {
				mailSec.appendChild( el( 'p', 'dxp-inbox-detail-empty', '—' ) );
			}
			inner.appendChild( mailSec );

			inbox.classList.add( 'is-open' );
			item.setAttribute( 'aria-expanded', 'true' );
			back.focus();

			/* Açılan mesaj okundu sayılır. */
			if ( item.classList.contains( 'is-unread' ) ) {
				markRead( item );
			}
		}

		/* Satır tıklaması: yalnızca metne tıklayınca aç; iç bağlantılar
		   (Sil / mailto / tel) kendi davranışını korusun. */
		list.addEventListener( 'click', function ( e ) {
			if ( e.target.closest( 'a' ) ) { return; }
			const item = e.target.closest( '.dxp-inbox-item' );
			if ( item ) { open( item ); }
		} );

		/* Klavye: Enter / Space ile aç (role="button"). */
		list.addEventListener( 'keydown', function ( e ) {
			if ( 'Enter' !== e.key && ' ' !== e.key && 'Spacebar' !== e.key ) { return; }
			if ( e.target.closest( 'a' ) ) { return; }
			const item = e.target.closest( '.dxp-inbox-item' );
			if ( ! item ) { return; }
			e.preventDefault();
			open( item );
		} );

		back.addEventListener( 'click', close );

		document.addEventListener( 'keydown', function ( e ) {
			if ( 'Escape' === e.key && inbox.classList.contains( 'is-open' ) ) { close(); }
		} );
	}

	/* ── İlk section id ───────────────────────────────────── */
	function getFirstSectionId() {
		const first = $( '.dxp-section' );
		return first ? first.id.replace( 'dxp-section-', '' ) : '';
	}

	/* ── Başlangıç ────────────────────────────────────────── */
	function init() {
		/*
		 * Bir bağlayıcı hata verirse diğerlerini (iskelet sürükleme, tekrarlayıcı,
		 * açılır menüler...) engellememesi için her birini ayrı ayrı çalıştır.
		 */
		function safe( fn ) {
			try {
				fn();
			} catch ( err ) {
				if ( window.console && console.error ) {
					console.error( 'DEVXPE panel binder hatası:', err );
				}
			}
		}

		/*
		 * Panel sayfasında değilsek (ör. yazı düzenleme ekranındaki meta box)
		 * yalnızca yeniden kullanılabilir bileşenleri bağla; panel'e özel
		 * routing/binder'ları çalıştırma.
		 */
		if ( ! document.getElementById( 'devxpe-panel' ) ) {
			safe( bindTeamRepeater );
			safe( bindOptionsRepeaters );
			safe( bindCharCount );
			safe( bindSkeleton );
			safe( bindCopyButtons );
			return;
		}

		const hash   = getHash();
		const parsed = parseHash( hash );

		/*
		 * Öncelik: URL hash'i → sunucunun açtığı bölüm → ilk bölüm.
		 * (Hash boşsa sunucunun çizdiği bölüm korunur; aksi hâlde sayfa
		 * yenilemesinde başka bir bölüme atlar.)
		 */
		const navActive = $( '#devxpe-panel-left .dxp-nav > li.active' );
		const subActive = $( '#devxpe-panel-left .dxp-submenu li.active' );
		const subAdi    = subActive ? ( subActive.dataset.subsection || '' ).split( '-' ).slice( 1 ).join( '-' ) : '';

		const section = parsed.section || ( navActive ? navActive.dataset.section : '' ) || getFirstSectionId();
		const sub     = parsed.sub || subAdi || '';

		/*
		 * Açık menü durumunu showSection() yönetir (tek menü açık kalır).
		 * Burada zorla "ilk menüyü aç" YAPILMAZ; aksi hâlde sunucunun açık
		 * bıraktığı bölümle birlikte iki menü açık görünür (glitch).
		 */

		safe( function () { showSection( section, sub ); } );

		[
			bindMenu,
			bindSearch,
			bindTools,
			bindDemoModal,
			bindMobileToggle,
			bindFormSubmit,
			bindDarkMode,
			bindScale,
			bindTokens,
			bindColorHarmony,
			bindColorFieldHarmony,
			bindRadioImages,
			bindIconPick,
			bindCollapse,
			bindTabs,
			bindLangSwitch,
			bindSelects,
			bindMultiselect,
			bindCharCount,
			bindSkeleton,
			bindSectionEnable,
			bindConditionSubmit,
			bindTeamRepeater,
			bindOptionsRepeaters,
			bindCopyButtons,
			bindInbox
		].forEach( safe );
	}

	/* ── DOM hazır ────────────────────────────────────────── */
	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}

	/* ── Tarayıcı geri/ileri ──────────────────────────────── */
	window.addEventListener( 'hashchange', function () {
		const parsed = parseHash( getHash() );
		if ( parsed.section ) {
			showSection( parsed.section, parsed.sub );
		}
	} );

} )();
