/**
 * İçerik Düzeni metabox — widget editörü.
 *
 * 3 kolon: soldaki kütüphaneden sürükle/tıkla ekle, ortada sırala/seç/sil,
 * sağda seçili widget'ın ayarlarını düzenle. Tüm veri gizli JSON input'a yazılır.
 */
(function () {
	'use strict';

	const root = document.getElementById('dxp-pw');
	if (!root || typeof DXPPW === 'undefined') {
		return;
	}

	const lib = DXPPW.kutuphane || {};
	const baglamlar = DXPPW.kapsamlar || { about: 1, contact: 1 };
	const jsonInput = document.getElementById('dxp-page-widgets-json');
	const typeSel = document.getElementById('dxp_page_type');
	const editor = document.getElementById('dxp-pw-editor');
	const libEl = document.getElementById('dxp-pw-lib');
	const listEl = document.getElementById('dxp-pw-list');
	const settingsEl = document.getElementById('dxp-pw-settings');
	const emptyEl = document.getElementById('dxp-pw-empty');

	/* Güvenilir SVG metnini DOM düğümüne çevirir (innerHTML kullanmaz). */
	function ikonDugumu(markup) {
		const belge = new DOMParser().parseFromString(markup, 'text/html');
		return document.importNode(belge.body.firstElementChild, true);
	}

	function ikonKoy(el, markup) {
		if (markup) {
			el.replaceChildren(ikonDugumu(markup));
		} else {
			el.replaceChildren();
		}
	}

	let widgets = [];
	let selected = -1;
	let focusAcik = false; /* odak modu: yalnızca ayarlar paneli görünür */
	let dragIndex = -1; /* listede sıralama kaynağı */
	let dragTip = '';   /* kütüphaneden gelen widget tipi */

	/*
	 * FLIP animasyonu için nesne başına kalıcı kimlik. Widget nesneleri
	 * dizide taşınsa da aynı referans kaldığı için kimlik korunur; JSON'a
	 * YAZILMAZ.
	 */
	const WID = new WeakMap();
	let widSay = 0;

	function widOf(w) {
		if (!WID.has(w)) {
			WID.set(w, ++widSay);
		}

		return WID.get(w);
	}

	/* Yerleşim değişimi animasyonlu mu? (erişilebilirlik: hareketi azalt) */
	function hareketVar() {
		return !window.matchMedia || !window.matchMedia('(prefers-reduced-motion: reduce)').matches;
	}
	let ph = null;      /* "Buraya ekle" önizleme kutusu */
	let phIndex = -1;   /* bırakılacak sıra */
	let phYer = '';     /* bırakılacak kolon: '' | sol | sag */
	let libSayfa = 1;   /* kütüphane sayfası (1 tabanlı) */
	let libLimit = 10;  /* sayfa başına widget tipi */
	let libBar = null;  /* sayfalama çubuğu */
	let libSayla = null;/* "1 / 3" etiketi */
	let libGeri = null; /* ‹ */
	let libIleri = null;/* › */

	/* ── yardımcılar ──────────────────────────────────────── */

	function defaults(tip) {
		const out = {};
		const ay = (lib[tip] && lib[tip].ayarlar) || {};
		Object.keys(ay).forEach(function (key) {
			out[key] = (typeof ay[key].varsayilan !== 'undefined') ? ay[key].varsayilan : '';
		});
		return out;
	}

	function syncJson() {
		if (jsonInput) {
			jsonInput.value = JSON.stringify(widgets);
		}
	}

	function makeButton(label, title, className) {
		const b = document.createElement('button');
		b.type = 'button';
		b.className = className;
		b.textContent = label;
		b.title = title;
		b.setAttribute('aria-label', title);
		return b;
	}

	function tipAdi(tip) {
		return (lib[tip] && lib[tip].ad) ? lib[tip].ad : tip;
	}

	function yerAdi(yer) {
		return ({ sol: 'Sol', sag: 'Sağ', tam: 'Tam' })[yer] || '';
	}

	/* ── lucide ikon seçici ───────────────────────────────── */

	/*
	 * Sayfadaki `#dxp-lucide-data` (isim → SVG iç gövdesi) bir kez okunur ve
	 * önbelleğe alınır. Yoksa/bozuksa {} döner; seçici boş grid + mesaj gösterir.
	 */
	let _lucideVeri = null;

	function lucideVeri() {
		if (_lucideVeri) {
			return _lucideVeri;
		}

		_lucideVeri = {};
		const el = document.getElementById('dxp-lucide-data');

		if (!el) {
			return _lucideVeri;
		}

		try {
			const veri = JSON.parse(el.textContent || '{}');

			if (veri && typeof veri === 'object') {
				_lucideVeri = veri;
			}
		} catch {
			_lucideVeri = {};
		}

		return _lucideVeri;
	}

	/* İkon adını ön yüzle aynı biçimde SVG dizesine çevirir. Bilinmeyen ad → ''. */
	function lucideSvg(ad) {
		if (!ad) {
			return '';
		}

		const govde = lucideVeri()[ad];

		if (!govde) {
			return '';
		}

		return '<svg class="dxp-ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + govde + '</svg>';
	}

	/*
	 * Aynı anda tek panel açık kalsın diye açık panelin kapatma işlevi burada
	 * tutulur; document'e dışarı-tıklama dinleyicisi tembel olarak bir kez bağlanır.
	 */
	let acikIkonPanel = null;
	let ikonBelgeBagli = false;

	function ikonBelgeBagla() {
		if (ikonBelgeBagli) {
			return;
		}
		ikonBelgeBagli = true;

		document.addEventListener('click', function (e) {
			if (!acikIkonPanel) {
				return;
			}
			/* Panel içine (metin alanı, grid, trigger) tıklama kapatmasın. */
			if (e.target && e.target.closest && e.target.closest('.dxp-iconpick')) {
				return;
			}
			acikIkonPanel();
		});
	}

	/*
	 * SVG önizlemeli + aramalı ikon seçici. `degisti(ad)` değer değişince
	 * çağrılır (boş string = ikon yok).
	 */
	function ikonSec(deger, degisti) {
		ikonBelgeBagla();

		const kok = document.createElement('div');
		kok.className = 'dxp-iconpick';
		kok.setAttribute('data-icon-set', 'lucide');

		const gizli = document.createElement('input');
		gizli.type = 'hidden';
		gizli.className = 'dxp-iconpick-value';
		gizli.value = deger || '';

		const tetik = document.createElement('button');
		tetik.type = 'button';
		tetik.className = 'dxp-iconpick-trigger';
		tetik.setAttribute('aria-haspopup', 'true');
		tetik.setAttribute('aria-expanded', 'false');

		const gorsel = document.createElement('span');
		gorsel.className = 'dxp-iconpick-visual';

		const ad = document.createElement('span');
		ad.className = 'dxp-iconpick-current';

		const oku = document.createElement('span');
		oku.className = 'dxp-iconpick-caret';
		oku.textContent = '▾';

		tetik.appendChild(gorsel);
		tetik.appendChild(ad);
		tetik.appendChild(oku);

		const panel = document.createElement('div');
		panel.className = 'dxp-iconpick-panel';
		panel.hidden = true;

		const arama = document.createElement('input');
		arama.type = 'search';
		arama.className = 'dxp-iconpick-search';
		arama.placeholder = 'İkon ara…';
		arama.autocomplete = 'off';

		const grid = document.createElement('div');
		grid.className = 'dxp-iconpick-grid';
		grid.setAttribute('role', 'listbox');

		const bos = document.createElement('div');
		bos.className = 'dxp-iconpick-empty';
		bos.hidden = true;
		bos.textContent = 'Sonuç yok.';

		panel.appendChild(arama);
		panel.appendChild(grid);
		panel.appendChild(bos);

		kok.appendChild(gizli);
		kok.appendChild(tetik);
		kok.appendChild(panel);

		const ogeler = {};    /* değer → grid öğesi */
		let uretildi = false; /* grid yalnızca ilk açılışta kurulur */
		let secilenEl = null;

		/* Önizleme SVG'si + adı gizli değere göre tazelenir. */
		function onizlemeGuncelle() {
			ikonKoy(gorsel, lucideSvg(gizli.value));
			ad.textContent = gizli.value || '';
		}

		function ogeYap(v) {
			const b = document.createElement('button');
			b.type = 'button';
			b.className = 'dxp-iconpick-item';
			b.setAttribute('role', 'option');
			b.dataset.value = v;

			if (v) {
				ikonKoy(b, lucideSvg(v));
				b.title = v;
			} else {
				b.textContent = '—';
			}

			if (v === gizli.value) {
				b.classList.add('is-selected');
				secilenEl = b;
			}

			b.addEventListener('click', function () { secildi(v); });
			ogeler[v] = b;
			return b;
		}

		function gridKur() {
			grid.replaceChildren();

			const adlar = Object.keys(lucideVeri());

			if (!adlar.length) {
				/* Veri yok: boş grid + mesaj. */
				bos.hidden = false;
				uretildi = true;
				return;
			}

			grid.appendChild(ogeYap('')); /* "—" = ikon yok */
			adlar.forEach(function (a) { grid.appendChild(ogeYap(a)); });
			uretildi = true;
		}

		function filtrele() {
			const kelimeler = arama.value.toLowerCase().trim().split(/\s+/).filter(Boolean);
			let gorunen = 0;

			Object.keys(ogeler).forEach(function (v) {
				const esles = !kelimeler.length || kelimeler.every(function (k) {
					return v.toLowerCase().indexOf(k) !== -1;
				});

				ogeler[v].hidden = !esles;

				if (esles) {
					gorunen += 1;
				}
			});

			bos.hidden = gorunen > 0;
		}

		function kapat() {
			panel.hidden = true;
			tetik.setAttribute('aria-expanded', 'false');

			if (acikIkonPanel === kapat) {
				acikIkonPanel = null;
			}
		}

		/* Yeni değer: gizli input, önizleme, seçili işareti, kapatma ve callback. */
		function secildi(v) {
			gizli.value = v;
			onizlemeGuncelle();

			if (secilenEl) {
				secilenEl.classList.remove('is-selected');
			}
			if (ogeler[v]) {
				ogeler[v].classList.add('is-selected');
				secilenEl = ogeler[v];
			}

			kapat();

			if (typeof degisti === 'function') {
				degisti(v);
			}
		}

		function ac() {
			if (acikIkonPanel && acikIkonPanel !== kapat) {
				acikIkonPanel();
			}
			if (!uretildi) {
				gridKur();
			}

			panel.hidden = false;
			tetik.setAttribute('aria-expanded', 'true');
			arama.value = '';
			filtrele();
			acikIkonPanel = kapat;
			arama.focus();
		}

		tetik.addEventListener('click', function (e) {
			e.stopPropagation();

			if (panel.hidden) {
				ac();
			} else {
				kapat();
			}
		});

		arama.addEventListener('input', filtrele);

		/* Esc yalnızca paneli kapatsın; odak modu kısayoluna sızmasın. */
		kok.addEventListener('keydown', function (e) {
			if (e.key === 'Escape' && !panel.hidden) {
				e.stopPropagation();
				kapat();
				tetik.focus();
			}
		});

		onizlemeGuncelle();
		return kok;
	}

	/* ── liste (orta kolon) ───────────────────────────────── */

	function renderList(eskiKonum) {
		listEl.replaceChildren();

		const nested = listEl.classList.contains('dxp-pw-list--nested');
		let solN = 0, sagN = 0;

		widgets.forEach(function (w, i) {
			const li = document.createElement('li');
			/*
			 * Nested düzende ön yüz sol/sağ yığınlara ayrılır; atanmamış
			 * widget sol kolona girer, önizlemede de öyle gösterilir.
			 */
			let yerSinif = w.yer;

			if (!yerSinif && listEl.classList.contains('dxp-pw-list--nested')) {
				yerSinif = 'sol';
			}

			li.className = 'dxp-pw-item' + (i === selected ? ' is-selected' : '') + (yerSinif ? ' dxp-pw-item--' + yerSinif : '');
			li.draggable = true;
			li.dataset.index = String(i);
			li.dataset.wid   = String(widOf(w));

			/*
			 * Nested önizleme: her kolon KENDİ içinde 1. satırdan başlar.
			 * Aksi hâlde grid otomatik yerleştirmesi sağdaki ilk widget'ı
			 * 1. satıra koyup soldakileri bir satır aşağı itiyordu.
			 */
			if (nested) {
				if ('tam' === yerSinif) {
					/* Tam satır: iki kolonu da bu satırdan sonra devam ettir. */
					const satir = Math.max(solN, sagN) + 1;

					li.style.gridRow = String(satir);
					solN = satir;
					sagN = satir;
				} else if ('sag' === yerSinif) {
					li.style.gridRow = String(++sagN);
				} else {
					li.style.gridRow = String(++solN);
				}
			}

			const handle = document.createElement('span');
			handle.className = 'dxp-pw-handle';
			handle.textContent = '⠿';
			handle.setAttribute('aria-hidden', 'true');

			const name = document.createElement('span');
			name.className = 'dxp-pw-name';
			name.textContent = tipAdi(w.tip);

			const tools = document.createElement('span');
			tools.className = 'dxp-pw-tools';

			/*
			 * TEK yerleşim düğmesi: üzerindeki yazı mevcut durumu gösterir,
			 * her basışta Sol → Sağ → Tam → Sol … sırayla döner.
			 */
			if (nested) {
				const sira = ['sol', 'sag', 'tam'];
				const simdiki = yerSinif || 'sol';
				const sonraki = sira[(sira.indexOf(simdiki) + 1) % sira.length];
				const ikonlar = {
					sol: '<svg viewBox="0 0 24 24" width="13" height="13" aria-hidden="true"><rect x="3" y="4" width="8" height="16" rx="1.5" fill="currentColor"/><rect x="13.5" y="4" width="7.5" height="16" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.6" opacity=".4"/></svg>',
					sag: '<svg viewBox="0 0 24 24" width="13" height="13" aria-hidden="true"><rect x="3" y="4" width="7.5" height="16" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.6" opacity=".4"/><rect x="13" y="4" width="8" height="16" rx="1.5" fill="currentColor"/></svg>',
					tam: '<svg viewBox="0 0 24 24" width="13" height="13" aria-hidden="true"><rect x="3" y="4" width="18" height="16" rx="1.5" fill="currentColor"/></svg>',
				};

				const yerBtn = makeButton('', 'Yerleşim', 'dxp-pw-btn dxp-pw-yer-btn dxp-pw-yer-btn--' + simdiki);

				ikonKoy(yerBtn, ikonlar[simdiki]);
				yerBtn.setAttribute('aria-label', yerAdi(simdiki) + ' — ' + yerAdi(sonraki) + ' yerleşime geçir');
				yerBtn.setAttribute('title', yerAdi(simdiki) + ' → ' + yerAdi(sonraki));
				yerBtn.addEventListener('click', function (e) {
					e.stopPropagation();
					setYer(i, sonraki);
				});
				tools.appendChild(yerBtn);
			}

			const del = makeButton('✕', 'Sil', 'dxp-pw-btn dxp-pw-del');

			const kilitli = !!(lib[w.tip] && lib[w.tip].kilitli);

			if (kilitli) {
				li.classList.add('is-locked');
			} else {
				del.addEventListener('click', function (e) { e.stopPropagation(); remove(i); });
				tools.appendChild(del);
			}

			li.appendChild(handle);
			li.appendChild(name);

			li.appendChild(tools);

			li.addEventListener('click', function () { select(i); });

			li.addEventListener('dragstart', function () { dragIndex = i; dragTip = ''; });
			li.addEventListener('dragend', function () { dragIndex = -1; dragTip = ''; phHide(); });

			listEl.appendChild(li);
		});

		if (emptyEl) {
			emptyEl.style.display = widgets.length ? 'none' : '';
		}

		/* Yerleşim/sıra değiştiyse kartlar yerine kayarak geçsin. */
		if (eskiKonum) {
			flipOynat(eskiKonum);
		}
	}

	/* Ekrandaki kart konumlarını kimliğe göre toplar (FLIP öncesi). */
	function rectleriAl() {
		const m = new Map();

		listEl.querySelectorAll('.dxp-pw-item').forEach(function (el) {
			if (el.dataset.wid) {
				m.set(el.dataset.wid, el.getBoundingClientRect());
			}
		});

		return m;
	}

	/* FLIP: önceki konumdan yeni konuma yumuşak geçiş (220 ms). */
	function flipOynat(eski) {
		if (!hareketVar() || !eski || !eski.size) {
			return;
		}

		listEl.querySelectorAll('.dxp-pw-item').forEach(function (el) {
			const a = eski.get(el.dataset.wid);

			if (!a) {
				return;
			}

			const b  = el.getBoundingClientRect();
			const dx = a.left - b.left;
			const dy = a.top - b.top;

			if (!dx && !dy) {
				return;
			}

			el.animate(
				[
					{ transform: 'translate(' + dx + 'px,' + dy + 'px)' },
					{ transform: 'none' },
				],
				{ duration: 220, easing: 'cubic-bezier(.2,.8,.2,1)' }
			);
		});
	}

	/* ── düzen: önizleme 2 kolon mu? ──────────────────────── */

	/*
	 * "Düzen → Nested (2 sütun)" seçilince önizleme listesi de ikiye bölünür.
	 * Böylece kaydetmeden önce ön yüzdeki görünümün aynısı panelde görülür.
	 */
	function listNested() {
		const sec = root.querySelector('input[name="dxp_pw_duzen"]:checked');
		listEl.classList.toggle('dxp-pw-list--nested', !!sec && sec.value === 'nested');
		renderList();
	}

	/* ── işlemler ─────────────────────────────────────────── */

	/* ── odak modu ────────────────────────────────────────── */

	/*
	 * Odak yalnızca bir widget seçiliyken ve kullanıcı odaktan çıkmadıysa
	 * açıktır. Köke is-focus eklenir; CSS kütüphane + önizlemeyi gizleyip
	 * ayarlar panelini tam genişliğe açar. "← Geri" / Esc focusAcik'ı kapatır.
	 */
	function focusUygula() {
		root.classList.toggle('is-focus', selected >= 0 && focusAcik);
	}

	function odaktanCik() {
		focusAcik = false;
		focusUygula();
	}

	function select(i) {
		selected = i;
		focusAcik = true;
		renderList();
		renderSettings();
		focusUygula();
	}

	/* Widget'ın kendi kolonundaki satır numarası (1 tabanlı). */
	function satirNo(i) {
		const y = widgets[i].yer || 'sol';
		let n = 0;

		for (let k = 0; k <= i; k++) {
			if ((widgets[k].yer || 'sol') === y) {
				n++;
			}
		}

		return n;
	}

	/* Görsel satır haritası (tam genişlik her iki kolonu da aşağı iter). */
	function satirHaritasi() {
		let s = 0, g = 0;

		return widgets.map(function (x) {
			const y = x.yer || 'sol';

			if ('tam' === y) {
				const r = Math.max(s, g) + 1;

				s = r;
				g = r;

				return r;
			}

			if ('sag' === y) {
				g++;

				return g;
			}

			s++;

			return s;
		});
	}

	/*
	 * Yerleşim değiştir:
	 *  - Sağ → sağ kolonun EN ÜSTÜNE geçer.
	 *  - Sol → AYNI satıra geçer; o satırdaki sol widget bir satır aşağı iner.
	 *  - Tam → kendi tam satırı (bulunduğu sırada kalır).
	 */
	function setYer(i, yer) {
		if (!widgets[i] || !yer) {
			return;
		}

		const eski = widgets[i].yer || 'sol';

		if (eski === yer) {
			return;
		}

		const satir = ('tam' === eski) ? 0 : satirNo(i);

		/* Animasyon için eski konumlar (mutasyondan ÖNCE). */
		const eskiKonum = rectleriAl();
		const item  = widgets.splice(i, 1)[0];

		item.yer = yer;

		let hedef = i;

		if ('tam' === yer) {
			/*
			 * Tam genişlik: KENDİ satırına yerleşir. Kendi satırının
			 * üstündeki kartlar yerinde kalır; kendi satırı ve altındaki
			 * TÜM kartlar (her iki kolonda) bir satır iner.
			 */
			const rows = satirHaritasi();
			const once = [];
			const sonra = [];

			for (let k = 0; k < widgets.length; k++) {
				if (rows[ k ] < satir) {
					once.push(widgets[ k ]);
				} else {
					sonra.push(widgets[ k ]);
				}
			}

			widgets.length = 0;
			once.forEach(function (x) { widgets.push(x); });

			hedef = widgets.length;
			widgets.push(item);
			sonra.forEach(function (x) { widgets.push(x); });

			selected = hedef;

			syncJson();
			renderList(eskiKonum);
			renderSettings();
			focusUygula();

			return;
		}

		if ('sag' === yer) {
			hedef = -1;

			for (let k = 0; k < widgets.length; k++) {
				if ('sag' === (widgets[k].yer || '')) { hedef = k; break; }
			}

			if (hedef < 0) {
				/* Hiç sağ yok: sol yığınının bittiği yere ekle. */
				hedef = widgets.length;

				for (let k = 0; k < widgets.length; k++) {
					if ('sag' !== (widgets[k].yer || '')) { hedef = k + 1; }
				}
			}
		} else if ('sol' === yer && satir > 0) {
			let sayac = 0;

			hedef = widgets.length;

			for (let k = 0; k < widgets.length; k++) {
				if ('sag' !== (widgets[k].yer || '')) {
					sayac++;

					if (sayac === satir) { hedef = k; break; }
				}
			}
		}

		widgets.splice(hedef, 0, item);
		selected = hedef;

		syncJson();
		renderList(eskiKonum);
		renderSettings();
		focusUygula();
	}

	function remove(i) {
		/* Kilitli temsilciler silinemez (WordPress başlığı/içeriği). */
		if (widgets[i] && lib[widgets[i].tip] && lib[widgets[i].tip].kilitli) {
			return;
		}

		const eskiKonum = rectleriAl();
		widgets.splice(i, 1);
		if (selected === i) {
			selected = -1;
		} else if (selected > i) {
			selected -= 1;
		}
		if (selected < 0) {
			focusAcik = false;
		}
		syncJson();
		renderList(eskiKonum);
		renderSettings();
		focusUygula();
	}

	function add(tip) {
		if (!lib[tip]) {
			return;
		}

		/* Kilitli temsilciden yalnızca bir tane olabilir. */
		if (lib[tip].kilitli) {
			const varOlan = widgets.findIndex(function (w) { return w.tip === tip; });

			if (varOlan >= 0) {
				selected = varOlan;
				renderList();
				renderSettings();
				focusUygula();
				return;
			}
		}

		widgets.push({ tip: tip, ayar: defaults(tip) });
		selected = widgets.length - 1;
		syncJson();
		renderList();
		renderSettings();
		focusUygula();
	}

	/* ── sürükleme önizlemesi ("Buraya ekle") ─────────────── */

	/*
	 * Sürükleme sırasında hedef konuma "Buraya ekle" kutusu konur.
	 * Nested düzende kutunun sütunu, imleç listenin hangi yarısındaysa
	 * ona göre belirlenir; bırakınca widget o kolona atanır (yer).
	 */
	function phHide() {
		if (ph && ph.parentNode) {
			ph.parentNode.removeChild(ph);
		}
		phIndex = -1;
		phYer = '';

		/* Boşluk kapansın: satırlar yeniden dağıtılır. */
		satirlariUygula();
	}

	function phShow(index, yer) {
		if (!ph) {
			ph = document.createElement('li');
			ph.textContent = 'Buraya ekle';
		}

		ph.className = 'dxp-pw-ph' + (yer ? ' dxp-pw-ph--' + yer : '');

		const items = listEl.querySelectorAll('.dxp-pw-item');

		if (index >= items.length) {
			listEl.appendChild(ph);
		} else {
			listEl.insertBefore(ph, items[index]);
		}

		phIndex = index;
		phYer = yer || '';

		/* Yer tutucu bir SATIR alsın: alttaki kartlar kayıp boşluk açılsın. */
		satirlariUygula();
	}

	/*
	 * Nested önizlemede satırları yeniden dağıtır.
	 *
	 * Yer tutucu (ph) varsa sanal bir slot gibi sayılır: içine girdiği
	 * satır ve altındaki kartlar bir satır aşağı kayar → görünür boşluk.
	 */
	function satirlariUygula() {
		if (!listEl.classList.contains('dxp-pw-list--nested')) {
			return;
		}

		const items = Array.prototype.slice.call(listEl.querySelectorAll('.dxp-pw-item'));
		let slots = items;

		if (ph && ph.parentNode && phIndex >= 0) {
			slots = items.slice();
			slots.splice(Math.min(phIndex, items.length), 0, ph);
		}

		let s = 0, g = 0;

		slots.forEach(function (el) {
			let y;

			if (el === ph) {
				y = phYer || 'sol';
			} else if (el.classList.contains('dxp-pw-item--sag')) {
				y = 'sag';
			} else if (el.classList.contains('dxp-pw-item--tam')) {
				y = 'tam';
			} else {
				y = 'sol';
			}

			if ('tam' === y) {
				const r = Math.max(s, g) + 1;

				el.style.gridRow = String(r);
				s = r;
				g = r;
			} else if ('sag' === y) {
				g++;
				el.style.gridRow = String(g);
			} else {
				s++;
				el.style.gridRow = String(s);
			}
		});
	}

	/* İmlece en yakın satıra göre bırakılacak sıra. */
	function phTarget(e) {
		const items = Array.prototype.slice.call(listEl.querySelectorAll('.dxp-pw-item'));

		if (!items.length) {
			return 0;
		}

		let en = 0;
		let min = Infinity;

		items.forEach(function (el, i) {
			const r = el.getBoundingClientRect();
			const dx = e.clientX - (r.left + r.width / 2);
			const dy = e.clientY - (r.top + r.height / 2);
			const d = dx * dx + dy * dy;

			if (d < min) {
				min = d;
				en = i;
			}
		});

		const r = items[en].getBoundingClientRect();

		return en + (e.clientY > r.top + r.height / 2 ? 1 : 0);
	}

	/* Nested düzende imlecin bulunduğu kolon. */
	function phYerBul(e) {
		if (!listEl.classList.contains('dxp-pw-list--nested')) {
			return '';
		}

		const r = listEl.getBoundingClientRect();

		return e.clientX < r.left + r.width / 2 ? 'sol' : 'sag';
	}

	function listDrop() {
		const eskiKonum = rectleriAl();
		const hedef = phIndex >= 0 ? phIndex : widgets.length;
		const yer   = phYer;

		if (dragIndex >= 0) {
			const tasinan = widgets.splice(dragIndex, 1)[0];
			const to      = hedef > dragIndex ? hedef - 1 : hedef;

			if (yer) {
				tasinan.yer = yer;
			}

			widgets.splice(to, 0, tasinan);
			selected = to;
		} else if (dragTip) {
			/* Kilitli temsilciden yalnızca bir tane olabilir. */
			if (lib[dragTip] && lib[dragTip].kilitli && widgets.some(function (w) { return w.tip === dragTip; })) {
				dragIndex = -1;
				dragTip = '';
				phHide();
				return;
			}

			const yeni = { tip: dragTip, ayar: defaults(dragTip) };

			if (yer) {
				yeni.yer = yer;
			}

			widgets.splice(hedef, 0, yeni);
			selected = hedef;
		}

		dragIndex = -1;
		dragTip = '';
		phHide();
		syncJson();
		renderList(eskiKonum);
		renderSettings();
	}

	/* ── ayar paneli (sağ kolon) ──────────────────────────── */

	function renderSettings() {
		settingsEl.replaceChildren();

		if (selected < 0 || !widgets[selected]) {
			const p = document.createElement('p');
			p.className = 'dxp-pw-settings-empty';
			p.textContent = 'Ayarları görmek için bir widget seçin.';
			settingsEl.appendChild(p);
			return;
		}

		const w = widgets[selected];
		const ay = (lib[w.tip] && lib[w.tip].ayarlar) || {};

		/* Odaktan çıkış: ayarların en üstünde "← Geri". */
		const geri = makeButton('← Geri', 'Odaktan çık', 'dxp-pw-back');
		geri.addEventListener('click', odaktanCik);
		settingsEl.appendChild(geri);

		const title = document.createElement('h4');
		title.textContent = tipAdi(w.tip);
		settingsEl.appendChild(title);

		if (lib[w.tip] && lib[w.tip].kilitli) {
			const bilgi = document.createElement('p');
			bilgi.className = 'dxp-pw-settings-empty';
			bilgi.textContent = 'WordPress sayfa başlığı/içeriği otomatik gelir. Düzenlenemez; yalnızca sırası değiştirilebilir.';
			settingsEl.appendChild(bilgi);
			return;
		}

		/* Ortak alan: her widget için yerleşim (sol / sağ / tam). */
		settingsEl.appendChild(buildYerField(w));

		Object.keys(ay).forEach(function (key) {
			settingsEl.appendChild(buildField(ay[key], key, w, w.ayar[key]));
		});
	}

	/* ── Harita önizlemesi (konum yazarken canlı) ───────────── */

	/* Konum → gömülebilir Google Harita adresi (API anahtarı gerekmez). */
	function haritaUrl(adres, zoom) {
		const z = parseInt(zoom, 10);

		return 'https://www.google.com/maps?q=' + encodeURIComponent((adres || '').trim())
			+ '&z=' + (z >= 1 && z <= 21 ? z : 14) + '&output=embed';
	}

	/*
	 * Widget ayarında konum yazarken nereyi işaret ettiğini gösterir.
	 * degerAl(): güncel konum · zoomAl(): güncel yakınlaştırma
	 */
	function haritaOnizleme(degerAl, zoomAl) {
		const sar = document.createElement('div');
		sar.className = 'dxp-pw-harita';

		const cap = document.createElement('span');
		cap.className = 'dxp-pw-harita-cap';
		cap.textContent = 'Harita önizlemesi';

		const kutu = document.createElement('div');
		kutu.className = 'dxp-pw-harita-kutu';

		const bos = document.createElement('p');
		bos.className = 'dxp-pw-harita-bos';

		let zaman = null;

		function yenile() {
			let adres = (degerAl() || '').trim();

			/* Alan boşsa paneldeki adres gösterilir (ön yüzle aynı davranış). */
			if (!adres && typeof DXPPW !== 'undefined' && DXPPW.varsayilan_adres) {
				adres = String(DXPPW.varsayilan_adres).trim();
			}

			const mevcut = kutu.querySelector('iframe');

			if (!adres) {
				if (mevcut) { mevcut.parentNode.removeChild(mevcut); }
				bos.textContent = 'Konum yazınca harita burada görünür.';
				bos.hidden = false;
				return;
			}

			bos.hidden = true;

			const url = haritaUrl(adres, zoomAl());

			if (mevcut && mevcut.getAttribute('data-url') === url) {
				return;
			}

			kutu.replaceChildren();

			const iframe = document.createElement('iframe');
			iframe.src = url;
			iframe.setAttribute('data-url', url);
			iframe.title = 'Harita önizlemesi';
			iframe.setAttribute('loading', 'lazy');
			iframe.setAttribute('referrerpolicy', 'no-referrer-when-downgrade');
			kutu.appendChild(iframe);
		}

		sar.appendChild(cap);
		sar.appendChild(kutu);
		sar.appendChild(bos);

		yenile();

		return {
			sar: sar,
			yenile: function () {
				if (zaman) { clearTimeout(zaman); }
				zaman = setTimeout(yenile, 350);
			}
		};
	}

	function buildField(sema, key, w, value) {
		const wrap = document.createElement('div');
		wrap.className = 'dxp-pw-field';

		const label = document.createElement('label');
		label.textContent = sema.etiket;

		const uid = 'dxp-pw-f-' + w.tip + '-' + key;
		label.setAttribute('for', uid);
		wrap.appendChild(label);

		function commit(val) {
			w.ayar[key] = val;
			syncJson();
		}

		if (sema.tip === 'metinuzun') {
			const ta = document.createElement('textarea');
			ta.id = uid;
			ta.rows = 5;
			ta.value = value || '';
			ta.addEventListener('input', function () { commit(ta.value); });
			wrap.appendChild(ta);

		} else if (sema.tip === 'secim') {
			const sel = document.createElement('select');
			sel.id = uid;
			Object.keys(sema.secenekler || {}).forEach(function (val) {
				const opt = document.createElement('option');
				opt.value = val;
				opt.textContent = sema.secenekler[val];
				sel.appendChild(opt);
			});
			sel.value = value;
			sel.addEventListener('change', function () { commit(sel.value); });
			wrap.appendChild(sel);

		} else if (sema.tip === 'onay') {
			const cb = document.createElement('input');
			cb.type = 'checkbox';
			cb.id = uid;
			cb.value = '1';
			cb.checked = (value === '1');
			cb.addEventListener('change', function () { commit(cb.checked ? '1' : ''); });
			wrap.appendChild(cb);

		} else if (sema.tip === 'sayi') {
			const num = document.createElement('input');
			num.type = 'number';
			num.id = uid;
			num.value = value || '';
			num.addEventListener('input', function () { commit(num.value); });
			wrap.appendChild(num);

		} else if (sema.tip === 'gorsel') {
			const inp = document.createElement('input');
			inp.type = 'text';
			inp.id = uid;
			inp.className = 'dxp-pw-img-url';
			inp.value = value || '';
			inp.addEventListener('input', function () { commit(inp.value); });

			const prev = document.createElement('div');
			prev.className = 'dxp-pw-img-prev';
			if (value) {
				const img = document.createElement('img');
				img.src = value;
				prev.appendChild(img);
			}

			const pick = makeButton('Görsel Seç', 'Görsel Seç', 'button');
			const clear = makeButton('Kaldır', 'Görseli kaldır', 'button');

			pick.addEventListener('click', function () {
				if (!window.wp || !window.wp.media) {
					return;
				}
				const frame = window.wp.media({ title: 'Görsel Seç', button: { text: 'Kullan' }, multiple: false });
				frame.on('select', function () {
					const att = frame.state().get('selection').first().toJSON();
					inp.value = att.url;
					commit(att.url);
					prev.replaceChildren();
					const im = document.createElement('img');
					im.src = att.url;
					prev.appendChild(im);
				});
				frame.open();
			});

			clear.addEventListener('click', function () {
				inp.value = '';
				commit('');
				prev.replaceChildren();
			});

			wrap.appendChild(inp);
			const actions = document.createElement('p');
			actions.className = 'dxp-pw-img-actions';
			actions.appendChild(pick);
			actions.appendChild(clear);
			wrap.appendChild(actions);
			wrap.appendChild(prev);

		} else if (sema.tip === 'satirlar') {
			wrap.appendChild(buildSatirlar(sema, w, key, value));

		} else if (sema.tip === 'ikon') {
			const secici = ikonSec(value || '', commit);
			const trg = secici.querySelector('.dxp-iconpick-trigger');

			if (trg) {
				trg.id = uid; /* label for=uid ile eşleşsin */
			}

			wrap.appendChild(secici);

		} else {
			const inp = document.createElement('input');
			inp.type = 'text';
			inp.id = uid;
			inp.value = value || '';
			inp.addEventListener('input', function () { commit(inp.value); });
			wrap.appendChild(inp);
		}

		/* Konum alanı: yazarken canlı harita önizlemesi. */
		if (sema.onizleme === 'harita') {
			const onizleme = haritaOnizleme(
				function () { return w.ayar[key]; },
				function () { return w.ayar.zoom; }
			);

			wrap.appendChild(onizleme.sar);
			wrap.addEventListener('input', onizleme.yenile);
		}

		return wrap;
	}

	/* ── satirlar: pipe-satır alan editörü ──────────────────
	 *
	 * Depolama biçimi: satırlar "\n", hücreler "|" ile birleşik TEK string.
	 * Örn: "a.jpg|Başlık|https://x\nb.jpg|Diğeri|"
	 */

	/* String'i satır dizisine çözer: eksik hücreler '' ile doldurulur,
	 * tamamen boş satırlar atılır. Dönüş: [ ['a','b','c'], ... ] */
	function satirCoz(str, kolonSayisi) {
		const sayi = kolonSayisi > 0 ? kolonSayisi : 1;
		const metin = (str === null || str === undefined) ? '' : String(str);
		if (!metin) {
			return [];
		}

		const sonuc = [];
		metin.split('\n').forEach(function (satir) {
			const hucreler = satir.split('|');
			const dolu = [];
			/* Eski kayıtlarda şemadan fazla hücre olabilir; kırpma, koru. */
			const adet = Math.max(sayi, hucreler.length);

			for (let i = 0; i < adet; i++) {
				dolu.push(typeof hucreler[i] === 'string' ? hucreler[i] : '');
			}
			const bos = dolu.every(function (h) { return h === ''; });
			if (!bos) {
				sonuc.push(dolu);
			}
		});
		return sonuc;
	}

	/* Satır dizisini depolama string'ine çevirir; boş satırlar atılır. */
	function satirYaz(satirlar) {
		const cikti = [];
		(satirlar || []).forEach(function (satir) {
			const hucreler = (satir || []).map(function (h) {
				return (h === null || h === undefined) ? '' : String(h);
			});
			if (hucreler.every(function (h) { return h === ''; })) {
				return;
			}
			cikti.push(hucreler.join('|'));
		});
		return cikti.join('\n');
	}

	/* Görsel önizlemesini yeniler (tek <img>). */
	function satirOnizleme(prev, url) {
		prev.replaceChildren();
		if (!url) {
			return;
		}
		const img = document.createElement('img');
		img.src = url;
		prev.appendChild(img);
	}

	/* Tek hücre girişini üretir (kolon tipine göre) ve duruma bağlar. */
	function satirHucre(kolon, cid, satirlar, r, c, kaydet) {
		const tip = kolon.tip || 'metin';

		if (tip === 'gorsel') {
			const sar = document.createElement('div');
			sar.className = 'dxp-pw-satir-gorsel';

			const inp = document.createElement('input');
			inp.type = 'text';
			inp.id = cid;
			inp.className = 'dxp-pw-img-url';
			inp.value = satirlar[r][c] || '';

			const prev = document.createElement('span');
			prev.className = 'dxp-pw-satir-img-prev';

			const pick = makeButton('Görsel', 'Görsel Seç', 'button dxp-pw-satir-gbtn');
			const clear = makeButton('Kaldır', 'Görseli kaldır', 'button dxp-pw-satir-gbtn');

			inp.addEventListener('input', function () {
				satirlar[r][c] = inp.value;
				kaydet();
			});
			pick.addEventListener('click', function () {
				if (!window.wp || !window.wp.media) {
					return;
				}
				const frame = window.wp.media({ title: 'Görsel Seç', button: { text: 'Kullan' }, multiple: false });
				frame.on('select', function () {
					const att = frame.state().get('selection').first().toJSON();
					inp.value = att.url;
					satirlar[r][c] = att.url;
					kaydet();
					satirOnizleme(prev, att.url);
				});
				frame.open();
			});
			clear.addEventListener('click', function () {
				inp.value = '';
				satirlar[r][c] = '';
				kaydet();
				satirOnizleme(prev, '');
			});

			sar.appendChild(inp);
			sar.appendChild(pick);
			sar.appendChild(clear);
			sar.appendChild(prev);
			satirOnizleme(prev, inp.value);
			return sar;
		}

		if (tip === 'ikon') {
			const sar = document.createElement('div');
			sar.className = 'dxp-pw-satir-ikon';

			const secici = ikonSec(satirlar[r][c] || '', function (v) {
				satirlar[r][c] = v;
				kaydet();
			});

			const trg = secici.querySelector('.dxp-iconpick-trigger');

			if (trg) {
				trg.id = cid; /* satır etiketi for=cid ile eşleşsin */
			}

			sar.appendChild(secici);
			return sar;
		}

		if (tip === 'metinuzun') {
			const ta = document.createElement('textarea');
			ta.id = cid;
			ta.rows = 2;
			ta.value = satirlar[r][c] || '';
			ta.addEventListener('input', function () {
				satirlar[r][c] = ta.value;
				kaydet();
			});
			return ta;
		}

		const inp = document.createElement('input');
		inp.type = 'text';
		inp.id = cid;
		inp.value = satirlar[r][c] || '';
		if (tip === 'link') {
			inp.placeholder = 'https://...';
		}
		inp.addEventListener('input', function () {
			satirlar[r][c] = inp.value;
			kaydet();
		});
		return inp;
	}

	/* Tek satırın kutusunu (kolonlar + sırala/sil araçları) üretir. */
	function satirKutusu(uidOn, kolonlar, satirlar, r, kaydet, ciz) {
		const satir = document.createElement('div');
		satir.className = 'dxp-pw-satir-satir';

		const alanlar = document.createElement('div');
		alanlar.className = 'dxp-pw-satir-alanlar';

		kolonlar.forEach(function (kolon, c) {
			const hucre = document.createElement('div');
			hucre.className = 'dxp-pw-satir-kolon dxp-pw-satir-kolon--' + (kolon.tip || 'metin');

			const cid = uidOn + r + '-' + c;
			const lab = document.createElement('label');
			lab.className = 'dxp-pw-satir-etiket';
			lab.setAttribute('for', cid);
			lab.textContent = kolon.ad;

			hucre.appendChild(lab);
			hucre.appendChild(satirHucre(kolon, cid, satirlar, r, c, kaydet));
			alanlar.appendChild(hucre);
		});

		const arac = document.createElement('div');
		arac.className = 'dxp-pw-satir-araclar';

		const yukari = makeButton('▲', 'Yukarı taşı', 'dxp-pw-btn dxp-pw-satir-btn');
		const asagi = makeButton('▼', 'Aşağı taşı', 'dxp-pw-btn dxp-pw-satir-btn');
		const sil = makeButton('✕', 'Satırı sil', 'dxp-pw-btn dxp-pw-satir-btn dxp-pw-del');

		yukari.disabled = (r === 0);
		asagi.disabled = (r === satirlar.length - 1);

		yukari.addEventListener('click', function () {
			if (r === 0) { return; }
			const t = satirlar[r - 1];
			satirlar[r - 1] = satirlar[r];
			satirlar[r] = t;
			kaydet();
			ciz();
		});
		asagi.addEventListener('click', function () {
			if (r >= satirlar.length - 1) { return; }
			const t = satirlar[r + 1];
			satirlar[r + 1] = satirlar[r];
			satirlar[r] = t;
			kaydet();
			ciz();
		});
		sil.addEventListener('click', function () {
			satirlar.splice(r, 1);
			kaydet();
			ciz();
		});

		arac.appendChild(yukari);
		arac.appendChild(asagi);
		arac.appendChild(sil);

		satir.appendChild(alanlar);
		satir.appendChild(arac);
		return satir;
	}

	/* satirlar alanının tam editörünü üretir. İç durum (satır dizisi)
	 * kapanışta tutulur; yalnızca satırlar kutusu yeniden çizilir. */
	function buildSatirlar(sema, w, key, value) {
		const kolonlar = (sema.kolonlar && sema.kolonlar.length)
			? sema.kolonlar
			: [{ ad: 'Değer', tip: 'metin' }];
		let satirlar = satirCoz(value, kolonlar.length);
		const uidOn = 'dxp-pw-satir-' + w.tip + '-' + key + '-';

		const kutu = document.createElement('div');
		kutu.className = 'dxp-pw-satir';

		const rowsEl = document.createElement('div');
		rowsEl.className = 'dxp-pw-satir-liste';

		function kaydet() {
			w.ayar[key] = satirYaz(satirlar);
			syncJson();
		}

		function ciz() {
			rowsEl.replaceChildren();
			satirlar.forEach(function (row, r) {
				rowsEl.appendChild(satirKutusu(uidOn, kolonlar, satirlar, r, kaydet, ciz));
			});
		}

		const ekle = makeButton('+ Satır Ekle', 'Yeni satır ekle', 'button dxp-pw-satir-ekle');
		ekle.addEventListener('click', function () {
			const bos = [];
			for (let i = 0; i < kolonlar.length; i++) {
				bos.push('');
			}
			satirlar.push(bos);
			kaydet();
			ciz();
		});

		kutu.appendChild(rowsEl);
		kutu.appendChild(ekle);
		ciz();
		return kutu;
	}

	/*
	 * Ortak yerleşim alanı (her widget'ta görünür).
	 *
	 * Etkisi yalnızca sayfa düzeni "Nested (2 sütun)" iken ortaya çıkar:
	 * widget'ı sol kolona, sağ kolona ya da tam genişliğe sabitler.
	 */
	function buildYerField(w) {
		const wrap = document.createElement('div');
		wrap.className = 'dxp-pw-field dxp-pw-field--yer';

		const label = document.createElement('label');
		label.setAttribute('for', 'dxp-pw-yer');
		label.textContent = 'Yerleşim (nested düzen)';

		const sel = document.createElement('select');
		sel.id = 'dxp-pw-yer';

		[['', 'Otomatik'], ['sol', 'Sol sütun'], ['sag', 'Sağ sütun'], ['tam', 'Tam genişlik']]
			.forEach(function (p) {
				const opt = document.createElement('option');
				opt.value = p[0];
				opt.textContent = p[1];
				sel.appendChild(opt);
			});

		sel.value = w.yer || '';
		sel.addEventListener('change', function () {
			if (sel.value) {
				w.yer = sel.value;
			} else {
				delete w.yer;
			}
			syncJson();
			renderList();
		});

		wrap.appendChild(label);
		wrap.appendChild(sel);
		return wrap;
	}

	/* ── kütüphane (sol kolon) ────────────────────────────── */

	/* ── kütüphane sayfalama (10 tip/sayfa) ───────────────── */

	/*
	 * "Widget Ekle" listesi uzun (26 tip); sayfa başına 10 gösterilir.
	 * ‹ › düğmeleri aynı metabox içinde sayfa değiştirir.
	 */
	function libToplamSayfa() {
		return Math.max(1, Math.ceil(libEl.querySelectorAll('.dxp-pw-lib-item').length / libLimit));
	}

	function libSayfaUygula() {
		const toplam = libToplamSayfa();

		if (libSayfa > toplam) { libSayfa = toplam; }
		if (libSayfa < 1) { libSayfa = 1; }

		const bas = (libSayfa - 1) * libLimit;
		let i = 0;

		Array.prototype.forEach.call(libEl.querySelectorAll('.dxp-pw-lib-item'), function (item) {
			item.style.display = (i >= bas && i < bas + libLimit) ? '' : 'none';
			i += 1;
		});

		if (libSayla) { libSayla.textContent = libSayfa + ' / ' + toplam; }
		if (libBar) { libBar.style.display = toplam > 1 ? '' : 'none'; }
		if (libGeri) { libGeri.disabled = (libSayfa <= 1); }
		if (libIleri) { libIleri.disabled = (libSayfa >= toplam); }
	}

	function libSayfalamaKur() {
		libBar = document.createElement('div');
		libBar.className = 'dxp-pw-sayfa';

		libGeri = makeButton('‹', 'Önceki sayfa', 'dxp-pw-sayfa-btn');
		libIleri = makeButton('›', 'Sonraki sayfa', 'dxp-pw-sayfa-btn');

		libSayla = document.createElement('span');
		libSayla.className = 'dxp-pw-sayfa-etiket';

		libGeri.addEventListener('click', function () {
			libSayfa -= 1;
			libSayfaUygula();
		});

		libIleri.addEventListener('click', function () {
			libSayfa += 1;
			libSayfaUygula();
		});

		libBar.appendChild(libGeri);
		libBar.appendChild(libSayla);
		libBar.appendChild(libIleri);

		/* Kütüphane listesinin hemen altına. */
		if (libEl.parentNode) {
			libEl.parentNode.insertBefore(libBar, libEl.nextSibling);
		}
	}

	function bindLib() {
		Array.prototype.forEach.call(libEl.querySelectorAll('.dxp-pw-lib-item'), function (item) {
			const tip = item.dataset.tip;
			item.addEventListener('click', function () { add(tip); });
			item.addEventListener('dragstart', function () { dragTip = tip; dragIndex = -1; });
			item.addEventListener('dragend', function () { dragTip = ''; phHide(); });
		});

		listEl.addEventListener('dragover', function (e) {
			if (dragIndex < 0 && !dragTip) {
				return;
			}

			e.preventDefault();

			/*
			 * Boşluk zaten açıksa ve imleç o boşluğun içindeyse yeniden
			 * hesaplama → titreme (gap aç/kapa döngüsü) olmasın.
			 */
			if (ph && ph.parentNode && phIndex >= 0) {
				const r = ph.getBoundingClientRect();

				if (e.clientY >= r.top - 2 && e.clientY <= r.bottom + 2) {
					return;
				}
			}

			const hedef = phTarget(e);
			const yer   = phYerBul(e);

			if (!ph || !ph.parentNode || hedef !== phIndex || yer !== phYer) {
				phShow(hedef, yer);
			}
		});

		listEl.addEventListener('dragleave', function (e) {
			if (!listEl.contains(e.relatedTarget)) {
				phHide();
			}
		});

		listEl.addEventListener('drop', function (e) {
			e.preventDefault();
			listDrop();
		});
	}

	/* ── sayfa tipi / görünürlük ──────────────────────────── */

	function currentBaglam() {
		/* Sayfada seçici belirler; içerik tipinde bağlam sunucudan gelir. */
		if (typeSel) {
			return typeSel.value;
		}
		return root.getAttribute('data-baglam') || '';
	}

	function updateVisibility() {
		const type = currentBaglam();
		const on = !!baglamlar[type];
		editor.style.display = on ? '' : 'none';
		root.classList.toggle('is-collapsed', !on);
	}

	/* ── başlat ───────────────────────────────────────────── */

	try {
		widgets = JSON.parse(jsonInput.value || '[]');
	} catch {
		widgets = [];
	}
	if (!Array.isArray(widgets)) {
		widgets = [];
	}

	widgets = widgets.filter(function (w) {
		return w && typeof w.tip === 'string' && lib[w.tip];
	});

	widgets = widgets.map(function (w) {
		if (!w.ayar || typeof w.ayar !== 'object') {
			w.ayar = defaults(w.tip);
		}
		return w;
	});

	bindLib();
	libSayfalamaKur();
	libSayfaUygula();
	renderList();
	renderSettings();
	syncJson();

	/* Düzen radyoları: seçime göre önizleme listesinin kolon sayısı değişir. */
	Array.prototype.forEach.call(root.querySelectorAll('input[name="dxp_pw_duzen"]'), function (el) {
		el.addEventListener('change', listNested);
	});
	listNested();

	if (typeSel) {
		typeSel.addEventListener('change', updateVisibility);
	}

	/* Esc ile odaktan çık (tercih edilen kısayol). */
	document.addEventListener('keydown', function (e) {
		if (e.key === 'Escape' && focusAcik) {
			odaktanCik();
		}
	});

	updateVisibility();
	focusUygula();
})();
