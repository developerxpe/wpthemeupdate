/**
 * İçerik Düzeni metabox — widget editörü.
 *
 * 3 kolon: soldaki kütüphaneden sürükle/tıkla ekle, ortada sırala/seç/sil,
 * sağda seçili widget'ın ayarlarını düzenle. Tüm veri gizli JSON input'a yazılır.
 */
(function () {
	'use strict';

	const root = document.getElementById('dxp-pw');
	if (!root || typeof DXPPW === 'undefined') {
		return;
	}

	const lib = DXPPW.kutuphane || {};
	const baglamlar = DXPPW.kapsamlar || { about: 1, contact: 1 };
	const jsonInput = document.getElementById('dxp-page-widgets-json');
	const typeSel = document.getElementById('dxp_page_type');
	const editor = document.getElementById('dxp-pw-editor');
	const libEl = document.getElementById('dxp-pw-lib');
	const listEl = document.getElementById('dxp-pw-list');
	const settingsEl = document.getElementById('dxp-pw-settings');
	const emptyEl = document.getElementById('dxp-pw-empty');

	let widgets = [];
	let selected = -1;
	let focusAcik = false; /* odak modu: yalnızca ayarlar paneli görünür */
	let dragIndex = -1; /* listede sıralama kaynağı */
	let dragTip = '';   /* kütüphaneden gelen widget tipi */
	let ph = null;      /* "Buraya ekle" önizleme kutusu */
	let phIndex = -1;   /* bırakılacak sıra */
	let phYer = '';     /* bırakılacak kolon: '' | sol | sag */
	let libSayfa = 1;   /* kütüphane sayfası (1 tabanlı) */
	let libLimit = 10;  /* sayfa başına widget tipi */
	let libBar = null;  /* sayfalama çubuğu */
	let libSayla = null;/* "1 / 3" etiketi */
	let libGeri = null; /* ‹ */
	let libIleri = null;/* › */

	/* ── yardımcılar ──────────────────────────────────────── */

	function defaults(tip) {
		const out = {};
		const ay = (lib[tip] && lib[tip].ayarlar) || {};
		Object.keys(ay).forEach(function (key) {
			out[key] = (typeof ay[key].varsayilan !== 'undefined') ? ay[key].varsayilan : '';
		});
		return out;
	}

	function syncJson() {
		if (jsonInput) {
			jsonInput.value = JSON.stringify(widgets);
		}
	}

	function makeButton(label, title, className) {
		const b = document.createElement('button');
		b.type = 'button';
		b.className = className;
		b.textContent = label;
		b.title = title;
		b.setAttribute('aria-label', title);
		return b;
	}

	function tipAdi(tip) {
		return (lib[tip] && lib[tip].ad) ? lib[tip].ad : tip;
	}

	function yerAdi(yer) {
		return ({ sol: 'Sol', sag: 'Sağ', tam: 'Tam' })[yer] || '';
	}

	/* ── lucide ikon seçici ───────────────────────────────── */

	/*
	 * Sayfadaki `#dxp-lucide-data` (isim → SVG iç gövdesi) bir kez okunur ve
	 * önbelleğe alınır. Yoksa/bozuksa {} döner; seçici boş grid + mesaj gösterir.
	 */
	let _lucideVeri = null;

	function lucideVeri() {
		if (_lucideVeri) {
			return _lucideVeri;
		}

		_lucideVeri = {};
		const el = document.getElementById('dxp-lucide-data');

		if (!el) {
			return _lucideVeri;
		}

		try {
			const veri = JSON.parse(el.textContent || '{}');

			if (veri && typeof veri === 'object') {
				_lucideVeri = veri;
			}
		} catch (err) {
			_lucideVeri = {};
		}

		return _lucideVeri;
	}

	/* İkon adını ön yüzle aynı biçimde SVG dizesine çevirir. Bilinmeyen ad → ''. */
	function lucideSvg(ad) {
		if (!ad) {
			return '';
		}

		const govde = lucideVeri()[ad];

		if (!govde) {
			return '';
		}

		return '<svg class="dxp-ic" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + govde + '</svg>';
	}

	/*
	 * Aynı anda tek panel açık kalsın diye açık panelin kapatma işlevi burada
	 * tutulur; document'e dışarı-tıklama dinleyicisi tembel olarak bir kez bağlanır.
	 */
	let acikIkonPanel = null;
	let ikonBelgeBagli = false;

	function ikonBelgeBagla() {
		if (ikonBelgeBagli) {
			return;
		}
		ikonBelgeBagli = true;

		document.addEventListener('click', function (e) {
			if (!acikIkonPanel) {
				return;
			}
			/* Panel içine (metin alanı, grid, trigger) tıklama kapatmasın. */
			if (e.target && e.target.closest && e.target.closest('.dxp-iconpick')) {
				return;
			}
			acikIkonPanel();
		});
	}

	/*
	 * SVG önizlemeli + aramalı ikon seçici. `degisti(ad)` değer değişince
	 * çağrılır (boş string = ikon yok).
	 */
	function ikonSec(deger, degisti) {
		ikonBelgeBagla();

		const kok = document.createElement('div');
		kok.className = 'dxp-iconpick';
		kok.setAttribute('data-icon-set', 'lucide');

		const gizli = document.createElement('input');
		gizli.type = 'hidden';
		gizli.className = 'dxp-iconpick-value';
		gizli.value = deger || '';

		const tetik = document.createElement('button');
		tetik.type = 'button';
		tetik.className = 'dxp-iconpick-trigger';
		tetik.setAttribute('aria-haspopup', 'true');
		tetik.setAttribute('aria-expanded', 'false');

		const gorsel = document.createElement('span');
		gorsel.className = 'dxp-iconpick-visual';

		const ad = document.createElement('span');
		ad.className = 'dxp-iconpick-current';

		const oku = document.createElement('span');
		oku.className = 'dxp-iconpick-caret';
		oku.textContent = '▾';

		tetik.appendChild(gorsel);
		tetik.appendChild(ad);
		tetik.appendChild(oku);

		const panel = document.createElement('div');
		panel.className = 'dxp-iconpick-panel';
		panel.hidden = true;

		const arama = document.createElement('input');
		arama.type = 'search';
		arama.className = 'dxp-iconpick-search';
		arama.placeholder = 'İkon ara…';
		arama.autocomplete = 'off';

		const grid = document.createElement('div');
		grid.className = 'dxp-iconpick-grid';
		grid.setAttribute('role', 'listbox');

		const bos = document.createElement('div');
		bos.className = 'dxp-iconpick-empty';
		bos.hidden = true;
		bos.textContent = 'Sonuç yok.';

		panel.appendChild(arama);
		panel.appendChild(grid);
		panel.appendChild(bos);

		kok.appendChild(gizli);
		kok.appendChild(tetik);
		kok.appendChild(panel);

		const ogeler = {};    /* değer → grid öğesi */
		let uretildi = false; /* grid yalnızca ilk açılışta kurulur */
		let secilenEl = null;

		/* Önizleme SVG'si + adı gizli değere göre tazelenir. */
		function onizlemeGuncelle() {
			gorsel.innerHTML = lucideSvg(gizli.value);
			ad.textContent = gizli.value || '';
		}

		function ogeYap(v) {
			const b = document.createElement('button');
			b.type = 'button';
			b.className = 'dxp-iconpick-item';
			b.setAttribute('role', 'option');
			b.dataset.value = v;

			if (v) {
				b.innerHTML = lucideSvg(v);
				b.title = v;
			} else {
				b.textContent = '—';
			}

			if (v === gizli.value) {
				b.classList.add('is-selected');
				secilenEl = b;
			}

			b.addEventListener('click', function () { secildi(v); });
			ogeler[v] = b;
			return b;
		}

		function gridKur() {
			grid.innerHTML = '';

			const adlar = Object.keys(lucideVeri());

			if (!adlar.length) {
				/* Veri yok: boş grid + mesaj. */
				bos.hidden = false;
				uretildi = true;
				return;
			}

			grid.appendChild(ogeYap('')); /* "—" = ikon yok */
			adlar.forEach(function (a) { grid.appendChild(ogeYap(a)); });
			uretildi = true;
		}

		function filtrele() {
			const kelimeler = arama.value.toLowerCase().trim().split(/\s+/).filter(Boolean);
			let gorunen = 0;

			Object.keys(ogeler).forEach(function (v) {
				const esles = !kelimeler.length || kelimeler.every(function (k) {
					return v.toLowerCase().indexOf(k) !== -1;
				});

				ogeler[v].hidden = !esles;

				if (esles) {
					gorunen += 1;
				}
			});

			bos.hidden = gorunen > 0;
		}

		function kapat() {
			panel.hidden = true;
			tetik.setAttribute('aria-expanded', 'false');

			if (acikIkonPanel === kapat) {
				acikIkonPanel = null;
			}
		}

		/* Yeni değer: gizli input, önizleme, seçili işareti, kapatma ve callback. */
		function secildi(v) {
			gizli.value = v;
			onizlemeGuncelle();

			if (secilenEl) {
				secilenEl.classList.remove('is-selected');
			}
			if (ogeler[v]) {
				ogeler[v].classList.add('is-selected');
				secilenEl = ogeler[v];
			}

			kapat();

			if (typeof degisti === 'function') {
				degisti(v);
			}
		}

		function ac() {
			if (acikIkonPanel && acikIkonPanel !== kapat) {
				acikIkonPanel();
			}
			if (!uretildi) {
				gridKur();
			}

			panel.hidden = false;
			tetik.setAttribute('aria-expanded', 'true');
			arama.value = '';
			filtrele();
			acikIkonPanel = kapat;
			arama.focus();
		}

		tetik.addEventListener('click', function (e) {
			e.stopPropagation();

			if (panel.hidden) {
				ac();
			} else {
				kapat();
			}
		});

		arama.addEventListener('input', filtrele);

		/* Esc yalnızca paneli kapatsın; odak modu kısayoluna sızmasın. */
		kok.addEventListener('keydown', function (e) {
			if (e.key === 'Escape' && !panel.hidden) {
				e.stopPropagation();
				kapat();
				tetik.focus();
			}
		});

		onizlemeGuncelle();
		return kok;
	}

	/* ── liste (orta kolon) ───────────────────────────────── */

	function renderList() {
		listEl.innerHTML = '';

		widgets.forEach(function (w, i) {
			const li = document.createElement('li');
			/*
			 * Nested düzende ön yüz sol/sağ yığınlara ayrılır; atanmamış
			 * widget sol kolona girer, önizlemede de öyle gösterilir.
			 */
			let yerSinif = w.yer;

			if (!yerSinif && listEl.classList.contains('dxp-pw-list--nested')) {
				yerSinif = 'sol';
			}

			li.className = 'dxp-pw-item' + (i === selected ? ' is-selected' : '') + (yerSinif ? ' dxp-pw-item--' + yerSinif : '');
			li.draggable = true;
			li.dataset.index = String(i);

			const handle = document.createElement('span');
			handle.className = 'dxp-pw-handle';
			handle.textContent = '⠿';
			handle.setAttribute('aria-hidden', 'true');

			const name = document.createElement('span');
			name.className = 'dxp-pw-name';
			name.textContent = tipAdi(w.tip);

			const tools = document.createElement('span');
			tools.className = 'dxp-pw-tools';

			const up = makeButton('▲', 'Yukarı taşı', 'dxp-pw-btn');
			const down = makeButton('▼', 'Aşağı taşı', 'dxp-pw-btn');
			const del = makeButton('✕', 'Sil', 'dxp-pw-btn dxp-pw-del');

			up.addEventListener('click', function (e) { e.stopPropagation(); move(i, i - 1); });
			down.addEventListener('click', function (e) { e.stopPropagation(); move(i, i + 1); });
			del.addEventListener('click', function (e) { e.stopPropagation(); remove(i); });

			tools.appendChild(up);
			tools.appendChild(down);
			tools.appendChild(del);

			li.appendChild(handle);
			li.appendChild(name);

			/* Yerleşim rozeti: nested düzende hangi kolona/satıra atandığını gösterir. */
			if (w.yer) {
				const badge = document.createElement('span');
				badge.className = 'dxp-pw-yer-badge dxp-pw-yer-badge--' + w.yer;
				badge.textContent = yerAdi(w.yer);
				li.appendChild(badge);
			}

			li.appendChild(tools);

			li.addEventListener('click', function () { select(i); });

			li.addEventListener('dragstart', function () { dragIndex = i; dragTip = ''; });
			li.addEventListener('dragend', function () { dragIndex = -1; dragTip = ''; phHide(); });

			listEl.appendChild(li);
		});

		if (emptyEl) {
			emptyEl.style.display = widgets.length ? 'none' : '';
		}
	}

	/* ── düzen: önizleme 2 kolon mu? ──────────────────────── */

	/*
	 * "Düzen → Nested (2 sütun)" seçilince önizleme listesi de ikiye bölünür.
	 * Böylece kaydetmeden önce ön yüzdeki görünümün aynısı panelde görülür.
	 */
	function listNested() {
		const sec = root.querySelector('input[name="dxp_pw_duzen"]:checked');
		listEl.classList.toggle('dxp-pw-list--nested', !!sec && sec.value === 'nested');
		renderList();
	}

	/* ── işlemler ─────────────────────────────────────────── */

	/* ── odak modu ────────────────────────────────────────── */

	/*
	 * Odak yalnızca bir widget seçiliyken ve kullanıcı odaktan çıkmadıysa
	 * açıktır. Köke is-focus eklenir; CSS kütüphane + önizlemeyi gizleyip
	 * ayarlar panelini tam genişliğe açar. "← Geri" / Esc focusAcik'ı kapatır.
	 */
	function focusUygula() {
		root.classList.toggle('is-focus', selected >= 0 && focusAcik);
	}

	function odaktanCik() {
		focusAcik = false;
		focusUygula();
	}

	function select(i) {
		selected = i;
		focusAcik = true;
		renderList();
		renderSettings();
		focusUygula();
	}

	function move(from, to) {
		if (to < 0 || to >= widgets.length) {
			return;
		}
		const item = widgets.splice(from, 1)[0];
		widgets.splice(to, 0, item);
		selected = to;
		syncJson();
		renderList();
		renderSettings();
	}

	function remove(i) {
		widgets.splice(i, 1);
		if (selected === i) {
			selected = -1;
		} else if (selected > i) {
			selected -= 1;
		}
		if (selected < 0) {
			focusAcik = false;
		}
		syncJson();
		renderList();
		renderSettings();
		focusUygula();
	}

	function add(tip) {
		if (!lib[tip]) {
			return;
		}
		widgets.push({ tip: tip, ayar: defaults(tip) });
		selected = widgets.length - 1;
		syncJson();
		renderList();
		renderSettings();
		focusUygula();
	}

	/* ── sürükleme önizlemesi ("Buraya ekle") ─────────────── */

	/*
	 * Sürükleme sırasında hedef konuma "Buraya ekle" kutusu konur.
	 * Nested düzende kutunun sütunu, imleç listenin hangi yarısındaysa
	 * ona göre belirlenir; bırakınca widget o kolona atanır (yer).
	 */
	function phHide() {
		if (ph && ph.parentNode) {
			ph.parentNode.removeChild(ph);
		}
		phIndex = -1;
		phYer = '';
	}

	function phShow(index, yer) {
		if (!ph) {
			ph = document.createElement('li');
			ph.textContent = 'Buraya ekle';
		}

		ph.className = 'dxp-pw-ph' + (yer ? ' dxp-pw-ph--' + yer : '');

		const items = listEl.querySelectorAll('.dxp-pw-item');

		if (index >= items.length) {
			listEl.appendChild(ph);
		} else {
			listEl.insertBefore(ph, items[index]);
		}

		phIndex = index;
		phYer = yer || '';
	}

	/* İmlece en yakın satıra göre bırakılacak sıra. */
	function phTarget(e) {
		const items = Array.prototype.slice.call(listEl.querySelectorAll('.dxp-pw-item'));

		if (!items.length) {
			return 0;
		}

		let en = 0;
		let min = Infinity;

		items.forEach(function (el, i) {
			const r = el.getBoundingClientRect();
			const dx = e.clientX - (r.left + r.width / 2);
			const dy = e.clientY - (r.top + r.height / 2);
			const d = dx * dx + dy * dy;

			if (d < min) {
				min = d;
				en = i;
			}
		});

		const r = items[en].getBoundingClientRect();

		return en + (e.clientY > r.top + r.height / 2 ? 1 : 0);
	}

	/* Nested düzende imlecin bulunduğu kolon. */
	function phYerBul(e) {
		if (!listEl.classList.contains('dxp-pw-list--nested')) {
			return '';
		}

		const r = listEl.getBoundingClientRect();

		return e.clientX < r.left + r.width / 2 ? 'sol' : 'sag';
	}

	function listDrop() {
		const hedef = phIndex >= 0 ? phIndex : widgets.length;
		const yer   = phYer;

		if (dragIndex >= 0) {
			const tasinan = widgets.splice(dragIndex, 1)[0];
			const to      = hedef > dragIndex ? hedef - 1 : hedef;

			if (yer) {
				tasinan.yer = yer;
			}

			widgets.splice(to, 0, tasinan);
			selected = to;
		} else if (dragTip) {
			const yeni = { tip: dragTip, ayar: defaults(dragTip) };

			if (yer) {
				yeni.yer = yer;
			}

			widgets.splice(hedef, 0, yeni);
			selected = hedef;
		}

		dragIndex = -1;
		dragTip = '';
		phHide();
		syncJson();
		renderList();
		renderSettings();
	}

	/* ── ayar paneli (sağ kolon) ──────────────────────────── */

	function renderSettings() {
		settingsEl.innerHTML = '';

		if (selected < 0 || !widgets[selected]) {
			const p = document.createElement('p');
			p.className = 'dxp-pw-settings-empty';
			p.textContent = 'Ayarları görmek için bir widget seçin.';
			settingsEl.appendChild(p);
			return;
		}

		const w = widgets[selected];
		const ay = (lib[w.tip] && lib[w.tip].ayarlar) || {};

		/* Odaktan çıkış: ayarların en üstünde "← Geri". */
		const geri = makeButton('← Geri', 'Odaktan çık', 'dxp-pw-back');
		geri.addEventListener('click', odaktanCik);
		settingsEl.appendChild(geri);

		const title = document.createElement('h4');
		title.textContent = tipAdi(w.tip);
		settingsEl.appendChild(title);

		/* Ortak alan: her widget için yerleşim (sol / sağ / tam). */
		settingsEl.appendChild(buildYerField(w));

		Object.keys(ay).forEach(function (key) {
			settingsEl.appendChild(buildField(ay[key], key, w, w.ayar[key]));
		});
	}

	/* ── Harita önizlemesi (konum yazarken canlı) ───────────── */

	/* Konum → gömülebilir Google Harita adresi (API anahtarı gerekmez). */
	function haritaUrl(adres, zoom) {
		const z = parseInt(zoom, 10);

		return 'https://www.google.com/maps?q=' + encodeURIComponent((adres || '').trim())
			+ '&z=' + (z >= 1 && z <= 21 ? z : 14) + '&output=embed';
	}

	/*
	 * Widget ayarında konum yazarken nereyi işaret ettiğini gösterir.
	 * degerAl(): güncel konum · zoomAl(): güncel yakınlaştırma
	 */
	function haritaOnizleme(degerAl, zoomAl) {
		const sar = document.createElement('div');
		sar.className = 'dxp-pw-harita';

		const cap = document.createElement('span');
		cap.className = 'dxp-pw-harita-cap';
		cap.textContent = 'Harita önizlemesi';

		const kutu = document.createElement('div');
		kutu.className = 'dxp-pw-harita-kutu';

		const bos = document.createElement('p');
		bos.className = 'dxp-pw-harita-bos';

		let zaman = null;

		function yenile() {
			let adres = (degerAl() || '').trim();

			/* Alan boşsa paneldeki adres gösterilir (ön yüzle aynı davranış). */
			if (!adres && typeof DXPPW !== 'undefined' && DXPPW.varsayilan_adres) {
				adres = String(DXPPW.varsayilan_adres).trim();
			}

			const mevcut = kutu.querySelector('iframe');

			if (!adres) {
				if (mevcut) { mevcut.parentNode.removeChild(mevcut); }
				bos.textContent = 'Konum yazınca harita burada görünür.';
				bos.hidden = false;
				return;
			}

			bos.hidden = true;

			const url = haritaUrl(adres, zoomAl());

			if (mevcut && mevcut.getAttribute('data-url') === url) {
				return;
			}

			kutu.innerHTML = '';

			const iframe = document.createElement('iframe');
			iframe.src = url;
			iframe.setAttribute('data-url', url);
			iframe.title = 'Harita önizlemesi';
			iframe.setAttribute('loading', 'lazy');
			iframe.setAttribute('referrerpolicy', 'no-referrer-when-downgrade');
			kutu.appendChild(iframe);
		}

		sar.appendChild(cap);
		sar.appendChild(kutu);
		sar.appendChild(bos);

		yenile();

		return {
			sar: sar,
			yenile: function () {
				if (zaman) { clearTimeout(zaman); }
				zaman = setTimeout(yenile, 350);
			}
		};
	}

	function buildField(sema, key, w, value) {
		const wrap = document.createElement('div');
		wrap.className = 'dxp-pw-field';

		const label = document.createElement('label');
		label.textContent = sema.etiket;

		const uid = 'dxp-pw-f-' + w.tip + '-' + key;
		label.setAttribute('for', uid);
		wrap.appendChild(label);

		function commit(val) {
			w.ayar[key] = val;
			syncJson();
		}

		if (sema.tip === 'metinuzun') {
			const ta = document.createElement('textarea');
			ta.id = uid;
			ta.rows = 5;
			ta.value = value || '';
			ta.addEventListener('input', function () { commit(ta.value); });
			wrap.appendChild(ta);

		} else if (sema.tip === 'secim') {
			const sel = document.createElement('select');
			sel.id = uid;
			Object.keys(sema.secenekler || {}).forEach(function (val) {
				const opt = document.createElement('option');
				opt.value = val;
				opt.textContent = sema.secenekler[val];
				sel.appendChild(opt);
			});
			sel.value = value;
			sel.addEventListener('change', function () { commit(sel.value); });
			wrap.appendChild(sel);

		} else if (sema.tip === 'onay') {
			const cb = document.createElement('input');
			cb.type = 'checkbox';
			cb.id = uid;
			cb.value = '1';
			cb.checked = (value === '1');
			cb.addEventListener('change', function () { commit(cb.checked ? '1' : ''); });
			wrap.appendChild(cb);

		} else if (sema.tip === 'sayi') {
			const num = document.createElement('input');
			num.type = 'number';
			num.id = uid;
			num.value = value || '';
			num.addEventListener('input', function () { commit(num.value); });
			wrap.appendChild(num);

		} else if (sema.tip === 'gorsel') {
			const inp = document.createElement('input');
			inp.type = 'text';
			inp.id = uid;
			inp.className = 'dxp-pw-img-url';
			inp.value = value || '';
			inp.addEventListener('input', function () { commit(inp.value); });

			const prev = document.createElement('div');
			prev.className = 'dxp-pw-img-prev';
			if (value) {
				const img = document.createElement('img');
				img.src = value;
				prev.appendChild(img);
			}

			const pick = makeButton('Görsel Seç', 'Görsel Seç', 'button');
			const clear = makeButton('Kaldır', 'Görseli kaldır', 'button');

			pick.addEventListener('click', function () {
				if (!window.wp || !window.wp.media) {
					return;
				}
				const frame = window.wp.media({ title: 'Görsel Seç', button: { text: 'Kullan' }, multiple: false });
				frame.on('select', function () {
					const att = frame.state().get('selection').first().toJSON();
					inp.value = att.url;
					commit(att.url);
					prev.innerHTML = '';
					const im = document.createElement('img');
					im.src = att.url;
					prev.appendChild(im);
				});
				frame.open();
			});

			clear.addEventListener('click', function () {
				inp.value = '';
				commit('');
				prev.innerHTML = '';
			});

			wrap.appendChild(inp);
			const actions = document.createElement('p');
			actions.className = 'dxp-pw-img-actions';
			actions.appendChild(pick);
			actions.appendChild(clear);
			wrap.appendChild(actions);
			wrap.appendChild(prev);

		} else if (sema.tip === 'satirlar') {
			wrap.appendChild(buildSatirlar(sema, w, key, value));

		} else if (sema.tip === 'ikon') {
			const secici = ikonSec(value || '', commit);
			const trg = secici.querySelector('.dxp-iconpick-trigger');

			if (trg) {
				trg.id = uid; /* label for=uid ile eşleşsin */
			}

			wrap.appendChild(secici);

		} else {
			const inp = document.createElement('input');
			inp.type = 'text';
			inp.id = uid;
			inp.value = value || '';
			inp.addEventListener('input', function () { commit(inp.value); });
			wrap.appendChild(inp);
		}

		/* Konum alanı: yazarken canlı harita önizlemesi. */
		if (sema.onizleme === 'harita') {
			const onizleme = haritaOnizleme(
				function () { return w.ayar[key]; },
				function () { return w.ayar.zoom; }
			);

			wrap.appendChild(onizleme.sar);
			wrap.addEventListener('input', onizleme.yenile);
		}

		return wrap;
	}

	/* ── satirlar: pipe-satır alan editörü ──────────────────
	 *
	 * Depolama biçimi: satırlar "\n", hücreler "|" ile birleşik TEK string.
	 * Örn: "a.jpg|Başlık|http://x\nb.jpg|Diğeri|"
	 */

	/* String'i satır dizisine çözer: eksik hücreler '' ile doldurulur,
	 * tamamen boş satırlar atılır. Dönüş: [ ['a','b','c'], ... ] */
	function satirCoz(str, kolonSayisi) {
		const sayi = kolonSayisi > 0 ? kolonSayisi : 1;
		const metin = (str == null) ? '' : String(str);
		if (!metin) {
			return [];
		}

		const sonuc = [];
		metin.split('\n').forEach(function (satir) {
			const hucreler = satir.split('|');
			const dolu = [];
			/* Eski kayıtlarda şemadan fazla hücre olabilir; kırpma, koru. */
			const adet = Math.max(sayi, hucreler.length);

			for (let i = 0; i < adet; i++) {
				dolu.push(typeof hucreler[i] === 'string' ? hucreler[i] : '');
			}
			const bos = dolu.every(function (h) { return h === ''; });
			if (!bos) {
				sonuc.push(dolu);
			}
		});
		return sonuc;
	}

	/* Satır dizisini depolama string'ine çevirir; boş satırlar atılır. */
	function satirYaz(satirlar) {
		const cikti = [];
		(satirlar || []).forEach(function (satir) {
			const hucreler = (satir || []).map(function (h) {
				return (h == null) ? '' : String(h);
			});
			if (hucreler.every(function (h) { return h === ''; })) {
				return;
			}
			cikti.push(hucreler.join('|'));
		});
		return cikti.join('\n');
	}

	/* Görsel önizlemesini yeniler (tek <img>). */
	function satirOnizleme(prev, url) {
		prev.innerHTML = '';
		if (!url) {
			return;
		}
		const img = document.createElement('img');
		img.src = url;
		prev.appendChild(img);
	}

	/* Tek hücre girişini üretir (kolon tipine göre) ve duruma bağlar. */
	function satirHucre(kolon, cid, satirlar, r, c, kaydet) {
		const tip = kolon.tip || 'metin';

		if (tip === 'gorsel') {
			const sar = document.createElement('div');
			sar.className = 'dxp-pw-satir-gorsel';

			const inp = document.createElement('input');
			inp.type = 'text';
			inp.id = cid;
			inp.className = 'dxp-pw-img-url';
			inp.value = satirlar[r][c] || '';

			const prev = document.createElement('span');
			prev.className = 'dxp-pw-satir-img-prev';

			const pick = makeButton('Görsel', 'Görsel Seç', 'button dxp-pw-satir-gbtn');
			const clear = makeButton('Kaldır', 'Görseli kaldır', 'button dxp-pw-satir-gbtn');

			inp.addEventListener('input', function () {
				satirlar[r][c] = inp.value;
				kaydet();
			});
			pick.addEventListener('click', function () {
				if (!window.wp || !window.wp.media) {
					return;
				}
				const frame = window.wp.media({ title: 'Görsel Seç', button: { text: 'Kullan' }, multiple: false });
				frame.on('select', function () {
					const att = frame.state().get('selection').first().toJSON();
					inp.value = att.url;
					satirlar[r][c] = att.url;
					kaydet();
					satirOnizleme(prev, att.url);
				});
				frame.open();
			});
			clear.addEventListener('click', function () {
				inp.value = '';
				satirlar[r][c] = '';
				kaydet();
				satirOnizleme(prev, '');
			});

			sar.appendChild(inp);
			sar.appendChild(pick);
			sar.appendChild(clear);
			sar.appendChild(prev);
			satirOnizleme(prev, inp.value);
			return sar;
		}

		if (tip === 'ikon') {
			const sar = document.createElement('div');
			sar.className = 'dxp-pw-satir-ikon';

			const secici = ikonSec(satirlar[r][c] || '', function (v) {
				satirlar[r][c] = v;
				kaydet();
			});

			const trg = secici.querySelector('.dxp-iconpick-trigger');

			if (trg) {
				trg.id = cid; /* satır etiketi for=cid ile eşleşsin */
			}

			sar.appendChild(secici);
			return sar;
		}

		if (tip === 'metinuzun') {
			const ta = document.createElement('textarea');
			ta.id = cid;
			ta.rows = 2;
			ta.value = satirlar[r][c] || '';
			ta.addEventListener('input', function () {
				satirlar[r][c] = ta.value;
				kaydet();
			});
			return ta;
		}

		const inp = document.createElement('input');
		inp.type = 'text';
		inp.id = cid;
		inp.value = satirlar[r][c] || '';
		if (tip === 'link') {
			inp.placeholder = 'https://...';
		}
		inp.addEventListener('input', function () {
			satirlar[r][c] = inp.value;
			kaydet();
		});
		return inp;
	}

	/* Tek satırın kutusunu (kolonlar + sırala/sil araçları) üretir. */
	function satirKutusu(uidOn, kolonlar, satirlar, r, kaydet, ciz) {
		const satir = document.createElement('div');
		satir.className = 'dxp-pw-satir-satir';

		const alanlar = document.createElement('div');
		alanlar.className = 'dxp-pw-satir-alanlar';

		kolonlar.forEach(function (kolon, c) {
			const hucre = document.createElement('div');
			hucre.className = 'dxp-pw-satir-kolon dxp-pw-satir-kolon--' + (kolon.tip || 'metin');

			const cid = uidOn + r + '-' + c;
			const lab = document.createElement('label');
			lab.className = 'dxp-pw-satir-etiket';
			lab.setAttribute('for', cid);
			lab.textContent = kolon.ad;

			hucre.appendChild(lab);
			hucre.appendChild(satirHucre(kolon, cid, satirlar, r, c, kaydet));
			alanlar.appendChild(hucre);
		});

		const arac = document.createElement('div');
		arac.className = 'dxp-pw-satir-araclar';

		const yukari = makeButton('▲', 'Yukarı taşı', 'dxp-pw-btn dxp-pw-satir-btn');
		const asagi = makeButton('▼', 'Aşağı taşı', 'dxp-pw-btn dxp-pw-satir-btn');
		const sil = makeButton('✕', 'Satırı sil', 'dxp-pw-btn dxp-pw-satir-btn dxp-pw-del');

		yukari.disabled = (r === 0);
		asagi.disabled = (r === satirlar.length - 1);

		yukari.addEventListener('click', function () {
			if (r === 0) { return; }
			const t = satirlar[r - 1];
			satirlar[r - 1] = satirlar[r];
			satirlar[r] = t;
			kaydet();
			ciz();
		});
		asagi.addEventListener('click', function () {
			if (r >= satirlar.length - 1) { return; }
			const t = satirlar[r + 1];
			satirlar[r + 1] = satirlar[r];
			satirlar[r] = t;
			kaydet();
			ciz();
		});
		sil.addEventListener('click', function () {
			satirlar.splice(r, 1);
			kaydet();
			ciz();
		});

		arac.appendChild(yukari);
		arac.appendChild(asagi);
		arac.appendChild(sil);

		satir.appendChild(alanlar);
		satir.appendChild(arac);
		return satir;
	}

	/* satirlar alanının tam editörünü üretir. İç durum (satır dizisi)
	 * kapanışta tutulur; yalnızca satırlar kutusu yeniden çizilir. */
	function buildSatirlar(sema, w, key, value) {
		const kolonlar = (sema.kolonlar && sema.kolonlar.length)
			? sema.kolonlar
			: [{ ad: 'Değer', tip: 'metin' }];
		let satirlar = satirCoz(value, kolonlar.length);
		const uidOn = 'dxp-pw-satir-' + w.tip + '-' + key + '-';

		const kutu = document.createElement('div');
		kutu.className = 'dxp-pw-satir';

		const rowsEl = document.createElement('div');
		rowsEl.className = 'dxp-pw-satir-liste';

		function kaydet() {
			w.ayar[key] = satirYaz(satirlar);
			syncJson();
		}

		function ciz() {
			rowsEl.innerHTML = '';
			satirlar.forEach(function (row, r) {
				rowsEl.appendChild(satirKutusu(uidOn, kolonlar, satirlar, r, kaydet, ciz));
			});
		}

		const ekle = makeButton('+ Satır Ekle', 'Yeni satır ekle', 'button dxp-pw-satir-ekle');
		ekle.addEventListener('click', function () {
			const bos = [];
			for (let i = 0; i < kolonlar.length; i++) {
				bos.push('');
			}
			satirlar.push(bos);
			kaydet();
			ciz();
		});

		kutu.appendChild(rowsEl);
		kutu.appendChild(ekle);
		ciz();
		return kutu;
	}

	/*
	 * Ortak yerleşim alanı (her widget'ta görünür).
	 *
	 * Etkisi yalnızca sayfa düzeni "Nested (2 sütun)" iken ortaya çıkar:
	 * widget'ı sol kolona, sağ kolona ya da tam genişliğe sabitler.
	 */
	function buildYerField(w) {
		const wrap = document.createElement('div');
		wrap.className = 'dxp-pw-field dxp-pw-field--yer';

		const label = document.createElement('label');
		label.setAttribute('for', 'dxp-pw-yer');
		label.textContent = 'Yerleşim (nested düzen)';

		const sel = document.createElement('select');
		sel.id = 'dxp-pw-yer';

		[['', 'Otomatik'], ['sol', 'Sol sütun'], ['sag', 'Sağ sütun'], ['tam', 'Tam genişlik']]
			.forEach(function (p) {
				const opt = document.createElement('option');
				opt.value = p[0];
				opt.textContent = p[1];
				sel.appendChild(opt);
			});

		sel.value = w.yer || '';
		sel.addEventListener('change', function () {
			if (sel.value) {
				w.yer = sel.value;
			} else {
				delete w.yer;
			}
			syncJson();
			renderList();
		});

		wrap.appendChild(label);
		wrap.appendChild(sel);
		return wrap;
	}

	/* ── kütüphane (sol kolon) ────────────────────────────── */

	/* ── kütüphane sayfalama (10 tip/sayfa) ───────────────── */

	/*
	 * "Widget Ekle" listesi uzun (26 tip); sayfa başına 10 gösterilir.
	 * ‹ › düğmeleri aynı metabox içinde sayfa değiştirir.
	 */
	function libToplamSayfa() {
		return Math.max(1, Math.ceil(libEl.querySelectorAll('.dxp-pw-lib-item').length / libLimit));
	}

	function libSayfaUygula() {
		const toplam = libToplamSayfa();

		if (libSayfa > toplam) { libSayfa = toplam; }
		if (libSayfa < 1) { libSayfa = 1; }

		const bas = (libSayfa - 1) * libLimit;
		let i = 0;

		Array.prototype.forEach.call(libEl.querySelectorAll('.dxp-pw-lib-item'), function (item) {
			item.style.display = (i >= bas && i < bas + libLimit) ? '' : 'none';
			i += 1;
		});

		if (libSayla) { libSayla.textContent = libSayfa + ' / ' + toplam; }
		if (libBar) { libBar.style.display = toplam > 1 ? '' : 'none'; }
		if (libGeri) { libGeri.disabled = (libSayfa <= 1); }
		if (libIleri) { libIleri.disabled = (libSayfa >= toplam); }
	}

	function libSayfalamaKur() {
		libBar = document.createElement('div');
		libBar.className = 'dxp-pw-sayfa';

		libGeri = makeButton('‹', 'Önceki sayfa', 'dxp-pw-sayfa-btn');
		libIleri = makeButton('›', 'Sonraki sayfa', 'dxp-pw-sayfa-btn');

		libSayla = document.createElement('span');
		libSayla.className = 'dxp-pw-sayfa-etiket';

		libGeri.addEventListener('click', function () {
			libSayfa -= 1;
			libSayfaUygula();
		});

		libIleri.addEventListener('click', function () {
			libSayfa += 1;
			libSayfaUygula();
		});

		libBar.appendChild(libGeri);
		libBar.appendChild(libSayla);
		libBar.appendChild(libIleri);

		/* Kütüphane listesinin hemen altına. */
		if (libEl.parentNode) {
			libEl.parentNode.insertBefore(libBar, libEl.nextSibling);
		}
	}

	function bindLib() {
		Array.prototype.forEach.call(libEl.querySelectorAll('.dxp-pw-lib-item'), function (item) {
			const tip = item.dataset.tip;
			item.addEventListener('click', function () { add(tip); });
			item.addEventListener('dragstart', function () { dragTip = tip; dragIndex = -1; });
			item.addEventListener('dragend', function () { dragTip = ''; phHide(); });
		});

		listEl.addEventListener('dragover', function (e) {
			if (dragIndex < 0 && !dragTip) {
				return;
			}

			e.preventDefault();

			const hedef = phTarget(e);
			const yer   = phYerBul(e);

			if (!ph || !ph.parentNode || hedef !== phIndex || yer !== phYer) {
				phShow(hedef, yer);
			}
		});

		listEl.addEventListener('dragleave', function (e) {
			if (!listEl.contains(e.relatedTarget)) {
				phHide();
			}
		});

		listEl.addEventListener('drop', function (e) {
			e.preventDefault();
			listDrop();
		});
	}

	/* ── sayfa tipi / görünürlük ──────────────────────────── */

	function currentBaglam() {
		/* Sayfada seçici belirler; içerik tipinde bağlam sunucudan gelir. */
		if (typeSel) {
			return typeSel.value;
		}
		return root.getAttribute('data-baglam') || '';
	}

	function updateVisibility() {
		const type = currentBaglam();
		const on = !!baglamlar[type];
		editor.style.display = on ? '' : 'none';
		root.classList.toggle('is-collapsed', !on);
	}

	/* ── başlat ───────────────────────────────────────────── */

	try {
		widgets = JSON.parse(jsonInput.value || '[]');
	} catch (err) {
		widgets = [];
	}
	if (!Array.isArray(widgets)) {
		widgets = [];
	}

	widgets = widgets.filter(function (w) {
		return w && typeof w.tip === 'string' && lib[w.tip];
	});

	widgets = widgets.map(function (w) {
		if (!w.ayar || typeof w.ayar !== 'object') {
			w.ayar = defaults(w.tip);
		}
		return w;
	});

	bindLib();
	libSayfalamaKur();
	libSayfaUygula();
	renderList();
	renderSettings();
	syncJson();

	/* Düzen radyoları: seçime göre önizleme listesinin kolon sayısı değişir. */
	Array.prototype.forEach.call(root.querySelectorAll('input[name="dxp_pw_duzen"]'), function (el) {
		el.addEventListener('change', listNested);
	});
	listNested();

	if (typeSel) {
		typeSel.addEventListener('change', updateVisibility);
	}

	/* Esc ile odaktan çık (tercih edilen kısayol). */
	document.addEventListener('keydown', function (e) {
		if (e.key === 'Escape' && focusAcik) {
			odaktanCik();
		}
	});

	updateVisibility();
	focusUygula();
})();
