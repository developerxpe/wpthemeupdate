<?php
/**
 * DEVXPE yönetim metabox'ları (manşet arkaplanı + sayfa içerik düzeni).
 *
 * Manşet arkaplan görseli meta kutusu, medya yükleyici, sayfa/içerik tipi
 * "İçerik Düzeni" widget editörü meta kutusu ve düzenleyici varlıkları
 * buradadır.
 *
 * Kamu Yüzeyi: devxpe_hero_metabox, devxpe_page_widgets_add_meta_box,
 * devxpe_page_widgets_meta_box_render/save, devxpe_admin_media,
 * devxpe_page_widgets_admin_assets fonksiyon adları; _dxp_hero_image,
 * _dxp_page_type, _dxp_template, _dxp_pw_migrated meta anahtarları;
 * dxp_page_widgets / devxpe_hero metabox id'leri; add_meta_boxes ve save_post
 * hook'ları sözleşmedir; değiştirilmez.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Anasayfa bölümlerini içeren şablonu çağırır.
 *
 * Tüm sayfa şablonlarında çalışması için header.php'deki
 * 'devxpe_content_top' kancasına bağlanır.
 *
 * @return void
 */
function devxpe_render_home_sections() {
	get_template_part( 'template-parts/home-sections' );
}
add_action( 'devxpe_content_top', 'devxpe_render_home_sections' );

/* ── Sayfa/yazı düzenleme: manşet arkaplanı alanı ─────────── */
function devxpe_hero_metabox() {
	add_meta_box(
		'devxpe_hero',
		__( 'DEVXPE Manşet Arkaplanı', 'devxpe-theme' ),
		'devxpe_hero_metabox_render',
		array( 'page', 'post' ),
		'side',
		'default'
	);
}
add_action( 'add_meta_boxes', 'devxpe_hero_metabox' );

/**
 * Meta box içeriği (görsel alanı + medya seçici).
 *
 * @param WP_Post $post Geçerli yazı.
 * @return void
 */
function devxpe_hero_metabox_render( $post ) {
	wp_nonce_field( 'devxpe_hero_save', 'devxpe_hero_nonce' );
	$url = get_post_meta( $post->ID, '_dxp_hero_image', true );
	?>
	<div class="dxp-hero-mb">
		<label class="screen-reader-text" for="dxp_hero_image"><?php esc_html_e( 'Manşet arkaplan görseli URL', 'devxpe-theme' ); ?></label>
		<input type="text" id="dxp_hero_image" name="dxp_hero_image" value="<?php echo esc_attr( $url ); ?>" class="widefat" autocomplete="off" placeholder="https://" />
		<p>
			<button type="button" class="button" id="dxp_hero_pick"><?php esc_html_e( 'Resim Seç', 'devxpe-theme' ); ?></button>
			<button type="button" class="button" id="dxp_hero_clear"><?php esc_html_e( 'Kaldır', 'devxpe-theme' ); ?></button>
		</p>
		<div id="dxp_hero_preview"><?php if ( $url ) : ?><img src="<?php echo esc_url( $url ); ?>" alt="" style="max-width:100%;" /><?php endif; ?></div>
	</div>
	<script>
	jQuery(function($){
		var frame;
		$('#dxp_hero_pick').on('click', function(e){
			e.preventDefault();
			if (frame) { frame.open(); return; }
			frame = wp.media({ title: '<?php echo esc_js( __( 'Manşet Arkaplanı', 'devxpe-theme' ) ); ?>', button: { text: '<?php echo esc_js( __( 'Kullan', 'devxpe-theme' ) ); ?>' }, multiple: false });
			frame.on('select', function(){
				var att = frame.state().get('selection').first().toJSON();
				$('#dxp_hero_image').val(att.url);
				$('#dxp_hero_preview').html('<img src="'+att.url+'" alt="" style="max-width:100%;" />');
			});
			frame.open();
		});
		$('#dxp_hero_clear').on('click', function(e){
			e.preventDefault();
			$('#dxp_hero_image').val('');
			$('#dxp_hero_preview').html('');
		});
	});
	</script>
	<?php
}

/**
 * Manşet arkaplan meta değerini kaydeder.
 *
 * @param int $post_id Yazı id'si.
 * @return void
 */
function devxpe_hero_metabox_save( $post_id ) {
	if ( ! isset( $_POST['devxpe_hero_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['devxpe_hero_nonce'] ) ), 'devxpe_hero_save' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	$value = isset( $_POST['dxp_hero_image'] ) ? esc_url_raw( wp_unslash( $_POST['dxp_hero_image'] ) ) : '';
	update_post_meta( $post_id, '_dxp_hero_image', $value );
}
add_action( 'save_post', 'devxpe_hero_metabox_save' );

/**
 * Yazı/sayfa düzenleme ekranında WP medya kütüphanesini yükler.
 *
 * @return void
 */
function devxpe_admin_media() {
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( $screen && in_array( $screen->base, array( 'post' ), true ) ) {
		wp_enqueue_media();
	}
}
add_action( 'admin_enqueue_scripts', 'devxpe_admin_media' );

/*
 * NOT: "Sayfa Manşeti" metabox'ı KALDIRILDI.
 *
 * Manşet artık sayfa düzenleyicideki "Sayfa Şablonu ve İçeriği" kutusundaki
 * WIDGET sisteminden eklenir (widget tipi: 'manset' → DEVXPE_Page_Widgets).
 * Eski _dxp_hero_title / _dxp_hero_subtitle değerleri veritabanında kalır ve
 * şablonlar (page-about.php / page-contact.php) onları okumaya devam eder;
 * yeni sayfalarda başlık yoksa sayfa adına düşer.
 */

/* ══════════════════════════════════════════════════════════
   İçerik Düzeni metabox'ı — sayfa tipi + sürükle-bırak widget editörü
   ══════════════════════════════════════════════════════════ */

/**
 * Sayfa ve içerik tipi düzenleyicisine "İçerik Düzeni" metabox'ını ekler.
 *
 * @return void
 */
function devxpe_page_widgets_add_meta_box() {
	$ekranlar = array_merge( array( 'page' ), wp_list_pluck( devxpe_custom_post_types(), 'slug' ) );

	foreach ( $ekranlar as $ekran ) {
		add_meta_box(
			'dxp_page_widgets',
			__( 'İçerik Düzeni', 'devxpe-theme' ),
			'devxpe_page_widgets_meta_box_render',
			$ekran,
			'normal',
			'high'
		);
	}
}
add_action( 'add_meta_boxes', 'devxpe_page_widgets_add_meta_box' );

/**
 * Metabox içeriği: sayfa tipi seçici + widget editörü (3 kolon).
 *
 * @param WP_Post $post Düzenlenen sayfa.
 * @return void
 */
function devxpe_page_widgets_meta_box_render( $post ) {
	wp_nonce_field( 'dxp_page_widgets_save', 'dxp_page_widgets_nonce' );

	$is_page = ( 'page' === $post->post_type );

	if ( $is_page ) {
		/* Sayfa: "Bu sayfa nedir?" seçimi belirler (about/contact). */
		$type = (string) get_post_meta( $post->ID, '_dxp_page_type', true );
		if ( ! array_key_exists( $type, DEVXPE_Page_Widgets::kapsam() ) ) {
			$type = '';
		}
	} else {
		/* İçerik tipi: bağlam doğrudan post_type'tır. */
		$type = (string) $post->post_type;
	}

	$raw      = (string) get_post_meta( $post->ID, DEVXPE_Page_Widgets::META_KEY, true );
	$hic_ayar = ( '' === $raw ); /* meta hiç yazılmamış mı? (varsayılan önerilsin) */

	if ( '' === $raw || ! is_array( json_decode( $raw, true ) ) ) {
		$raw = '[]';
	}

	/*
	 * Liste daha önce hiç kaydedilmemişse, mevcut düzen WIDGET olarak önerilir.
	 * Sayfada şablon düzeni, içerik tipinde eski meta alanları aktarılır.
	 * Kullanıcı kaydedince kalıcı olur; kasten boş liste kaydedilirse bir
	 * daha önerilmez.
	 */
	if ( $hic_ayar && '' !== $type ) {
		$oneri = DEVXPE_Page_Widgets::varsayilan_liste( $type );

		/* İçerik tipi: eski meta alanları widget ayarlarına çevrilir. */
		if ( ! $oneri ) {
			$oneri = DEVXPE_Page_Widgets::meta_aktar( $post->ID );
		}

		if ( $oneri ) {
			$raw = (string) wp_json_encode( $oneri );
		}
	}
	$liste     = json_decode( $raw, true );

	if ( ! is_array( $liste ) ) {
		$liste = array();
	}

	/*
	 * Yerleşik blok (Hakkımızda istatistikleri / İletişim kartları) henüz
	 * widget olarak eklenmemişse bir kez otomatik eklenir; kaydedince kalıcı
	 * olur, kullanıcı sonradan silerse tekrar eklenmez.
	 */
	if ( $liste && '' !== $type && ! get_post_meta( $post->ID, '_dxp_pw_migrated', true ) ) {
		$liste = array_merge( $liste, DEVXPE_Page_Widgets::eksik_yerlesik( $post->ID, $type ) );

		/* Gizli input bu JSON'dan beslenir; JS listeyi ondan kurar. */
		$raw = (string) wp_json_encode( $liste );
	}
	$kutup     = DEVXPE_Page_Widgets::kutuphane();
	$kapsam    = DEVXPE_Page_Widgets::kapsam();
	$baglamlar = DEVXPE_Page_Widgets::kapsamlar();
	$aktif     = isset( $baglamlar[ $type ] );
	?>
	<div class="dxp-pw <?php echo $aktif ? '' : 'is-collapsed'; ?>" id="dxp-pw" data-baglam="<?php echo esc_attr( $type ); ?>">

		<?php
		/*
		 * Lucide ikon verisi editör JS'i için metabox HTML'i içinde bir kez
		 * gömülür. Panel ekranındaki print_lucide_data() ile aynı çıktıdır.
		 */
		static $dxp_lucide_printed = false;
		if ( ! $dxp_lucide_printed && function_exists( 'devxpe_lucide_icons' ) ) {
			echo '<script type="application/json" id="dxp-lucide-data">' . wp_json_encode( devxpe_lucide_icons() ) . '</script>';
			$dxp_lucide_printed = true;
		}
		?>

		<?php if ( $is_page ) : ?>
		<div class="dxp-pw-top">
			<label for="dxp_page_type"><strong><?php esc_html_e( 'Bu sayfa nedir?', 'devxpe-theme' ); ?></strong></label>
			<select id="dxp_page_type" name="dxp_page_type">
				<option value="" <?php selected( $type, '' ); ?>><?php esc_html_e( 'Yok (normal sayfa)', 'devxpe-theme' ); ?></option>
				<?php foreach ( $kapsam as $dxp_val => $dxp_lbl ) : ?>
					<option value="<?php echo esc_attr( $dxp_val ); ?>" <?php selected( $type, $dxp_val ); ?>><?php echo esc_html( $dxp_lbl ); ?></option>
				<?php endforeach; ?>
			</select>
			<p class="description"><?php esc_html_e( 'Bir tip seçilince alttaki widget editörü açılır.', 'devxpe-theme' ); ?></p>
		</div>
		<?php else : ?>
		<div class="dxp-pw-top">
			<?php $dxp_tpl = devxpe_normalize_template( get_post_meta( $post->ID, '_dxp_template', true ) ); ?>
			<label for="dxp_template"><strong><?php esc_html_e( 'Şablon', 'devxpe-theme' ); ?></strong></label>
			<select id="dxp_template" name="dxp_template">
				<?php foreach ( devxpe_template_labels() as $dxp_tpl_id => $dxp_tpl_lbl ) : ?>
					<option value="<?php echo esc_attr( $dxp_tpl_id ); ?>" <?php selected( $dxp_tpl, $dxp_tpl_id ); ?>><?php echo esc_html( $dxp_tpl_lbl ); ?></option>
				<?php endforeach; ?>
			</select>
			<p class="description"><?php esc_html_e( 'Bu içeriğin sayfa düzeni (Şablon 1 / Şablon 2).', 'devxpe-theme' ); ?></p>
		</div>
		<?php endif; ?>

		<div class="dxp-pw-editor" id="dxp-pw-editor"<?php echo $aktif ? '' : ' style="display:none"'; ?>>

			<div class="dxp-pw-col dxp-pw-col--lib">
				<h4><?php esc_html_e( 'Widget Ekle', 'devxpe-theme' ); ?></h4>
				<ul class="dxp-pw-lib" id="dxp-pw-lib">
					<?php foreach ( $kutup as $dxp_tip => $dxp_w ) : ?>
						<li class="dxp-pw-lib-item"
							draggable="true"
							data-tip="<?php echo esc_attr( $dxp_tip ); ?>">
							<span class="dashicons <?php echo esc_attr( $dxp_w['ikon'] ); ?>" aria-hidden="true"></span>
							<span><?php echo esc_html( $dxp_w['ad'] ); ?></span>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>

			<div class="dxp-pw-col dxp-pw-col--list">
				<?php /* Düzen: tam genişlik | 2 sütun (nested) — önizleme alanının hemen üstünde. */ ?>
				<div class="dxp-pw-duzen">
					<span class="dxp-pw-duzen-label"><?php esc_html_e( 'Düzen', 'devxpe-theme' ); ?></span>
					<label class="dxp-pw-duzen-btn">
						<input type="radio" name="dxp_pw_duzen" value="full" <?php checked( DEVXPE_Page_Widgets::duzen( $post->ID ), 'full' ); ?> />
						<span><?php esc_html_e( 'Tam genişlik', 'devxpe-theme' ); ?></span>
					</label>
					<label class="dxp-pw-duzen-btn">
						<input type="radio" name="dxp_pw_duzen" value="nested" <?php checked( DEVXPE_Page_Widgets::duzen( $post->ID ), 'nested' ); ?> />
						<span><?php esc_html_e( 'Nested (2 sütun)', 'devxpe-theme' ); ?></span>
					</label>
				</div>
				<h4><?php esc_html_e( 'Sayfa önizleme', 'devxpe-theme' ); ?></h4>
				<ul class="dxp-pw-list" id="dxp-pw-list">
					<?php foreach ( $liste as $dxp_i => $dxp_widget ) : ?>
						<?php if ( ! is_array( $dxp_widget ) || empty( $dxp_widget['tip'] ) || ! isset( $kutup[ $dxp_widget['tip'] ] ) ) : ?>
							<?php continue; ?>
						<?php endif; ?>
						<li class="dxp-pw-item" draggable="true" data-index="<?php echo esc_attr( $dxp_i ); ?>">
							<span class="dxp-pw-handle" aria-hidden="true">⠿</span>
							<span class="dxp-pw-name"><?php echo esc_html( $kutup[ $dxp_widget['tip'] ]['ad'] ); ?></span>
						</li>
					<?php endforeach; ?>
				</ul>
				<p class="dxp-pw-empty" id="dxp-pw-empty"><?php esc_html_e( 'Soldan sürükleyin veya tıklayın.', 'devxpe-theme' ); ?></p>
			</div>

			<div class="dxp-pw-col dxp-pw-col--settings">
				<h4><?php esc_html_e( 'Ayarlar', 'devxpe-theme' ); ?></h4>
				<div class="dxp-pw-settings" id="dxp-pw-settings">
					<p class="dxp-pw-settings-empty"><?php esc_html_e( 'Ayarları görmek için bir widget seçin.', 'devxpe-theme' ); ?></p>
				</div>
			</div>

		</div>

		<input type="hidden" name="dxp_page_widgets" id="dxp-page-widgets-json" value="<?php echo esc_attr( $raw ); ?>" />
	</div>
	<?php
}

/**
 * Widget listesini güvenli JSON olarak kaydeder.
 *
 * @param int $post_id Sayfa kimliği.
 * @return void
 */
function devxpe_page_widgets_meta_box_save( $post_id ) {
	if ( ! isset( $_POST['dxp_page_widgets_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['dxp_page_widgets_nonce'] ) ), 'dxp_page_widgets_save' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	/* Yalnızca sayfa ve panelde tanımlı içerik tiplerinde kaydet. */
	$dxp_pt = get_post_type( $post_id );
	if ( 'page' !== $dxp_pt && ! in_array( $dxp_pt, wp_list_pluck( devxpe_custom_post_types(), 'slug' ), true ) ) {
		return;
	}

	/*
	 * Sayfa tipi (about | contact) — beyaz liste.
	 * Sayfa tipi seçicisi bu metabox'tadır; kaydı da burada yapılır.
	 */
	if ( 'page' === $dxp_pt ) {
		$dxp_page_type = isset( $_POST['dxp_page_type'] ) ? sanitize_key( wp_unslash( $_POST['dxp_page_type'] ) ) : '';

		if ( ! in_array( $dxp_page_type, array( 'about', 'contact' ), true ) ) {
			$dxp_page_type = '';
		}

		update_post_meta( $post_id, '_dxp_page_type', $dxp_page_type );
	}

	/*
	 * Şablon (yalnızca içerik tipleri): seçici widget metabox'ının üstünde.
	 * Beyaz liste + eski anahtar normalizasyonu uygulanır.
	 */
	if ( 'page' !== $dxp_pt && isset( $_POST['dxp_template'] ) ) {
		$dxp_tpl = sanitize_key( wp_unslash( $_POST['dxp_template'] ) );
		update_post_meta( $post_id, '_dxp_template', devxpe_normalize_template( $dxp_tpl ) );
	}

	/* Widget düzeni: tam genişlik | nested (2 sütun) — beyaz liste. */
	$dxp_duzen = isset( $_POST['dxp_pw_duzen'] ) ? sanitize_key( wp_unslash( $_POST['dxp_pw_duzen'] ) ) : '';

	if ( ! in_array( $dxp_duzen, array( 'full', 'nested' ), true ) ) {
		$dxp_duzen = 'full';
	}

	update_post_meta( $post_id, DEVXPE_Page_Widgets::DUZEN_KEY, $dxp_duzen );

	$raw = isset( $_POST['dxp_page_widgets'] ) ? wp_unslash( $_POST['dxp_page_widgets'] ) : '';
	/*
	 * temizle_json JSON'u yeniden üretir. update_post_meta değere ters-slash
	 * uyguladığı için çıktıyı wp_slash ile kaçışlamak gerekir; aksi halde
	 * \n gibi JSON kaçışları bozulur (satırlı alanlar tek satıra düşer).
	 */
	update_post_meta( $post_id, DEVXPE_Page_Widgets::META_KEY, wp_slash( DEVXPE_Page_Widgets::temizle_json( $raw ) ) );

	/* Yerleşik blok göçü bir kez yapılır; sonraki silmeler kalıcı olur. */
	update_post_meta( $post_id, '_dxp_pw_migrated', '1' );
}
/*
 * Tek işleyici: sayfa ve içerik tipi (CPT) düzenleyicileri. "save_post"
 * kullanılır ki her istekte CPT listesi sorgulanmasın (tip kontrolü
 * kaydetme anında yapılır).
 */
add_action( 'save_post', 'devxpe_page_widgets_meta_box_save' );

/**
 * Sayfa düzenleme ekranında widget editörü varlıklarını yükler.
 *
 * @param string $hook Geçerli admin sayfası.
 * @return void
 */
function devxpe_page_widgets_admin_assets( $hook ) {
	if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
		return;
	}

	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( ! $screen ) {
		return;
	}

	$ekranlar = array_merge( array( 'page' ), wp_list_pluck( devxpe_custom_post_types(), 'slug' ) );
	if ( ! in_array( $screen->post_type, $ekranlar, true ) ) {
		return;
	}

	$ver = max(
		(int) filemtime( DEVXPE_THEME_PATH . 'includes/admin/page-widgets.js' ),
		(int) filemtime( DEVXPE_THEME_PATH . 'includes/admin/page-widgets.css' )
	);

	wp_enqueue_media();
	wp_enqueue_style( 'devxpe-page-widgets', DEVXPE_THEME_URL . 'includes/admin/page-widgets.css', array( 'dashicons' ), $ver );
	wp_enqueue_script( 'devxpe-page-widgets', DEVXPE_THEME_URL . 'includes/admin/page-widgets.js', array(), $ver, true );
	wp_localize_script(
		'devxpe-page-widgets',
		'DXPPW',
		array(
			'kutuphane' => DEVXPE_Page_Widgets::kutuphane(),
			'kapsam'    => DEVXPE_Page_Widgets::kapsam(),
			'kapsamlar' => DEVXPE_Page_Widgets::kapsamlar(),
			'varsayilan_adres' => (string) devxpe_theme_get( 'address' ),
		)
	);
}
add_action( 'admin_enqueue_scripts', 'devxpe_page_widgets_admin_assets' );
