<?php
/**
 * DEVXPE Panel — modüler işlem yönlendiricisi (action registry).
 *
 * AKIŞ:
 *   POST → (load-{page} veya admin_post_{action}) → dispatch()
 *        → yetki → nonce → callback → 302 → admin_notices mesajı.
 *
 * YENİ İŞLEM EKLEMEK: register() çağrısı ekle. Kanca otomatik bağlanır.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DEVXPE_Theme_Panel_Actions {

	/**
	 * Varsayılan yetki (panel menüsüyle aynı).
	 */
	const CAP = 'manage_options';

	/**
	 * Sonuç mesajı query arg'ı (PRG sonrası admin_notices okur).
	 */
	const MSG_ARG = 'dxp_msg';

	/**
	 * Kayıtlı işlemler: action => config.
	 *
	 * config: cap, nonce, field, detect, callback.
	 *
	 * @var array
	 */
	private static $actions = array();

	/**
	 * Kancaları bağlar ve kayıtlı işlemleri yönlendiriciye ekler.
	 *
	 * @return void
	 */
	public static function init() {
		self::register_defaults();

		add_action( 'admin_notices', array( __CLASS__, 'render_notice' ) );

		/*
		 * PRG: sayfa gövdesi basılmadan ÖNCE (load-{page}) POST'u işle ve
		 * yönlendir. Böylece "headers already sent" olmaz.
		 */
		add_action(
			'load-toplevel_page_' . DEVXPE_Theme_Panel::MENU_SLUG,
			array( __CLASS__, 'handle_request' )
		);

		/*
		 * Geriye uyum: aynı işlemler admin-post.php üzerinden de çağrılabilir.
		 * Mevcut action adları korunur.
		 */
		foreach ( array_keys( self::$actions ) as $action ) {
			add_action(
				'admin_post_' . $action,
				static function () use ( $action ) {
					self::dispatch( $action, array_merge( $_GET, $_POST ) );
				}
			);
		}
	}

	/**
	 * Bir işlem kaydeder.
	 *
	 * @param string $action İşlem adı (admin_post_{action} kancası).
	 * @param array  $config Özel ayarlar.
	 * @return void
	 */
	public static function register( $action, array $config ) {
		self::$actions[ $action ] = $config + array(
			'cap'   => self::CAP,
			'nonce' => $action,
			'field' => '_wpnonce',
		);
	}

	/**
	 * Panel sayfasına gelen POST'u ilgili işleme yönlendirir.
	 *
	 * @return void
	 */
	public static function handle_request() {
		if ( empty( $_POST ) ) {
			return;
		}

		$action = self::detect();
		if ( '' !== $action ) {
			self::dispatch( $action, $_POST );
		}
	}

	/**
	 * POST işaretçilerine göre hangi işlemin yapıldığını bulur.
	 *
	 * @return string İşlem adı ya da ''.
	 */
	private static function detect() {
		/*
		 * Kaydetme alanı (`devxpe_theme_save`) panel formunun TAMAMINDA bulunur;
		 * bir alt işlem düğmesi (ör. eklenti kurulumu) aynı formda gönderildiğinde
		 * POST'ta İKİ alan birden bulunur. Kaydet her zaman kazandığı için
		 * eklenti kurulumu hiç çalışmıyordu.
		 *
		 * Bu yüzden ÖZEL işlemler önce denenir; kaydetme en sona bırakılır.
		 */
		$oncelik = array( 'devxpe_plugin_install', 'devxpe_design_install', 'devxpe_design_activate' );

		foreach ( $oncelik as $alan ) {
			if ( ! empty( $_POST[ $alan ] ) ) {
				foreach ( self::$actions as $action => $config ) {
					if ( isset( $config['detect'] ) && $alan === $config['detect'] ) {
						return $action;
					}
				}
			}
		}

		foreach ( self::$actions as $action => $config ) {
			if ( ! empty( $config['detect'] ) && ! empty( $_POST[ $config['detect'] ] ) ) {
				return $action;
			}
		}

		return '';
	}

	/**
	 * İşlemi doğrular ve çalıştırır; ardından PRG ile panele döner.
	 *
	 * @param string $action İşlem adı.
	 * @param array  $data   İstek verisi.
	 * @return void
	 */
	public static function dispatch( $action, array $data ) {
		if ( ! isset( self::$actions[ $action ] ) ) {
			wp_die( esc_html__( 'Bilinmeyen işlem.', 'devxpe-theme' ), '', array( 'response' => 400 ) );
		}

		$config = self::$actions[ $action ];

		if ( ! current_user_can( $config['cap'] ) ) {
			wp_die( esc_html__( 'Bu işlem için yetkiniz yok.', 'devxpe-theme' ), '', array( 'response' => 403 ) );
		}

		/* Nonce yanlış/eksikse wp_die ile reddeder. */
		check_admin_referer( $config['nonce'], $config['field'] );

		$kod = (string) call_user_func( $config['callback'], $data );

		$hedef = add_query_arg(
			self::MSG_ARG,
			$kod,
			admin_url( 'admin.php?page=' . DEVXPE_Theme_Panel::MENU_SLUG )
		);

		wp_safe_redirect( $hedef );
		exit;
	}

	/**
	 * PRG sonrası tek seferlik sonuç mesajını basar.
	 *
	 * @return void
	 */
	public static function render_notice() {
		if ( empty( $_GET[ self::MSG_ARG ] ) ) {
			return;
		}

		$kod = sanitize_key( wp_unslash( (string) $_GET[ self::MSG_ARG ] ) );
		$map = self::messages();

		if ( ! isset( $map[ $kod ] ) ) {
			return;
		}

		printf(
			'<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>',
			esc_attr( $map[ $kod ]['tip'] ),
			esc_html( $map[ $kod ]['metin'] )
		);
	}

	/**
	 * Sonuç kodları → mesaj/tip eşlemesi.
	 *
	 * @return array
	 */
	private static function messages() {
		return array(
			'saved'        => array( 'tip' => 'success', 'metin' => __( 'Ayarlar kaydedildi.', 'devxpe-theme' ) ),
			'imported'     => array( 'tip' => 'success', 'metin' => __( 'Ayarlar içe aktarıldı.', 'devxpe-theme' ) ),
			'import_error' => array( 'tip' => 'error',   'metin' => __( 'İçe aktarma başarısız: geçersiz JSON.', 'devxpe-theme' ) ),
			'plugin_ok'    => array( 'tip' => 'success', 'metin' => __( 'Eklenti etkinleştirildi.', 'devxpe-theme' ) ),
			'plugin_error' => array( 'tip' => 'error',   'metin' => __( 'Eklenti kurulamadı. Eklenti deposuna ulaşılamadıysa internet bağlantınızı kontrol edip tekrar deneyin.', 'devxpe-theme' ) ),
			'plugin_nocap' => array( 'tip' => 'error',   'metin' => __( 'Eklenti kurma/etkinleştirme yetkiniz yok.', 'devxpe-theme' ) ),
			'design_ok'          => array( 'tip' => 'success', 'metin' => __( 'Görünüm etkinleştirildi.', 'devxpe-theme' ) ),
			'design_reset'       => array( 'tip' => 'success', 'metin' => __( 'Varsayılan görünüme dönüldü.', 'devxpe-theme' ) ),
			'design_error'       => array( 'tip' => 'error',   'metin' => __( 'Görünüm kurulamadı. Katalog adresine ulaşılamadıysa internet bağlantınızı kontrol edip tekrar deneyin.', 'devxpe-theme' ) ),
			'design_incompatible' => array( 'tip' => 'error',  'metin' => __( 'Bu görünüm, temanızın daha yeni bir sürümünü gerektiriyor.', 'devxpe-theme' ) ),
			'design_missing'     => array( 'tip' => 'error',   'metin' => __( 'Görünüm kurulu değil.', 'devxpe-theme' ) ),
			'design_notchild'    => array( 'tip' => 'error',   'metin' => __( 'Bu görünüm bu temayla uyumlu değil.', 'devxpe-theme' ) ),
			'design_nocap'       => array( 'tip' => 'error',   'metin' => __( 'Görünüm kurma/etkinleştirme yetkiniz yok.', 'devxpe-theme' ) ),
		);
	}

	/**
	 * Panelin kendi işlemlerini kaydeder.
	 *
	 * detect: POST'ta hangi alan varsa bu işlem seçilir. İçe aktarma önce
	 * gelir ki formda eski bir devxpe_theme_save alanı kalmışsa bile doğru
	 * işlem çalışsın.
	 *
	 * @return void
	 */
	private static function register_defaults() {
		self::register(
			'devxpe_theme_import',
			array(
				'cap'      => 'manage_options',
				'nonce'    => 'devxpe_theme_save',
				'field'    => 'devxpe_theme_nonce',
				'detect'   => 'devxpe_theme_import',
				'callback' => array( 'DEVXPE_Theme_Panel', 'panel_import' ),
			)
		);

		self::register(
			'devxpe_save_panel',
			array(
				'cap'      => 'manage_options',
				'nonce'    => 'devxpe_theme_save',
				'field'    => 'devxpe_theme_nonce',
				'detect'   => 'devxpe_theme_save',
				'callback' => array( 'DEVXPE_Theme_Panel', 'panel_save' ),
			)
		);

		/*
		 * Önerilen eklenti kurulumu. Panel formundaki düğme `devxpe_plugin_install`
		 * gönderir; nonce/alan ana formunkiyle aynıdır. Yetki callback içinde de
		 * ayrıca kontrol edilir.
		 */
		self::register(
			'devxpe_plugin_install',
			array(
				'cap'      => 'install_plugins',
				'nonce'    => 'devxpe_theme_save',
				'field'    => 'devxpe_theme_nonce',
				'detect'   => 'devxpe_plugin_install',
				'callback' => array( 'DEVXPE_Theme_Panel', 'panel_install_plugin' ),
			)
		);

		/* Tasarım (child theme) kurulumu. */
		self::register(
			'devxpe_design_install',
			array(
				'cap'      => 'install_themes',
				'nonce'    => 'devxpe_theme_save',
				'field'    => 'devxpe_theme_nonce',
				'detect'   => 'devxpe_design_install',
				'callback' => array( 'DEVXPE_Theme_Panel', 'panel_design_install' ),
			)
		);

		/* Tasarım etkinleştirme (veya varsayılana dönüş). */
		self::register(
			'devxpe_design_activate',
			array(
				'cap'      => 'switch_themes',
				'nonce'    => 'devxpe_theme_save',
				'field'    => 'devxpe_theme_nonce',
				'detect'   => 'devxpe_design_activate',
				'callback' => array( 'DEVXPE_Theme_Panel', 'panel_design_activate' ),
			)
		);
	}
}
