<?php
/**
 * DEVXPE Panel — modüler işlem yönlendiricisi (action registry).
 *
 * AKIŞ:
 *   POST → (load-{page} veya admin_post_{action}) → dispatch()
 *        → yetki → nonce → callback → 302 → admin_notices mesajı.
 *
 * YENİ İŞLEM EKLEMEK: register() çağrısı ekle. Kanca otomatik bağlanır.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DEVXPE_Theme_Panel_Actions {

	/**
	 * Varsayılan yetki (panel menüsüyle aynı).
	 */
	const CAP = 'manage_options';

	/**
	 * Sonuç mesajı query arg'ı (PRG sonrası admin_notices okur).
	 */
	const MSG_ARG = 'dxp_msg';

	/**
	 * Kayıtlı işlemler: action => config.
	 *
	 * config: cap, nonce, field, detect, callback.
	 *
	 * @var array
	 */
	private static $actions = array();

	/**
	 * Kancaları bağlar ve kayıtlı işlemleri yönlendiriciye ekler.
	 *
	 * @return void
	 */
	public static function init() {
		self::register_defaults();

		/*
		 * PRG: sayfa gövdesi basılmadan ÖNCE (load-{page}) POST'u işle ve
		 * yönlendir. Böylece "headers already sent" olmaz.
		 */
		add_action(
			'load-toplevel_page_' . DEVXPE_Theme_Panel::MENU_SLUG,
			array( __CLASS__, 'handle_request' )
		);

		/*
		 * Geriye uyum: aynı işlemler admin-post.php üzerinden de çağrılabilir.
		 * Mevcut action adları korunur.
		 */
		foreach ( array_keys( self::$actions ) as $action ) {
			add_action(
				'admin_post_' . $action,
				static function () use ( $action ) {
					self::dispatch( $action, array_merge( $_GET, $_POST ) );
				}
			);
		}
	}

	/**
	 * Bir işlem kaydeder.
	 *
	 * @param string $action İşlem adı (admin_post_{action} kancası).
	 * @param array  $config Özel ayarlar.
	 * @return void
	 */
	public static function register( $action, array $config ) {
		self::$actions[ $action ] = $config + array(
			'cap'   => self::CAP,
			'nonce' => $action,
			'field' => '_wpnonce',
		);
	}

	/**
	 * Panel sayfasına gelen POST'u ilgili işleme yönlendirir.
	 *
	 * @return void
	 */
	public static function handle_request() {
		if ( empty( $_POST ) ) {
			return;
		}

		$action = self::detect();
		if ( '' !== $action ) {
			self::dispatch( $action, $_POST );
		}
	}

	/**
	 * POST işaretçilerine göre hangi işlemin yapıldığını bulur.
	 *
	 * @return string İşlem adı ya da ''.
	 */
	private static function detect() {
		/*
		 * Kaydetme alanı (`devxpe_theme_save`) panel formunun TAMAMINDA bulunur;
		 * bir alt işlem düğmesi (ör. eklenti kurulumu) aynı formda gönderildiğinde
		 * POST'ta İKİ alan birden bulunur. Kaydet her zaman kazandığı için
		 * eklenti kurulumu hiç çalışmıyordu.
		 *
		 * Bu yüzden ÖZEL işlemler önce denenir; kaydetme en sona bırakılır.
		 */
		$oncelik = array( 'devxpe_plugin_install' );

		foreach ( $oncelik as $alan ) {
			if ( ! empty( $_POST[ $alan ] ) ) {
				foreach ( self::$actions as $action => $config ) {
					if ( isset( $config['detect'] ) && $alan === $config['detect'] ) {
						return $action;
					}
				}
			}
		}

		foreach ( self::$actions as $action => $config ) {
			if ( ! empty( $config['detect'] ) && ! empty( $_POST[ $config['detect'] ] ) ) {
				return $action;
			}
		}

		return '';
	}

	/**
	 * İşlemi doğrular ve çalıştırır; ardından PRG ile panele döner.
	 *
	 * @param string $action İşlem adı.
	 * @param array  $data   İstek verisi.
	 * @return void
	 */
	public static function dispatch( $action, array $data ) {
		if ( ! isset( self::$actions[ $action ] ) ) {
			wp_die( esc_html__( 'Bilinmeyen işlem.', 'devxpe-theme' ), '', array( 'response' => 400 ) );
		}

		$config = self::$actions[ $action ];

		if ( ! current_user_can( $config['cap'] ) ) {
			wp_die( esc_html__( 'Bu işlem için yetkiniz yok.', 'devxpe-theme' ), '', array( 'response' => 403 ) );
		}

		/* Nonce yanlış/eksikse wp_die ile reddeder. */
		check_admin_referer( $config['nonce'], $config['field'] );

		$kod = (string) call_user_func( $config['callback'], $data );

		/* Mesaj tek seferlik: adres parametresi yerine kısa ömürlü transient.
		   Böylece sayfa yenilendiğinde "Ayarlar kaydedildi." tekrar çıkmaz. */
		if ( '' !== $kod ) {
			set_transient( self::flash_key(), $kod, 60 );
		}

		$hedef = admin_url( 'admin.php?page=' . DEVXPE_Theme_Panel::MENU_SLUG );

		/* İşlem, panelde belirli bir bölümde kalacaksa hash ekle. */
		if ( ! empty( $config['redirect'] ) ) {
			$hedef .= '#' . ltrim( (string) $config['redirect'], '#' );
		}

		wp_safe_redirect( $hedef );
		exit;
	}

	/**
	 * PRG sonrası tek seferlik sonuç mesajını döndürür (yoksa null).
	 *
	 * Mesajı basmak panelin işidir: toast, panelin içinde çizilir ki panel
	 * CSS değişkenleri ve karanlık mod orada geçerli olsun.
	 *
	 * @return array|null array( 'tip' => 'success|error|warning|info', 'metin' => string )
	 */
	public static function current_notice() {
		/* Tek seferlik mesaj (PRG sonrası): oku ve sil. */
		$kod = (string) get_transient( self::flash_key() );
		if ( '' !== $kod ) {
			delete_transient( self::flash_key() );
		} elseif ( ! empty( $_GET[ self::MSG_ARG ] ) ) {
			/* Eski bağlantı biçimi (geriye dönük). */
			$kod = sanitize_key( wp_unslash( (string) $_GET[ self::MSG_ARG ] ) );
		}

		if ( '' === $kod ) {
			return null;
		}

		$map = self::messages();

		if ( ! isset( $map[ $kod ] ) ) {
			return null;
		}

		return array(
			'tip'   => (string) $map[ $kod ]['tip'],
			'metin' => (string) $map[ $kod ]['metin'],
		);
	}

	/**
	 * Tek seferlik mesaj anahtarı (kullanıcı bazlı).
	 *
	 * @return string
	 */
	private static function flash_key() {
		return 'devxpe_notice_' . (int) get_current_user_id();
	}

	/**
	 * Sonuç kodları → mesaj/tip eşlemesi.
	 *
	 * @return array
	 */
	private static function messages() {
		return array(
			'saved'        => array( 'tip' => 'success', 'metin' => __( 'Ayarlar kaydedildi.', 'devxpe-theme' ) ),
			'imported'     => array( 'tip' => 'success', 'metin' => __( 'Ayarlar içe aktarıldı.', 'devxpe-theme' ) ),
			'import_error' => array( 'tip' => 'error',   'metin' => __( 'İçe aktarma başarısız: geçersiz JSON.', 'devxpe-theme' ) ),
			'backup_ok'       => array( 'tip' => 'success', 'metin' => __( 'Yedek alındı. En fazla 2 yedek saklanır.', 'devxpe-theme' ) ),
			'widget_ok'       => array( 'tip' => 'success', 'metin' => __( 'Widget kitaplığı yenilendi: sayfa ve içerik listeleri güncel şemaya göre tekrar oluşturuldu.', 'devxpe-theme' ) ),
			'backup_restored' => array( 'tip' => 'success', 'metin' => __( 'Yedek geri yüklendi.', 'devxpe-theme' ) ),
			'backup_deleted'  => array( 'tip' => 'success', 'metin' => __( 'Yedek silindi.', 'devxpe-theme' ) ),
			'backup_error'    => array( 'tip' => 'error',   'metin' => __( 'Yedek işlemi başarısız oldu.', 'devxpe-theme' ) ),
			'plugin_ok'    => array( 'tip' => 'success', 'metin' => __( 'Eklenti etkinleştirildi.', 'devxpe-theme' ) ),
			'plugin_error' => array( 'tip' => 'error',   'metin' => __( 'Eklenti kurulamadı. Eklenti deposuna ulaşılamadıysa internet bağlantınızı kontrol edip tekrar deneyin.', 'devxpe-theme' ) ),
			'plugin_nocap' => array( 'tip' => 'error',   'metin' => __( 'Eklenti kurma/etkinleştirme yetkiniz yok.', 'devxpe-theme' ) ),
			'design_ok'          => array( 'tip' => 'success', 'metin' => __( 'Görünüm etkinleştirildi.', 'devxpe-theme' ) ),
			'design_reset'       => array( 'tip' => 'success', 'metin' => __( 'Varsayılan görünüme dönüldü.', 'devxpe-theme' ) ),
			'design_error'       => array( 'tip' => 'error',   'metin' => __( 'Görünüm kurulamadı. Katalog adresine ulaşılamadıysa internet bağlantınızı kontrol edip tekrar deneyin.', 'devxpe-theme' ) ),
			'design_incompatible' => array( 'tip' => 'error',  'metin' => __( 'Bu görünüm, temanızın daha yeni bir sürümünü gerektiriyor.', 'devxpe-theme' ) ),
			'design_missing'     => array( 'tip' => 'error',   'metin' => __( 'Görünüm kurulu değil.', 'devxpe-theme' ) ),
			'design_notchild'    => array( 'tip' => 'error',   'metin' => __( 'Bu görünüm bu temayla uyumlu değil.', 'devxpe-theme' ) ),
			'design_nocap'       => array( 'tip' => 'error',   'metin' => __( 'Görünüm kurma/etkinleştirme yetkiniz yok.', 'devxpe-theme' ) ),
		);
	}

	/**
	 * Panelin kendi işlemlerini kaydeder.
	 *
	 * detect: POST'ta hangi alan varsa bu işlem seçilir. İçe aktarma önce
	 * gelir ki formda eski bir devxpe_theme_save alanı kalmışsa bile doğru
	 * işlem çalışsın.
	 *
	 * @return void
	 */
	private static function register_defaults() {
		self::register(
			'devxpe_theme_import',
			array(
				'cap'      => 'manage_options',
				'nonce'    => 'devxpe_theme_save',
				'field'    => 'devxpe_theme_nonce',
				'detect'   => 'devxpe_theme_import',
				'callback' => array( 'DEVXPE_Theme_Panel', 'panel_import' ),
			)
		);

		self::register(
			'devxpe_save_panel',
			array(
				'cap'      => 'manage_options',
				'nonce'    => 'devxpe_theme_save',
				'field'    => 'devxpe_theme_nonce',
				'detect'   => 'devxpe_theme_save',
				'callback' => array( 'DEVXPE_Theme_Panel', 'panel_save' ),
			)
		);

		/* Yedekleme: al / geri yükle / sil (nonce'lu GET bağlantıları). */
		foreach ( array( 'now', 'restore', 'delete' ) as $dxp_bk_islem ) {
			self::register(
				'devxpe_backup_' . $dxp_bk_islem,
				array(
					'cap'      => 'manage_options',
					'nonce'    => 'devxpe_theme_save',
					'field'    => 'devxpe_theme_nonce',
					'redirect' => 'settings--importexport',
					'callback' => array( 'DEVXPE_Theme_Panel', 'panel_backup_' . $dxp_bk_islem ),
				)
			);
		}

		/* Widget kitaplığı: sayfalardaki widget listelerini güncel şemayla yeniler. */
		self::register(
			'devxpe_widgets_rebuild',
			array(
				'cap'      => 'manage_options',
				'nonce'    => 'devxpe_theme_save',
				'field'    => 'devxpe_theme_nonce',
				'redirect' => 'settings--importexport',
				'callback' => array( 'DEVXPE_Theme_Panel', 'panel_widgets_rebuild' ),
			)
		);

		/*
		 * Önerilen eklenti kurulumu. Panel formundaki düğme `devxpe_plugin_install`
		 * gönderir; nonce/alan ana formunkiyle aynıdır. Yetki callback içinde de
		 * ayrıca kontrol edilir.
		 */
		self::register(
			'devxpe_plugin_install',
			array(
				'cap'      => 'install_plugins',
				'nonce'    => 'devxpe_theme_save',
				'field'    => 'devxpe_theme_nonce',
				'detect'   => 'devxpe_plugin_install',
				'callback' => array( 'DEVXPE_Theme_Panel', 'panel_install_plugin' ),
			)
		);

	}
}
