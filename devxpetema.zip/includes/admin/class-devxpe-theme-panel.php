<?php
/**
 * DEVXPE Tema Yönetim Paneli — Tek Sayfa Mimarisi.
 *
 * Safir Panel ile aynı mantık: tek bir WordPress admin sayfasında
 * tüm section'lar render edilir; sol menü JavaScript hash routing
 * ile gezinti sağlar (sayfa yenilenmez).
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/../class-devxpe-theme-conditions.php';
require_once __DIR__ . '/class-devxpe-theme-panel-actions.php';

class DEVXPE_Theme_Panel {

	/**
	 * Üst menü slug'ı.
	 */
	const MENU_SLUG = 'devxpe-theme-panel';

	/**
	 * Panel menüsü — section => config.
	 *
	 * Her section isteğe bağlı 'subsections' içerebilir.
	 *
	 * @var array
	 */
	private static $sections = array();

	/* ── Başlatma ─────────────────────────────────────────── */

	/**
	 * Hook'ları bağlar.
	 *
	 * @return void
	 */
	public static function init() {
		self::register_sections();
		DEVXPE_Theme_Panel_Actions::init();
		add_action( 'init',                  array( __CLASS__, 'register_late_fields' ), 20 );
		add_action( 'admin_menu',            array( __CLASS__, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'admin_footer',          array( __CLASS__, 'print_media_js' ) );
	}

	/* ── Section kaydı ────────────────────────────────────── */

	/**
	 * Tüm panel section'larını ve içlerindeki alanları tanımlar.
	 *
	 * @return void
	 */
	public static function register_sections() {

		/* Alan tanımları */
		DEVXPE_Theme_Fields::register( 'site_title',    array( 'label' => __( 'Site Başlığı',            'devxpe-theme' ), 'type' => 'text',     'wp_option' => 'blogname', 'help' => __( 'Sitenizin ana adını belirler.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'tagline',       array( 'label' => __( 'Slogan',                   'devxpe-theme' ), 'type' => 'text',     'wp_option' => 'blogdescription', 'help' => __( 'Sitenizi kısaca tanıtan metin.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'show_site_title', array( 'label' => __( 'Site Başlığını Göster',  'devxpe-theme' ), 'type' => 'checkbox', 'default' => '1', 'help' => __( 'Site başlığının logoyla birlikte veya tek başına görünüp görünmeyeceğini seçin.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'show_site_tagline', array( 'label' => __( 'Sloganı Göster',       'devxpe-theme' ), 'type' => 'checkbox', 'default' => '1', 'help' => __( 'Site sloganının logonun/başlığın yanında görünüp görünmeyeceğini seçin.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'logo',          array( 'label' => __( 'Logo',                     'devxpe-theme' ), 'type' => 'image', 'help' => __( 'Masaüstü ve genel kullanım için ana logo görseli.', 'devxpe-theme' ) ) );

		DEVXPE_Theme_Fields::register( 'site_description', array( 'label' => __( 'Site Açıklaması (Footer)', 'devxpe-theme' ), 'type' => 'textarea', 'help' => __( 'Yalnızca footer açıklamasını besler. Footer Açıklaması alanı boşsa burada yazılan görünür.', 'devxpe-theme' ) ) );

		DEVXPE_Theme_Fields::register( 'phone',         array( 'label' => __( 'Telefon',                  'devxpe-theme' ), 'type' => 'tel' ) );
		DEVXPE_Theme_Fields::register( 'whatsapp',      array( 'label' => __( 'WhatsApp',                 'devxpe-theme' ), 'type' => 'tel' ) );
		DEVXPE_Theme_Fields::register( 'email',         array( 'label' => __( 'E-posta',                  'devxpe-theme' ), 'type' => 'email' ) );
		DEVXPE_Theme_Fields::register( 'address',       array( 'label' => __( 'Adres',                    'devxpe-theme' ), 'type' => 'textarea' ) );
		DEVXPE_Theme_Fields::register( 'working_hours', array( 'label' => __( 'Çalışma Saatleri',         'devxpe-theme' ), 'type' => 'text' ) );

		DEVXPE_Theme_Fields::register( 'facebook',  array( 'label' => 'Facebook',  'type' => 'url' ) );
		DEVXPE_Theme_Fields::register( 'instagram', array( 'label' => 'Instagram', 'type' => 'url' ) );
		DEVXPE_Theme_Fields::register( 'twitter',   array( 'label' => 'X (Twitter)', 'type' => 'url' ) );
		DEVXPE_Theme_Fields::register( 'youtube',   array( 'label' => 'YouTube',   'type' => 'url' ) );
		DEVXPE_Theme_Fields::register( 'linkedin',  array( 'label' => 'LinkedIn',  'type' => 'url' ) );

		/* ── Header / Footer alanları ───────────────────────── */
		DEVXPE_Theme_Fields::register( 'header_btn_enable', array( 'label' => __( 'Teklif Butonunu Göster', 'devxpe-theme' ), 'type' => 'checkbox', 'default' => '', 'help' => __( 'Header sağındaki yeşil "Ücretsiz Teklif" butonu.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'header_btn_text', array( 'label' => __( 'Teklif Butonu Yazısı', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Ücretsiz Teklif', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'header_btn_url',  array( 'label' => __( 'Teklif Butonu Linki',  'devxpe-theme' ), 'type' => 'url' ) );
		DEVXPE_Theme_Fields::register( 'footer_style', array( 'label' => __( 'Footer Düzeni', 'devxpe-theme' ), 'type' => 'select', 'default' => 'full', 'options' => array( 'full' => __( 'Tam Düzen (üst şerit + sütunlar)', 'devxpe-theme' ), 'minimal' => __( 'Sade (yalnız telif)', 'devxpe-theme' ) ) ) );
		DEVXPE_Theme_Fields::register( 'footer_bg_image', array( 'label' => __( 'Footer Arkaplan Görseli', 'devxpe-theme' ), 'type' => 'image', 'help' => __( 'Boş bırakılırsa düz arkaplan rengi kullanılır.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'footer_logo', array( 'label' => __( 'Footer Logosu', 'devxpe-theme' ), 'type' => 'image', 'help' => __( 'Boş bırakılırsa site logosu kullanılır.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'footer_about_text', array( 'label' => __( 'Footer Açıklaması', 'devxpe-theme' ), 'type' => 'textarea', 'maxlength' => 1000, 'help' => __( 'Boş bırakılırsa site açıklaması kullanılır.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'footer_copyright', array( 'label' => __( 'Telif Metni', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Tüm hakları saklıdır', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'footer_note', array( 'label' => __( 'Footer Alt Notu', 'devxpe-theme' ), 'type' => 'textarea', 'maxlength' => 300, 'help' => __( 'Açıklamanın altındaki küçük not.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'footer_col2_title', array( 'label' => __( '2. Sütun Başlığı', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Hizmetler', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'footer_col2_limit', array( 'label' => __( '2. Sütun Link Sayısı', 'devxpe-theme' ), 'type' => 'select', 'default' => '8', 'options' => array( '4' => '4', '6' => '6', '8' => '8', '12' => '12', '20' => '20' ) ) );
		DEVXPE_Theme_Fields::register( 'footer_col3_title', array( 'label' => __( '3. Sütun Başlığı', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Bölgeler', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'footer_col3_limit', array( 'label' => __( '3. Sütun Link Sayısı', 'devxpe-theme' ), 'type' => 'select', 'default' => '8', 'options' => array( '4' => '4', '6' => '6', '8' => '8', '12' => '12', '20' => '20' ) ) );
		DEVXPE_Theme_Fields::register( 'privacy_url', array( 'label' => __( 'Gizlilik Politikası Linki', 'devxpe-theme' ), 'type' => 'url', 'default' => '', 'help' => __( 'Formlardaki "gizlilik politikası" bağlantısı ve footer\'daki gizlilik linki bu adrese gider. Boş bırakılırsa Yasal Sayfalar listesindeki gizlilik sayfası kullanılır.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'footer_legal_pages', array( 'label' => __( 'Yasal Sayfalar', 'devxpe-theme' ), 'type' => 'pages', 'default' => array(), 'help' => __( 'Seçtiğiniz sayfalar telif metninin yanında yasal link olarak görünür (Gizlilik, Çerezler…).', 'devxpe-theme' ) ) );

		/* ── Yüzen butonlar ─────────────────────────────────── */
		DEVXPE_Theme_Fields::register( 'float_enable', array( 'label' => __( 'Yüzen Butonlar', 'devxpe-theme' ), 'type' => 'checkbox', 'default' => '1', 'help' => __( 'Sayfanın köşelerinde sabit duran hızlı iletişim butonları.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'float_style', array( 'label' => __( 'Buton Şablonu', 'devxpe-theme' ), 'type' => 'select', 'default' => 'classic', 'options' => array( 'classic' => __( 'Şablon 1 — Yüzen Butonlar', 'devxpe-theme' ), 'bar' => __( 'Şablon 2 — Mobil Alt Bar', 'devxpe-theme' ) ), 'help' => __( 'Mobil alt bar yalnızca telefonda görünür: Ara / WhatsApp / Teklif Al.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'float_whatsapp_enable', array( 'label' => __( 'WhatsApp Butonu', 'devxpe-theme' ), 'type' => 'checkbox', 'default' => '1', 'help' => __( 'Masaüstünde solda, mobilde sağ altta görünür.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'float_whatsapp_number', array( 'label' => __( 'WhatsApp Numarası', 'devxpe-theme' ), 'type' => 'tel', 'help' => __( 'Boş bırakılırsa İletişim bölümündeki WhatsApp numarası kullanılır.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'float_whatsapp_text', array( 'label' => __( 'WhatsApp Mesajı', 'devxpe-theme' ), 'type' => 'text', 'help' => __( 'Sohbet açılırken yazı alanına bu mesaj gelir. Boş bırakılabilir.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'float_phone_enable', array( 'label' => __( 'Telefon Butonu', 'devxpe-theme' ), 'type' => 'checkbox', 'default' => '1', 'help' => __( 'Yalnızca mobilde görünür.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'float_phone_number', array( 'label' => __( 'Telefon Numarası', 'devxpe-theme' ), 'type' => 'tel', 'help' => __( 'Boş bırakılırsa İletişim bölümündeki telefon numarası kullanılır.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'float_top_enable', array( 'label' => __( 'Yukarı Çık Butonu', 'devxpe-theme' ), 'type' => 'checkbox', 'default' => '1', 'help' => __( 'Sayfa aşağı kaydırıldığında sağda beliren yukarı çık oku.', 'devxpe-theme' ) ) );

		/*
		 * Mobil alt bar (Şablon 2) butonları: her biri için ikon + yazı + link.
		 * Alanlar yalnızca "Şablon 2" seçiliyken görünür (depends).
		 */
		$mbar_dep = array( 'field' => 'float_style', 'value' => 'bar' );

		DEVXPE_Theme_Fields::register( 'mbar_tel_icon', array( 'label' => __( 'Ara — İkon', 'devxpe-theme' ), 'type' => 'icon_lucide', 'default' => 'phone', 'depends' => $mbar_dep ) );
		DEVXPE_Theme_Fields::register( 'mbar_tel_text', array( 'label' => __( 'Ara — Yazı', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Ara', 'devxpe-theme' ), 'depends' => $mbar_dep ) );
		DEVXPE_Theme_Fields::register( 'mbar_tel_url', array( 'label' => __( 'Ara — Link', 'devxpe-theme' ), 'type' => 'text', 'help' => __( 'Boş bırakılırsa telefon numarasına bağlanır.', 'devxpe-theme' ), 'depends' => $mbar_dep ) );

		DEVXPE_Theme_Fields::register( 'mbar_wa_icon', array( 'label' => __( 'WhatsApp — İkon', 'devxpe-theme' ), 'type' => 'icon_lucide', 'default' => 'dashicons-whatsapp', 'help' => __( 'Varsayılan: WhatsApp logosu (WordPress çekirdek ikonu, ek yükleme gerektirmez).', 'devxpe-theme' ), 'depends' => $mbar_dep ) );
		DEVXPE_Theme_Fields::register( 'mbar_wa_text', array( 'label' => __( 'WhatsApp — Yazı', 'devxpe-theme' ), 'type' => 'text', 'default' => 'WhatsApp', 'depends' => $mbar_dep ) );
		DEVXPE_Theme_Fields::register( 'mbar_wa_url', array( 'label' => __( 'WhatsApp — Link', 'devxpe-theme' ), 'type' => 'text', 'help' => __( 'Boş bırakılırsa WhatsApp numarasına bağlanır.', 'devxpe-theme' ), 'depends' => $mbar_dep ) );

		DEVXPE_Theme_Fields::register( 'mbar_quote_icon', array( 'label' => __( 'Teklif — İkon', 'devxpe-theme' ), 'type' => 'icon_lucide', 'default' => 'file-text', 'depends' => $mbar_dep ) );
		DEVXPE_Theme_Fields::register( 'mbar_quote_text', array( 'label' => __( 'Teklif — Yazı', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Teklif Al', 'devxpe-theme' ), 'depends' => $mbar_dep ) );
		DEVXPE_Theme_Fields::register( 'mbar_quote_url', array( 'label' => __( 'Teklif — Link', 'devxpe-theme' ), 'type' => 'text', 'help' => __( 'Boş bırakılırsa header teklif butonunun linki kullanılır.', 'devxpe-theme' ), 'depends' => $mbar_dep ) );

		/* ── Popup / duyuru ─────────────────────────────────── */
		DEVXPE_Theme_Fields::register( 'popup_enable', array( 'label' => __( 'Popup Aktif', 'devxpe-theme' ), 'type' => 'checkbox', 'default' => '', 'help' => __( 'Duyuru penceresini site genelinde etkinleştirir.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'popup_trigger', array( 'label' => __( 'Açılış Şekli', 'devxpe-theme' ), 'type' => 'select', 'default' => 'both', 'options' => array( 'auto' => __( 'Sayfa açılışında', 'devxpe-theme' ), 'link' => __( 'Yalnızca link ile', 'devxpe-theme' ), 'both' => __( 'İkisi de', 'devxpe-theme' ) ), 'help' => __( 'Link ile açmak için herhangi bir bağlantının URL alanına #duyuru yazın ya da kısa kodu kullanın: [devxpe_popup]Duyuruyu gör[/devxpe_popup]', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'popup_scope', array( 'label' => __( 'Nerede Açılsın', 'devxpe-theme' ), 'type' => 'select', 'default' => 'home', 'options' => array( 'home' => __( 'Yalnızca Anasayfa', 'devxpe-theme' ), 'all' => __( 'Tüm Sayfalar', 'devxpe-theme' ) ), 'help' => __( 'Yalnızca kendiliğinden açılan durumu etkiler; link her yerde çalışır.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'popup_frequency', array( 'label' => __( 'Gösterim Sıklığı', 'devxpe-theme' ), 'type' => 'select', 'default' => 'day', 'options' => array( 'always' => __( 'Her Ziyarette', 'devxpe-theme' ), 'session' => __( 'Oturumda Bir Kez', 'devxpe-theme' ), 'day' => __( 'Günde Bir Kez', 'devxpe-theme' ), 'once' => __( 'Yalnızca Bir Kez', 'devxpe-theme' ) ) ) );
		DEVXPE_Theme_Fields::register( 'popup_delay', array( 'label' => __( 'Açılış Gecikmesi', 'devxpe-theme' ), 'type' => 'select', 'default' => '1', 'options' => array( '0' => __( 'Hemen', 'devxpe-theme' ), '1' => '1 sn', '2' => '2 sn', '3' => '3 sn', '5' => '5 sn' ) ) );
		DEVXPE_Theme_Fields::register( 'popup_title', array( 'label' => __( 'Başlık', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Duyuru', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'popup_text', array( 'label' => __( 'Metin', 'devxpe-theme' ), 'type' => 'textarea', 'maxlength' => 2000 ) );
		DEVXPE_Theme_Fields::register( 'popup_image', array( 'label' => __( 'Görsel', 'devxpe-theme' ), 'type' => 'image', 'help' => __( 'Boş bırakılırsa görsel çizilmez.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'popup_btn_text', array( 'label' => __( 'Buton Yazısı', 'devxpe-theme' ), 'type' => 'text', 'help' => __( 'Buton linki doldurulmazsa buton çizilmez.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'popup_btn_url', array( 'label' => __( 'Buton Linki', 'devxpe-theme' ), 'type' => 'url' ) );

		/* ── Arşiv davranışı ────────────────────────────────── */
		DEVXPE_Theme_Fields::register( 'category_archive_action', array( 'label' => __( 'Kategori Sayfaları', 'devxpe-theme' ), 'type' => 'select', 'default' => 'normal', 'options' => array( 'normal' => __( 'Normal', 'devxpe-theme' ), 'home' => __( 'Anasayfaya yönlendir', 'devxpe-theme' ), '404' => __( '404 ver', 'devxpe-theme' ) ), 'help' => __( 'Kategori arşivlerini kapatır; kategori linkleri metne dönüşür.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'cpt_archive_action', array( 'label' => __( 'İçerik Tipi Arşivleri', 'devxpe-theme' ), 'type' => 'select', 'default' => 'normal', 'options' => array( 'normal' => __( 'Normal', 'devxpe-theme' ), 'home' => __( 'Anasayfaya yönlendir', 'devxpe-theme' ), '404' => __( '404 ver', 'devxpe-theme' ) ), 'help' => __( 'Panelde tanımlı içerik tiplerinin listeleme arşivleri için davranış. İçerik tipinin Arşiv onayı açıksa uygulanır.', 'devxpe-theme' ) ) );

		/* ── SEO / Schema ───────────────────────────────────── */
		DEVXPE_Theme_Fields::register( 'schema_enabled', array( 'label' => __( 'Yapısal Veri (Schema)', 'devxpe-theme' ), 'type' => 'checkbox', 'default' => '', 'help' => __( 'Arama motorları için JSON-LD yapısal veri üretir. Bir SEO eklentisi (Yoast) varsa otomatik devre dışı kalır.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'schema_type', array( 'label' => __( 'İşletme Tipi', 'devxpe-theme' ), 'type' => 'select', 'default' => 'LocalBusiness', 'options' => array( 'LocalBusiness' => __( 'Yerel İşletme (LocalBusiness)', 'devxpe-theme' ), 'Organization' => __( 'Kuruluş (Organization)', 'devxpe-theme' ) ), 'help' => __( 'İşletme bilgileri bu tipe göre işaretlenir (ad, telefon, adres, sosyal medya).', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'schema_faq', array( 'label' => __( 'SSS Şeması (FAQPage)', 'devxpe-theme' ), 'type' => 'checkbox', 'default' => '1', 'help' => __( 'Anasayfadaki SSS maddelerinden FAQPage üretir.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'schema_service', array( 'label' => __( 'Hizmet Şeması (Service)', 'devxpe-theme' ), 'type' => 'checkbox', 'default' => '1', 'help' => __( 'Anasayfadaki hizmet kartlarından Service üretir.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'schema_area', array( 'label' => __( 'Hizmet Bölgeleri (areaServed)', 'devxpe-theme' ), 'type' => 'checkbox', 'default' => '1', 'help' => __( 'Bölge kayıtlarını işletmenin hizmet alanı olarak ekler.', 'devxpe-theme' ) ) );

		/* ── Özel içerik tipleri ────────────────────────────── */
		DEVXPE_Theme_Fields::register( 'custom_post_types', array( 'label' => __( 'İçerik Tipleri', 'devxpe-theme' ), 'type' => 'cpts', 'default' => array(), 'help' => __( 'Hizmetler, Projeler, Bölgeler gibi kendi içerik tiplerinizi tanımlayın. Kaydettikten sonra WordPress menüsünde görünür ve bölümlerde kaynak olarak seçilebilir. DİKKAT: Bir tanımı listeden çıkardığınızda o tipe ait tüm içerik kalıcı olarak silinir.', 'devxpe-theme' ) ) );

		DEVXPE_Theme_Fields::register( 'layout',           array( 'label' => __( 'Sayfa Düzeni',         'devxpe-theme' ), 'type' => 'select',   'default' => 'boxed',  'options' => array( 'boxed' => __( 'Dar (Yanlarda Boşluklu)', 'devxpe-theme' ), 'full' => __( 'Tam Genişlik (Kenarlara Yakın)', 'devxpe-theme' ) ), 'help' => __( 'Tam genişlikte içerik kenarlara yaklaşır; dar düzende yanlarda boşluk kalır.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'topbar_enabled',   array( 'label' => __( 'Üst Bar',              'devxpe-theme' ), 'type' => 'checkbox', 'default' => '',       'help' => __( 'Ana header menüsünün en üstünde ince bir bar gösterir (sosyal ikonlar vb. için ideal).', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'sticky_header',    array( 'label' => __( 'Sabit Header',         'devxpe-theme' ), 'type' => 'checkbox', 'default' => '', 'help' => __( 'Sayfa aşağı kaydırıldığında ana menünün üst kısımda sabit (yapışık) kalmasını sağlar.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'breadcrumb_enabled', array( 'label' => __( 'Breadcrumb',         'devxpe-theme' ), 'type' => 'checkbox', 'default' => '1', 'help' => __( 'Sayfalarda ve yazılarda kullanıcının bulunduğu konumu (Anasayfa > Kategori > Yazı) gösterir.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'rounded_image',    array( 'label' => __( 'Yuvarlak Görseller',   'devxpe-theme' ), 'type' => 'checkbox', 'default' => '', 'help' => __( 'Sitedeki tüm görsel kenarlarını hafifçe yuvarlatır (border-radius).', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'elementor_assets', array( 'label' => __( 'Elementor Varlıkları', 'devxpe-theme' ), 'type' => 'select', 'default' => 'auto', 'options' => array( 'auto' => __( 'Otomatik (yalnızca Elementor içeren sayfalarda)', 'devxpe-theme' ), 'always' => __( 'Her zaman yükle (WordPress varsayılanı)', 'devxpe-theme' ), 'off' => __( 'Hiç yükleme', 'devxpe-theme' ) ), 'help' => __( 'Elementor CSS/JS dosyaları sayfa başına ~60 KB. Sayfalar Elementor ile yapılmadıysa "Otomatik" bunları hiç yüklemez ve site hızlanır.', 'devxpe-theme' ) ) );

		DEVXPE_Theme_Fields::register( 'typo_body', array( 'label' => __( 'Ana Gövde (Body)', 'devxpe-theme' ), 'type' => 'typography', 'default' => array() ) );
		DEVXPE_Theme_Fields::register( 'typo_h1',   array( 'label' => __( 'Başlık 1 (H1)', 'devxpe-theme' ),    'type' => 'typography', 'default' => array() ) );
		DEVXPE_Theme_Fields::register( 'typo_h2',   array( 'label' => __( 'Başlık 2 (H2)', 'devxpe-theme' ),    'type' => 'typography', 'default' => array() ) );
		DEVXPE_Theme_Fields::register( 'typo_h3',   array( 'label' => __( 'Başlık 3 (H3)', 'devxpe-theme' ),    'type' => 'typography', 'default' => array() ) );
		DEVXPE_Theme_Fields::register( 'typo_h4',   array( 'label' => __( 'Başlık 4 (H4)', 'devxpe-theme' ),    'type' => 'typography', 'default' => array() ) );
		DEVXPE_Theme_Fields::register( 'typo_h5',   array( 'label' => __( 'Başlık 5 (H5)', 'devxpe-theme' ),    'type' => 'typography', 'default' => array() ) );
		DEVXPE_Theme_Fields::register( 'typo_h6',   array( 'label' => __( 'Başlık 6 (H6)', 'devxpe-theme' ),    'type' => 'typography', 'default' => array() ) );

		DEVXPE_Theme_Fields::register( 'primary_color',   array( 'label' => __( 'Ana Renk',           'devxpe-theme' ), 'type' => 'color', 'default' => '#006731' ) );
		DEVXPE_Theme_Fields::register( 'harmonize_colors', array( 'label' => __( 'Renkleri Uyumlu Yap', 'devxpe-theme' ), 'type' => 'checkbox', 'default' => '1', 'help' => __( 'Ana renkten otomatik açık ton (hover) ve koyu ton (tıklama/focus) üretir. Açıkken hover/focus renkleri elle seçilemez.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'primary_hover', array( 'label' => __( 'Ana Renk — Hover (Açık Ton)', 'devxpe-theme' ), 'type' => 'color', 'help' => __( 'Uyum kapalıyken butonun üzerine gelindiğinde kullanılacak renk.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'primary_focus', array( 'label' => __( 'Ana Renk — Focus (Koyu Ton)', 'devxpe-theme' ), 'type' => 'color', 'help' => __( 'Uyum kapalıyken butona tıklanınca/odaklanınca kullanılacak renk.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'secondary_color', array( 'label' => __( 'İkincil Renk',       'devxpe-theme' ), 'type' => 'color', 'default' => '#033216' ) );
		DEVXPE_Theme_Fields::register( 'text_color',      array( 'label' => __( 'Yazı Rengi',         'devxpe-theme' ), 'type' => 'color', 'default' => '#033216' ) );
		DEVXPE_Theme_Fields::register( 'link_color',      array( 'label' => __( 'Link Rengi',         'devxpe-theme' ), 'type' => 'color', 'default' => '#006731' ) );
		DEVXPE_Theme_Fields::register( 'link_harmonize',  array( 'label' => __( 'Ana Renkle Uyumlu', 'devxpe-theme' ), 'type' => 'checkbox', 'default' => '1', 'help' => __( 'Açıkken link rengi ana renge bağlanır (hover = koyu ton). Kapalıyken elle seçtiğiniz link rengi kullanılır.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'header_bg',       array( 'label' => __( 'Header Arkaplanı',   'devxpe-theme' ), 'type' => 'color', 'default' => '#f6fcf7' ) );
		DEVXPE_Theme_Fields::register( 'header_text',     array( 'label' => __( 'Header Yazı Rengi',  'devxpe-theme' ), 'type' => 'color', 'default' => '#033216' ) );
		DEVXPE_Theme_Fields::register( 'header_text_harmonize', array( 'label' => __( 'Ana Renkle Uyumlu', 'devxpe-theme' ), 'type' => 'checkbox', 'default' => '', 'help' => __( 'Açıkken header yazı rengi ana rengin açık tonuna bağlanır. Kapalıyken elle seçtiğiniz renk kullanılır.', 'devxpe-theme' ) ) );
		/*
		 * Footer renkleri ayrı ayar: zemin ve yazı rengi elle seçilir.
		 */
		DEVXPE_Theme_Fields::register( 'footer_bg',   array( 'label' => __( 'Footer Arkaplanı',  'devxpe-theme' ), 'type' => 'color', 'default' => '#09090b' ) );
		DEVXPE_Theme_Fields::register( 'footer_text', array( 'label' => __( 'Footer Yazı Rengi', 'devxpe-theme' ), 'type' => 'color', 'default' => '', 'help' => __( 'Boş bırakılırsa zemin rengine göre okunaklı renk otomatik seçilir.', 'devxpe-theme' ) ) );

		DEVXPE_Theme_Fields::register( 'ticker_enabled', array( 'label' => __( 'Ticker Aktif',    'devxpe-theme' ), 'type' => 'checkbox', 'default' => '' ) );
		DEVXPE_Theme_Fields::register( 'ticker_position', array( 'label' => __( 'Ticker Konumu', 'devxpe-theme' ), 'type' => 'select', 'default' => 'header_bottom', 'options' => array( 'header_top' => __( 'Header Üstü', 'devxpe-theme' ), 'header_bottom' => __( 'Header Altı', 'devxpe-theme' ), 'footer_top' => __( 'Footer Üstü', 'devxpe-theme' ), 'footer_bottom' => __( 'Footer Altı', 'devxpe-theme' ) ) ) );
		DEVXPE_Theme_Fields::register( 'ticker_title',   array( 'label' => __( 'Ticker Başlığı',  'devxpe-theme' ), 'type' => 'text',     'default' => __( 'Son Dakika', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'ticker_text',    array( 'label' => __( 'Ticker İçerikleri','devxpe-theme'), 'type' => 'textarea', 'help' => __( 'Her satır bir öğe.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'ticker_speed',   array( 'label' => __( 'Ticker Hızı',     'devxpe-theme' ), 'type' => 'select',   'default' => 'normal', 'options' => array( 'slow' => __( 'Yavaş', 'devxpe-theme' ), 'normal' => __( 'Normal', 'devxpe-theme' ), 'fast' => __( 'Hızlı', 'devxpe-theme' ) ) ) );
		DEVXPE_Theme_Fields::register( 'ticker_bg',      array( 'label' => __( 'Ticker Rengi',    'devxpe-theme' ), 'type' => 'color',    'default' => '#1e73be' ) );

		DEVXPE_Theme_Fields::register( 'mobile_logo',       array( 'label' => __( 'Mobil Logo',             'devxpe-theme' ), 'type' => 'image', 'help' => __( 'Sadece mobil cihazlarda gösterilecek özel logo görseli (boş bırakılırsa masaüstü logosu kullanılır).', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'sticky_mobile',     array( 'label' => __( 'Sabit Mobil Header',     'devxpe-theme' ), 'type' => 'checkbox', 'default' => '', 'help' => __( 'Mobil cihazlarda sayfayı aşağı kaydırırken header\'ın (logonun ve menü butonunun) ekranın üstüne yapışık (sabit) kalmasını sağlar.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'burger_color',      array( 'label' => __( 'Hamburger Menü Rengi',   'devxpe-theme' ), 'type' => 'color',    'default' => '#222222', 'help' => __( 'Mobilde görünen 3 çizgili hamburger ikonunun rengi.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'mobile_breakpoint', array( 'label' => __( 'Mobil Kırılma Noktası',  'devxpe-theme' ), 'type' => 'select',   'default' => '992', 'options' => array( '768' => '768 px (Tabletler dahil değil)', '992' => '992 px (Tabletler dahil)' ), 'help' => __( 'Hangi ekran genişliğinden itibaren mobil menünün (hamburger ikonunun) devreye gireceğini belirler.', 'devxpe-theme' ) ) );
		
		// Yeni Mobil Menü Ayarları
		DEVXPE_Theme_Fields::register( 'mobile_menu_position', array( 'label' => __( 'Hamburger Konumu', 'devxpe-theme' ), 'type' => 'select', 'default' => 'right', 'options' => array( 'left' => __( 'Solda', 'devxpe-theme' ), 'right' => __( 'Sağda', 'devxpe-theme' ) ), 'help' => __( 'Mobilde hamburger butonunun logonun solunda mı yoksa sağında mı duracağını belirler.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'mobile_menu_style', array( 'label' => __( 'Açılış Efekti (Stili)', 'devxpe-theme' ), 'type' => 'select', 'default' => 'dropdown', 'options' => array( 'dropdown' => __( 'Aşağı Doğru Kayarak (Dropdown)', 'devxpe-theme' ), 'offcanvas_left' => __( 'Soldan Kayarak (Off-canvas)', 'devxpe-theme' ), 'offcanvas_right' => __( 'Sağdan Kayarak (Off-canvas)', 'devxpe-theme' ), 'modal_center' => __( 'Ekranın Ortasından (Tam Ekran)', 'devxpe-theme' ) ), 'help' => __( 'Hamburger ikonuna tıklandığında menünün ekrana nasıl bir animasyonla geleceğini belirler.', 'devxpe-theme' ) ) );

		DEVXPE_Theme_Fields::register( 'header_ad_enable',      array( 'label' => __( 'Header Reklamı',       'devxpe-theme' ), 'type' => 'checkbox', 'default' => '' ) );
		DEVXPE_Theme_Fields::register( 'header_ad_code',        array( 'label' => __( 'Header Reklam Kodu',   'devxpe-theme' ), 'type' => 'scripts' ) );
		DEVXPE_Theme_Fields::register( 'left_ad_enable',        array( 'label' => __( 'Sol Yan Reklam',       'devxpe-theme' ), 'type' => 'checkbox', 'default' => '' ) );
		DEVXPE_Theme_Fields::register( 'left_ad_code',          array( 'label' => __( 'Sol Yan Reklam Kodu',  'devxpe-theme' ), 'type' => 'scripts' ) );
		DEVXPE_Theme_Fields::register( 'right_ad_enable',       array( 'label' => __( 'Sağ Yan Reklam',       'devxpe-theme' ), 'type' => 'checkbox', 'default' => '' ) );
		DEVXPE_Theme_Fields::register( 'right_ad_code',         array( 'label' => __( 'Sağ Yan Reklam Kodu',  'devxpe-theme' ), 'type' => 'scripts' ) );
		DEVXPE_Theme_Fields::register( 'post_top_ad_enable',    array( 'label' => __( 'Yazı Üst Reklamı',     'devxpe-theme' ), 'type' => 'checkbox', 'default' => '' ) );
		DEVXPE_Theme_Fields::register( 'post_top_ad_code',      array( 'label' => __( 'Yazı Üst Reklam Kodu','devxpe-theme' ), 'type' => 'scripts' ) );
		DEVXPE_Theme_Fields::register( 'post_bottom_ad_enable', array( 'label' => __( 'Yazı Alt Reklamı',     'devxpe-theme' ), 'type' => 'checkbox', 'default' => '' ) );
		DEVXPE_Theme_Fields::register( 'post_bottom_ad_code',   array( 'label' => __( 'Yazı Alt Reklam Kodu','devxpe-theme' ), 'type' => 'scripts' ) );
		DEVXPE_Theme_Fields::register( 'footer_ad_enable',      array( 'label' => __( 'Footer Reklamı',       'devxpe-theme' ), 'type' => 'checkbox', 'default' => '' ) );
		DEVXPE_Theme_Fields::register( 'footer_ad_code',        array( 'label' => __( 'Footer Reklam Kodu',  'devxpe-theme' ), 'type' => 'scripts' ) );

		DEVXPE_Theme_Fields::register( 'maintenance_enable',  array( 'label' => __( 'Bakım Modu',       'devxpe-theme' ), 'type' => 'checkbox', 'default' => '', 'help' => __( 'Etkinleştirildiğinde site yöneticiler hariç herkese kapalı görünür.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'maintenance_title',   array( 'label' => __( 'Bakım Başlığı',    'devxpe-theme' ), 'type' => 'text',     'default' => __( 'Bakımdayız', 'devxpe-theme' ), 'help' => __( 'Bakım sayfasındaki ana büyük başlık.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'maintenance_message', array( 'label' => __( 'Bakım Mesajı',     'devxpe-theme' ), 'type' => 'textarea', 'default' => __( 'Sitemiz şu anda güncellenmektedir. Lütfen daha sonra tekrar deneyin.', 'devxpe-theme' ), 'help' => __( 'Bakım sayfasında başlığın altındaki açıklama metni.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'maintenance_image',   array( 'label' => __( 'Bakım Görseli',    'devxpe-theme' ), 'type' => 'image',    'help' => __( 'Bakım sayfasında gösterilecek büyük bir fotoğraf veya illüstrasyon.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'maintenance_date',    array( 'label' => __( 'Açılış Zamanlayıcısı', 'devxpe-theme' ), 'type' => 'datetime', 'help' => __( 'Geri sayım sayacı için açılış tarihi ve saati. Takvimden seçin. Boş bırakılırsa sayaç gösterilmez.', 'devxpe-theme' ) ) );

		DEVXPE_Theme_Fields::register( 'script_head', array( 'label' => __( 'Head Script',    'devxpe-theme' ), 'type' => 'scripts', 'help' => __( '</head> öncesine eklenir.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'script_body', array( 'label' => __( 'Body Script',    'devxpe-theme' ), 'type' => 'scripts', 'help' => __( '<body> açılışından sonra eklenir.', 'devxpe-theme' ) ) );

		/* ── Google reCAPTCHA (v3) ──────────────────────────── */
		DEVXPE_Theme_Fields::register( 'recaptcha_enable', array( 'label' => __( 'reCAPTCHA Aktif', 'devxpe-theme' ), 'type' => 'checkbox', 'default' => '', 'help' => __( 'Tüm formlar gönderilirken Google reCAPTCHA v3 ile doğrulanır. Site ve gizli anahtar girilmeden doğrulama çalışmaz.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'recaptcha_site_key', array( 'label' => __( 'Site Anahtarı', 'devxpe-theme' ), 'type' => 'text', 'help' => __( 'Google reCAPTCHA v3 site anahtarı (public).', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'recaptcha_secret_key', array( 'label' => __( 'Gizli Anahtar', 'devxpe-theme' ), 'type' => 'password', 'help' => __( 'Google reCAPTCHA v3 gizli anahtarı. Veritabanında düz metin saklanır; alan yalnızca yöneticiye görünür.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'recaptcha_score', array( 'label' => __( 'En Düşük Puan', 'devxpe-theme' ), 'type' => 'select', 'default' => '0.5', 'options' => array( '0.3' => '0.3', '0.5' => '0.5', '0.7' => '0.7' ), 'help' => __( 'Google\'ın döndürdüğü puan bu değerin altındaysa gönderim reddedilir. Yükseldikçe daha katı olur.', 'devxpe-theme' ) ) );

		/* ── Anasayfa bölüm alanları ─────────────────────────── */
		DEVXPE_Theme_Fields::register( 'hero_image',    array( 'label' => __( 'Manşet Görseli (varsayılan)', 'devxpe-theme' ), 'type' => 'image', 'help' => __( 'Sayfaya özel görsel girilmemişse tüm sayfalarda bu görsel kullanılır.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'hero_btn_text', array( 'label' => __( 'Birinci Buton Yazısı', 'devxpe-theme' ), 'type' => 'text', 'default' => '' ) );
		DEVXPE_Theme_Fields::register( 'hero_btn_url',  array( 'label' => __( 'Birinci Buton Linki',  'devxpe-theme' ), 'type' => 'url' ) );
		DEVXPE_Theme_Fields::register( 'hero_btn2_text', array( 'label' => __( 'İkinci Buton Yazısı', 'devxpe-theme' ), 'type' => 'text', 'help' => __( 'Boş bırakılırsa telefon numarası yazılır.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'hero_btn2_url', array( 'label' => __( 'İkinci Buton Linki',   'devxpe-theme' ), 'type' => 'url', 'help' => __( 'Boş bırakılırsa telefon numarasına bağlanır.', 'devxpe-theme' ) ) );

		DEVXPE_Theme_Fields::register( 'services_title',    array( 'label' => __( 'Hizmetler Başlığı',    'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Neler Yapıyoruz', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'services_subtitle', array( 'label' => __( 'Hizmetler Alt Yazısı', 'devxpe-theme' ), 'type' => 'textarea', 'default' => __( 'Sunduğumuz hizmetleri inceleyin ve size en uygun olanı seçin.', 'devxpe-theme' ) ) );

		/* Lucide ikon seçenekleri (hero rozetleri, maddeler için ortak) */
		$lucide_options = array();
		foreach ( array_keys( devxpe_lucide_icons() ) as $lucide_name ) {
			$lucide_options[ $lucide_name ] = $lucide_name;
		}

		/* ── Hizmetler alanları ─────────────────────────────── */
		DEVXPE_Theme_Fields::register( 'services_eyebrow', array( 'label' => __( 'Üst Etiket', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Hizmetler', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'services_more_text', array( 'label' => __( 'Kart Link Yazısı', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Daha Fazla', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'services_cards', array( 'label' => __( 'Manuel Kartlar (Yedek)', 'devxpe-theme' ), 'type' => 'cards', 'default' => array(), 'depends' => array( 'field' => 'services_cards_source', 'value' => 'manual' ), 'help' => __( 'Yalnızca Kart Kaynağı "Manuel kartlar" iken gösterilir. Sınırsız kart ekleyebilir, oklarla sıralayabilirsiniz.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'services_cards_limit', array( 'label' => __( 'Kart Sayısı', 'devxpe-theme' ), 'type' => 'select', 'default' => '6', 'options' => array( '3' => '3', '6' => '6', '9' => '9', '12' => '12' ), 'help' => __( 'Kaynaktan kaç içerik kart olarak gösterilsin.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'services_terms_source', array( 'label' => __( 'Etiket Kaynağı', 'devxpe-theme' ), 'type' => 'select', 'default' => 'none', 'options' => array( 'none' => __( 'Gizli', 'devxpe-theme' ), 'category' => __( 'Kategoriler', 'devxpe-theme' ), 'post_tag' => __( 'Etiketler', 'devxpe-theme' ), 'page' => __( 'Sayfalar', 'devxpe-theme' ), 'post' => __( 'Yazılar', 'devxpe-theme' ) ), 'help' => __( 'Alttaki etiket satırı bu kaynaktan otomatik doldurulur. Yeni yazı/sayfa/terim eklendiğinde kendiliğinden listeye girer.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'services_terms_limit', array( 'label' => __( 'Etiket Sayısı', 'devxpe-theme' ), 'type' => 'select', 'default' => '10', 'options' => array( '6' => '6', '8' => '8', '10' => '10', '12' => '12', '20' => '20' ) ) );

		/* ── Neden Biz alanları ─────────────────────────────── */
		DEVXPE_Theme_Fields::register( 'features_eyebrow', array( 'label' => __( 'Üst Etiket', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Neden Biz', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'features_title', array( 'label' => __( 'Başlık', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Güvenilir Yerel Ekip', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'features_items', array( 'label' => __( 'Maddeler', 'devxpe-theme' ), 'type' => 'rows', 'default' => array(), 'icons' => $lucide_options, 'help' => __( 'İkon, başlık ve metin girin. Sınırsız madde ekleyebilirsiniz.', 'devxpe-theme' ) ) );

		/* ── Nasıl Çalışır alanları ─────────────────────────── */
		DEVXPE_Theme_Fields::register( 'steps_eyebrow', array( 'label' => __( 'Üst Etiket', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Nasıl Çalışır', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'steps_title', array( 'label' => __( 'Başlık', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'İlk Görüşmeden Teslime', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'steps_subtitle', array( 'label' => __( 'Alt Metin', 'devxpe-theme' ), 'type' => 'textarea', 'default' => __( 'Her adımda ne olacağını baştan bilirsiniz.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'steps_items', array( 'label' => __( 'Adımlar', 'devxpe-theme' ), 'type' => 'rows', 'default' => array(), 'help' => __( 'Başlık ve metin girin; sıra numaraları otomatik verilir.', 'devxpe-theme' ) ) );

		/* ── Projeler alanları ──────────────────────────────── */
		DEVXPE_Theme_Fields::register( 'projects_eyebrow', array( 'label' => __( 'Üst Etiket', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Son İşler', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'projects_title', array( 'label' => __( 'Başlık', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Tamamladığımız İşler', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'projects_subtitle', array( 'label' => __( 'Alt Metin', 'devxpe-theme' ), 'type' => 'textarea', 'default' => __( 'Gerçek işlerimizden bir seçki.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'projects_limit', array( 'label' => __( 'Proje Sayısı', 'devxpe-theme' ), 'type' => 'select', 'default' => '6', 'options' => array( '3' => '3', '6' => '6', '9' => '9', '12' => '12' ), 'help' => __( 'Kaynaktan kaç proje gösterilsin.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'projects_items', array( 'label' => __( 'Manuel Projeler (Yedek)', 'devxpe-theme' ), 'type' => 'cards', 'default' => array(), 'depends' => array( 'field' => 'projects_source', 'value' => 'manual' ), 'help' => __( 'Yalnızca Proje Kaynağı "Manuel" iken gösterilir.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'projects_terms_source', array( 'label' => __( 'Etiket Kaynağı', 'devxpe-theme' ), 'type' => 'select', 'default' => 'none', 'options' => array( 'none' => __( 'Gizli', 'devxpe-theme' ), 'category' => __( 'Kategoriler', 'devxpe-theme' ), 'post_tag' => __( 'Etiketler', 'devxpe-theme' ), 'page' => __( 'Sayfalar', 'devxpe-theme' ), 'post' => __( 'Yazılar', 'devxpe-theme' ) ), 'help' => __( 'Proje listesinin altındaki etiket satırı bu kaynaktan otomatik doldurulur. Yeni yazı/sayfa/terim eklendiğinde kendiliğinden listeye girer.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'projects_terms_limit', array( 'label' => __( 'Etiket Sayısı', 'devxpe-theme' ), 'type' => 'select', 'default' => '10', 'options' => array( '6' => '6', '8' => '8', '10' => '10', '12' => '12', '20' => '20' ) ) );

		/* ── Yorumlar alanları ──────────────────────────────── */
		DEVXPE_Theme_Fields::register( 'reviews_eyebrow', array( 'label' => __( 'Üst Etiket', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Yorumlar', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'reviews_title', array( 'label' => __( 'Başlık', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Müşterilerimiz Ne Diyor', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'reviews_rating', array( 'label' => __( 'Yıldız Sayısı', 'devxpe-theme' ), 'type' => 'select', 'default' => '5', 'options' => array( '1' => '1', '2' => '2', '3' => '3', '4' => '4', '5' => '5' ) ) );
		DEVXPE_Theme_Fields::register( 'reviews_items', array( 'label' => __( 'Yorumlar', 'devxpe-theme' ), 'type' => 'rows', 'default' => array(), 'long_text' => true, 'help' => __( 'Başlık = yorumu yapan kişi (örn. "Ayşe K. - Merkez"), Metin = yorumun kendisi.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'reviews_note', array( 'label' => __( 'Alt Not', 'devxpe-theme' ), 'type' => 'textarea', 'maxlength' => 300 ) );

		/* ── Bölgeler alanları ──────────────────────────────── */
		DEVXPE_Theme_Fields::register( 'areas_eyebrow', array( 'label' => __( 'Üst Etiket', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Hizmet Bölgeleri', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'areas_title', array( 'label' => __( 'Başlık', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Hizmet Verdiğimiz Bölgeler', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'areas_subtitle', array( 'label' => __( 'Alt Metin', 'devxpe-theme' ), 'type' => 'textarea', 'default' => __( 'Size en yakın bölgede hizmet veriyoruz.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'areas_terms_source', array( 'label' => __( 'Etiket Kaynağı', 'devxpe-theme' ), 'type' => 'select', 'default' => 'none', 'options' => array( 'none' => __( 'Gizli', 'devxpe-theme' ), 'category' => __( 'Kategoriler', 'devxpe-theme' ), 'post_tag' => __( 'Etiketler', 'devxpe-theme' ), 'page' => __( 'Sayfalar', 'devxpe-theme' ), 'post' => __( 'Yazılar', 'devxpe-theme' ) ), 'help' => __( 'Bölge listesi bu kaynaktan otomatik doldurulur.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'areas_terms_limit', array( 'label' => __( 'Etiket Sayısı', 'devxpe-theme' ), 'type' => 'select', 'default' => '12', 'options' => array( '6' => '6', '8' => '8', '12' => '12', '20' => '20', '50' => '50' ) ) );

		/* ── SSS alanları ───────────────────────────────────── */
		DEVXPE_Theme_Fields::register( 'faq_eyebrow', array( 'label' => __( 'Üst Etiket', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Sıkça Sorulan Sorular', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'faq_title', array( 'label' => __( 'Başlık', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Merak Edilenler', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'faq_items', array( 'label' => __( 'Sorular', 'devxpe-theme' ), 'type' => 'rows', 'default' => array(), 'long_text' => true, 'help' => __( 'Başlık = soru, Metin = cevap.', 'devxpe-theme' ) ) );

		/* ── Form alanları ──────────────────────────────────── */
		DEVXPE_Theme_Fields::register( 'form_eyebrow', array( 'label' => __( 'Üst Etiket', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Ücretsiz Teklif', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'form_title', array( 'label' => __( 'Başlık', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Ücretsiz Teklifinizi Alın', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'form_subtitle', array( 'label' => __( 'Alt Metin', 'devxpe-theme' ), 'type' => 'textarea', 'default' => __( 'Projenizi kısaca anlatın; 24 saat içinde net ve yükümlülük gerektirmeyen bir fiyatla döneriz.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'form_benefits', array( 'label' => __( 'Avantajlar', 'devxpe-theme' ), 'type' => 'textarea', 'help' => __( 'Her satır bir madde.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'form_phone_text', array( 'label' => __( 'Telefon Metni', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Veya telefonla ulaşın:', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'form_step1_title', array( 'label' => __( '1. Adım Başlığı', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Hizmet', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'form_step2_title', array( 'label' => __( '2. Adım Başlığı', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Projeniz', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'form_step3_title', array( 'label' => __( '3. Adım Başlığı', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Bilgileriniz', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'form_step4_title', array( 'label' => __( '4. Adım Başlığı', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Gözden geçir ve gönder', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'form_note', array( 'label' => __( 'Form Alt Notu', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Hangisinden emin değil misiniz? En yakınını seçin; keşifte netleştiririz.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'form_services', array( 'label' => __( 'Hizmet Seçenekleri', 'devxpe-theme' ), 'type' => 'rows', 'default' => array(), 'long_text' => true, 'help' => __( 'Başlık = grup adı (örn. "Grup 1"), Metin = seçenekler (her satır bir seçenek).', 'devxpe-theme' ) ) );

		/*
		 * Teklif formunun metinleri ve alanları panelden yönetilir; şablonda
		 * sabit yazı yok. Alan etiketleri alan listeleriyle birlikte gelir.
		 */
		DEVXPE_Theme_Fields::register( 'form_step1_legend', array( 'label' => __( '1. Adım Açıklaması', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Neye ihtiyacınız var?', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'form_btn_next', array( 'label' => __( 'Devam Butonu', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Devam Et', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'form_btn_back', array( 'label' => __( 'Geri Butonu', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Geri', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'form_btn_send', array( 'label' => __( 'Gönder Butonu', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Gönder', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'quote_project_fields', array( 'label' => __( 'Proje Adımı Alanları', 'devxpe-theme' ), 'type' => 'form_fields', 'default' => devxpe_quote_project_default_fields(), 'help' => __( '2. adımın alanları. Sürükle veya oklarla sırala; tür, etiket, yer tutucu, alt not, genişlik ve zorunluluk değiştirilebilir.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'quote_contact_fields', array( 'label' => __( 'İletişim Adımı Alanları', 'devxpe-theme' ), 'type' => 'form_fields', 'default' => devxpe_quote_contact_default_fields(), 'help' => __( '3. adımın alanları. E-posta ve telefon alanları otomatik doğrulanır.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'form_recipient', array( 'label' => __( 'Alıcı E-posta', 'devxpe-theme' ), 'type' => 'text', 'help' => __( 'Birden fazla adres için virgülle ayırın. Geçersiz adresler yok sayılır. Boş bırakılırsa site yöneticisinin e-postası kullanılır.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'form_subject', array( 'label' => __( 'E-posta Konusu', 'devxpe-theme' ), 'type' => 'subject', 'help' => __( 'Çiplere tıklayınca konuya eklenir. Örn: #{no} | {service} | {name}', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'form_success', array( 'label' => __( 'Başarı Mesajı', 'devxpe-theme' ), 'type' => 'textarea', 'maxlength' => 300, 'default' => 'Teşekkürler! En kısa sürede size döneceğiz.', 'help' => __( 'Tüm formlarda (teklif + iletişim) gönderim sonrası görünen mesaj.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'contact_btn_text', array( 'label' => __( 'Form Buton Yazısı', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Mesaj Gönder', 'devxpe-theme' ), 'help' => __( 'Form oluşturucuda buton yazısı girilmemişse bu kullanılır.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'form_mini_title', array( 'label' => __( 'Detay Sayfası Form Başlığı', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Teklif İsteyin', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'form_mini_subtitle', array( 'label' => __( 'Detay Sayfası Form Alt Metni', 'devxpe-theme' ), 'type' => 'text', 'default' => __( '24 saat içinde yanıt, yükümlülük yok.', 'devxpe-theme' ) ) );

		/* ── İletişim formu (panelden tasarlanır) ── */
		DEVXPE_Theme_Fields::register( 'custom_forms', array( 'label' => __( 'Formlar', 'devxpe-theme' ), 'type' => 'forms', 'default' => array( array( 'name' => __( 'İletişim Formu', 'devxpe-theme' ), 'slug' => 'iletisim', 'btn' => __( 'Mesaj Gönder', 'devxpe-theme' ) ) ), 'help' => __( 'Sınırsız form oluşturun. Her formun kendi slug\'ı, kısa kodu ve alan oluşturucusu olur. Kaydettikten sonra her form için ayrı sekme açılır.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'contact_consent_enable', array( 'label' => __( 'Onay Kutusu', 'devxpe-theme' ), 'type' => 'checkbox', 'default' => '1', 'help' => __( 'Tüm form gönderimlerinde gizlilik onayı ister; onaysız gönderim reddedilir.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'contact_consent_text', array( 'label' => __( 'Onay Metni', 'devxpe-theme' ), 'type' => 'textarea', 'default' => 'Gizlilik politikasını okudum ve kişisel verilerimin işlenmesini onaylıyorum.' ) );
		DEVXPE_Theme_Fields::register( 'contact_upload_types', array( 'label' => __( 'İzinli Dosya Türleri', 'devxpe-theme' ), 'type' => 'text', 'default' => 'jpg,jpeg,png,webp,pdf', 'help' => __( 'Virgülle ayrılmış uzantılar. Örn: jpg,png,pdf', 'devxpe-theme' ) ) );

		/* ── SMTP: form e-postaları kendi sunucudan gönderilsin ── */
		DEVXPE_Theme_Fields::register( 'smtp_enable', array( 'label' => __( 'SMTP Aktif', 'devxpe-theme' ), 'type' => 'checkbox', 'default' => '', 'help' => __( 'Kapatılırsa sunucunun kendi e-posta gönderimi kullanılır.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'smtp_host', array( 'label' => __( 'Sunucu', 'devxpe-theme' ), 'type' => 'text', 'help' => __( 'Örn: smtp.gmail.com', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'smtp_port', array( 'label' => __( 'Port', 'devxpe-theme' ), 'type' => 'text', 'default' => '587' ) );
		DEVXPE_Theme_Fields::register( 'smtp_encryption', array( 'label' => __( 'Şifreleme', 'devxpe-theme' ), 'type' => 'select', 'default' => 'tls', 'options' => array( 'tls' => 'TLS (587)', 'ssl' => 'SSL (465)', 'none' => __( 'Yok', 'devxpe-theme' ) ) ) );
		DEVXPE_Theme_Fields::register( 'smtp_auth', array( 'label' => __( 'Kimlik Doğrulama', 'devxpe-theme' ), 'type' => 'checkbox', 'default' => '1', 'help' => __( 'Sunucu kullanıcı adı/şifre istiyorsa açık kalsın.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'smtp_user', array( 'label' => __( 'Kullanıcı Adı', 'devxpe-theme' ), 'type' => 'text' ) );
		DEVXPE_Theme_Fields::register( 'smtp_pass', array( 'label' => __( 'Şifre', 'devxpe-theme' ), 'type' => 'password', 'help' => __( 'Şifre veritabanında düz metin olarak saklanır; alan yalnızca sana görünür ve panele şifreli bağlantıyla gir.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'smtp_from_email', array( 'label' => __( 'Gönderen E-posta', 'devxpe-theme' ), 'type' => 'email', 'help' => __( 'Boş bırakılırsa Kullanıcı Adı kullanılır.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'smtp_from_name', array( 'label' => __( 'Gönderen Adı', 'devxpe-theme' ), 'type' => 'text', 'help' => __( 'Boş bırakılırsa site adı kullanılır.', 'devxpe-theme' ) ) );

		/*
		 * ── Form doğrulama: tek yerden ayarlanır, tüm formlarda geçerli ──
		 * Kurallar + mesajlar burada; ön yüz hem buradan beslenir.
		 */
		DEVXPE_Theme_Fields::register( 'validate_enable', array( 'label' => __( 'Doğrulama', 'devxpe-theme' ), 'type' => 'checkbox', 'default' => '1', 'help' => __( 'Kapatılırsa tarayıcı tarafı doğrulama durur; sunucu tarafı zorunlu alan kontrolü devam eder.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'validate_numbers_only', array( 'label' => __( 'Sadece Sayı Girişi', 'devxpe-theme' ), 'type' => 'checkbox', 'default' => '1', 'help' => __( 'Telefon ve sayı alanlarına harf yazılmasını engeller; yazarken temizlenir.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'validate_min_len', array( 'label' => __( 'Metin — En Az Karakter', 'devxpe-theme' ), 'type' => 'select', 'default' => '2', 'options' => array( '0' => __( 'Kapalı', 'devxpe-theme' ), '2' => '2', '3' => '3', '5' => '5', '10' => '10' ) ) );
		DEVXPE_Theme_Fields::register( 'validate_max_len', array( 'label' => __( 'Metin — En Çok Karakter', 'devxpe-theme' ), 'type' => 'select', 'default' => '120', 'options' => array( '0' => __( 'Kapalı', 'devxpe-theme' ), '60' => '60', '80' => '80', '120' => '120', '200' => '200', '500' => '500' ), 'help' => __( 'Tek satırlık alanlar (ad, e-posta, yer tutucu…). Sınıra gelince yazma durur.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'validate_textarea_max', array( 'label' => __( 'Mesaj Alanı — En Çok Karakter', 'devxpe-theme' ), 'type' => 'select', 'default' => '500', 'options' => array( '0' => __( 'Kapalı', 'devxpe-theme' ), '200' => '200', '300' => '300', '500' => '500', '1000' => '1000' ), 'help' => __( 'Uzun metin (mesaj, proje detayı) alanları. Altında canlı sayaç görünür.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'validate_country_enable', array( 'label' => __( 'Telefon Ülkesi', 'devxpe-theme' ), 'type' => 'checkbox', 'default' => '0', 'help' => __( 'Açıksa telefon alanlarının başında ülke kodu seçicisi görünür.', 'devxpe-theme' ) ) );
		$country_options = function_exists( 'devxpe_form_countries' ) ? devxpe_form_countries() : array();
		if ( empty( $country_options ) && class_exists( 'DEVXPE_Theme_Fields' ) ) {
			$country_options = DEVXPE_Theme_Fields::country_list();
		}
		DEVXPE_Theme_Fields::register( 'validate_country_default', array( 'label' => __( 'Varsayılan Ülke', 'devxpe-theme' ), 'type' => 'select', 'default' => '+44', 'options' => $country_options, 'help' => __( 'Formdaki ülke seçicisi açıldığında varsayılan kod.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'validate_countries', array( 'label' => __( 'Ülke Kodları', 'devxpe-theme' ), 'type' => 'countries', 'default' => "+44|United Kingdom\n+90|Türkiye\n+1|United States\n+49|Germany\n+33|France\n+34|Spain\n+39|Italy\n+31|Netherlands\n+353|Ireland", 'help' => __( 'Hangi ülke kodları görünsün? İşaretledikleriniz formdaki ülke seçicisinde listelenir.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'validate_email_tlds', array( 'label' => __( 'Kabul Edilen E-posta Uzantıları', 'devxpe-theme' ), 'type' => 'text', 'default' => '', 'help' => __( 'Virgülle ayırın: com, net, co.uk. Boş bırakılırsa tüm uzantılar kabul edilir. Geçersiz uzantıda kabul edilenler kutunun altında listelenir.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'validate_msg_required', array( 'label' => __( 'Mesaj — Zorunlu', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Bu alanı doldurun.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'validate_msg_email', array( 'label' => __( 'Mesaj — E-posta', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Geçerli bir e-posta adresi girin.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'validate_msg_phone', array( 'label' => __( 'Mesaj — Telefon', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Geçerli bir telefon numarası girin.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'validate_msg_min', array( 'label' => __( 'Mesaj — Çok Kısa', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Bu alan çok kısa.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'validate_msg_max', array( 'label' => __( 'Mesaj — Çok Uzun', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Bu alan çok uzun.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'validate_msg_number', array( 'label' => __( 'Mesaj — Sayı', 'devxpe-theme' ), 'type' => 'text', 'default' => __( 'Bu alana yalnızca sayı girebilirsiniz.', 'devxpe-theme' ) ) );

		/* ── Dinamik sayfa verileri (ikonlu kartlar / istatistikler) ── */
		DEVXPE_Theme_Fields::register( 'contact_cards', array( 'label' => __( 'İletişim Kartları', 'devxpe-theme' ), 'type' => 'rows', 'default' => array(), 'icons' => $lucide_options, 'with_url' => true, 'help' => __( 'İkon + başlık + değer + bağlantı. Boş bırakılırsa telefon/WhatsApp/e-posta/adres alanlarından otomatik oluşturulur.', 'devxpe-theme' ) ) );
		DEVXPE_Theme_Fields::register( 'about_stats', array( 'label' => __( 'İstatistikler', 'devxpe-theme' ), 'type' => 'rows', 'default' => array(), 'icons' => $lucide_options, 'help' => __( 'İkon + değer + etiket. Boş bırakılırsa paneldeki manşet rozetlerinden gelir.', 'devxpe-theme' ) ) );

		/* ── Hero (Manşet) alanları ─────────────────────────── */
		DEVXPE_Theme_Fields::register( 'hero_badge', array( 'label' => __( 'Rozet Metni', 'devxpe-theme' ), 'type' => 'text', 'default' => '' ) );
		DEVXPE_Theme_Fields::register( 'hero_title', array( 'label' => __( 'Başlık', 'devxpe-theme' ), 'type' => 'text', 'default' => '' ) );
		DEVXPE_Theme_Fields::register( 'hero_subtitle', array( 'label' => __( 'Alt Metin', 'devxpe-theme' ), 'type' => 'textarea', 'maxlength' => 300, 'default' => '' ) );

		$hero_chip_defaults = array(
			1 => array( 'hammer', '', '' ),
			2 => array( 'shield-check', '', '' ),
			3 => array( 'badge-check', '', '' ),
			4 => array( 'clock', '', '' ),
		);
		for ( $i = 1; $i <= 4; $i++ ) {
			DEVXPE_Theme_Fields::register( 'hero_stat_' . $i . '_icon',  array( 'label' => sprintf( __( 'Rozet %d — İkon', 'devxpe-theme' ), $i ), 'type' => 'icon_lucide', 'default' => $hero_chip_defaults[ $i ][0] ) );
			DEVXPE_Theme_Fields::register( 'hero_stat_' . $i . '_value', array( 'label' => sprintf( __( 'Rozet %d — Değer', 'devxpe-theme' ), $i ), 'type' => 'text', 'default' => $hero_chip_defaults[ $i ][1] ) );
			DEVXPE_Theme_Fields::register( 'hero_stat_' . $i . '_label', array( 'label' => sprintf( __( 'Rozet %d — Etiket', 'devxpe-theme' ), $i ), 'type' => 'text', 'default' => $hero_chip_defaults[ $i ][2] ) );
		}



		/* ── Bölüm aç/kapa + kısa kod (sayfa seçimi yok) ────── */
		foreach ( devxpe_home_section_ids() as $home_section ) {
			DEVXPE_Theme_Fields::register( $home_section . '_enable', array( 'label' => __( 'Bölüm Aktif', 'devxpe-theme' ), 'type' => 'checkbox', 'default' => '1', 'help' => __( 'Bölümün açma/kapama anahtarı. Anasayfada kapalı bölümler çizilmez.', 'devxpe-theme' ) ) );
			DEVXPE_Theme_Fields::register( $home_section . '_shortcode', array( 'label' => __( 'Kısa Kod', 'devxpe-theme' ), 'type' => 'shortcode', 'tag' => '[devxpe_section id="' . $home_section . '"]' ) );
			/* Bölümün paneldeki görünen adı (müşteri kendi adını yazabilir). */
			DEVXPE_Theme_Fields::register( 'home_label_' . $home_section, array( 'label' => __( 'Bölüm Adı', 'devxpe-theme' ), 'type' => 'text', 'help' => __( 'Yalnızca panelde ve kısa kod listesinde görünen ad. Boş bırakılırsa varsayılan kullanılır.', 'devxpe-theme' ) ) );
		}

		/* ── Anasayfa iskeleti (sürüklenebilir sıra) ────────── */
		DEVXPE_Theme_Fields::register( 'home_sections_order', array( 'label' => __( 'Bölüm Sırası', 'devxpe-theme' ), 'type' => 'sections', 'default' => array(), 'help' => __( 'Bölümleri fareyle sürükleyip bırakarak anasayfadaki sıralarını değiştirin. Kapalı bölümler soluk görünür ve ön yüzde çizilmez.', 'devxpe-theme' ) ) );
		// Görsel alanı yok: sıra alanının içindeki gizli input ile gönderilir.
		DEVXPE_Theme_Fields::register( 'home_sections_split', array( 'label' => __( 'Yan Yana Bölümler', 'devxpe-theme' ), 'type' => 'sections', 'default' => array() ) );

		/* ── İletişim Formu sekmeleri: kayıtlı her form için ayrı sekme ── */
		$contact_tabs = array();
		foreach ( devxpe_custom_forms() as $f_slug => $f ) {
			$contact_tabs[ $f_slug ] = array(
				'label'  => $f['name'],
				'fields' => array( 'form_builder_' . $f_slug, 'form_shortcode_' . $f_slug ),
			);
		}
		if ( ! $contact_tabs ) {
			$contact_tabs['iletisim'] = array(
				'label'  => __( 'İletişim Formu', 'devxpe-theme' ),
				'fields' => array( 'form_builder_iletisim', 'form_shortcode_iletisim' ),
			);
		}

		/* ── Section yapısı ─────────────────────────────────── */
		self::$sections = array(
			'site' => array(
				'label' => __( 'Site Ayarları', 'devxpe-theme' ),
				'icon'  => 'dashicons-admin-site',
				'subsections' => array(
					'general' => array(
						'label'  => __( 'Genel', 'devxpe-theme' ),
						'fields' => array( 'site_title', 'tagline', 'show_site_title', 'show_site_tagline', 'logo', 'site_description' ),
					),
					'skeleton' => array(
						'label'  => __( 'Aktif Olanlar', 'devxpe-theme' ),
						'fields' => array( 'home_sections_order' ),
					),
					'floating' => array(
						'label'  => __( 'Yüzen Butonlar', 'devxpe-theme' ),
						'fields' => array( 'float_enable', 'float_style', 'float_whatsapp_enable', 'float_whatsapp_number', 'float_whatsapp_text', 'float_phone_enable', 'float_phone_number', 'float_top_enable' ),
						'groups' => array(
							array(
								'label'  => __( 'Mobil Alt Bar Butonları', 'devxpe-theme' ),
								'cols'   => 3,
								/*
								 * Grup, yalnızca "Şablon 2 — Mobil Alt Bar" seçiliyken görünür.
								 * (Alanların her birinde de depends var; buradaki grup başlığını
								 * ve kart alanını da gizler → Şablon 1'de boş kutu kalmaz.)
								 */
								'depends' => array( 'field' => 'float_style', 'value' => 'bar' ),
								'fields' => array(
									'mbar_tel_icon', 'mbar_tel_text', 'mbar_tel_url',
									'mbar_wa_icon', 'mbar_wa_text', 'mbar_wa_url',
									'mbar_quote_icon', 'mbar_quote_text', 'mbar_quote_url',
								),
							),
						),
					),
					'popup' => array(
						'label'  => __( 'Popup', 'devxpe-theme' ),
						'fields' => array( 'popup_enable', 'popup_trigger', 'popup_scope', 'popup_frequency', 'popup_delay', 'popup_title', 'popup_text', 'popup_image', 'popup_btn_text', 'popup_btn_url' ),
					),
					'header_footer' => array(
						'label'  => __( 'Header ve Footer', 'devxpe-theme' ),
						'tabs'   => array(
							'global' => array(
								'label'  => __( 'Global', 'devxpe-theme' ),
								'fields' => array( 'ticker_enabled', 'ticker_position', 'ticker_title', 'ticker_text', 'ticker_speed', 'ticker_bg' ),
							),
							'header' => array(
								'label'  => __( 'Header', 'devxpe-theme' ),
								'fields' => array( 'sticky_header', 'header_btn_enable', 'header_btn_text', 'header_btn_url', 'topbar_enabled' ),
							),
							'footer' => array(
								'label'  => __( 'Footer', 'devxpe-theme' ),
								'groups' => array(
									array(
										'label'  => __( 'Düzen', 'devxpe-theme' ),
										'cols'   => 1,
										'fields' => array( 'footer_style' ),
									),
									array(
										'label'  => __( 'Yasal Linkler (Alt Şerit)', 'devxpe-theme' ),
										'cols'   => 1,
										'fields' => array( 'footer_legal_pages' ),
									),
									array(
										'label'  => __( 'Telif ve Metinler', 'devxpe-theme' ),
										'cols'   => 3,
										'fields' => array( 'footer_copyright', 'footer_about_text', 'footer_note' ),
									),
									array(
										'label'  => __( 'Logo ve Arka Plan Görseli', 'devxpe-theme' ),
										'cols'   => 2,
										'fields' => array( 'footer_logo', 'footer_bg_image' ),
									),
									array(
										'label'  => __( '2. Sütun', 'devxpe-theme' ),
										'cols'   => 3,
										'fields' => array( 'footer_col2_title', 'footer_col2_source', 'footer_col2_limit' ),
									),
									array(
										'label'  => __( '3. Sütun', 'devxpe-theme' ),
										'cols'   => 3,
										'fields' => array( 'footer_col3_title', 'footer_col3_source', 'footer_col3_limit' ),
									),
								),
							),
						),
					),
					'contact' => array(
						'label'  => __( 'İletişim', 'devxpe-theme' ),
						'order'  => 1001,
						'fields' => array( 'phone', 'whatsapp', 'email', 'address', 'working_hours' ),
					),
					'archives' => array(
						'label'  => __( 'Arşivler', 'devxpe-theme' ),
						'fields' => array( 'category_archive_action', 'cpt_archive_action' ),
					),
					'social' => array(
						'label'  => __( 'Sosyal Medya', 'devxpe-theme' ),
						'fields' => array( 'facebook', 'instagram', 'twitter', 'youtube', 'linkedin' ),
					),
				),
			),
			'home' => array(
				'label' => __( 'Anasayfa', 'devxpe-theme' ),
				'icon'  => 'dashicons-welcome-widgets-menus',
				'subsections' => array(
					'hero' => array(
						'label'  => __( 'Manşet', 'devxpe-theme' ),
						'fields' => array(
							'hero_enable',
							'hero_badge', 'hero_title', 'hero_subtitle',
							'hero_btn_text', 'hero_btn_url', 'hero_btn2_text', 'hero_btn2_url',
							'hero_image',
						),
						/*
						 * Rozet alanları (ikon + değer + etiket) tek grup içinde
						 * 3 sütuna dizilir: 12 satır yerine 4 kompakt satır.
						 */
						'groups' => array(
							array(
								'label'  => __( 'Rozetler', 'devxpe-theme' ),
								/*
								 * İkon sütunu dar (72px) sabit: ikon seçici 64px
								 * olduğu için değer alanıyla arasında boşluk kalmaz.
								 */
								'cols'   => '72px 1fr 1fr',
								'fields' => array(
									'hero_stat_1_icon', 'hero_stat_1_value', 'hero_stat_1_label',
									'hero_stat_2_icon', 'hero_stat_2_value', 'hero_stat_2_label',
									'hero_stat_3_icon', 'hero_stat_3_value', 'hero_stat_3_label',
									'hero_stat_4_icon', 'hero_stat_4_value', 'hero_stat_4_label',
								),
							),
						),
					),
					'services' => array(
						'label'  => __( 'Hizmetler', 'devxpe-theme' ),
						'fields' => array(
							'services_enable',
							'services_eyebrow', 'services_title', 'services_subtitle', 'services_more_text',
							'services_cards_source', 'services_cards_limit', 'services_cards',
							'services_terms_source', 'services_terms_limit',
						),
					),
					'features' => array(
						'label'  => __( 'Neden Biz', 'devxpe-theme' ),
						'fields' => array(
							'features_enable',
							'features_eyebrow', 'features_title', 'features_items',
						),
					),
					'steps' => array(
						'label'  => __( 'Nasıl Çalışır', 'devxpe-theme' ),
						'fields' => array(
							'steps_enable',
							'steps_eyebrow', 'steps_title', 'steps_subtitle', 'steps_items',
						),
					),
					'projects' => array(
						'label'  => __( 'Projeler', 'devxpe-theme' ),
						'fields' => array(
							'projects_enable',
							'projects_eyebrow', 'projects_title', 'projects_subtitle',
							'projects_source', 'projects_limit', 'projects_items',
							'projects_terms_source', 'projects_terms_limit',
						),
					),
					'reviews' => array(
						'label'  => __( 'Yorumlar', 'devxpe-theme' ),
						'fields' => array(
							'reviews_enable',
							'reviews_eyebrow', 'reviews_title', 'reviews_rating',
							'reviews_items', 'reviews_note',
						),
					),
					'areas' => array(
						'label'  => __( 'Bölgeler', 'devxpe-theme' ),
						'fields' => array(
							'areas_enable',
							'areas_eyebrow', 'areas_title', 'areas_subtitle',
							'areas_terms_source', 'areas_terms_limit',
						),
					),
					'faq' => array(
						'label'  => __( 'SSS', 'devxpe-theme' ),
						'fields' => array(
							'faq_enable',
							'faq_eyebrow', 'faq_title', 'faq_items',
						),
					),
					'quote' => array(
						'label'  => __( 'Teklif Formu', 'devxpe-theme' ),
						'fields' => array(
							'form_enable', 'home_form_choice',
							'form_eyebrow', 'form_title', 'form_subtitle', 'form_benefits', 'form_phone_text',
							'form_step1_title', 'form_step2_title', 'form_step3_title', 'form_step4_title',
							'form_step1_legend',
							'form_btn_next', 'form_btn_back', 'form_btn_send',
							'quote_project_fields', 'quote_contact_fields',
							'form_note', 'form_services', 'form_mini_title', 'form_mini_subtitle',
						),
					),
				),
			),
			'form' => array(
				'label' => __( 'Form', 'devxpe-theme' ),
				'icon'  => 'dashicons-email-alt',
				'subsections' => array(
					'inbox' => array(
						'label'  => __( 'Gelen Mesajlar', 'devxpe-theme' ),
						'fields' => array(),
						'order'  => 1,
					),
					'settings' => array(
						'label'  => __( 'Form Ayarları', 'devxpe-theme' ),
						'fields' => array( 'form_recipient', 'form_subject', 'form_success', 'contact_btn_text', 'contact_consent_enable', 'contact_consent_text', 'privacy_url', 'contact_upload_types' ),
						'order'  => 2,
					),
					'forms' => array(
						'label'  => __( 'Formlar', 'devxpe-theme' ),
						'fields' => array( 'custom_forms' ),
						'order'  => 3,
					),
					'contact' => array(
						'label'  => __( 'İletişim Formu', 'devxpe-theme' ),
						'tabs'   => $contact_tabs,
						'order'  => 4,
					),
					'validate' => array(
						'label'  => __( 'Doğrulama', 'devxpe-theme' ),
						'order'  => 5,
						'groups' => array(
							array(
								'label'  => '',
								'cols'   => 3,
								'fields' => array( 'validate_enable', 'validate_numbers_only', 'validate_min_len', 'validate_max_len', 'validate_textarea_max', 'validate_email_tlds', 'validate_country_enable', 'validate_country_default', 'validate_countries', 'validate_msg_required', 'validate_msg_email', 'validate_msg_phone', 'validate_msg_min', 'validate_msg_max', 'validate_msg_number' ),
							),
						),
					),
					'smtp' => array(
						'label'  => __( 'SMTP Ayarları', 'devxpe-theme' ),
						'fields' => array(),
						'order'  => 6,
					),
				),
			),
			'design' => array(
				'label' => __( 'Tasarım', 'devxpe-theme' ),
				'icon'  => 'dashicons-admin-appearance',
				'subsections' => array(
					'design' => array(
						'label' => __( 'Tasarım', 'devxpe-theme' ),
						'tabs'  => array(
							'layout' => array(
								'label'  => __( 'Düzen', 'devxpe-theme' ),
								'fields' => array( 'layout', 'breadcrumb_enabled', 'rounded_image', 'elementor_assets' ),
							),
							'font' => array(
								'label'  => __( 'Font', 'devxpe-theme' ),
								'fields' => array( 'typo_body', 'typo_h1', 'typo_h2', 'typo_h3', 'typo_h4', 'typo_h5', 'typo_h6' ),
							),
							'color' => array(
								'label'  => __( 'Renk', 'devxpe-theme' ),
								'fields' => array( 'primary_color', 'harmonize_colors', 'primary_hover', 'primary_focus', 'secondary_color', 'text_color', 'link_color', 'link_harmonize', 'header_bg', 'header_text', 'header_text_harmonize', 'footer_bg', 'footer_text' ),
							),
						),
					),
				),
			),
			'cpts' => array(
				'label' => __( 'İçerik Tipleri', 'devxpe-theme' ),
				'icon'  => 'dashicons-screenoptions',
				'subsections' => array(
					'cpts' => array(
						'label'  => __( 'İçerik Tipleri', 'devxpe-theme' ),
						'fields' => array( 'custom_post_types' ),
					),
				),
			),
			'mobile' => array(
				'label' => __( 'Mobil', 'devxpe-theme' ),
				'icon'  => 'dashicons-smartphone',
				'subsections' => array(
					'mobile_settings' => array(
						'label'  => __( 'Mobil Ayarlar', 'devxpe-theme' ),
						'fields' => array( 'mobile_logo', 'sticky_mobile', 'burger_color', 'mobile_breakpoint', 'mobile_menu_position', 'mobile_menu_style' ),
					),
				),
			),
			'maintenance' => array(
				'label' => __( 'Bakım Modu', 'devxpe-theme' ),
				'icon'  => 'dashicons-hammer',
				'subsections' => array(
					'maintenance_settings' => array(
						'label'  => __( 'Ayarlar', 'devxpe-theme' ),
						'fields' => array( 'maintenance_enable', 'maintenance_image', 'maintenance_title', 'maintenance_message', 'maintenance_date' ),
					),
				),
			),
			'ads' => array(
				'label' => __( 'Reklam Ayarları', 'devxpe-theme' ),
				'icon'  => 'dashicons-chart-bar',
				'subsections' => array(
					'header'  => array( 'label' => __( 'Header Reklamı',  'devxpe-theme' ), 'fields' => array( 'header_ad_enable', 'header_ad_code' ) ),
					'left_ad' => array( 'label' => __( 'Sol Yan Reklam', 'devxpe-theme' ), 'fields' => array( 'left_ad_enable', 'left_ad_code' ) ),
					'right_ad'=> array( 'label' => __( 'Sağ Yan Reklam', 'devxpe-theme' ), 'fields' => array( 'right_ad_enable', 'right_ad_code' ) ),
					'post'    => array( 'label' => __( 'Yazı Reklamları', 'devxpe-theme' ), 'fields' => array( 'post_top_ad_enable', 'post_top_ad_code', 'post_bottom_ad_enable', 'post_bottom_ad_code' ) ),
					'footer'  => array( 'label' => __( 'Footer Reklamı',  'devxpe-theme' ), 'fields' => array( 'footer_ad_enable', 'footer_ad_code' ) ),
				),
			),

			'settings' => array(
				'label'      => __( 'Gelişmiş Ayarlar', 'devxpe-theme' ),
				'icon'       => 'dashicons-admin-generic',
				'subsections' => array(
					'scripts' => array(
						'label'  => __( 'Script Yönetimi', 'devxpe-theme' ),
						'fields' => array( 'script_head', 'script_body' ),
					),
					'seo' => array(
						'label'  => __( 'SEO Ayarları', 'devxpe-theme' ),
						'fields' => array( 'schema_enabled', 'schema_type', 'schema_faq', 'schema_service', 'schema_area' ),
					),
					'webp' => array(
						'label'  => __( 'Görseller', 'devxpe-theme' ),
						'fields' => array(),
					),
					'captcha' => array(
						'label'  => __( 'Google reCAPTCHA', 'devxpe-theme' ),
						'fields' => array( 'recaptcha_enable', 'recaptcha_site_key', 'recaptcha_secret_key', 'recaptcha_score' ),
					),
					'demo' => array(
						'label'  => __( 'Demo İçeriği', 'devxpe-theme' ),
						'fields' => array(),
					),
					'importexport' => array(
						'label'  => __( 'İçe / Dışa Aktar', 'devxpe-theme' ),
						'fields' => array(),
					),
					'child' => array(
						'label'  => __( 'Child Tema', 'devxpe-theme' ),
						'fields' => array(),
					),
				),
			),
			'plugins' => array(
				'label' => __( 'Önerilen Eklentiler', 'devxpe-theme' ),
				'icon'  => 'dashicons-admin-plugins',
				'subsections' => array(
					'oneriler' => array(
						'label'  => __( 'Önerilen Eklentiler', 'devxpe-theme' ),
						'fields' => array(),
					),
				),
			),
			'gorunum' => array(
				'label' => __( 'Görünüm', 'devxpe-theme' ),
				'icon'  => 'dashicons-art',
				'subsections' => array(
					'katalog' => array(
						'label'  => __( 'Tema Kütüphanesi', 'devxpe-theme' ),
						'fields' => array(),
					),
				),
			),
			'about' => array(
				'label' => __( 'Hakkımızda', 'devxpe-theme' ),
				'icon'  => 'dashicons-info',
				'subsections' => array(
					'about' => array(
						'label'  => __( 'Hakkımızda', 'devxpe-theme' ),
						'fields' => array(),
					),
				),
			),
		);

		/*
		 * Her anasayfa bölümüne kendi kısa kodunu ekle. Yerleşim kısa kodla
		 * veya anasayfa sırasıyla yapılır.
		 */
		if ( isset( self::$sections['home']['subsections'] ) ) {
			/* Tüm bölümlerin kısa kodları tek yerde. */
			$dxp_short_fields = array();
			foreach ( devxpe_home_section_ids() as $dxp_sid ) {
				$dxp_short_fields[] = $dxp_sid . '_shortcode';
			}
			self::$sections['home']['subsections']['shortcodes'] = array(
				'label'  => __( 'Kısa Kodlar', 'devxpe-theme' ),
				'fields' => $dxp_short_fields,
				'order'  => 90,
			);
		}

		/*
		 * Alt menü öğelerini etiketlerine göre alfabetik sırala (Türkçe harf
		 * duyarlı). Üst bölümler ve sekmeler bilinçli sıralarını korur.
		 */
		foreach ( self::$sections as &$section ) {
			if ( ! empty( $section['subsections'] ) ) {
				uasort(
					$section['subsections'],
					function ( $a, $b ) {
						$oa = isset( $a['order'] ) ? (int) $a['order'] : 999;
						$ob = isset( $b['order'] ) ? (int) $b['order'] : 999;
						if ( $oa !== $ob ) {
							return $oa <=> $ob;
						}
						return strcmp( self::sort_key( $a['label'] ), self::sort_key( $b['label'] ) );
					}
				);
			}
		}
		unset( $section );

		/*
		 * Anasayfa alt bölümlerini "Aktif Olanlar" kaydındaki sıraya diz:
		 * bölüm sırası panelden değiştirildiğinde Anasayfa menüsü de aynı
		 * sırayı izler (bölüm anahtarları sıra listesiyle aynıdır).
		 */
		if ( ! empty( self::$sections['home']['subsections'] ) && function_exists( 'devxpe_home_sections_order' ) ) {
			$subs    = self::$sections['home']['subsections'];
			$ordered = array();
			$idx     = 0;
			foreach ( devxpe_home_sections_order() as $dxp_sid ) {
				$dxp_key = ( 'form' === $dxp_sid ) ? 'quote' : $dxp_sid;
				if ( isset( $subs[ $dxp_key ] ) ) {
					$subs[ $dxp_key ]['order'] = $idx++;
					$ordered[ $dxp_key ]       = $subs[ $dxp_key ];
					unset( $subs[ $dxp_key ] );
				}
			}
			self::$sections['home']['subsections'] = $ordered + $subs;
		}
	}

	/* ── Gecikmeli alan kaydı ─────────────────────────────── */

	/**
	 * Çalışma zamanı verisine bağlı alanları init sonrası kaydeder.
	 *
	 * wp_get_nav_menus() 'nav_menu' taksonomisini sorgular; bu taksonomi
	 * init'te kaydedildiği için after_setup_theme sırasında çağrılırsa
	 * WP_Error döner. Bu yüzden menü listesi init(20)'de okunur.
	 *
	 * @return void
	 */
	public static function register_late_fields() {
		/*
		 * Sayfa seçicileri: hangi sayfaların About/Contact olarak render
		 * edileceği. "Otomatik" seçiliyse sayfaya atanan şablon geçerli kalır.
		 */
		$dxp_page_pick = array(
			'0' => __( 'Otomatik', 'devxpe-theme' ),
		);
		foreach ( get_pages( array( 'sort_column' => 'post_title', 'sort_order' => 'ASC' ) ) as $dxp_pick_page ) {
			$dxp_page_pick[ (string) $dxp_pick_page->ID ] = $dxp_pick_page->post_title . ' (ID ' . $dxp_pick_page->ID . ')';
		}

		foreach ( array(
			'about_page_pick'   => array( 'label' => __( 'Hakkımızda Sayfası', 'devxpe-theme' ), 'help' => __( 'Bu sayfa Hakkımızda şablonuyla (page-about.php) açılır; şablon ataması gerekmez.', 'devxpe-theme' ), 'default' => '0' ),
			'contact_page_pick' => array( 'label' => __( 'İletişim Sayfası', 'devxpe-theme' ), 'help' => __( 'Bu sayfa İletişim şablonuyla (page-contact.php) açılır; şablon ataması gerekmez.', 'devxpe-theme' ), 'default' => '0' ),
		) as $dxp_pick_id => $dxp_pick_field ) {
			DEVXPE_Theme_Fields::register(
				$dxp_pick_id,
				array(
					'label'   => $dxp_pick_field['label'],
					'type'    => 'select',
					'default' => '0',
					'options' => $dxp_page_pick,
					'help'    => $dxp_pick_field['help'],
				)
			);
		}

		/*
		 * Kart kaynağı: kategori/etiket/sayfa seçenekleri çalışma zamanında
		 * oluşturulur (terimler init'ten sonra okunabilir).
		 */
		$sources = array( 'manual' => __( 'Manuel kartlar', 'devxpe-theme' ) );

		foreach ( get_taxonomies( array( 'public' => true ), 'objects' ) as $taxonomy ) {
			$terms = get_terms( array( 'taxonomy' => $taxonomy->name, 'hide_empty' => false ) );
			if ( is_wp_error( $terms ) || ! $terms ) {
				continue;
			}
			foreach ( $terms as $term ) {
				$sources[ $taxonomy->name . ':' . $term->term_id ] = $taxonomy->labels->singular_name . ': ' . $term->name;
			}
		}

		$sources['post'] = __( 'Son yazılar', 'devxpe-theme' );
		$sources['page'] = __( 'Sayfalar', 'devxpe-theme' );

		/* Panelden tanımlı özel içerik tipleri (cpt:<slug>). */
		foreach ( devxpe_custom_post_types() as $cpt ) {
			if ( empty( $cpt['slug'] ) || empty( $cpt['name'] ) ) {
				continue;
			}
			$sources[ 'cpt:' . $cpt['slug'] ] = $cpt['name'];
		}

		DEVXPE_Theme_Fields::register(
			'services_cards_source',
			array(
				'label'   => __( 'Kart Kaynağı', 'devxpe-theme' ),
				'type'    => 'select',
				'default' => 'manual',
				'options' => $sources,
				'help'    => __( 'Bir kategori/etiket/sayfa seçin: o içerikler otomatik olarak kart olur ve yeni içerik eklendiğinde kendiliğinden girer. Kaynakta içerik yoksa aşağıdaki manuel kartlar gösterilir.', 'devxpe-theme' ),
			)
		);

		DEVXPE_Theme_Fields::register(
			'projects_source',
			array(
				'label'   => __( 'Proje Kaynağı', 'devxpe-theme' ),
				'type'    => 'select',
				'default' => 'manual',
				'options' => $sources,
				'help'    => __( 'Bir kategori/etiket/sayfa seçin: o içerikler otomatik olarak proje kartı olur. Kaynakta içerik yoksa aşağıdaki manuel liste gösterilir.', 'devxpe-theme' ),
			)
		);

		DEVXPE_Theme_Fields::register(
			'footer_col2_source',
			array(
				'label'   => __( '2. Sütun Kaynağı', 'devxpe-theme' ),
				'type'    => 'select',
				'default' => 'page',
				'options' => $sources,
				'help'    => __( 'Footer\'daki link listesi bu kaynaktan otomatik doldurulur.', 'devxpe-theme' ),
			)
		);

		DEVXPE_Theme_Fields::register(
			'footer_col3_source',
			array(
				'label'   => __( '3. Sütun Kaynağı', 'devxpe-theme' ),
				'type'    => 'select',
				'default' => 'category',
				'options' => $sources,
				'help'    => __( 'Footer\'daki link listesi bu kaynaktan otomatik doldurulur.', 'devxpe-theme' ),
			)
		);

		/*
		 * Bant başlıkları ve hizmet kaynağı artık içerik (post) bazında,
		 * düzenleyici ekranındaki "Bant başlıkları" meta box'ından yönetilir.
		 */

		/* Form oluşturucu: kayıtlı her form için ayrı alan (sekme başına). */
		foreach ( devxpe_custom_forms() as $f_slug => $f ) {
			DEVXPE_Theme_Fields::register(
				'form_builder_' . $f_slug,
				array(
					'label'   => __( 'Alan Oluşturucu', 'devxpe-theme' ),
					'type'    => 'form_fields',
					'default' => array(),
					'slug'    => $f_slug,
				)
			);
			DEVXPE_Theme_Fields::register(
				'form_shortcode_' . $f_slug,
				array(
					'label' => __( 'Kısa Kod', 'devxpe-theme' ),
					'type'  => 'shortcode',
					'tag'   => '[devxpe_form slug="' . $f_slug . '"]',
				)
			);
		}

		/* Sayfa form seçicileri: 4 adımlı teklif formu + tanımlı formlar. */
		$form_choices = devxpe_form_choice_options();
		DEVXPE_Theme_Fields::register(
			'home_form_choice',
			array(
				'label'   => __( 'Form Seç', 'devxpe-theme' ),
				'type'    => 'select',
				'default' => 'quote',
				'options' => $form_choices,
				'help'    => __( 'Anasayfa teklif bölümünde hangi form gösterilsin.', 'devxpe-theme' ),
			)
		);
	}

	/**
	 * Alfabetik karşılaştırma için Türkçe harfleri ASCII karşılıklarına çevirir.
	 *
	 * @param string $text Metin.
	 * @return string
	 */
	private static function sort_key( $text ) {
		$text = strtr(
			(string) $text,
			array(
				'Ç' => 'C', 'ç' => 'c',
				'Ğ' => 'G', 'ğ' => 'g',
				'İ' => 'I', 'ı' => 'i',
				'Ö' => 'O', 'ö' => 'o',
				'Ş' => 'S', 'ş' => 's',
				'Ü' => 'U', 'ü' => 'u',
				'Â' => 'A', 'â' => 'a',
			)
		);

		return strtolower( $text );
	}

	/* ── Menü kaydı ───────────────────────────────────────── */

	/**
	 * Tek bir WordPress admin sayfası olarak kaydeder.
	 *
	 * @return void
	 */
	public static function register_menu() {
		add_menu_page(
			__( 'DEVXPE Panel', 'devxpe-theme' ),
			__( 'DEVXPE Panel', 'devxpe-theme' ),
			'manage_options',
			self::MENU_SLUG,
			array( __CLASS__, 'render_page' ),
			'dashicons-art',
			56
		);
	}

	/* ── Asset'ler ────────────────────────────────────────── */

	/**
	 * CSS + JS + WP medya kütüphanesini yükler.
	 *
	 * @param string $hook WordPress admin hook.
	 * @return void
	 */
	public static function enqueue_assets( $hook ) {
		if ( 'toplevel_page_' . self::MENU_SLUG !== $hook ) {
			return;
		}

		$base = DEVXPE_THEME_URL . 'includes/admin/';
		$dir  = DEVXPE_THEME_PATH . 'includes/admin/';

		wp_enqueue_style(
			'devxpe-panel',
			$base . 'panel.css',
			array(),
			filemtime( $dir . 'panel.css' )
		);

		/* Font Awesome 6: ikon seçicinin önizlemeleri için (CDN). */
		devxpe_fa_enqueue();

		wp_enqueue_script(
			'devxpe-panel',
			$base . 'panel.js',
			array(),
			filemtime( $dir . 'panel.js' ),
			true
		);

		wp_enqueue_media();

		/* Panel JS metinleri (çeviriye bağlı). */
		wp_add_inline_script(
			'devxpe-panel',
			'window.DXPDEMO = ' . wp_json_encode(
				array(
					'kuruluyor'  => __( 'Demo kuruluyor', 'devxpe-theme' ),
					'tamamlandi' => __( 'Tamamlandı', 'devxpe-theme' ),
					'yenileniyor' => __( 'Demo kurulumu tamamlandı, sayfa yenileniyor…', 'devxpe-theme' ),
					'adimHata'   => __( 'Kurulum adımı başarısız oldu.', 'devxpe-theme' ),
					'baglanti'   => __( 'Bağlantı hatası. Tekrar deneyin.', 'devxpe-theme' ),
				)
			) . ';',
			'before'
		);
	}

	/**
	 * WP medya seçici JS — admin_footer.
	 *
	 * @return void
	 */
	public static function print_media_js() {
		$screen  = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		$allowed = array( 'toplevel_page_' . self::MENU_SLUG, 'post', 'page' );

		/* Yazı/içerik tipi düzenleme ekranında da medya seçici çalışsın
		   (detay sayfası meta box'ındaki görsel alanı için). */
		if ( ! $screen || ! in_array( $screen->id, $allowed, true ) ) {
			return;
		}
		?>
		<script id="devxpe-panel-media">
		jQuery( function ( $ ) {
			$( document ).on( 'click', '.dxp-image-upload', function ( e ) {
				e.preventDefault();
				var box  = $( this ).closest( '.dxp-image-field' );
				var url  = box.find( '.dxp-image-url' );
				var view = wp.media( {
					title    : '<?php echo esc_js( __( 'Resim Seç', 'devxpe-theme' ) ); ?>',
					library  : { type: 'image' },
					multiple : false
				} );
				view.on( 'select', function () {
					var att = view.state().get( 'selection' ).first().toJSON();
					url.val( att.url );
					var src = ( att.sizes && att.sizes.thumbnail ) ? att.sizes.thumbnail.url : att.url;
					box.find( '.dxp-image-preview' ).html( '<img src="' + src + '" alt="" />' );
				} );
				view.open();
			} );
		} );
		</script>
		<?php
	}

	/* ── POST işleme ──────────────────────────────────────── */

	/**
	 * Panel sayfasını render eder.
	 *
	 * POST işleme ARTIK BURADA DEĞİL: ayar kaydetme / içe aktarma istekleri
	 * DEVXPE_Theme_Panel_Actions yönlendiricisinde (load-{page} + PRG) işlenir.
	 * Bu metot yalnızca panel HTML'ini çizer.
	 *
	 * @return void
	 */
	public static function render_page() {
		self::render_panel();
	}

	/**
	 * Paneli kaydeder (yönlendirici callback'i).
	 *
	 * Yetki + nonce kontrolü yönlendiricide yapılır; burada yalnızca gönderilen
	 * alanlar yazılır (gönderilmeyenler korunur → bayat form koruması).
	 *
	 * @param array $data POST verisi.
	 * @return string admin_notices sonuç kodu.
	 */
	public static function panel_save( array $data ) {
		self::save_fields( wp_unslash( $data ) );
		return 'saved';
	}

	/**
	 * JSON içe aktarmayı işler (yönlendirici callback'i).
	 *
	 * @param array $data POST verisi.
	 * @return string admin_notices sonuç kodu.
	 */
	public static function panel_import( array $data ) {
		$raw  = isset( $data['devxpe_theme_import_data'] ) ? wp_unslash( $data['devxpe_theme_import_data'] ) : '';
		$json = json_decode( (string) $raw, true );

		if ( ! is_array( $json ) ) {
			return 'import_error';
		}

		$options = get_option( DEVXPE_Theme_Fields::OPTION_KEY, array() );
		$all     = DEVXPE_Theme_Fields::all();

		foreach ( $json as $key => $value ) {
			if ( ! isset( $all[ $key ] ) || ! empty( $all[ $key ]['wp_option'] ) ) {
				continue;
			}
			$options[ $key ] = DEVXPE_Theme_Fields::sanitize( $key, $value );
		}

		update_option( DEVXPE_Theme_Fields::OPTION_KEY, $options, false );

		return 'imported';
	}

	/**
	 * POST verisini ayar olarak kaydeder.
	 *
	 * Yalnızca gönderilen alanlar güncellenir; gönderilmeyenler korunur. Bu,
	 * başka bir sekmede açık (bayat) panelin kaydetmesi durumunda o sekmede
	 * dokunulmamış alanların üzerine eski değerlerle yazılmasını engeller.
	 *
	 * @param array $data Gönderilen veri (tam veya kısmi).
	 * @return void
	 */
	private static function save_fields( $data ) {
		$options = get_option( DEVXPE_Theme_Fields::OPTION_KEY, array() );
		$all     = DEVXPE_Theme_Fields::all();

		foreach ( $all as $field_id => $field ) {
			if ( ! array_key_exists( $field_id, $data ) ) {
				continue;
			}

			$value = $data[ $field_id ];

			/*
			 * Boş kaydedilen metin alanı, alanın VARSAYILANI doluysa varsayılana döner.
			 *
			 * NEDEN: Panelde bir buton/metin alanı yanlışlıkla boşaltılırsa ön yüzde
			 * yazısız kalıyordu (ör. "Geri" butonu). Varsayılanı boş olan alanlar
			 * (rozet, ikinci buton vb.) etkilenmez; onlarda boş = gizle.
			 */
			if ( '' === $value && is_string( $value ) && ! empty( $field['default'] ) ) {
				$value = $field['default'];
			}

			if ( ! empty( $field['wp_option'] ) ) {
				update_option( $field['wp_option'], DEVXPE_Theme_Fields::sanitize( $field_id, $value ) );
				continue;
			}

			$options[ $field_id ] = DEVXPE_Theme_Fields::sanitize( $field_id, $value );
		}

		update_option( DEVXPE_Theme_Fields::OPTION_KEY, $options, false );
	}

	/* ── HTML Render ──────────────────────────────────────── */

	/**
	 * Panelin tüm HTML çıktısını üretir.
	 *
	 * @return void
	 */
	private static function render_panel() {
		settings_errors( 'devxpe_theme' );

		$sections = self::$sections;
		$first    = array_key_first( $sections );

		/*
		 * Son açık bölüm/alt bölüm (cookie) yüklenmeden önce uygulanır;
		 * böylece sayfa yenilesinde "varsayılan bölüm flaşı" olmaz.
		 * panel.js gezinmekte bu cookie'yi yazar.
		 */
		$dxp_last_sec = '';
		$dxp_last_sub = '';
		if ( isset( $_COOKIE['dxp_panel_last'] ) ) {
			$dxp_last = preg_replace( '/[^a-z0-9_\-]/i', '', wp_unslash( $_COOKIE['dxp_panel_last'] ) );
			if ( false !== strpos( $dxp_last, '--' ) ) {
				list( $dxp_last_sec, $dxp_last_sub ) = array_map( 'trim', explode( '--', $dxp_last, 2 ) );
			} else {
				$dxp_last_sec = $dxp_last;
			}
			if ( ! isset( $sections[ $dxp_last_sec ] ) ) {
				$dxp_last_sec = '';
			}
			if ( $dxp_last_sec && $dxp_last_sub && ! isset( $sections[ $dxp_last_sec ]['subsections'][ $dxp_last_sub ] ) ) {
				$dxp_last_sub = '';
			}
		}
		$active_sec = $dxp_last_sec ? $dxp_last_sec : $first;
		$active_sub = $dxp_last_sub ? $dxp_last_sub : array_key_first( (array) $sections[ $active_sec ]['subsections'] );
		?>
		<div id="devxpe-panel">
			<!-- Mobil overlay -->
			<div class="dxp-overlay"></div>

			<!-- ── Sol Sidebar ─────────────────────────────── -->
			<div id="devxpe-panel-left">

				<div class="dxp-logo">
					<a href="#">
						<div class="dxp-logo-icon">✦</div>
						DEVXPE Panel
					</a>
				</div>

				<div class="dxp-search">
					<span class="dxp-search-icon dashicons dashicons-search"></span>
					<input type="search" id="dxp-search" name="dxp_search" aria-label="<?php esc_attr_e( 'Ayarlarda ara', 'devxpe-theme' ); ?>" placeholder="<?php esc_attr_e( 'Ayarlarda ara…', 'devxpe-theme' ); ?>" autocomplete="off">
				</div>

				<ul class="dxp-nav">
					<?php foreach ( $sections as $section_id => $section ) :
						$has_sub = ! empty( $section['subsections'] ) && count( $section['subsections'] ) > 1;
					?>
					<li data-section="<?php echo esc_attr( $section_id ); ?>"
						    class="<?php echo $section_id === $active_sec ? 'active open' : ''; ?>">
						<a href="#<?php echo esc_attr( $section_id ); ?>">
							<span class="dxp-nav-icon dashicons <?php echo esc_attr( $section['icon'] ?? 'dashicons-admin-generic' ); ?>"></span>
							<span class="dxp-nav-label"><?php echo esc_html( $section['label'] ); ?></span><?php echo devxpe_section_has_new( $section ) ? ' <span class="dxp-new-badge">' . esc_html__( 'Yeni', 'devxpe-theme' ) . '</span>' : ''; // phpcs:ignore WordPress.Security.EscapeOutput ?><?php if ( 'form' === $section_id ) : ?><?php echo devxpe_form_unread_badge(); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php endif; ?>
							<?php if ( $has_sub ) : ?>
								<span class="dxp-arrow">▾</span>
							<?php endif; ?>
						</a>

						<?php if ( $has_sub ) : ?>
						<ul class="dxp-submenu">
							<?php foreach ( $section['subsections'] as $sub_id => $sub ) : ?>
							<li data-subsection="<?php echo esc_attr( $section_id . '-' . $sub_id ); ?>">
								<a href="#<?php echo esc_attr( $section_id . '--' . $sub_id ); ?>">
									<?php echo esc_html( $sub['label'] ); ?><?php echo devxpe_new_badge( $sub_id ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php if ( 'form' === $section_id && 'inbox' === $sub_id ) : ?><?php echo devxpe_form_unread_badge(); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php endif; ?>
								</a>
							</li>
							<?php endforeach; ?>
						</ul>
						<?php endif; ?>
					</li>
					<?php endforeach; ?>
				</ul>

			</div><!-- /devxpe-panel-left -->

			<!-- ── Sağ İçerik ──────────────────────────────── -->
			<div id="devxpe-panel-right">

				<div class="dxp-topbar">
					<button class="dxp-menu-toggle" aria-label="<?php esc_attr_e( 'Menüyü Aç', 'devxpe-theme' ); ?>" aria-expanded="false">
						&#9776;
					</button>
					<div class="dxp-page-title"><?php echo esc_html( $sections[ $active_sec ]['label'] ); ?></div>
					<div style="display: flex; gap: 8px; align-items: center;">
						<?php DEVXPE_Theme_Language::render_switcher(); ?>
						<div class="dxp-scale" role="group" aria-label="<?php esc_attr_e( 'Yazı boyutu', 'devxpe-theme' ); ?>">
							<button type="button" class="dxp-scale-btn" data-dxp-scale="-1" aria-label="<?php esc_attr_e( 'Küçült', 'devxpe-theme' ); ?>">&minus;</button>
							<span class="dxp-scale-value" title="<?php esc_attr_e( 'Yazı boyutu', 'devxpe-theme' ); ?>">Aa<small>3</small></span>
							<button type="button" class="dxp-scale-btn" data-dxp-scale="1" aria-label="<?php esc_attr_e( 'Büyüt', 'devxpe-theme' ); ?>">&plus;</button>
						</div>
						<button type="button" class="dxp-dark-mode-toggle" aria-label="<?php esc_attr_e( 'Toggle Dark Mode', 'devxpe-theme' ); ?>" title="<?php esc_attr_e( 'Dark/Light Mode', 'devxpe-theme' ); ?>">
							<span class="dashicons dashicons-visibility"></span>
						</button>
						<button type="submit" form="devxpe-panel-form" name="devxpe_theme_save" value="1" class="dxp-save-btn">
							<?php esc_html_e( 'Kaydet', 'devxpe-theme' ); ?>
						</button>
					</div>
				</div>

				<div class="dxp-content">
					<form id="devxpe-panel-form" method="post" action="" autocomplete="off" data-dxp-condition-sources="<?php echo esc_attr( implode( ',', self::condition_sources() ) ); ?>">
						<?php wp_nonce_field( 'devxpe_theme_save', 'devxpe_theme_nonce' ); ?>

						<?php foreach ( $sections as $section_id => $section ) : ?>
						<div class="dxp-section <?php echo $section_id === $active_sec ? 'active' : ''; ?>"
						     id="dxp-section-<?php echo esc_attr( $section_id ); ?>">

							<?php foreach ( $section['subsections'] as $sub_id => $sub ) : ?>
							<div class="dxp-subsection <?php echo ( $section_id === $active_sec && $sub_id === $active_sub ) ? 'active' : ''; ?>"
							     id="dxp-subsection-<?php echo esc_attr( $section_id . '-' . $sub_id ); ?>">

								<?php if ( $sub_id === 'demo' ) : ?>
									<?php self::render_demo(); ?>
								<?php elseif ( $sub_id === 'importexport' ) : ?>
									<?php self::render_importexport(); ?>
								<?php elseif ( 'form' === $section_id && 'inbox' === $sub_id ) : ?>
									<?php self::render_form_inbox(); ?>
								<?php elseif ( 'form' === $section_id && 'smtp' === $sub_id ) : ?>
									<?php self::render_smtp(); ?>
								<?php elseif ( 'settings' === $section_id && 'child' === $sub_id ) : ?>
									<?php self::render_child(); ?>
								<?php elseif ( 'settings' === $section_id && 'webp' === $sub_id ) : ?>
									<?php self::render_webp(); ?>
								<?php elseif ( 'about' === $section_id && 'about' === $sub_id ) : ?>
									<?php self::render_about(); ?>
								<?php elseif ( 'plugins' === $section_id && 'oneriler' === $sub_id ) : ?>
									<?php self::render_plugins(); ?>
								<?php elseif ( 'gorunum' === $section_id && 'katalog' === $sub_id ) : ?>
									<?php self::render_library(); ?>
								<?php elseif ( ! empty( $sub['tabs'] ) ) : ?>
									<?php self::render_tabs( $sub['tabs'] ); ?>
								<?php else : ?>
									<?php $sub_fields = isset( $sub['fields'] ) ? (array) $sub['fields'] : array(); ?>
									<div class="dxp-card">
										<div class="dxp-card-header">
											<?php echo esc_html( $sub['label'] ); ?><?php echo devxpe_new_badge( $sub_id ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
										</div>
										<?php if ( ! empty( $sub_fields ) ) : ?>
											<?php self::render_field_rows( $sub_fields ); ?>
										<?php endif; ?>
										<?php if ( ! empty( $sub['groups'] ) && self::groups_visible( $sub['groups'] ) ) : ?>
											<div class="dxp-card-groups">
												<?php self::render_field_groups( $sub['groups'] ); ?>
											</div>
										<?php endif; ?>
									</div>
								<?php endif; ?>

							</div><!-- /subsection -->
							<?php endforeach; ?>

						</div><!-- /section -->
						<?php endforeach; ?>

						<div class="dxp-no-results"><?php esc_html_e( 'Aramanızla eşleşen bir ayar bulunamadı.', 'devxpe-theme' ); ?></div>

					</form>
				</div>

			</div><!-- /devxpe-panel-right -->

		</div><!-- /devxpe-panel -->
		<?php
	}

	/**
	 * Alan listesini satır satır çizer.
	 *
	 * @param array $field_ids Alan id listesi.
	 * @return void
	 */
	private static function render_field_rows( $field_ids ) {
		foreach ( (array) $field_ids as $field_id ) :
			$field = DEVXPE_Theme_Fields::all()[ $field_id ] ?? null;
			if ( ! $field ) continue;
			self::render_row( $field_id, $field, DEVXPE_Theme_Fields::get( $field_id ) );
		endforeach;
	}

	/**
	 * Alan listesini iç içe gruplara ayırarak çizer.
	 *
	 * Her grup kendi başlığına ve sütun sayısına sahiptir; panelde
	 * uzun alan listelerinin alt alta kaybolmasını engeller.
	 *
	 * @param array $groups array( array( 'label', 'cols', 'fields' ) ).
	 * @return void
	 */
	private static function render_field_groups( $groups ) {
		foreach ( (array) $groups as $group ) :
			/*
			 * Grup seviyesinde koşul: 'depends' => ... sağlanmıyorsa grup
			 * (başlık + alanlar) HTML'e hiç basılmaz.
			 */
			$dep = isset( $group['depends'] ) ? (array) $group['depends'] : array();
			if ( ! DEVXPE_Theme_Conditions::met( $dep ) ) {
				continue;
			}

			/*
			 * Grup içindeki tüm alanlar koşul nedeniyle gizleniyorsa boş
			 * kutu/başlık kalmaması için grubun tamamı atlanır.
			 */
			if ( ! self::group_has_visible_fields( $group ) ) {
				continue;
			}

			/*
			 * cols: sayı verilirse eşit sütunlar; metin verilirse doğrudan
			 * CSS track listesi kullanılır (ör. '72px 1fr 1fr' → ikon sütunu
			 * dar olur, yanındaki alanla arasında boşluk kalmaz).
			 */
			$cols = isset( $group['cols'] ) ? $group['cols'] : 1;
			$tpl  = is_numeric( $cols ) ? 'repeat(' . max( 1, (int) $cols ) . ', minmax(0, 1fr))' : (string) $cols;
			?>
			<div class="dxp-field-group" style="--dxp-grid-template:<?php echo esc_attr( $tpl ); ?>;">
				<?php if ( ! empty( $group['label'] ) ) : ?>
					<div class="dxp-field-group-label"><?php echo esc_html( $group['label'] ); ?></div>
				<?php endif; ?>
				<div class="dxp-field-group-grid">
					<?php self::render_field_rows( $group['fields'] ?? array() ); ?>
				</div>
			</div>
			<?php
		endforeach;
	}

	/**
	 * Bir alanın koşulu sağlanıyor mu (sunucu tarafı görünürlük).
	 *
	 * @param string $field_id Alan kimliği.
	 * @return bool
	 */
	private static function field_visible( $field_id ) {
		$all = DEVXPE_Theme_Fields::all();
		if ( ! isset( $all[ $field_id ] ) ) {
			return false; /* Tanımsız alan render edilmez. */
		}
		$dep = isset( $all[ $field_id ]['depends'] ) ? (array) $all[ $field_id ]['depends'] : array();
		return DEVXPE_Theme_Conditions::met( $dep );
	}

	/**
	 * Bir grupta görünür en az bir alan var mı.
	 *
	 * @param array $group Grup tanımı.
	 * @return bool
	 */
	private static function group_has_visible_fields( $group ) {
		foreach ( (array) ( $group['fields'] ?? array() ) as $field_id ) {
			if ( self::field_visible( $field_id ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Verilen gruplardan görünür olan var mı (kart kapsayıcısını basmak için).
	 *
	 * @param array $groups Grup listesi.
	 * @return bool
	 */
	private static function groups_visible( $groups ) {
		foreach ( (array) $groups as $group ) {
			$dep = isset( $group['depends'] ) ? (array) $group['depends'] : array();
			if ( DEVXPE_Theme_Conditions::met( $dep ) && self::group_has_visible_fields( $group ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Tüm koşul kurallarının kaynak aldığı alan adlarını toplar.
	 *
	 * Alan kuralları Fields kaydından, grup kuralları section yapısından
	 * gelir. panel.js bu listeyi kullanarak yalnızca bu alanlar değişince
	 * formu normal POST ile gönderir (PHP görünürlüğü yeniden hesaplar).
	 *
	 * @return array Benzersiz alan adları.
	 */
	private static function condition_sources() {
		$rules = array();

		foreach ( DEVXPE_Theme_Fields::all() as $field ) {
			if ( ! empty( $field['depends'] ) ) {
				$rules[] = (array) $field['depends'];
			}
		}

		self::collect_depends( self::$sections, $rules );

		return DEVXPE_Theme_Conditions::sources( $rules );
	}

	/**
	 * Bir section ağacındaki 'depends' anahtarlarını özyinelemeli toplar.
	 *
	 * @param array $node  Ağaç düğümü.
	 * @param array $rules Toplanan kurallar (referans).
	 * @return void
	 */
	private static function collect_depends( $node, &$rules ) {
		if ( ! is_array( $node ) ) {
			return;
		}
		foreach ( $node as $key => $value ) {
			if ( 'depends' === $key && is_array( $value ) ) {
				$rules[] = $value;
				continue;
			}
			if ( is_array( $value ) ) {
				self::collect_depends( $value, $rules );
			}
		}
	}

	/**
	 * Sekmeli alt bölümü çizer (ör. Header | Footer).
	 *
	 * @param array $tabs tab_id => array( 'label', 'fields', 'groups', 'html' ).
	 * @return void
	 */
	private static function render_tabs( $tabs ) {
		/*
		 * İçeriği tamamen gizlenen sekmeleri (ne alan, ne grup, ne hazır HTML)
		 * başlık olarak da basma. Kural motoru FAIL-OPEN çalıştığı için
		 * koşulsuz sekmeler her zaman görünür kalır.
		 */
		$visible = array();
		foreach ( (array) $tabs as $tab_id => $tab ) {
			if ( self::tab_visible( $tab ) ) {
				$visible[ $tab_id ] = $tab;
			}
		}

		if ( empty( $visible ) ) {
			return;
		}

		$first = array_key_first( $visible );
		?>
		<div class="dxp-card dxp-tabs">
			<div class="dxp-tabs-nav">
				<?php foreach ( $visible as $tab_id => $tab ) : ?>
				<button type="button" class="dxp-tab<?php echo $tab_id === $first ? ' active' : ''; ?>" data-tab="<?php echo esc_attr( $tab_id ); ?>">
					<?php echo esc_html( $tab['label'] ); ?>
				</button>
				<?php endforeach; ?>
			</div>

			<?php foreach ( $visible as $tab_id => $tab ) : ?>
			<div class="dxp-tab-panel<?php echo $tab_id === $first ? ' active' : ''; ?>" data-tab-panel="<?php echo esc_attr( $tab_id ); ?>">
				<?php if ( ! empty( $tab['fields'] ) ) : ?>
					<?php self::render_field_rows( $tab['fields'] ); ?>
				<?php endif; ?>
				<?php if ( ! empty( $tab['groups'] ) && self::groups_visible( $tab['groups'] ) ) : ?>
					<div class="dxp-card-groups">
						<?php self::render_field_groups( $tab['groups'] ); ?>
					</div>
				<?php endif; ?>
			</div>
			<?php endforeach; ?>
		</div>
		<?php
	}

	/**
	 * Bir sekmede görünür içerik var mı (alan, grup veya hazır HTML).
	 *
	 * @param array $tab Sekme tanımı.
	 * @return bool
	 */
	private static function tab_visible( $tab ) {
		foreach ( (array) ( $tab['fields'] ?? array() ) as $field_id ) {
			if ( self::field_visible( $field_id ) ) {
				return true;
			}
		}
		if ( self::groups_visible( $tab['groups'] ?? array() ) ) {
			return true;
		}
		return false;
	}

	/**
	 * Tek bir form satırı render eder.
	 *
	 * @param string $field_id Alan kimliği.
	 * @param array  $field    Alan tanımı.
	 * @param mixed  $value    Mevcut değer.
	 * @return void
	 */
	private static function render_row( $field_id, $field, $value ) {
		/*
		 * Yalnızca tek bir input'u (id="dxp_{field_id}") olan tiplerde label'ın
		 * for'u o inputa bağlanır. Birleşik tiplerde (radio_image, pages,
		 * page_hero, icon, team, typography) for verilmez; aksi halde for var
		 * olmayan bir id'yi gösterip "Incorrect use of label for" hatası verir.
		 */
		$single_input_types = array( 'text', 'textarea', 'scripts', 'checkbox', 'url', 'email', 'tel', 'color', 'image' );
		$type               = isset( $field['type'] ) ? $field['type'] : 'text';
		$has_for            = in_array( $type, $single_input_types, true );

		/*
		 * Koşullu alan: 'depends' tanımlıysa ve koşul sağlanmıyorsa satır
		 * HTML'e HİÇ basılmaz (istemci tarafı display:none/JS yok).
		 * DEVXPE_Theme_Conditions::met FAIL-OPEN çalışır: kural eksik/bozuksa
		 * alan gösterilir.
		 */
		$depends = isset( $field['depends'] ) ? (array) $field['depends'] : array();
		if ( ! DEVXPE_Theme_Conditions::met( $depends ) ) {
			return;
		}

		/*
		 * Geniş içerikli tipler (form oluşturucu, tekrarlayıcı, seçim listeleri)
		 * iki sütuna sığmaz; grup ızgarasında tam satır kaplar.
		 */
		$wide_types = array(
			'scripts', 'form_builder', 'form_fields', 'rows', 'cards', 'projects', 'cpts',
			'sections', 'forms', 'pages', 'team', 'logos',
			'typography', 'radio_image',
		);
		$row_class = in_array( $type, $wide_types, true ) ? ' dxp-row-wide' : '';

		/*
		 * Geniş içerikli tipler (form oluşturucu): başlık üstte, içerik tam
		 * genişlikte altta; iki sütunlu sıkışık düzen kullanılmaz.
		 */
		if ( 'form_builder' === $type ) :
			?>
			<div class="dxp-row dxp-row-full<?php echo esc_attr( $row_class ); ?>">
				<div class="dxp-label"><span class="dxp-label-text"><?php echo esc_html( $field['label'] ); ?></span></div>
				<div>
					<?php DEVXPE_Theme_Fields::render_input( $field_id, $field, $value ); ?>
				</div>
				<?php if ( ! empty( $field['help'] ) ) : ?>
				<div class="dxp-desc"><?php echo esc_html( $field['help'] ); ?></div>
				<?php endif; ?>
			</div>
			<?php
			return;
		endif;
		?>
		<div class="dxp-row<?php echo esc_attr( $row_class ); ?>">
			<div>
				<div class="dxp-label">
					<?php if ( $has_for ) : ?>
					<label for="dxp_<?php echo esc_attr( $field_id ); ?>"><?php echo esc_html( $field['label'] ); ?></label>
					<?php else : ?>
					<span class="dxp-label-text"><?php echo esc_html( $field['label'] ); ?></span>
					<?php endif; ?>
				</div>
			</div>
			<div>
				<?php DEVXPE_Theme_Fields::render_input( $field_id, $field, $value ); ?>
				<?php if ( ! empty( $field['help'] ) ) : ?>
				<div class="dxp-desc"><?php echo esc_html( $field['help'] ); ?></div>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	/**
	 * SMTP ayarları + test e-postası bölümü.
	 *
	 * Test butonu, panel formunun içinden `formaction` ile admin-post.php'ye
	 * gider (iç içe form geçersiz olurdu). panel.js formaction'lı butonu
	 * AJAX kaydından muaf tutar.
	 *
	 * @return void
	 */
	private static function render_smtp() {
		$notice = isset( $_GET['dxp_smtp'] ) ? sanitize_key( wp_unslash( $_GET['dxp_smtp'] ) ) : '';
		$detail = get_transient( 'devxpe_smtp_notice' );

		if ( $detail ) {
			delete_transient( 'devxpe_smtp_notice' );
		}

		$to_list = devxpe_form_recipients();
		$to_first = $to_list ? $to_list[0] : (string) get_option( 'admin_email' );
		?>
		<div class="dxp-card">
			<div class="dxp-card-header"><?php esc_html_e( 'SMTP Ayarları', 'devxpe-theme' ); ?></div>
			<?php
			self::render_field_rows(
				array( 'smtp_enable', 'smtp_host', 'smtp_port', 'smtp_encryption', 'smtp_auth', 'smtp_user', 'smtp_pass', 'smtp_from_email', 'smtp_from_name' )
			);
			?>
		</div>

		<div class="dxp-card">
			<div class="dxp-card-header"><?php esc_html_e( 'Test E-postası', 'devxpe-theme' ); ?></div>
			<div class="dxp-row">
				<div>
					<div class="dxp-label"><span class="dxp-label-text"><?php esc_html_e( 'Test Alıcısı', 'devxpe-theme' ); ?></span></div>
					<div class="dxp-desc"><?php esc_html_e( 'Önce ayarları kaydet, sonra test et. Test, kayıtlı ayarlarla gönderilir.', 'devxpe-theme' ); ?></div>
				</div>
				<div>
					<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
						<input type="hidden" name="action" value="devxpe_smtp_test" />
						<input type="hidden" name="dxp_smtp_nonce" value="<?php echo esc_attr( wp_create_nonce( 'devxpe_smtp_test' ) ); ?>" />
						<input type="email" name="dxp_smtp_to" value="<?php echo esc_attr( $to_first ); ?>" />
						<button type="submit" class="button button-primary" formaction="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" formmethod="post">
							<?php esc_html_e( 'Test Gönder', 'devxpe-theme' ); ?>
						</button>
					</div>
					<?php if ( $notice ) : ?>
					<p class="dxp-desc" style="font-weight:600;color:<?php echo 'ok' === $notice ? '#15803d' : '#dc2626'; ?>;">
						<?php
						echo esc_html(
							$detail ? $detail : ( 'ok' === $notice
								? __( 'Test e-postası gönderildi. Gelen kutunu kontrol et.', 'devxpe-theme' )
								: __( 'Gönderim başarısız.', 'devxpe-theme' ) )
						);
						?>
					</p>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Form mesaj kutusunu çizer.
	 *
	 * @return void
	 */
	private static function render_form_inbox() {
		$entries    = devxpe_form_entries();
		$unread     = devxpe_form_unread_count();
		$read_all   = wp_nonce_url( admin_url( 'admin-post.php?action=devxpe_form_read&scope=all&okundu=1' ), 'devxpe_form_read' );
		$unread_all = wp_nonce_url( admin_url( 'admin-post.php?action=devxpe_form_read&scope=unread&okundu=0' ), 'devxpe_form_read' );
		?>
		<div class="dxp-card">
			<div class="dxp-card-header">
				<span>
					<?php esc_html_e( 'Gelen Mesajlar', 'devxpe-theme' ); ?>
					<?php if ( $unread > 0 ) : ?>
						<span class="dxp-count-badge"><?php echo esc_html( number_format_i18n( $unread ) ); ?></span>
						<?php
						/* translators: %d: okunmamış mesaj sayısı. */
						echo esc_html( sprintf( __( '(%d okunmadı)', 'devxpe-theme' ), $unread ) );
						?>
					<?php endif; ?>
				</span>
				<?php if ( $entries ) : ?>
				<span class="dxp-inbox-bulk">
					<a class="button" href="<?php echo esc_url( $read_all ); ?>"><?php esc_html_e( 'Tümünü okundu işaretle', 'devxpe-theme' ); ?></a>
					<a class="button" href="<?php echo esc_url( $unread_all ); ?>"><?php esc_html_e( 'Tümünü okunmadı say', 'devxpe-theme' ); ?></a>
				</span>
				<?php endif; ?>
			</div>

			<?php if ( ! $entries ) : ?>
			<div class="dxp-row" style="grid-template-columns:1fr;">
				<div>
					<p class="dxp-desc"><?php esc_html_e( 'Henüz mesaj yok. Ziyaretçiler formu doldurduğunda mesajlar burada listelenir ve belirtilen e-posta adresine gönderilir.', 'devxpe-theme' ); ?></p>
				</div>
			</div>
			<?php else : ?>
			<div class="dxp-inbox" id="dxp-inbox"
				data-read-url="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>"
				data-read-nonce="<?php echo esc_attr( wp_create_nonce( 'devxpe_form_read' ) ); ?>">
				<div class="dxp-inbox-list">
				<?php foreach ( $entries as $entry ) : ?>
					<?php
					$del_url = wp_nonce_url(
						admin_url( 'admin-post.php?action=devxpe_form_delete&id=' . rawurlencode( isset( $entry['id'] ) ? $entry['id'] : '' ) ),
						'devxpe_form_delete'
					);

					/* Okundu durumu: satır vurgusu ve "Okundu/Okunmadı" bağlantısı. */
					$dxp_unread = devxpe_form_is_unread( $entry );
					$read_url   = wp_nonce_url(
						admin_url( 'admin-post.php?action=devxpe_form_read&scope=one&okundu=' . ( $dxp_unread ? '1' : '0' ) . '&id=' . rawurlencode( isset( $entry['id'] ) ? $entry['id'] : '' ) ),
						'devxpe_form_read'
					);

					/* Detay görünümü verisi: JS, data-msg'den okuyup çizer. */
					$dxp_labels = devxpe_form_field_labels();
					$dxp_skip   = array( 'id', 'time', 'ip', 'read', 'mail_subject', 'mail_body' );
					$dxp_fields = array();
					foreach ( (array) $entry as $dxp_key => $dxp_val ) {
						if ( in_array( $dxp_key, $dxp_skip, true ) ) {
							continue;
						}
						if ( '' === (string) $dxp_val ) {
							continue;
						}
						$dxp_fields[] = array(
							'key'   => $dxp_key,
							'label' => isset( $dxp_labels[ $dxp_key ] ) ? $dxp_labels[ $dxp_key ] : $dxp_key,
							'value' => (string) $dxp_val,
						);
					}
					$dxp_msg = array(
						'mail_subject' => isset( $entry['mail_subject'] ) ? (string) $entry['mail_subject'] : '',
						'mail_body'    => isset( $entry['mail_body'] ) ? (string) $entry['mail_body'] : '',
						'time'         => isset( $entry['time'] ) ? (string) $entry['time'] : '',
						'service'      => isset( $entry['service'] ) ? (string) $entry['service'] : '',
						'ip'           => isset( $entry['ip'] ) ? (string) $entry['ip'] : '',
						'name'         => isset( $entry['name'] ) ? (string) $entry['name'] : '',
						'email'        => isset( $entry['email'] ) ? (string) $entry['email'] : '',
						'phone'        => isset( $entry['phone'] ) ? (string) $entry['phone'] : '',
						'fields'       => $dxp_fields,
					);
					?>
				<div class="dxp-inbox-item<?php echo $dxp_unread ? ' is-unread' : ''; ?>" role="button" tabindex="0" aria-expanded="false" data-id="<?php echo esc_attr( isset( $entry['id'] ) ? (string) $entry['id'] : '' ); ?>" data-msg="<?php echo esc_attr( wp_json_encode( $dxp_msg ) ); ?>">
					<div class="dxp-inbox-head">
						<strong><?php echo esc_html( isset( $entry['name'] ) && '' !== (string) $entry['name'] ? $entry['name'] : '—' ); ?></strong>
						<span class="dxp-inbox-actions">
							<a class="dxp-inbox-read" href="<?php echo esc_url( $read_url ); ?>"><?php echo esc_html( $dxp_unread ? __( 'Okunmadı', 'devxpe-theme' ) : __( 'Okundu', 'devxpe-theme' ) ); ?></a>
							<a class="dxp-inbox-del" href="<?php echo esc_url( $del_url ); ?>"><?php esc_html_e( 'Sil', 'devxpe-theme' ); ?></a>
						</span>
					</div>
					<div class="dxp-inbox-meta">
						<?php if ( ! empty( $entry['service'] ) ) : ?>
						<span class="dxp-inbox-service"><?php echo esc_html( $entry['service'] ); ?></span>
						<?php endif; ?>
						<time><?php echo esc_html( isset( $entry['time'] ) ? $entry['time'] : '' ); ?></time>
					</div>
					<div class="dxp-inbox-body">
						<?php if ( ! empty( $entry['phone'] ) ) : ?>
						<a href="tel:<?php echo esc_attr( preg_replace( '/\s+/', '', $entry['phone'] ) ); ?>"><?php echo esc_html( $entry['phone'] ); ?></a>
						<?php endif; ?>
						<?php if ( ! empty( $entry['email'] ) ) : ?>
						<a href="mailto:<?php echo esc_attr( $entry['email'] ); ?>"><?php echo esc_html( $entry['email'] ); ?></a>
						<?php endif; ?>
						<?php if ( ! empty( $entry['postcode'] ) ) : ?>
						<span><?php echo esc_html( $entry['postcode'] ); ?></span>
						<?php endif; ?>
					</div>
				</div>
				<?php endforeach; ?>
				</div>
				<div class="dxp-inbox-detail">
					<button type="button" class="dxp-inbox-back"><?php esc_html_e( '← Geri', 'devxpe-theme' ); ?></button>
					<div class="dxp-inbox-detail-inner"></div>
				</div>
			</div>

			<p style="padding:0 16px 16px;">
				<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=devxpe_form_delete&id=all' ), 'devxpe_form_delete' ) ); ?>" onclick="return confirm('<?php echo esc_js( __( 'Tüm mesajlar silinsin mi?', 'devxpe-theme' ) ); ?>');">
					<?php esc_html_e( 'Tümünü Sil', 'devxpe-theme' ); ?>
				</a>
			</p>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Demo paketi arayüzünü render eder.
	 *
	 * @return void
	 */
	private static function render_demo() {
		$installed   = DEVXPE_Theme_Demo::is_installed();
		$lang        = DEVXPE_Theme_Demo::lang();
		$status      = isset( $_GET['demo'] ) ? sanitize_key( wp_unslash( $_GET['demo'] ) ) : '';
		$demos       = class_exists( 'DEVXPE_Theme_Demos' ) ? DEVXPE_Theme_Demos::all() : array();
		$demo_id     = class_exists( 'DEVXPE_Theme_Demos' ) ? DEVXPE_Theme_Demos::active_id() : 'arc';
		$demo_adi    = ( isset( $demos[ $demo_id ]['label'] ) ) ? (string) $demos[ $demo_id ]['label'] : $demo_id;
		$image_count = DEVXPE_Theme_Demo::image_count();

		$install_url = wp_nonce_url( admin_url( 'admin-post.php?action=devxpe_demo_install&demo=' . rawurlencode( $demo_id ) ), 'devxpe_demo_install' );
		$remove_url  = wp_nonce_url( admin_url( 'admin-post.php?action=devxpe_demo_remove' ), 'devxpe_demo_remove' );
		?>
		<div class="dxp-card">
			<div class="dxp-card-header"><?php esc_html_e( 'Demo Paketi', 'devxpe-theme' ); ?><?php echo devxpe_new_badge( 'demo' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
			<div class="dxp-row" style="grid-template-columns:1fr;">
				<div class="dxp-scripts-field">
					<?php if ( 'installed' === $status ) : ?>
					<div class="dxp-notice dxp-notice--ok">
						<strong><?php esc_html_e( 'Demo paketi kuruldu.', 'devxpe-theme' ); ?></strong>
						<?php esc_html_e( 'Sayfalar, yazılar, içerik tipleri ve demo fotoğrafları hazır.', 'devxpe-theme' ); ?>
					</div>
					<?php elseif ( 'removed' === $status ) : ?>
					<div class="dxp-notice dxp-notice--warn">
						<strong><?php esc_html_e( 'Demo paketi kaldırıldı.', 'devxpe-theme' ); ?></strong>
						<?php esc_html_e( 'Tüm demo fotoğrafları Media kitaplığından silindi ve önceki ayarlarınız geri yüklendi.', 'devxpe-theme' ); ?>
						<br />
						<?php esc_html_e( 'Bu fotoğrafları tekrar görmek isterseniz demo paketini (gerekirse temayı) yeniden kurmanız gerekir.', 'devxpe-theme' ); ?>
					</div>
					<?php endif; ?>

					<p class="dxp-desc"><?php esc_html_e( 'Tek tıkla örnek site kurar: sayfalar (Anasayfa, Hakkımızda, İletişim, Blog, yasal), hizmet/bölge kayıtları, blog yazıları, menü ve demo fotoğrafları. Renk ayarlarınıza dokunulmaz.', 'devxpe-theme' ); ?></p>

					<?php /* Demo seçici: birden çok demo (tasarım) varsa hangisinin kurulacağını belirler. */ ?>
					<?php if ( count( $demos ) > 1 ) : ?>
					<div class="dxp-demo-pick" id="dxp-demo-pick">
						<div class="dxp-demo-pick-label"><?php esc_html_e( 'Demo seçin', 'devxpe-theme' ); ?></div>
						<div class="dxp-demo-pick-list">
							<?php foreach ( $demos as $d_id => $d_tanim ) : ?>
							<label class="dxp-demo-pick-item<?php echo ( $d_id === $demo_id ) ? ' is-active' : ''; ?>">
								<input type="radio" name="dxp_demo_pick" value="<?php echo esc_attr( $d_id ); ?>" <?php checked( $d_id, $demo_id ); ?> />
								<span class="dxp-demo-pick-body">
									<span class="dxp-demo-pick-name"><?php echo esc_html( $d_tanim['label'] ); ?></span>
									<?php if ( ! empty( $d_tanim['description'] ) ) : ?>
									<span class="dxp-demo-pick-desc"><?php echo esc_html( $d_tanim['description'] ); ?></span>
									<?php endif; ?>
								</span>
							</label>
							<?php endforeach; ?>
						</div>
					</div>
					<?php endif; ?>

					<p class="dxp-desc">
						<?php
						printf(
							/* translators: 1: demo adı, 2: dil adı, 3: fotoğraf sayısı. */
							esc_html__( 'Demo: %1$s · Metin dili: %2$s (panel dilinize göre). Katalogdan %3$d fotoğraf + 2 logo indirilir.', 'devxpe-theme' ),
							'<strong>' . esc_html( $demo_adi ) . '</strong>',
							'<strong>' . esc_html( 'en' === $lang ? 'English' : 'Türkçe' ) . '</strong>',
							absint( $image_count )
						);
						?>
					</p>

					<p style="display:flex;gap:10px;align-items:center;margin-top:12px;">
						<a class="button button-primary" id="dxp-demo-install-btn" href="<?php echo esc_url( $install_url ); ?>"
							data-nonce="<?php echo esc_attr( wp_create_nonce( 'devxpe_demo_step' ) ); ?>"
							data-lang="<?php echo esc_attr( $lang ); ?>"
							data-demo="<?php echo esc_attr( $demo_id ); ?>"><?php esc_html_e( 'Demo paketini kur', 'devxpe-theme' ); ?></a>
						<?php if ( $installed ) : ?>
						<button type="button" class="button" id="dxp-demo-remove-btn"
							data-remove-url="<?php echo esc_url( $remove_url ); ?>">
							<?php esc_html_e( 'Demo paketini kaldır', 'devxpe-theme' ); ?>
						</button>
						<?php endif; ?>
					</p>

					<?php if ( $installed ) : ?>
					<p class="dxp-desc"><?php esc_html_e( 'Şu anda kurulu. Kaldırınca demo kayıtları, menü ve demo fotoğrafları silinir; kaldırmadan önceki ayarlarınız geri yüklenir.', 'devxpe-theme' ); ?></p>
					<?php endif; ?>
				</div>
			</div>
		</div>

		<?php /* Kurulum kilidi: ilerleme %0→%100. Kapatma yok; bitince sayfa yenilenir. */ ?>
		<div class="dxp-demo-lock" id="dxp-demo-lock" hidden>
			<div class="dxp-demo-lock-box" role="alertdialog" aria-live="polite" aria-labelledby="dxp-demo-lock-title">
				<h3 class="dxp-demo-lock-title" id="dxp-demo-lock-title"><?php esc_html_e( 'Demo kuruluyor', 'devxpe-theme' ); ?></h3>
				<div class="dxp-demo-lock-bar"><span class="dxp-demo-lock-fill" id="dxp-demo-lock-fill"></span></div>
				<div class="dxp-demo-lock-info">
					<span class="dxp-demo-lock-yuzde" id="dxp-demo-lock-yuzde">0%</span>
					<span class="dxp-demo-lock-mesaj" id="dxp-demo-lock-mesaj"></span>
				</div>
				<p class="dxp-demo-lock-note"><?php esc_html_e( 'Görseller internetten indirildiği için bu işlem birkaç dakika sürebilir. Kurulum bitene kadar panel kilitlidir — lütfen bekleyin.', 'devxpe-theme' ); ?></p>
				<p class="dxp-demo-lock-error" id="dxp-demo-lock-error" hidden></p>
				<button type="button" class="button" id="dxp-demo-lock-retry" hidden><?php esc_html_e( 'Tekrar dene', 'devxpe-theme' ); ?></button>
			</div>
		</div>

		<?php /* Kurulum öncesi onay */ ?>
		<div class="dxp-modal" id="dxp-demo-install-modal" hidden>
			<div class="dxp-modal-backdrop" data-dxp-demo-install-close></div>
			<div class="dxp-modal-box" role="dialog" aria-modal="true" aria-labelledby="dxp-demo-install-title">
				<h2 class="dxp-modal-title" id="dxp-demo-install-title"><?php esc_html_e( 'Demo paketi kurulsun mu?', 'devxpe-theme' ); ?></h2>
				<div class="dxp-modal-body">
					<p><?php esc_html_e( 'Şunlar kurulacak:', 'devxpe-theme' ); ?></p>
					<ul class="dxp-modal-list">
						<li><?php esc_html_e( 'Sayfalar (Anasayfa, Hakkımızda, İletişim, Blog, yasal sayfalar)', 'devxpe-theme' ); ?></li>
						<li><?php esc_html_e( 'Hizmet ve bölge kayıtları, blog yazıları, menü', 'devxpe-theme' ); ?></li>
						<li>
							<?php
							printf(
								/* translators: %d: fotoğraf sayısı. */
								esc_html__( 'Media kitaplığına %d demo fotoğrafı indirilir (internetten)', 'devxpe-theme' ),
								absint( $image_count )
							);
							?>
						</li>
					</ul>

					<?php /* Dil uyarısı: demo içeriği panel diline göre kurulur. */ ?>
					<div class="dxp-notice dxp-notice--warn dxp-demo-lang-note">
						<strong><?php esc_html_e( 'Dil bilgisi', 'devxpe-theme' ); ?></strong>
						<?php
						printf(
							/* translators: %s: geçerli dil adı (Türkçe/English). */
							esc_html__( 'Demo içeriğinin dili panel dilinize göre kurulur; şu anda %s. Kurulumdan sonra demoyu kaldırıp diğer dille yeniden kurabilirsiniz.', 'devxpe-theme' ),
							'<strong>' . esc_html( 'en' === $lang ? 'English' : 'Türkçe' ) . '</strong>'
						);
						?>
					</div>

					<p class="dxp-desc"><?php esc_html_e( 'Kurulum birkaç dakika sürebilir ve bu süre boyunca panel kilitli kalır. Mevcut demo içeriği yenilenir.', 'devxpe-theme' ); ?></p>
				</div>
				<div class="dxp-modal-actions">
					<button type="button" class="button" data-dxp-demo-install-close><?php esc_html_e( 'Vazgeç', 'devxpe-theme' ); ?></button>
					<button type="button" class="button button-primary" id="dxp-demo-install-confirm"><?php esc_html_e( 'Evet, kur', 'devxpe-theme' ); ?></button>
				</div>
			</div>
		</div>

		<?php if ( $installed ) : ?>
		<div class="dxp-modal" id="dxp-demo-modal" hidden>
			<div class="dxp-modal-backdrop" data-dxp-demo-close></div>
			<div class="dxp-modal-box" role="dialog" aria-modal="true" aria-labelledby="dxp-demo-modal-title">
				<h2 class="dxp-modal-title" id="dxp-demo-modal-title"><?php esc_html_e( 'Demo paketi kaldırılsın mı?', 'devxpe-theme' ); ?></h2>
				<div class="dxp-modal-body">
					<p><?php esc_html_e( 'Bu işlem geri alınamaz. Şunlar silinir:', 'devxpe-theme' ); ?></p>
					<ul class="dxp-modal-list">
						<li><?php esc_html_e( 'Demo sayfaları, blog yazıları, hizmet ve bölge kayıtları', 'devxpe-theme' ); ?></li>
						<li><?php esc_html_e( 'Demo menüsü', 'devxpe-theme' ); ?></li>
						<li>
							<strong>
								<?php
								printf(
									/* translators: %d: fotoğraf sayısı. */
									esc_html__( 'Media kitaplığındaki tüm demo fotoğrafları (%d fotoğraf + 2 logo)', 'devxpe-theme' ),
									absint( $image_count )
								);
								?>
							</strong>
						</li>
					</ul>
					<div class="dxp-notice dxp-notice--warn">
						<?php esc_html_e( 'Uyarı: Demo fotoğraflarını tekrar görmek isterseniz demo paketini (gerekirse temayı) yeniden kurmanız gerekir.', 'devxpe-theme' ); ?>
					</div>
					<p class="dxp-desc"><?php esc_html_e( 'Tema ayarları, kaldırmadan önceki hâline döner.', 'devxpe-theme' ); ?></p>
				</div>
				<div class="dxp-modal-actions">
					<button type="button" class="button" data-dxp-demo-close><?php esc_html_e( 'Vazgeç', 'devxpe-theme' ); ?></button>
					<a class="button button-primary" id="dxp-demo-confirm" href="#"><?php esc_html_e( 'Evet, kaldır', 'devxpe-theme' ); ?></a>
				</div>
			</div>
		</div>
		<?php endif; ?>
		<?php
	}

	/**
	 * Import/Export arayüzünü render eder.
	 *
	 * @return void
	 */
	private static function render_importexport() {
		$export = wp_json_encode( get_option( DEVXPE_Theme_Fields::OPTION_KEY, array() ), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE );
		?>
		<div class="dxp-card">
			<div class="dxp-card-header">📤 <?php esc_html_e( 'Dışa Aktar', 'devxpe-theme' ); ?></div>
			<div class="dxp-row" style="grid-template-columns:1fr;">
				<div class="dxp-scripts-field">
					<p class="dxp-desc"><?php esc_html_e( 'Ayarlarınızı yedeklemek için aşağıdaki JSON\'u kopyalayın.', 'devxpe-theme' ); ?></p>
					<textarea id="dxp-export-data" aria-label="<?php esc_attr_e( 'Dışa aktarılacak ayarlar (JSON)', 'devxpe-theme' ); ?>" readonly><?php echo esc_textarea( $export ); ?></textarea>
					<div class="dxp-ie-actions">
						<button type="button" id="dxp-copy-export" class="button">
							<?php esc_html_e( 'Kopyala', 'devxpe-theme' ); ?>
						</button>
						<button type="button" id="dxp-download-export" class="button">
							<?php esc_html_e( 'JSON İndir', 'devxpe-theme' ); ?>
						</button>
					</div>
				</div>
			</div>
		</div>
		<div class="dxp-card">
			<div class="dxp-card-header">📥 <?php esc_html_e( 'İçe Aktar', 'devxpe-theme' ); ?></div>
			<div class="dxp-row" style="grid-template-columns:1fr;">
				<div class="dxp-scripts-field">
					<p class="dxp-desc"><?php esc_html_e( 'Yedek JSON\'unuzu yapıştırın ya da dosyadan seçin, ardından İçe Aktar butonuna tıklayın.', 'devxpe-theme' ); ?></p>

					<div class="dxp-file">
						<input type="file" id="dxp-import-file" accept="application/json,.json" class="dxp-file-input" />
						<label for="dxp-import-file" class="button dxp-file-btn">
							<span class="dashicons dashicons-upload" aria-hidden="true"></span>
							<?php esc_html_e( 'Dosya Seç', 'devxpe-theme' ); ?>
						</label>
						<span class="dxp-file-name" id="dxp-import-file-name" aria-live="polite"><?php esc_html_e( 'Dosya seçilmedi', 'devxpe-theme' ); ?></span>
					</div>

					<textarea name="devxpe_theme_import_data" aria-label="<?php esc_attr_e( 'İçe aktarılacak ayarlar (JSON)', 'devxpe-theme' ); ?>" placeholder="{ ... }"></textarea>
					<div class="dxp-ie-actions">
						<button type="submit" name="devxpe_theme_import" value="1" class="button button-primary">
							<?php esc_html_e( 'İçe Aktar', 'devxpe-theme' ); ?>
						</button>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * "Child Tema" bilgi/indirme bölümünü çizer (OPSİYONEL).
	 *
	 * Yalnızca panelde durum + indirme bağlantısı + yönerge gösterir.
	 * Otomatik kurulum YAPMAZ; müşteri zip'i WordPress'in tema yükleme
	 * ekranından (Görünüm → Temalar → Yeni Ekle → Zip yükle) kurar.
	 *
	 * @return void
	 */
	private static function render_child() {
		/* update.json'daki child adresi (yoksa boş → bağlantı gizlenir). */
		$child   = DEVXPE_Theme_Update::child_paket();
		$pkg_url = isset( $child['package'] ) ? (string) $child['package'] : '';
		$pkg_ver = isset( $child['version'] ) ? (string) $child['version'] : '';

		/* Kurulu child tema (klasör: devxpe-child) ve etkinlik durumu. */
		$child_theme = wp_get_theme( 'devxpe-child' );
		$kurulu      = $child_theme->exists();
		$aktif       = ( 'devxpe-child' === get_stylesheet() );
		$kurulu_ver  = $kurulu ? (string) $child_theme->get( 'Version' ) : '';
		?>
		<div class="dxp-card">
			<div class="dxp-card-header"><?php esc_html_e( 'Child Tema', 'devxpe-theme' ); ?></div>
			<div class="dxp-row" style="grid-template-columns:1fr;">
				<div>
					<p class="dxp-desc">
						<?php esc_html_e( 'Child tema, üst temayı güncellemelerden etkilenmeden özelleştirmenizi sağlar. Opsiyonel — zorunlu değildir.', 'devxpe-theme' ); ?>
					</p>

					<p class="dxp-desc">
						<strong><?php esc_html_e( 'Durum', 'devxpe-theme' ); ?>:</strong>
						<?php
						if ( $aktif ) {
							echo esc_html(
								'' !== $kurulu_ver
									? sprintf( /* translators: %s: child tema sürümü */ __( 'Kurulu ve etkin (v%s).', 'devxpe-theme' ), $kurulu_ver )
									: __( 'Kurulu ve etkin.', 'devxpe-theme' )
							);
						} elseif ( $kurulu ) {
							echo esc_html(
								'' !== $kurulu_ver
									? sprintf( /* translators: %s: child tema sürümü */ __( 'Kurulu ancak etkin değil (v%s).', 'devxpe-theme' ), $kurulu_ver )
									: __( 'Kurulu ancak etkin değil.', 'devxpe-theme' )
							);
						} else {
							esc_html_e( 'Kurulu değil.', 'devxpe-theme' );
						}
						?>
						<?php if ( '' !== $pkg_ver ) : ?>
							<br><strong><?php esc_html_e( 'Yayındaki child sürümü', 'devxpe-theme' ); ?>:</strong> v<?php echo esc_html( $pkg_ver ); ?>
						<?php endif; ?>
					</p>

					<?php if ( '' !== $pkg_url ) : ?>
						<p class="dxp-desc">
							<a class="button" href="<?php echo esc_url( $pkg_url ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Child Temayı İndir (.zip)', 'devxpe-theme' ); ?></a>
						</p>
					<?php endif; ?>

					<p class="dxp-desc" style="font-weight:600; margin-bottom:4px;"><?php esc_html_e( 'Kurulum', 'devxpe-theme' ); ?></p>
					<ol class="dxp-desc" style="margin:0 0 8px 18px; padding:0;">
						<li><?php esc_html_e( 'Yukarıdaki bağlantıdan child tema zip dosyasını indirin.', 'devxpe-theme' ); ?></li>
						<li><?php esc_html_e( 'WordPress yönetiminde Görünüm → Temalar → Yeni Ekle → Tema Yükle bölümüne gidin.', 'devxpe-theme' ); ?></li>
						<li><?php esc_html_e( 'İndirdiğiniz zip dosyasını seçip yükleyin.', 'devxpe-theme' ); ?></li>
						<li><?php esc_html_e( '"Etkinleştir" ile child temayı devreye alın.', 'devxpe-theme' ); ?></li>
					</ol>

					<p class="dxp-desc" style="color:#b45309; font-weight:600;">
						<?php esc_html_e( 'Uyarı: Child temayı etkinleştirmeden önce üst temanın güncel olduğundan emin olun.', 'devxpe-theme' ); ?>
					</p>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * "Önerilen Eklentiler" kartını çizer.
	 *
	 * Düğmeye basılınca panel formu `devxpe_plugin_install` alanını gönderir;
	 * işlem yönlendiricisi (class-devxpe-theme-panel-actions.php) kurulumu
	 * yapar ve PRG ile panele döner.
	 *
	 * @return void
	 */
	private static function render_plugins() {
		if ( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$eklentiler = devxpe_onerilen_eklentiler();
		$kurabilir  = current_user_can( 'install_plugins' ) && current_user_can( 'activate_plugins' );
		?>
		<div class="dxp-card">
			<div class="dxp-card-header"><?php esc_html_e( 'Önerilen Eklentiler', 'devxpe-theme' ); ?></div>
			<?php foreach ( $eklentiler as $anahtar => $eklenti ) : ?>
				<?php $durum = devxpe_eklenti_durum( $eklenti ); ?>
				<div class="dxp-row">
					<div>
						<div class="dxp-label"><span class="dxp-label-text"><?php echo esc_html( $eklenti['ad'] ); ?></span></div>
					</div>
					<div>
						<div class="dxp-inline">
							<?php if ( 'aktif' === $durum ) : ?>
								<span class="dxp-plugin-badge"><?php esc_html_e( 'Aktif', 'devxpe-theme' ); ?></span>
							<?php else : ?>
								<button type="submit" name="devxpe_plugin_install" value="<?php echo esc_attr( $anahtar ); ?>" class="button button-primary"<?php disabled( ! $kurabilir ); ?>>
									<?php echo ( 'pasif' === $durum ) ? esc_html__( 'Etkinleştir', 'devxpe-theme' ) : esc_html__( 'Kur ve Etkinleştir', 'devxpe-theme' ); ?>
								</button>
							<?php endif; ?>
						</div>
						<div class="dxp-desc"><?php echo esc_html( $eklenti['aciklama'] ); ?></div>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
		<?php
	}

	/**
	 * WebP durum kartı + mevcut görselleri toplu dönüştürme.
	 *
	 * @return void
	 */
	private static function render_webp() {
		$methods = function_exists( 'devxpe_webp_supported_methods' ) ? devxpe_webp_supported_methods() : array();
		$has     = ! empty( $methods );
		?>
		<div class="dxp-card">
			<div class="dxp-card-header"><?php esc_html_e( 'Görseller', 'devxpe-theme' ); ?></div>

			<div class="dxp-row">
				<div>
					<div class="dxp-label"><span class="dxp-label-text"><?php esc_html_e( 'WebP', 'devxpe-theme' ); ?></span></div>
				</div>
				<div>
					<?php if ( $has ) : ?>
						<div class="dxp-inline">
							<span class="dxp-plugin-badge"><?php esc_html_e( 'Aktif', 'devxpe-theme' ); ?></span>
							<span style="color:var(--dxp-text);font-weight:600;"><?php echo esc_html( implode( ', ', $methods ) ); ?></span>
							<button type="button" class="button dxp-webp-convert" data-nonce="<?php echo esc_attr( wp_create_nonce( 'devxpe_webp_bulk' ) ); ?>">
								<?php esc_html_e( 'Mevcut görselleri WebP’ye çevir', 'devxpe-theme' ); ?>
							</button>
							<span class="dxp-webp-status" style="color:var(--dxp-text-muted);"></span>
						</div>
						<div class="dxp-desc">
							<?php
							printf(
								/* translators: %s: kullanılabilir WebP dönüştürücüsü (gd/imagick/cwebp). */
								esc_html__( 'Görseller WebP biçimine çevrilebilir (kullanılabilir: %s). Yeni yüklenen görseller otomatik olarak WebP’ye çevrilir; düğme, mevcut tüm JPEG/PNG görselleri dönüştürür.', 'devxpe-theme' ),
								esc_html( implode( ', ', $methods ) )
							);
							?>
						</div>
					<?php else : ?>
						<div class="dxp-inline">
							<span class="dxp-plugin-badge" style="background:#f4f4f5;color:#71717a;"><?php esc_html_e( 'Kapalı', 'devxpe-theme' ); ?></span>
						</div>
						<div class="dxp-desc">
							<?php esc_html_e( 'Bulunamadı. Hosting sağlayıcınızdan GD (WebP), Imagick veya cwebp kurmasını isteyin.', 'devxpe-theme' ); ?>
							<?php esc_html_e( 'WebP opsiyoneldir; sunucu desteklemiyorsa görseller JPEG/PNG olarak kalır ve site normal çalışır.', 'devxpe-theme' ); ?>
						</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Önerilen eklentiyi kurar ve etkinleştirir (yönlendirici callback'i).
	 *
	 * Yetki + nonce yönlendiricide kontrol edilir. Burada yalnızca eklenti
	 * kurulur/etkinleştirilir; kullanıcı düğmeye basmadan çalışmaz.
	 *
	 * @param array $data POST verisi.
	 * @return string Sonuç kodu.
	 */
	public static function panel_install_plugin( array $data ) {
		if ( ! current_user_can( 'install_plugins' ) || ! current_user_can( 'activate_plugins' ) ) {
			return 'plugin_nocap';
		}

		$anahtar = isset( $data['devxpe_plugin_install'] ) ? sanitize_key( wp_unslash( (string) $data['devxpe_plugin_install'] ) ) : '';
		$liste   = devxpe_onerilen_eklentiler();

		if ( '' === $anahtar || empty( $liste[ $anahtar ] ) ) {
			return 'plugin_error';
		}

		$eklenti = $liste[ $anahtar ];
		$slug    = isset( $eklenti['slug'] ) ? sanitize_key( $eklenti['slug'] ) : '';
		$dosya   = isset( $eklenti['dosya'] ) ? (string) $eklenti['dosya'] : '';
		if ( '' === $slug || '' === $dosya ) {
			return 'plugin_error';
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/misc.php';
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';

		/* Kurulu değilse WordPress.org deposundan indir/kur. */
		if ( ! file_exists( WP_PLUGIN_DIR . '/' . $dosya ) ) {
			$yukleyici = new Plugin_Upgrader( new Automatic_Upgrader_Skin() );
			$sonuc     = $yukleyici->install( 'https://downloads.wordpress.org/plugin/' . $slug . '.zip' );
			if ( is_wp_error( $sonuc ) || ! $sonuc ) {
				return 'plugin_error';
			}
		}

		$aktif = activate_plugin( $dosya );
		if ( is_wp_error( $aktif ) ) {
			return 'plugin_error';
		}

		return 'plugin_ok';
	}

	/**
	 * "Görünüm / Tema Kütüphanesi" içeriğini çizer.
	 *
	 * @return void
	 */
	private static function render_library() {
		$active    = DEVXPE_Theme_Library::active_slug();
		$parent    = DEVXPE_Theme_Library::parent_slug();
		$installed = DEVXPE_Theme_Library::installed_designs();
		$designs   = DEVXPE_Theme_Library::visible_designs();
		$can_inst  = current_user_can( 'install_themes' );
		$can_switch = current_user_can( 'switch_themes' );
		?>
		<div class="dxp-card">
			<div class="dxp-card-header"><?php esc_html_e( 'Görünüm / Tema Kütüphanesi', 'devxpe-theme' ); ?></div>


			<div class="dxp-row">
				<div><div class="dxp-label"><span class="dxp-label-text"><?php esc_html_e( 'Varsayılan', 'devxpe-theme' ); ?></span></div></div>
				<div>
					<div class="dxp-inline">
						<?php if ( $active === $parent ) : ?>
							<span class="dxp-plugin-badge"><?php esc_html_e( 'Aktif', 'devxpe-theme' ); ?></span>
						<?php else : ?>
							<button type="submit" name="devxpe_design_activate" value="__default__" class="button"<?php disabled( ! $can_switch ); ?>><?php esc_html_e( 'Varsayılana dön', 'devxpe-theme' ); ?></button>
						<?php endif; ?>
					</div>
					<div class="dxp-desc"><?php esc_html_e( 'Temanın kendi tasarımı. Görünüm değişse de panel ve ayarlar aynı kalır.', 'devxpe-theme' ); ?></div>
				</div>
			</div>

			<?php
			foreach ( $designs as $design ) :
				$slug = isset( $design['slug'] ) ? sanitize_key( $design['slug'] ) : '';
				if ( '' === $slug ) {
					continue;
				}
				$styles       = ! empty( $design['stylesheet'] ) ? sanitize_key( $design['stylesheet'] ) : $slug;
				$is_installed = isset( $installed[ $styles ] );
				$is_active    = ( $active === $styles );
				$compat       = DEVXPE_Theme_Library::is_compatible( $design );
				$gallery      = DEVXPE_Theme_Library::gallery( $design );
				$cover        = $gallery ? $gallery[0] : '';
				$name         = isset( $design['name'] ) ? $design['name'] : $styles;
				?>
			<div class="dxp-row">
				<div><div class="dxp-label"><span class="dxp-label-text"><?php echo esc_html( $name ); ?></span></div></div>
				<div>
					<div class="dxp-inline">
						<?php if ( $cover ) : ?>
							<button type="button" class="dxp-design-thumb" data-gallery="<?php echo esc_attr( wp_json_encode( $gallery ) ); ?>" aria-label="<?php esc_attr_e( 'Galeri', 'devxpe-theme' ); ?>">
								<img src="<?php echo esc_url( $cover ); ?>" alt="<?php echo esc_attr( $name ); ?>" loading="lazy">
							</button>
						<?php endif; ?>
						<?php if ( $is_active ) : ?>
							<span class="dxp-plugin-badge"><?php esc_html_e( 'Aktif', 'devxpe-theme' ); ?></span>
						<?php elseif ( ! $compat ) : ?>
							<span class="dxp-design-warn">
								<?php
								printf(
									/* translators: %s: gereken tema sürümü. */
									esc_html__( 'Temanız en az v%s olmalı', 'devxpe-theme' ),
									esc_html( isset( $design['requires'] ) ? $design['requires'] : '' )
								);
								?>
							</span>
						<?php elseif ( $is_installed ) : ?>
							<button type="submit" name="devxpe_design_activate" value="<?php echo esc_attr( $styles ); ?>" class="button button-primary"<?php disabled( ! $can_switch ); ?>><?php esc_html_e( 'Etkinleştir', 'devxpe-theme' ); ?></button>
						<?php else : ?>
							<button type="submit" name="devxpe_design_install" value="<?php echo esc_attr( $slug ); ?>" class="button button-primary"<?php disabled( ! $can_inst ); ?>><?php esc_html_e( 'Kur ve Etkinleştir', 'devxpe-theme' ); ?></button>
						<?php endif; ?>
						<?php if ( ! empty( $design['version'] ) ) : ?><span class="dxp-design-ver">v<?php echo esc_html( $design['version'] ); ?></span><?php endif; ?>
						<?php if ( DEVXPE_Theme_Library::is_dev_design( $design ) ) : ?><span class="dxp-design-warn"><?php esc_html_e( 'Yapım aşamasında', 'devxpe-theme' ); ?></span><?php endif; ?>
					</div>
					<?php if ( ! empty( $design['description'] ) ) : ?>
						<div class="dxp-desc"><?php echo esc_html( $design['description'] ); ?></div>
					<?php elseif ( $cover && count( $gallery ) > 1 ) : ?>
						<div class="dxp-desc"><?php printf( esc_html__( '%d görsel — kapağa tıklayın', 'devxpe-theme' ), count( $gallery ) ); ?></div>
					<?php endif; ?>
				</div>
			</div>
			<?php endforeach; ?>

			<?php if ( empty( $designs ) ) : ?>
			<div class="dxp-row">
				<div><div class="dxp-label"><span class="dxp-label-text"><?php esc_html_e( 'Tasarımlar', 'devxpe-theme' ); ?></span></div></div>
				<div><div class="dxp-desc"><?php esc_html_e( 'Henüz yayınlanmış ek tasarım yok. Kataloğa tasarım eklendiğinde burada listelenir.', 'devxpe-theme' ); ?></div></div>
			</div>
			<?php endif; ?>

			<div class="dxp-row">
				<div><div class="dxp-label"><span class="dxp-label-text"><?php esc_html_e( 'Katalog', 'devxpe-theme' ); ?></span></div></div>
				<div>
					<div class="dxp-inline">
						<a class="button" href="<?php echo esc_url( add_query_arg( 'dxp_catalog_refresh', '1' ) ); ?>"><?php esc_html_e( 'Kataloğu yenile', 'devxpe-theme' ); ?></a>
					</div>
					<div class="dxp-desc"><?php esc_html_e( 'Yeni tasarımlar yayınlandıysa listeyi tazeleyin.', 'devxpe-theme' ); ?></div>
				</div>
			</div>
		</div>

		<div class="dxp-design-modal" id="dxp-design-modal" hidden>
			<div class="dxp-design-modal-backdrop" data-close></div>
			<div class="dxp-design-modal-box" role="dialog" aria-modal="true">
				<button type="button" class="dxp-design-modal-x" data-close aria-label="<?php esc_attr_e( 'Kapat', 'devxpe-theme' ); ?>">×</button>
				<img class="dxp-design-modal-img" src="" alt="">
				<button type="button" class="dxp-design-modal-nav dxp-prev" data-dir="-1" aria-label="<?php esc_attr_e( 'Önceki', 'devxpe-theme' ); ?>">‹</button>
				<button type="button" class="dxp-design-modal-nav dxp-next" data-dir="1" aria-label="<?php esc_attr_e( 'Sonraki', 'devxpe-theme' ); ?>">›</button>
			</div>
		</div>
		<?php
	}

	/**
	 * Görünüm kurar ve etkinleştirir (yönlendirici callback'i).
	 *
	 * @param array $data POST verisi.
	 * @return string Sonuç kodu.
	 */
	public static function panel_design_install( array $data ) {
		if ( ! current_user_can( 'install_themes' ) ) {
			return 'design_nocap';
		}
		$slug = isset( $data['devxpe_design_install'] ) ? sanitize_key( wp_unslash( (string) $data['devxpe_design_install'] ) ) : '';
		if ( '' === $slug ) {
			return 'design_error';
		}
		return DEVXPE_Theme_Library::install( $slug );
	}

	/**
	 * Görünüm etkinleştirir (veya varsayılana döner).
	 *
	 * @param array $data POST verisi.
	 * @return string Sonuç kodu.
	 */
	public static function panel_design_activate( array $data ) {
		if ( ! current_user_can( 'switch_themes' ) ) {
			return 'design_nocap';
		}
		$slug = isset( $data['devxpe_design_activate'] ) ? sanitize_key( wp_unslash( (string) $data['devxpe_design_activate'] ) ) : '';
		if ( '' === $slug ) {
			return 'design_error';
		}
		if ( '__default__' === $slug ) {
			return DEVXPE_Theme_Library::reset_default();
		}
		return DEVXPE_Theme_Library::activate( $slug );
	}

	/**
	 * "Hakkımızda" içeriğini çizer (bilgi + telif).
	 *
	 * @return void
	 */
	private static function render_about() {
		?>
		<div class="dxp-card">
			<div class="dxp-card-header"><?php esc_html_e( 'Hakkımızda', 'devxpe-theme' ); ?></div>
			<div class="dxp-about">
				<div class="dxp-about-logo">DEVXPE</div>
				<p class="dxp-about-desc">
					<?php esc_html_e( 'DEVXPE, çok sektörlü WordPress tema ve eklenti paketidir. Elementor uyumlu, modüler ve panelden yönetilebilir.', 'devxpe-theme' ); ?>
				</p>
				<ul class="dxp-about-meta">
					<li><strong><?php esc_html_e( 'Site Adresi', 'devxpe-theme' ); ?>:</strong> <a href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( home_url( '/' ) ); ?></a></li>
					<li><strong><?php esc_html_e( 'Sürüm', 'devxpe-theme' ); ?>:</strong> <?php echo esc_html( DEVXPE_THEME_VERSION ); ?></li>
					<li><strong><?php esc_html_e( 'Geliştirici', 'devxpe-theme' ); ?>:</strong> DEVXPE</li>
					<li><strong><?php esc_html_e( 'Web', 'devxpe-theme' ); ?>:</strong> <a href="https://soydan.me" target="_blank" rel="noopener noreferrer">soydan.me</a></li>
				</ul>
				<p class="dxp-about-copy">
					&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> DEVXPE — <?php esc_html_e( 'Tüm hakları saklıdır.', 'devxpe-theme' ); ?>
				</p>

				<div class="dxp-about-actions">
					<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=devxpe_setup_restart' ), 'devxpe_setup_restart' ) ); ?>"><?php esc_html_e( 'Kurulumu Tekrar Çalıştır', 'devxpe-theme' ); ?></a>
				</div>
			</div>
		</div>

		<?php
		/*
		 * Sürüm notları (changelog): update.json'daki changelog_history'den gelir.
		 * Çevrimdışıysa ya da notlar silinmişse history() boş döner → kart hiç
		 * gösterilmez (aşağıda erken dönüş).
		 */
		$dxp_changelog = DEVXPE_Theme_Update::history();
		$dxp_manifest  = DEVXPE_Theme_Update::manifest();

		/* Önbellekteki manifest kurulu sürümden eskiyse notlar da eski olabilir. */
		$dxp_bayat = ! empty( $dxp_manifest['version'] )
			&& version_compare( (string) $dxp_manifest['version'], DEVXPE_THEME_VERSION, '<' );

		/*
		 * Changelog BOŞSA "Sürüm Notları" kartı HİÇ gösterilmez: boş kutu,
		 * başlık ya da "not yok" mesajı bırakmıyoruz. Böylece yayın panelinden
		 * silinen test notları müşteride de görünmez.
		 */
		if ( ! $dxp_changelog ) {
			return;
		}
		?>
		<div class="dxp-card">
			<div class="dxp-card-header">
				<?php
				/*
				 * Başlık dile göre: Türkçe "Sürüm Notları", İngilizce "Changelog".
				 * Tema dil seçicisi .mo dosyasını değiştirdiğinden seçili dil
				 * doğrudan kullanılır ('auto' ise sitenin varsayılanı).
				 */
				$dxp_not_dil = DEVXPE_Theme_Language::selected();
				if ( 'auto' === $dxp_not_dil ) {
					$dxp_not_dil = DEVXPE_Theme_Language::default_lang();
				}
				echo esc_html( ( 'en_US' === $dxp_not_dil ) ? 'Changelog' : 'Sürüm Notları' );
				?>
				<a class="dxp-changelog-refresh"
					href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=devxpe_changelog_refresh' ), 'devxpe_changelog_refresh' ) ); ?>"
					onclick="event.stopPropagation();"><?php esc_html_e( 'Yenile', 'devxpe-theme' ); ?></a>
			</div>
			<?php if ( $dxp_bayat ) : ?>
				<p class="dxp-desc" style="padding:12px 16px 0;">
					<?php
					printf(
						/* translators: %s: önbellekteki (eski) sürüm. */
						esc_html__( 'Notlar önbellekten geliyor (v%s) ve kurulu sürümden eski. Yayından hemen sonra CDN gecikmesi olabilir — "Yenile" ile tazeleyin.', 'devxpe-theme' ),
						esc_html( (string) $dxp_manifest['version'] )
					);
					?>
				</p>
				<?php endif; ?>
				<?php
				/* Yeni → eski sırala (sürüm karşılaştırması). */
				uksort(
					$dxp_changelog,
					static function ( $a, $b ) {
						return version_compare( (string) $b, (string) $a );
					}
				);
				?>
				<div class="dxp-changelog">
					<?php foreach ( $dxp_changelog as $dxp_surum => $dxp_kayit ) : ?>
					<div class="dxp-changelog-item">
						<div class="dxp-changelog-head">
							<span class="dxp-changelog-version">v<?php echo esc_html( $dxp_surum ); ?></span>
							<?php if ( ! empty( $dxp_kayit['tarih'] ) ) : ?>
							<time class="dxp-changelog-date"><?php echo esc_html( $dxp_kayit['tarih'] ); ?></time>
							<?php endif; ?>
						</div>
						<?php if ( '' !== (string) $dxp_kayit['not'] ) : ?>
						<div class="dxp-changelog-note"><?php echo nl2br( esc_html( (string) $dxp_kayit['not'] ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
						<?php endif; ?>
					</div>
					<?php endforeach; ?>
				</div>
		</div>
		<?php
	}

}

/**
 * Panelde listelenecek önerilen eklentiler.
 *
 * Başka bir eklenti önermek için `devxpe_onerilen_eklentiler` filtresini
 * kullanın. Her kayıt: ad, slug (wordpress.org), dosya (plugin ana dosyası),
 * aciklama.
 *
 * @return array
 */
function devxpe_onerilen_eklentiler() {
	$eklentiler = array(
		'yoast' => array(
			'ad'       => 'Yoast SEO',
			'slug'     => 'wordpress-seo',
			'dosya'    => 'wordpress-seo/wp-seo.php',
			'ikon'     => 'dashicons-search',
			'aciklama' => __( 'Arama motoru optimizasyonu: başlık ve meta açıklama düzenleme, site haritası, içerik analizi.', 'devxpe-theme' ),
		),
		'fastestcache' => array(
			'ad'       => 'WP Fastest Cache',
			'slug'     => 'wp-fastest-cache',
			'dosya'    => 'wp-fastest-cache/wpFastestCache.php',
			'ikon'     => 'dashicons-performance',
			'aciklama' => __( 'Sayfa önbelleği: siteyi hızlandırır ve sunucu yükünü azaltır. Kurulumdan sonra ayarlarını gözden geçirin.', 'devxpe-theme' ),
		),
	);

	return apply_filters( 'devxpe_onerilen_eklentiler', $eklentiler );
}

/**
 * Bir önerilen eklentinin durumunu döndürür.
 *
 * @param array $eklenti Eklenti kaydı.
 * @return string 'aktif' | 'pasif' | 'kurulu_degil'
 */
function devxpe_eklenti_durum( array $eklenti ) {
	if ( ! function_exists( 'is_plugin_active' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}

	$dosya = isset( $eklenti['dosya'] ) ? (string) $eklenti['dosya'] : '';
	if ( '' === $dosya ) {
		return 'kurulu_degil';
	}
	if ( is_plugin_active( $dosya ) ) {
		return 'aktif';
	}
	if ( file_exists( WP_PLUGIN_DIR . '/' . $dosya ) ) {
		return 'pasif';
	}
	return 'kurulu_degil';
}
