<?php
/**
 * DEVXPE tema ilk kurulum sihirbazi.
 *
 * Tema ilk etkinlestirildiginde 3 adimli basit kurulum gosterir:
 * 1) Site adi, 2) Panel dili, 3) Bitis. Tamamlaninca bir daha gosterilmez.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DEVXPE_Theme_Setup {

	const OPTION_KEY = 'devxpe_setup_complete';
	const PAGE_SLUG  = 'devxpe-theme-setup';

	/**
	 * Kancalari baglar.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'after_switch_theme', array( __CLASS__, 'on_activate' ) );
		add_action( 'admin_menu', array( __CLASS__, 'register_page' ) );
		add_action( 'admin_init', array( __CLASS__, 'set_page_title' ) );
		add_action( 'admin_init', array( __CLASS__, 'maybe_redirect' ) );
		add_action( 'admin_init', array( __CLASS__, 'maybe_migrate_demo_texts' ) );
		add_action( 'admin_post_devxpe_setup_save', array( __CLASS__, 'handle_save' ) );
		add_action( 'admin_post_devxpe_setup_skip', array( __CLASS__, 'handle_skip' ) );
		add_action( 'admin_post_devxpe_setup_restart', array( __CLASS__, 'handle_restart' ) );
	}

	/**
	 * Kurulumu atlar (tamamlandı sayar).
	 *
	 * @return void
	 */
	public static function handle_skip() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Yetkiniz yok.', 'devxpe-theme' ) );
		}
		check_admin_referer( 'devxpe_setup_skip' );

		update_option( self::OPTION_KEY, '1', false );
		wp_safe_redirect( devxpe_panel_url() );
		exit;
	}

	/**
	 * Kurulumu sıfırlar ve baştan başlatır.
	 *
	 * @return void
	 */
	public static function handle_restart() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Yetkiniz yok.', 'devxpe-theme' ) );
		}
		check_admin_referer( 'devxpe_setup_restart' );

		update_option( self::OPTION_KEY, '0', false );
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::PAGE_SLUG ) );
		exit;
	}

	/**
	 * Gizli kurulum sayfasının başlığını ayarlar.
	 *
	 * add_submenu_page( null, ... ) ile gizli kaydedilen sayfayı WP çekirdeği
	 * menüde bulamadığı için get_admin_page_title() null döner ve
	 * admin-header.php'de strip_tags(null) deprecation üretir. Başlığı
	 * admin-header.php'den önce çalışan admin_init'te ata.
	 *
	 * @return void
	 */
	public static function set_page_title() {
		if ( isset( $_GET['page'] ) && self::PAGE_SLUG === $_GET['page'] ) {
			global $title;
			$title = __( 'Kurulum', 'devxpe-theme' );
		}
	}

	/**
	 * Tema etkinlestirildiginde kurulumu baslatir.
	 *
	 * @return void
	 */
	public static function on_activate() {
		if ( '1' !== get_option( self::OPTION_KEY, '' ) ) {
			update_option( self::OPTION_KEY, '0', false );
			set_transient( 'devxpe_setup_redirect', '1', 60 );
		}

		/*
		 * Eski bir panel dili seçimi kalmışsa temizle: yeni kurulum, WordPress
		 * sitesinin diline göre başlasın. Kurulum adımında kullanıcı zaten
		 * yeniden seçebilir; seçmezse 'auto' (site dili) geçerli olur.
		 */
		if ( class_exists( 'DEVXPE_Theme_Language' ) ) {
			delete_option( DEVXPE_Theme_Language::OPTION_KEY );
		}
	}

	/**
	 * Etkinlestirme sonrasi kurulum sayfasina yonlendirir.
	 *
	 * @return void
	 */
	public static function maybe_redirect() {
		global $pagenow;

		if ( ! current_user_can( 'manage_options' ) || '1' === get_option( self::OPTION_KEY, '' ) ) {
			return;
		}
		if ( wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return;
		}
		if ( in_array( $pagenow, array( 'admin-post.php', 'admin-ajax.php', 'async-upload.php' ), true ) ) {
			return;
		}
		if ( isset( $_GET['page'] ) && self::PAGE_SLUG === $_GET['page'] ) {
			return;
		}

		wp_safe_redirect( admin_url( 'admin.php?page=' . self::PAGE_SLUG ) );
		exit;
	}

	/**
	 * Eski İngilizce demo metinlerini Türkçe'ye taşır (tek seferlik).
	 *
	 * Yönetici bağlamında çalışır; taşıma sonucu bir option ile işaretlenir.
	 *
	 * @return void
	 */
	public static function maybe_migrate_demo_texts() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		if ( class_exists( 'DEVXPE_Theme_Demo' ) ) {
			DEVXPE_Theme_Demo::migrate_en_texts();
			DEVXPE_Theme_Demo::cleanup_legacy_cards();
			DEVXPE_Theme_Demo::cleanup_orphan_demo();
			DEVXPE_Theme_Demo::cleanup_placeholder_chips();
		}
	}

	/**
	 * Gizli kurulum sayfasini kaydeder.
	 *
	 * @return void
	 */
	public static function register_page() {
		add_submenu_page(
			null,
			__( 'Kurulum', 'devxpe-theme' ),
			__( 'Kurulum', 'devxpe-theme' ),
			'manage_options',
			self::PAGE_SLUG,
			array( __CLASS__, 'render' )
		);
	}

	/**
	 * Adim kaydini isler (admin-post).
	 *
	 * @return void
	 */
	public static function handle_save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Yetkiniz yok.', 'devxpe-theme' ) );
		}
		if ( ! isset( $_POST['devxpe_setup_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['devxpe_setup_nonce'] ) ), 'devxpe_setup_save' ) ) {
			wp_die( esc_html__( 'Güvenlik kontrolü başarısız.', 'devxpe-theme' ) );
		}

		$step = isset( $_POST['step'] ) ? absint( $_POST['step'] ) : 1;

		if ( 1 === $step ) {
			// Dil seçimi, panel dil değiştirici bileşeniyle anında kaydedilir.
			$next = 2;
		} elseif ( 2 === $step ) {
			$name = isset( $_POST['site_name'] ) ? sanitize_text_field( wp_unslash( $_POST['site_name'] ) ) : '';
			if ( '' !== $name ) {
				devxpe_safe_update_blog_option( 'blogname', $name );
				update_option( 'devxpe_setup_site_name', $name, false );
			}
			$next = 3;
		} elseif ( 3 === $step ) {
			/* Demo içeriği istenirse kurulur (metin dili site diline göre). */
			if ( ! empty( $_POST['demo_install'] ) ) {
				DEVXPE_Theme_Demo::install();

				/* Kurulumda girilen site adı demoyla ezilmesin. */
				$name = (string) get_option( 'devxpe_setup_site_name', '' );
				if ( '' !== $name ) {
					devxpe_safe_update_blog_option( 'blogname', $name );
				}
			}
			$next = 4;
		} else {
			update_option( self::OPTION_KEY, '1', false );
			delete_option( 'devxpe_setup_site_name' );
			wp_safe_redirect( devxpe_panel_url() );
			exit;
		}

		wp_safe_redirect( admin_url( 'admin.php?page=' . self::PAGE_SLUG . '&step=' . $next ) );
		exit;
	}

	/**
	 * Kurulum sayfasini cizer.
	 *
	 * @return void
	 */
	public static function render() {
		$step   = isset( $_GET['step'] ) ? absint( $_GET['step'] ) : 1;
		$step   = max( 1, min( 4, $step ) );
		$action = admin_url( 'admin-post.php' );
		?>
		<?php if ( 1 === $step ) : ?>
		<div class="dxp-setup-intro" id="dxp-setup-intro">
			<div class="dxp-setup-intro-inner">
				<div class="dxp-setup-intro-icon">✦</div>
				<h1><?php esc_html_e( 'Kuruluma Hoş Geldiniz', 'devxpe-theme' ); ?></h1>
				<p><?php esc_html_e( 'DEVXPE teması kurulumu başlıyor…', 'devxpe-theme' ); ?></p>
			</div>
		</div>
		<?php endif; ?>
		<div class="wrap dxp-setup">
			<h1><?php esc_html_e( 'DEVXPE Kurulum', 'devxpe-theme' ); ?></h1>

			<ol class="dxp-setup-steps">
				<?php for ( $i = 1; $i <= 4; $i++ ) : ?>
					<li class="<?php echo ( $i === $step ) ? 'active' : ( ( $i < $step ) ? 'done' : '' ); ?>">
						<span><?php echo absint( $i ); ?></span>
					</li>
				<?php endfor; ?>
			</ol>

			<div class="dxp-setup-card">
				<?php if ( 1 === $step ) : ?>
					<h2><?php esc_html_e( 'Panel Dili', 'devxpe-theme' ); ?></h2>
					<p class="description"><?php esc_html_e( 'Yönetim panelinin dilini seçin. Ön yüz WordPress (site) dilini izler.', 'devxpe-theme' ); ?></p>
					<div class="dxp-setup-lang"><?php DEVXPE_Theme_Language::render_switcher(); ?></div>
				<?php elseif ( 2 === $step ) : ?>
					<h2><?php esc_html_e( 'Site Adı', 'devxpe-theme' ); ?></h2>
					<p class="description"><?php esc_html_e( 'Sitenizin adını girin.', 'devxpe-theme' ); ?></p>
				<?php elseif ( 3 === $step ) : ?>
					<h2><?php esc_html_e( 'Demo İçeriği', 'devxpe-theme' ); ?></h2>
					<p class="description"><?php esc_html_e( 'Örnek sayfalar, hizmetler, bölgeler ve görsellerle hazır bir site kuralım mı? İstediğiniz zaman panelden kaldırabilirsiniz. Var olan içeriğinizle çakışmaması için varsayılan olarak KAPALIDIR.', 'devxpe-theme' ); ?></p>
				<?php else : ?>
					<h2><?php esc_html_e( 'Kurulum tamamlandı', 'devxpe-theme' ); ?></h2>
					<p class="description"><?php esc_html_e( 'Her şey hazır. Panele geçerek ayarlarınızı düzenleyebilirsiniz.', 'devxpe-theme' ); ?></p>
				<?php endif; ?>

				<form method="post" action="<?php echo esc_url( $action ); ?>">
					<input type="hidden" name="action" value="devxpe_setup_save" />
					<input type="hidden" name="step" value="<?php echo absint( $step ); ?>" />
					<?php wp_nonce_field( 'devxpe_setup_save', 'devxpe_setup_nonce' ); ?>

					<?php if ( 2 === $step ) : ?>
						<input type="text" name="site_name" class="regular-text" value="<?php echo esc_attr( get_option( 'blogname' ) ); ?>" autocomplete="off" />
					<?php endif; ?>

					<?php if ( 3 === $step ) : ?>
						<label style="display:flex;gap:8px;align-items:flex-start;margin:12px 0 0;font-size:13px;">
							<input type="checkbox" name="demo_install" value="1" style="margin-top:2px;" />
							<span><?php esc_html_e( 'Evet, demo içeriğini kur', 'devxpe-theme' ); ?></span>
						</label>
					<?php endif; ?>

					<p class="dxp-setup-actions">
						<button type="submit" class="button button-primary">
							<?php echo ( 4 === $step ) ? esc_html__( 'Panele Git', 'devxpe-theme' ) : esc_html__( 'Devam Et', 'devxpe-theme' ); ?>
						</button>
						<a class="button-link" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=devxpe_setup_skip' ), 'devxpe_setup_skip' ) ); ?>"><?php esc_html_e( 'Atla', 'devxpe-theme' ); ?></a>
					</p>
				</form>
			</div>
		</div>
		<style>
			/* Panel ile aynı shadcn (zinc) token'ları */
			.dxp-setup {
				--s-bg         : #ffffff;
				--s-surface    : #f4f4f5;
				--s-border     : #e4e4e7;
				--s-text       : #09090b;
				--s-muted      : #71717a;
				--s-primary    : #18181b;
				--s-primary-fg : #fafafa;
				max-width      : 560px;
				margin-top     : 24px;
				color          : var(--s-text);
				font-family    : "Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
			}
			.dxp-setup > h1 { color: var(--s-text); font-weight: 600; font-size: 22px; }

			/* Adım göstergesi */
			.dxp-setup-steps { display: flex; gap: 8px; list-style: none; padding: 0; margin: 16px 0; }
			.dxp-setup-steps li { width: 30px; height: 30px; border-radius: 6px; display: flex; align-items: center; justify-content: center; background: var(--s-surface); color: var(--s-muted); font-size: 12.5px; font-weight: 600; border: 1px solid var(--s-border); transition: background .15s, color .15s, border-color .15s; }
			.dxp-setup-steps li.active { background: var(--s-primary); color: var(--s-primary-fg); border-color: var(--s-primary); }
			.dxp-setup-steps li.done { background: var(--s-bg); color: var(--s-text); }

			/* Kart */
			.dxp-setup-card { background: var(--s-bg); border: 1px solid var(--s-border); border-radius: 8px; padding: 24px; box-shadow: 0 1px 3px rgba(0,0,0,.05), 0 10px 30px rgba(0,0,0,.03); }
			.dxp-setup-card h2 { margin: 0 0 4px; color: var(--s-text); font-size: 17px; font-weight: 600; }
			.dxp-setup-card .description { margin: 0 0 12px; color: var(--s-muted); font-size: 13px; }
			.dxp-setup-card input[type="text"] { width: 100%; min-height: 38px; border: 1px solid var(--s-border); border-radius: 6px; padding: 8px 11px; font-size: 13.5px; color: var(--s-text); background: var(--s-bg); box-shadow: none; }
			.dxp-setup-card input[type="text"]:focus { border-color: var(--s-primary); box-shadow: 0 0 0 3px color-mix(in srgb, var(--s-primary) 12%, transparent); outline: none; }
			.dxp-setup-lang { margin: 0 0 12px; }

			/* Butonlar */
			.dxp-setup-actions { display: flex; align-items: center; gap: 16px; margin: 20px 0 0; }
			.dxp-setup-actions .button-primary { background: var(--s-primary) !important; border-color: var(--s-primary) !important; color: var(--s-primary-fg) !important; border-radius: 6px; text-transform: none; letter-spacing: 0; font-weight: 500; font-size: 13px; padding: 8px 16px; height: auto; line-height: 1.4; text-shadow: none; box-shadow: none; }
			.dxp-setup-actions .button-primary:hover { background: #27272a !important; border-color: #27272a !important; }
			.dxp-setup-actions .button-primary:focus { box-shadow: 0 0 0 3px color-mix(in srgb, var(--s-primary) 25%, transparent) !important; }
			.dxp-setup-actions .button-link { color: var(--s-muted); text-decoration: none; font-size: 13px; }
			.dxp-setup-actions .button-link:hover { color: var(--s-text); }

			/* Panel dil değiştirici bileşeniyle aynı görünüm */
			.dxp-setup .dxp-lang-switch { position: relative; display: inline-flex; align-items: center; margin: 0; }
			.dxp-setup .dxp-lang-trigger { display: flex; align-items: center; gap: 6px; height: 34px; padding: 0 12px; background: var(--s-surface); border: 1px solid var(--s-border); border-radius: 6px; color: var(--s-text); font-size: 13px; font-weight: 500; cursor: pointer; transition: border-color .15s, box-shadow .15s; }
			.dxp-setup .dxp-lang-trigger:hover { border-color: var(--s-muted); }
			.dxp-setup .dxp-lang-trigger:focus-visible { border-color: var(--s-primary); box-shadow: 0 0 0 2px color-mix(in srgb, var(--s-primary) 25%, transparent); outline: none; }
			.dxp-setup .dxp-lang-trigger .dashicons { font-size: 15px; width: 15px; height: 15px; color: var(--s-muted); }
			.dxp-setup .dxp-lang-caret { font-size: 10px; opacity: .5; }
			.dxp-setup .dxp-lang-menu { position: absolute; top: calc(100% + 6px); left: 0; z-index: 60; min-width: 180px; display: flex; flex-direction: column; gap: 2px; padding: 4px; background: var(--s-bg); border: 1px solid var(--s-border); border-radius: 6px; box-shadow: 0 10px 30px rgba(0,0,0,.12); }
			.dxp-setup .dxp-lang-menu[hidden] { display: none; }
			.dxp-setup .dxp-lang-item { text-align: left; border: none; background: transparent; color: var(--s-text); font-size: 13px; padding: 7px 10px; border-radius: 4px; cursor: pointer; transition: background .12s, color .12s; }
			.dxp-setup .dxp-lang-item:hover { background: var(--s-surface); }
			.dxp-setup .dxp-lang-item.is-selected { color: var(--s-primary); font-weight: 600; }

			/* Hoş geldiniz girişi (token'lar .dxp-setup dışında olduğu için sabit renk) */
			.dxp-setup-intro { position: fixed; inset: 0; z-index: 100000; display: flex; align-items: center; justify-content: center; text-align: center; background: #09090b; color: #fafafa; transition: opacity .6s ease, visibility .6s ease; }
			.dxp-setup-intro.is-hidden { opacity: 0; visibility: hidden; }
			.dxp-setup-intro-inner { animation: dxpIntroIn .7s ease both; padding: 24px; }
			.dxp-setup-intro-icon { font-size: 52px; line-height: 1; color: #fafafa; animation: dxpIntroPulse 1.6s ease-in-out infinite; }
			.dxp-setup-intro h1 { font-size: 26px; margin: 18px 0 10px; color: #fafafa; font-weight: 600; }
			.dxp-setup-intro p { font-size: 14px; margin: 0; color: #a1a1aa; }
			@keyframes dxpIntroIn { from { opacity: 0; transform: translateY(18px) scale(.96); } to { opacity: 1; transform: none; } }
			@keyframes dxpIntroPulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.15); } }
			@media (max-width: 480px) { .dxp-setup-intro h1 { font-size: 22px; } .dxp-setup-intro-icon { font-size: 42px; } }
		</style>
		<script>
		( function () {
			var sw = document.querySelector( '.dxp-lang-switch' );
			if ( sw ) {
				var trigger = sw.querySelector( '.dxp-lang-trigger' );
				var menu    = sw.querySelector( '.dxp-lang-menu' );
				trigger.addEventListener( 'click', function ( e ) {
					e.stopPropagation();
					menu.hidden = ! menu.hidden;
					trigger.setAttribute( 'aria-expanded', menu.hidden ? 'false' : 'true' );
				} );
				menu.addEventListener( 'click', function ( e ) {
					var item = e.target.closest( '.dxp-lang-item' );
					if ( ! item ) { return; }
					sw.querySelector( '.dxp-lang-value' ).value = item.getAttribute( 'data-lang' );
					sw.submit();
				} );
				document.addEventListener( 'click', function ( e ) {
					if ( ! e.target.closest( '.dxp-lang-switch' ) ) {
						menu.hidden = true;
						trigger.setAttribute( 'aria-expanded', 'false' );
					}
				} );
			}

			var intro = document.getElementById( 'dxp-setup-intro' );
			if ( ! intro ) { return; }
			setTimeout( function () {
				intro.classList.add( 'is-hidden' );
				setTimeout( function () { intro.remove(); }, 700 );
			}, 1800 );
		} )();
		</script>
		<?php
	}
}
