<?php
/**
 * DEVXPE Tema — temel SEO çıktısı.
 *
 * Amaç: bir SEO eklentisi (ör. Yoast) YOKKEN temel başlık/meta/canonical ve
 * Open Graph etiketlerini basmak. Eklenti varsa tema hiçbir etiket basmaz;
 * böylece çakışma olmaz.
 *
 * `add_theme_support( 'title-tag' )` kullanıldığı için <title> burada ELLE
 * basılmaz (WordPress üretir). JSON-LD/schema eklenmez.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DEVXPE_Theme_SEO {

	/**
	 * Meta açıklaması için en fazla karakter.
	 */
	const DESC_LEN = 155;

	/**
	 * Kancaları bağlar.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'wp_head', array( __CLASS__, 'render_head' ), 5 );
		add_action( 'wp_head', array( __CLASS__, 'render_schema' ), 6 );
		add_filter( 'wp_robots', array( __CLASS__, 'robots' ) );
	}

	/**
	 * Bir SEO eklentisi aktif mi? (Şimdilik Yoast.)
	 *
	 * @return bool
	 */
	public static function has_plugin() {
		return defined( 'WPSEO_VERSION' ) || class_exists( 'WPSEO_Frontend' );
	}

	/**
	 * Head etiketlerini basar (yalnız SEO eklentisi yokken).
	 *
	 * @return void
	 */
	public static function render_head() {
		if ( self::has_plugin() || is_404() ) {
			return;
		}

		$desc  = self::description();
		$url   = self::current_url();
		$image = self::image();
		$title = wp_get_document_title();
		$type  = is_singular( 'post' ) ? 'article' : 'website';

		if ( '' !== $desc ) {
			echo '<meta name="description" content="' . esc_attr( $desc ) . '">' . "\n";
		}

		/*
		 * Canonical: çekirdek `rel_canonical()` yalnızca tekil içerikte basar.
		 * Arşiv/blog gibi diğer sayfalarda kendine işaret eden canonical
		 * burada eklenir. Arama ve 404 zaten noindex olduğu için eklenmez.
		 */
		if ( ! is_singular() && ! is_search() ) {
			echo '<link rel="canonical" href="' . esc_url( $url ) . '">' . "\n";
		}

		echo '<meta property="og:type" content="' . esc_attr( $type ) . '">' . "\n";
		echo '<meta property="og:title" content="' . esc_attr( $title ) . '">' . "\n";
		if ( '' !== $desc ) {
			echo '<meta property="og:description" content="' . esc_attr( $desc ) . '">' . "\n";
		}
		echo '<meta property="og:url" content="' . esc_url( $url ) . '">' . "\n";
		echo '<meta property="og:site_name" content="' . esc_attr( get_bloginfo( 'name' ) ) . '">' . "\n";
		if ( '' !== $image ) {
			echo '<meta property="og:image" content="' . esc_url( $image ) . '">' . "\n";
		}

		echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
		echo '<meta name="twitter:title" content="' . esc_attr( $title ) . '">' . "\n";
		if ( '' !== $desc ) {
			echo '<meta name="twitter:description" content="' . esc_attr( $desc ) . '">' . "\n";
		}
		if ( '' !== $image ) {
			echo '<meta name="twitter:image" content="' . esc_url( $image ) . '">' . "\n";
		}
	}

	/**
	 * Arama ve 404 sayfalarını aranamaz yapar (SEO eklentisi yokken).
	 *
	 * @param array $robots wp_robots değerleri.
	 * @return array
	 */
	public static function robots( $robots ) {
		if ( self::has_plugin() ) {
			return $robots;
		}
		/*
		 * Yalnızca noindex eklenir; follow/nofollow kararını çekirdek verir
		 * (blog_public ayarına göre). Böylece "follow, nofollow" çakışması olmaz.
		 */
		if ( is_search() || is_404() ) {
			$robots['noindex'] = true;
		}
		return $robots;
	}

	/**
	 * JSON-LD yapısal veri basar (LocalBusiness/Organization + FAQPage + Service).
	 *
	 * SEO eklentisi varsa veya panelden kapatıldıysa hiçbir şey basılmaz.
	 *
	 * @return void
	 */
	public static function render_schema() {
		if ( self::has_plugin() || is_404() || is_search() ) {
			return;
		}
		if ( '1' !== devxpe_theme_get( 'schema_enabled', '1' ) ) {
			return;
		}

		$graph = array();

		$business = self::schema_business();
		if ( $business ) {
			$graph[] = $business;
		}

		if ( ( is_front_page() || is_home() ) && '1' === devxpe_theme_get( 'schema_faq', '1' ) ) {
			$faq = self::schema_faq();
			if ( $faq ) {
				$graph[] = $faq;
			}
		}

		if ( '1' === devxpe_theme_get( 'schema_service', '1' ) ) {
			foreach ( self::schema_services() as $service ) {
				$graph[] = $service;
			}
		}

		if ( empty( $graph ) ) {
			return;
		}

		$data = array(
			'@context' => 'https://schema.org',
			'@graph'   => $graph,
		);

		echo '<script type="application/ld+json">'
			. wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE )
			. '</script>' . "\n";
	}

	/**
	 * İşletme/kuruluş düğümü (LocalBusiness / Organization).
	 *
	 * @return array
	 */
	private static function schema_business() {
		$type = devxpe_theme_get( 'schema_type', 'LocalBusiness' );
		$type = in_array( $type, array( 'LocalBusiness', 'Organization' ), true ) ? $type : 'LocalBusiness';

		$name = get_bloginfo( 'name' );
		if ( '' === $name ) {
			return array();
		}

		$node = array(
			'@type' => $type,
			'@id'   => home_url( '/#business' ),
			'name'  => $name,
			'url'   => home_url( '/' ),
		);

		$desc = devxpe_theme_get( 'site_description' );
		if ( ! $desc ) {
			$desc = get_bloginfo( 'description' );
		}
		if ( $desc ) {
			$node['description'] = wp_strip_all_tags( (string) $desc );
		}

		$phone = devxpe_theme_get( 'phone' );
		if ( $phone ) {
			$node['telephone'] = (string) $phone;
		}

		$email = devxpe_theme_get( 'email' );
		if ( $email ) {
			$node['email'] = (string) $email;
		}

		$address = devxpe_theme_get( 'address' );
		if ( $address ) {
			$node['address'] = array(
				'@type'         => 'PostalAddress',
				'streetAddress' => wp_strip_all_tags( (string) $address ),
			);
		}

		$logo = devxpe_theme_get( 'logo' );
		if ( ! $logo ) {
			$logo = get_site_icon_url( 512 );
		}
		if ( $logo ) {
			$node['image'] = $logo;
		}

		if ( 'LocalBusiness' === $type ) {
			$hours = devxpe_theme_get( 'working_hours' );
			if ( $hours ) {
				$node['openingHours'] = wp_strip_all_tags( (string) $hours );
			}
		}

		$same = self::social_urls();
		if ( $same ) {
			$node['sameAs'] = $same;
		}

		if ( '1' === devxpe_theme_get( 'schema_area', '1' ) ) {
			$areas = self::area_names();
			if ( $areas ) {
				$node['areaServed'] = $areas;
			}
		}

		return $node;
	}

	/**
	 * SSS düğümü (FAQPage) — anasayfa SSS maddelerinden.
	 *
	 * @return array
	 */
	private static function schema_faq() {
		$items = (array) devxpe_theme_get( 'faq_items' );
		$q     = array();

		foreach ( $items as $row ) {
			if ( ! is_array( $row ) || empty( $row['title'] ) ) {
				continue;
			}
			$q[] = array(
				'@type'          => 'Question',
				'name'           => wp_strip_all_tags( (string) $row['title'] ),
				'acceptedAnswer' => array(
					'@type' => 'Answer',
					'text'  => wp_strip_all_tags( isset( $row['text'] ) ? (string) $row['text'] : '' ),
				),
			);
		}

		if ( empty( $q ) ) {
			return array();
		}

		return array(
			'@type'      => 'FAQPage',
			'mainEntity' => $q,
		);
	}

	/**
	 * Hizmet düğümleri (Service) — anasayfa hizmet kartları/CPT.
	 *
	 * @return array
	 */
	private static function schema_services() {
		if ( ! ( is_front_page() || is_home() ) ) {
			return array();
		}

		$items = array();

		if ( function_exists( 'devxpe_cards_from_source' ) ) {
			$items = devxpe_cards_from_source(
				devxpe_theme_get( 'services_cards_source', 'cpt:services' ),
				devxpe_theme_get( 'services_cards_limit', '6' )
			);
		}

		if ( empty( $items ) ) {
			foreach ( (array) devxpe_theme_get( 'services_cards' ) as $row ) {
				if ( is_array( $row ) && ! empty( $row['title'] ) ) {
					$items[] = array(
						'title' => $row['title'],
						'text'  => isset( $row['text'] ) ? $row['text'] : '',
					);
				}
			}
		}

		$out = array();
		foreach ( $items as $it ) {
			$title = isset( $it['title'] ) ? wp_strip_all_tags( (string) $it['title'] ) : '';
			if ( '' === $title ) {
				continue;
			}
			$out[] = array(
				'@type'       => 'Service',
				'name'        => $title,
				'description' => isset( $it['text'] ) ? wp_strip_all_tags( (string) $it['text'] ) : '',
				'provider'    => array( '@id' => home_url( '/#business' ) ),
			);
		}

		return $out;
	}

	/**
	 * Sosyal medya URL'leri (dolu olanlar).
	 *
	 * @return array
	 */
	private static function social_urls() {
		$out = array();
		foreach ( array( 'facebook', 'instagram', 'twitter', 'youtube', 'linkedin' ) as $key ) {
			$url = devxpe_theme_get( $key );
			if ( $url ) {
				$out[] = esc_url_raw( $url );
			}
		}
		return $out;
	}

	/**
	 * Hizmet bölgesi adları (CPT 'areas' yoksa panel etiket kaynağı).
	 *
	 * @return array
	 */
	private static function area_names() {
		if ( ! function_exists( 'devxpe_items_list' ) ) {
			return array();
		}

		$items = devxpe_items_list( 'cpt:areas', 20 );
		if ( empty( $items ) ) {
			$src = devxpe_theme_get( 'areas_terms_source', 'none' );
			if ( 'none' !== $src ) {
				$items = devxpe_items_list( $src, 20 );
			}
		}

		$names = array();
		foreach ( (array) $items as $it ) {
			if ( ! empty( $it['title'] ) ) {
				$names[] = wp_strip_all_tags( (string) $it['title'] );
			}
		}
		return $names;
	}

	/**
	 * Sayfaya uygun meta açıklaması üretir.
	 *
	 * @return string
	 */
	private static function description() {
		if ( is_singular() ) {
			$post = get_queried_object();
			if ( $post ) {
				$text = $post->post_excerpt ? $post->post_excerpt : $post->post_content;
				$text = self::trim( wp_strip_all_tags( strip_shortcodes( (string) $text ) ) );
				if ( '' !== $text ) {
					return $text;
				}
			}
			/* İçerik boşsa aşağıdaki son çareye düşer. */
		} elseif ( is_front_page() || is_home() ) {
			$text = devxpe_theme_get( 'site_description' );
			if ( ! $text ) {
				$text = get_bloginfo( 'description' );
			}
			return self::trim( wp_strip_all_tags( (string) $text ) );
		} elseif ( is_category() || is_tag() || is_tax() ) {
			$text = self::trim( wp_strip_all_tags( (string) term_description() ) );
			if ( '' !== $text ) {
				return $text;
			}
		} elseif ( is_post_type_archive() ) {
			$obj = get_queried_object();
			if ( $obj instanceof WP_Post_Type ) {
				$text = self::trim( (string) $obj->description );
				if ( '' !== $text ) {
					return $text;
				}
			}
		}

		/* Son çare: panel site açıklaması / slogan. */
		$text = devxpe_theme_get( 'site_description' );
		if ( ! $text ) {
			$text = get_bloginfo( 'description' );
		}
		return self::trim( wp_strip_all_tags( (string) $text ) );
	}

	/**
	 * Geçerli sayfa URL'si.
	 *
	 * @return string
	 */
	private static function current_url() {
		global $wp;

		if ( is_singular() ) {
			return get_permalink();
		}

		if ( is_search() ) {
			return get_search_link();
		}

		$paged = (int) get_query_var( 'paged' );
		if ( $paged > 1 ) {
			return get_pagenum_link( $paged );
		}

		$path = isset( $wp->request ) ? (string) $wp->request : '';
		return $path ? home_url( user_trailingslashit( $path ) ) : home_url( '/' );
	}

	/**
	 * Paylaşım görseli: öne çıkan görsel > panel logosu > site ikonu.
	 *
	 * @return string
	 */
	private static function image() {
		if ( is_singular() && has_post_thumbnail() ) {
			$img = get_the_post_thumbnail_url( null, 'large' );
			if ( $img ) {
				return $img;
			}
		}

		$logo = devxpe_theme_get( 'logo' );
		if ( $logo ) {
			return $logo;
		}

		$icon = get_site_icon_url( 512 );
		return $icon ? $icon : '';
	}

	/**
	 * Metni boşluklarını sadeleştirip DESC_LEN karaktere kısaltır.
	 *
	 * @param string $text Metin.
	 * @return string
	 */
	private static function trim( $text ) {
		$text = trim( preg_replace( '/\s+/', ' ', (string) $text ) );
		if ( function_exists( 'mb_substr' ) ) {
			return mb_substr( $text, 0, self::DESC_LEN );
		}
		return substr( $text, 0, self::DESC_LEN );
	}
}
