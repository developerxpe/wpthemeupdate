<?php
/**
 * DEVXPE Tema — temel SEO çıktısı.
 *
 * Amaç: bir SEO eklentisi (ör. Yoast) YOKKEN temel başlık/meta/canonical ve
 * Open Graph etiketlerini basmak. Eklenti varsa tema hiçbir etiket basmaz;
 * böylece çakışma olmaz.
 *
 * `add_theme_support( 'title-tag' )` kullanıldığı için <title> burada ELLE
 * basılmaz (WordPress üretir). JSON-LD/schema eklenmez.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DEVXPE_Theme_SEO {

	/**
	 * Meta açıklaması için en fazla karakter.
	 */
	const DESC_LEN = 155;

	/**
	 * Kancaları bağlar.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'wp_head', array( __CLASS__, 'render_head' ), 5 );
		add_filter( 'wp_robots', array( __CLASS__, 'robots' ) );
	}

	/**
	 * Bir SEO eklentisi aktif mi? (Şimdilik Yoast.)
	 *
	 * @return bool
	 */
	public static function has_plugin() {
		return defined( 'WPSEO_VERSION' ) || class_exists( 'WPSEO_Frontend' );
	}

	/**
	 * Head etiketlerini basar (yalnız SEO eklentisi yokken).
	 *
	 * @return void
	 */
	public static function render_head() {
		if ( self::has_plugin() || is_404() ) {
			return;
		}

		$desc  = self::description();
		$url   = self::current_url();
		$image = self::image();
		$title = wp_get_document_title();
		$type  = is_singular( 'post' ) ? 'article' : 'website';

		if ( '' !== $desc ) {
			echo '<meta name="description" content="' . esc_attr( $desc ) . '">' . "\n";
		}

		/*
		 * Canonical: çekirdek `rel_canonical()` yalnızca tekil içerikte basar.
		 * Arşiv/blog gibi diğer sayfalarda kendine işaret eden canonical
		 * burada eklenir. Arama ve 404 zaten noindex olduğu için eklenmez.
		 */
		if ( ! is_singular() && ! is_search() ) {
			echo '<link rel="canonical" href="' . esc_url( $url ) . '">' . "\n";
		}

		echo '<meta property="og:type" content="' . esc_attr( $type ) . '">' . "\n";
		echo '<meta property="og:title" content="' . esc_attr( $title ) . '">' . "\n";
		if ( '' !== $desc ) {
			echo '<meta property="og:description" content="' . esc_attr( $desc ) . '">' . "\n";
		}
		echo '<meta property="og:url" content="' . esc_url( $url ) . '">' . "\n";
		echo '<meta property="og:site_name" content="' . esc_attr( get_bloginfo( 'name' ) ) . '">' . "\n";
		if ( '' !== $image ) {
			echo '<meta property="og:image" content="' . esc_url( $image ) . '">' . "\n";
		}

		echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
		echo '<meta name="twitter:title" content="' . esc_attr( $title ) . '">' . "\n";
		if ( '' !== $desc ) {
			echo '<meta name="twitter:description" content="' . esc_attr( $desc ) . '">' . "\n";
		}
		if ( '' !== $image ) {
			echo '<meta name="twitter:image" content="' . esc_url( $image ) . '">' . "\n";
		}
	}

	/**
	 * Arama ve 404 sayfalarını aranamaz yapar (SEO eklentisi yokken).
	 *
	 * @param array $robots wp_robots değerleri.
	 * @return array
	 */
	public static function robots( $robots ) {
		if ( self::has_plugin() ) {
			return $robots;
		}
		/*
		 * Yalnızca noindex eklenir; follow/nofollow kararını çekirdek verir
		 * (blog_public ayarına göre). Böylece "follow, nofollow" çakışması olmaz.
		 */
		if ( is_search() || is_404() ) {
			$robots['noindex'] = true;
		}
		return $robots;
	}

	/**
	 * Sayfaya uygun meta açıklaması üretir.
	 *
	 * @return string
	 */
	private static function description() {
		if ( is_singular() ) {
			$post = get_queried_object();
			if ( $post ) {
				$text = $post->post_excerpt ? $post->post_excerpt : $post->post_content;
				$text = self::trim( wp_strip_all_tags( strip_shortcodes( (string) $text ) ) );
				if ( '' !== $text ) {
					return $text;
				}
			}
			/* İçerik boşsa aşağıdaki son çareye düşer. */
		} elseif ( is_front_page() || is_home() ) {
			$text = devxpe_theme_get( 'site_description' );
			if ( ! $text ) {
				$text = get_bloginfo( 'description' );
			}
			return self::trim( wp_strip_all_tags( (string) $text ) );
		} elseif ( is_category() || is_tag() || is_tax() ) {
			$text = self::trim( wp_strip_all_tags( (string) term_description() ) );
			if ( '' !== $text ) {
				return $text;
			}
		} elseif ( is_post_type_archive() ) {
			$obj = get_queried_object();
			if ( $obj instanceof WP_Post_Type ) {
				$text = self::trim( (string) $obj->description );
				if ( '' !== $text ) {
					return $text;
				}
			}
		}

		/* Son çare: panel site açıklaması / slogan. */
		$text = devxpe_theme_get( 'site_description' );
		if ( ! $text ) {
			$text = get_bloginfo( 'description' );
		}
		return self::trim( wp_strip_all_tags( (string) $text ) );
	}

	/**
	 * Geçerli sayfa URL'si.
	 *
	 * @return string
	 */
	private static function current_url() {
		global $wp;

		if ( is_singular() ) {
			return get_permalink();
		}

		if ( is_search() ) {
			return get_search_link();
		}

		$paged = (int) get_query_var( 'paged' );
		if ( $paged > 1 ) {
			return get_pagenum_link( $paged );
		}

		$path = isset( $wp->request ) ? (string) $wp->request : '';
		return $path ? home_url( user_trailingslashit( $path ) ) : home_url( '/' );
	}

	/**
	 * Paylaşım görseli: öne çıkan görsel > panel logosu > site ikonu.
	 *
	 * @return string
	 */
	private static function image() {
		if ( is_singular() && has_post_thumbnail() ) {
			$img = get_the_post_thumbnail_url( null, 'large' );
			if ( $img ) {
				return $img;
			}
		}

		$logo = devxpe_theme_get( 'logo' );
		if ( $logo ) {
			return $logo;
		}

		$icon = get_site_icon_url( 512 );
		return $icon ? $icon : '';
	}

	/**
	 * Metni boşluklarını sadeleştirip DESC_LEN karaktere kısaltır.
	 *
	 * @param string $text Metin.
	 * @return string
	 */
	private static function trim( $text ) {
		$text = trim( preg_replace( '/\s+/', ' ', (string) $text ) );
		if ( function_exists( 'mb_substr' ) ) {
			return mb_substr( $text, 0, self::DESC_LEN );
		}
		return substr( $text, 0, self::DESC_LEN );
	}
}
