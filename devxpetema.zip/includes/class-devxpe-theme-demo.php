<?php
/**
 * DEVXPE demo içerik kurucusu.
 *
 * Panelden ya da kurulum sihirbazından tek tıkla:
 * - Sayfalar (Anasayfa, Blog, Hakkımızda, İletişim, yasal sayfalar)
 * - Özel içerik tipleri (hizmetler, bölgeler) ve örnek kayıtlar
 * - Menü + ön sayfa/blog ayarları
 * - Tema ayarları (metinler, kartlar, iletişim, demo görselleri)
 *
 * Metinler tema yazarının kendi metinleridir; panel diline göre TR/EN kurulur.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DEVXPE_Theme_Demo {

	const STATE_KEY  = 'devxpe_demo_state';
	const IMG_COUNT  = 9;

	/**
	 * O an kurulmakta olan demonun kimliği.
	 *
	 * Kurulum isteği boyunca sabittir; `data()/options()/strings()` bu kimliğe
	 * göre doğru sağlayıcıdan içerik çeker.
	 *
	 * @var string
	 */
	private static $current_demo = '';

	/**
	 * Kancaları bağlar.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_post_devxpe_demo_install', array( __CLASS__, 'handle_install' ) );
		add_action( 'admin_post_devxpe_demo_remove', array( __CLASS__, 'handle_remove' ) );
		add_action( 'wp_ajax_devxpe_demo_step', array( __CLASS__, 'handle_step_ajax' ) );
	}

	/**
	 * Dil kimlikleri.
	 *
	 * @return array
	 */
	public static function langs() {
		return array( 'tr', 'en' );
	}

	/**
	 * Demo metin dili.
	 *
	 * Panelden bir dil seçilmişse (Tema dili: Türkçe/İngilizce) demo içeriği
	 * O dilde kurulur; "Otomatik" seçiliyse site diline (get_locale) düşer.
	 *
	 * @return string 'tr' | 'en'
	 */
	public static function lang() {
		if ( class_exists( 'DEVXPE_Theme_Language' ) ) {
			$a = DEVXPE_Theme_Language::selected();
			if ( 'en_US' === $a ) {
				return 'en';
			}
			if ( 'tr_TR' === $a ) {
				return 'tr';
			}
		}

		return ( 0 === strpos( (string) get_locale(), 'tr' ) ) ? 'tr' : 'en';
	}

	/**
	 * Kurulum için etkin demo kimliği.
	 *
	 * @param string $istenen Zorlanmak istenen kimlik (opsiyonel).
	 * @return string
	 */
	public static function demo_id( $istenen = '' ) {
		if ( '' !== self::$current_demo && '' === $istenen ) {
			return self::$current_demo;
		}

		$id = class_exists( 'DEVXPE_Theme_Demos' )
			? DEVXPE_Theme_Demos::active_id( $istenen )
			: 'arc';

		return $id;
	}

	/**
	 * Demo kurulu mu?
	 *
	 * @return bool
	 */
	public static function is_installed() {
		$state = get_option( self::STATE_KEY, array() );
		return is_array( $state ) && ! empty( $state['ids'] );
	}

	/**
	 * Demo paketindeki görsel sayısı (fotoğraflar; logolar hariç).
	 *
	 * @return int
	 */
	public static function image_count() {
		$id = self::demo_id();

		if ( class_exists( 'DEVXPE_Theme_Demos' ) ) {
			return DEVXPE_Theme_Demos::images( $id );
		}

		return self::IMG_COUNT;
	}

	/**
	 * Demo görsel seti (tasarım) kimliği.
	 *
	 * Görseller pakette değil, GitHub'daki katalogdadır; her tasarımın kendi
	 * seti vardır. Child tasarımlar `devxpe_demo_asset_design` filtresiyle
	 * kendi setini seçebilir.
	 *
	 * @return string
	 */
	private static function demo_design() {
		$design = (string) apply_filters( 'devxpe_demo_asset_design', '' );
		if ( '' !== $design ) {
			return $design;
		}

		/*
		 * Kurulan demo yerleşik varsayılan değilse onun kendi görsel klasörü
		 * kullanılır. Yerleşik demoda eski davranış korunur: aktif görünüm bir
		 * child ise onun slug'ı, değilse 'arc'.
		 */
		$id = self::demo_id();

		if ( class_exists( 'DEVXPE_Theme_Demos' ) && $id !== DEVXPE_Theme_Demos::default_id() ) {
			return DEVXPE_Theme_Demos::design( $id );
		}

		$active = get_stylesheet();
		if ( $active !== get_template() ) {
			return $active;
		}

		return class_exists( 'DEVXPE_Theme_Demos' ) ? DEVXPE_Theme_Demos::DEFAULT_ID : 'arc';
	}

	/**
	 * Demo görsellerinin uzak taban adresi (`main/<tasarım>/demo/`).
	 *
	 * Klasör yapısı: `main/<tasarım-slug>/demo/demo-1.jpg … logo.png`
	 * Seçili tema değişince (`switch_theme`) demo görselleri o temanın
	 * `demo/` klasöründen çekilir.
	 *
	 * @return string
	 */
	private static function assets_base_url() {
		$base = class_exists( 'DEVXPE_Theme_Library' )
			? DEVXPE_Theme_Library::assets_base()
			: trailingslashit( defined( 'DEVXPE_ASSETS_BASE' ) ? DEVXPE_ASSETS_BASE : 'https://raw.githubusercontent.com/developerxpe/wpthemeupdate/assets/' );

		$base = (string) apply_filters( 'devxpe_demo_assets_url', $base );

		return trailingslashit( $base ) . self::demo_design() . '/demo/';
	}

	/**
	 * Demo görselleri: ad => kaynak (yerel dosya varsa o, yoksa uzak URL).
	 *
	 * Yerel kopya varsa (geliştirme) onu kullanır; pakette yerel kopya
	 * bulunmaz, bu yüzden üretimde GitHub'dan çekilir.
	 *
	 * @return array
	 */
	private static function demo_assets() {
		$out = array();

		$adet = self::image_count();

		for ( $i = 1; $i <= $adet; $i++ ) {
			$file  = 'demo-' . $i . '.jpg';
			$local = DEVXPE_THEME_PATH . 'assets/img/demo/' . $file;
			$out[ 'demo-' . $i ] = file_exists( $local ) ? $local : self::assets_base_url() . $file;
		}

		foreach ( array( 'logo' => 'logo.png', 'logo-light' => 'logo-light.png' ) as $key => $file ) {
			$local = DEVXPE_THEME_PATH . 'assets/img/demo/' . $file;
			$out[ $key ] = file_exists( $local ) ? $local : self::assets_base_url() . $file;
		}

		return $out;
	}

	/**
	 * Bir demo dosyasının içeriğini döndürür (yerel yol veya uzak URL).
	 *
	 * @param string $src Yerel mutlak yol ya da http(s) URL.
	 * @return string Dosya içeriği; başarısızsa ''.
	 */
	private static function fetch_demo_file( $src ) {
		if ( file_exists( $src ) ) {
			$data = file_get_contents( $src ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			return ( false === $data ) ? '' : $data;
		}

		if ( ! wp_http_validate_url( $src ) ) {
			return '';
		}

		$res = wp_remote_get( $src, array( 'timeout' => 20 ) );
		if ( is_wp_error( $res ) || 200 !== (int) wp_remote_retrieve_response_code( $res ) ) {
			return '';
		}

		return (string) wp_remote_retrieve_body( $res );
	}

	/**
	 * Kaynağın uzantısı (jpg/png).
	 *
	 * @param string $src Kaynak.
	 * @return string
	 */
	private static function demo_ext( $src ) {
		$path = preg_replace( '/\?.*$/', '', (string) $src );
		return ( '.png' === strtolower( substr( $path, -4 ) ) ) ? 'png' : 'jpg';
	}

	/* ══════════════════════════════════════════════════════════
	   Kur / kaldır
	   ══════════════════════════════════════════════════════════ */

	/**
	 * Panel/kurulum formundan demoyu kurar.
	 *
	 * @return void
	 */
	public static function handle_install() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Yetkiniz yok.', 'devxpe-theme' ) );
		}
		check_admin_referer( 'devxpe_demo_install' );

		$demo = isset( $_GET['demo'] ) ? sanitize_key( wp_unslash( $_GET['demo'] ) ) : '';

		self::install( '', $demo );

		wp_safe_redirect( devxpe_panel_url( '&demo=installed#settings--demo' ) );
		exit;
	}

	/**
	 * Demoyu kaldırır.
	 *
	 * @return void
	 */
	public static function handle_remove() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Yetkiniz yok.', 'devxpe-theme' ) );
		}
		check_admin_referer( 'devxpe_demo_remove' );

		self::remove();

		wp_safe_redirect( devxpe_panel_url( '&demo=removed#settings--demo' ) );
		exit;
	}

	/**
	 * AJAX: kurulumun tek adımını çalıştırır (panel ilerleme çubuğu için).
	 *
	 * @return void
	 */
	public static function handle_step_ajax() {
		check_ajax_referer( 'devxpe_demo_step', 'nonce' );

		$adim = isset( $_POST['adim'] ) ? sanitize_key( wp_unslash( $_POST['adim'] ) ) : '';

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array(
					'ok'      => false,
					'adim'    => $adim,
					'sonraki' => '',
					'yuzde'   => 0,
					'mesaj'   => __( 'Yetkiniz yok.', 'devxpe-theme' ),
				)
			);
		}

		$lang  = isset( $_POST['lang'] ) ? sanitize_key( wp_unslash( $_POST['lang'] ) ) : '';
		$demo  = isset( $_POST['demo'] ) ? sanitize_key( wp_unslash( $_POST['demo'] ) ) : '';
		$sonuc = self::step( $adim, $lang, $demo );

		if ( empty( $sonuc['ok'] ) ) {
			wp_send_json_error( $sonuc );
		}

		wp_send_json_success( $sonuc );
	}

	/**
	 * Demo içeriğini kurar.
	 *
	 * @param string $lang Dil ('tr'|'en'|''=otomatik).
	 * @param string $demo Demo kimliği (''=etkin/varsayılan).
	 * @return bool
	 */
	public static function install( $lang = '', $demo = '' ) {
		self::$current_demo = self::demo_id( $demo );

		$lang = in_array( $lang, self::langs(), true ) ? $lang : self::lang();
		$d    = self::data( $lang );

		/* Zaten kuruluysa önce temizle — çift kayıt oluşmasın. */
		if ( self::is_installed() ) {
			self::remove();
		}

		$state = array(
			'lang'   => $lang,
			'demo'   => self::$current_demo,
			'ids'    => array(
				'pages'       => array(),
				'posts'       => array(),
				'cpt'         => array(),
				'attachments' => array(),
				'menu'        => 0,
			),
			'backup' => array(
				'options'         => get_option( 'devxpe_theme_options', array() ),
				'show_on_front'   => get_option( 'show_on_front' ),
				'page_on_front'   => get_option( 'page_on_front' ),
				'page_for_posts'  => get_option( 'page_for_posts' ),
				'blogname'        => get_option( 'blogname' ),
				'blogdescription' => get_option( 'blogdescription' ),
			),
		);

		/* Durumu hemen kaydet: yarıda kesilse bile "kaldır" temizleyebilsin. */
		update_option( self::STATE_KEY, $state, false );

		$img = self::import_images( $state );
		update_option( self::STATE_KEY, $state, false );

		/* 1) İçerik tipleri tanımı + tema ayarları */
		$options = $state['backup']['options'];
		if ( ! is_array( $options ) ) {
			$options = array();
		}
		$options = array_merge( $options, self::options( $d, $img ) );

		$options['custom_post_types'] = array(
			array( 'name' => $d['cpt_services'], 'slug' => 'services', 'icon' => 'dashicons-hammer', 'archive' => '1', 'template' => 'layout_1' ),
			array( 'name' => $d['cpt_areas'], 'slug' => 'areas', 'icon' => 'dashicons-location-alt', 'archive' => '0', 'template' => 'layout_2' ),
		);

		update_option( 'devxpe_theme_options', $options, false );

		if ( function_exists( 'devxpe_register_custom_post_types' ) ) {
			devxpe_register_custom_post_types();
		}

		/* 2) Sayfalar */
		$pages = array();
		foreach ( $d['pages'] as $key => $page ) {
			$id = wp_insert_post(
				array(
					'post_type'    => 'page',
					'post_status'  => 'publish',
					'post_title'   => $page['title'],
					'post_name'    => $page['slug'],
					'post_content' => $page['content'],
				)
			);
			if ( $id && ! is_wp_error( $id ) ) {
				$pages[ $key ] = $id;
				$state['ids']['pages'][] = $id;
				update_post_meta( $id, '_dxp_demo', '1' );
				/* Şablon seçimi: WordPress şablon listesi yerine metabox alanı. */
				$dxp_tpl = isset( $page['template'] ) ? $page['template'] : '';
				if ( 'page-about.php' === $dxp_tpl ) {
					update_post_meta( $id, '_dxp_page_type', 'about' );
				} elseif ( 'page-contact.php' === $dxp_tpl ) {
					update_post_meta( $id, '_dxp_page_type', 'contact' );
				}

				/*
				 * Hakkımızda istatistikleri: varsayilan_liste() bu satırları
				 * `_dxp_about_stats` meta'sından okur. Bu yüzden meta, widget
				 * listesi ÜRETİLMEDEN ÖNCE yazılır; aksi hâlde "stats" widget'ı
				 * listeye hiç girmez (meta sonra yazılırsa okuma onu görmez).
				 */
				if ( ! empty( $page['about_stats'] ) ) {
					update_post_meta( $id, '_dxp_about_cols', '3' );
					update_post_meta( $id, '_dxp_about_stats', $page['about_stats'] );
				}

				/*
				 * Sayfa düzeni hazır gelsin: demo sayfası "İçerik Düzeni"
				 * widgetsiz açılmasın. Varsayılan widget listesi nested
				 * düzende yazılır; iletişim formu referans tasarımda olduğu gibi sağ
				 * kolona atanır.
				 */
				if ( in_array( $dxp_tpl, array( 'page-about.php', 'page-contact.php' ), true ) && class_exists( 'DEVXPE_Page_Widgets' ) ) {
					$dxp_baglam = ( 'page-contact.php' === $dxp_tpl ) ? 'contact' : 'about';
					$dxp_liste  = DEVXPE_Page_Widgets::varsayilan_liste( $dxp_baglam, $id );
					$dxp_sag    = ( 'contact' === $dxp_baglam ) ? array( 'form' ) : array();

					foreach ( $dxp_liste as $dxp_i => $dxp_w ) {
						if ( in_array( $dxp_w['tip'], $dxp_sag, true ) ) {
							$dxp_liste[ $dxp_i ]['yer'] = 'sag';
						}
					}

					if ( $dxp_liste ) {
						update_post_meta( $id, DEVXPE_Page_Widgets::META_KEY, wp_slash( wp_json_encode( $dxp_liste ) ) );
						update_post_meta( $id, DEVXPE_Page_Widgets::DUZEN_KEY, 'nested' );
					}
				}
			}
		}

		/* 3) Özel içerik kayıtları */
		foreach ( $d['cpt_items'] as $type => $items ) {
			foreach ( $items as $item ) {
				$id = wp_insert_post(
					array(
						'post_type'    => $type,
						'post_status'  => 'publish',
						'post_title'   => $item['title'],
						'post_name'    => $item['slug'],
						'post_content' => isset( $item['content'] ) ? $item['content'] : '',
					)
				);
				if ( ! $id || is_wp_error( $id ) ) {
					continue;
				}
				$state['ids']['cpt'][] = $id;
				update_post_meta( $id, '_dxp_demo', '1' );

				$item_meta = isset( $item['meta'] ) && is_array( $item['meta'] ) ? $item['meta'] : array();
				$item_meta = array_merge( self::cpt_default_meta( $type, $item, $d, $img ), $item_meta );
				foreach ( $item_meta as $meta_key => $meta_value ) {
					update_post_meta( $id, $meta_key, $meta_value );
				}
			}
		}

		/* 4) Yazılar */
		foreach ( $d['posts'] as $post ) {
			$id = wp_insert_post(
				array(
					'post_type'    => 'post',
					'post_status'  => 'publish',
					'post_title'   => $post['title'],
					'post_content' => $post['content'],
				)
			);
			if ( $id && ! is_wp_error( $id ) ) {
				$state['ids']['posts'][] = $id;
				update_post_meta( $id, '_dxp_demo', '1' );
			}
		}
		update_option( self::STATE_KEY, $state, false );

		/* 5) Sayfa bağlantıları: teklif butonu + yasal linkler */
		$legal = array();
		foreach ( array( 'privacy', 'cookies', 'terms' ) as $legal_key ) {
			if ( ! empty( $pages[ $legal_key ] ) ) {
				$legal[] = (int) $pages[ $legal_key ];
			}
		}
		if ( $legal ) {
			$options['footer_legal_pages']  = $legal;
			$options['footer_legal_source'] = 'none';
		}
		if ( ! empty( $pages['contact'] ) ) {
			$contact_url               = get_permalink( $pages['contact'] );
			$options['header_btn_url'] = $contact_url;
			$options['hero_btn_url']   = $contact_url;
		}
		update_option( 'devxpe_theme_options', $options, false );

		/* 6) Menü */
		$state['ids']['menu'] = self::build_menu( $d, $pages );

		/* 7) Ön sayfa / blog */
		if ( isset( $pages['home'] ) ) {
			update_option( 'show_on_front', 'page' );
			update_option( 'page_on_front', $pages['home'] );
		}
		if ( isset( $pages['blog'] ) ) {
			update_option( 'page_for_posts', $pages['blog'] );
		}

		devxpe_safe_update_blog_option( 'blogname', $d['site_title'] );
		devxpe_safe_update_blog_option( 'blogdescription', $d['tagline'] );

		update_option( self::STATE_KEY, $state, false );
		flush_rewrite_rules( false );

		return true;
	}

	/* ══════════════════════════════════════════════════════════
	   Adım adım (AJAX) kurulum
	   ══════════════════════════════════════════════════════════ */

	/**
	 * Kurulum adımlarının sırası.
	 *
	 * @return array
	 */
	public static function steps() {
		return array( 'hazirlik', 'gorseller', 'ayarlar', 'sayfalar', 'icerikler', 'linkler', 'menu', 'bitis' );
	}

	/**
	 * Kurulumun TEK adımını çalıştırır ve ilerleme bilgisini döndürür.
	 *
	 * Durum `self::STATE_KEY` option'ında saklanır; bu yüzden bir adım
	 * hata verirse aynı adım yeniden çağrılarak kaldığı yerden devam eder.
	 *
	 * @param string $adim Adım adı (steps() listesinden).
	 * @param string $lang Dil ('tr'|'en'|''=otomatik).
	 * @param string $demo Demo kimliği (''=durumdan/etkin).
	 * @return array{ok:bool,adim:string,sonraki:string,yuzde:int,mesaj:string}
	 */
	public static function step( $adim, $lang = '', $demo = '' ) {
		$adim  = sanitize_key( (string) $adim );
		$steps = self::steps();

		if ( ! in_array( $adim, $steps, true ) ) {
			return array(
				'ok'      => false,
				'adim'    => $adim,
				'sonraki' => '',
				'yuzde'   => 0,
				'mesaj'   => __( 'Geçersiz kurulum adımı.', 'devxpe-theme' ),
			);
		}

		if ( 'hazirlik' === $adim ) {
			return self::step_hazirlik( $lang, $demo );
		}

		$state = get_option( self::STATE_KEY, array() );
		if ( ! is_array( $state ) || empty( $state['ids'] ) ) {
			return array(
				'ok'      => false,
				'adim'    => $adim,
				'sonraki' => 'hazirlik',
				'yuzde'   => 0,
				'mesaj'   => __( 'Kurulum durumu bulunamadı; baştan başlatın.', 'devxpe-theme' ),
			);
		}

		$state_lang = ( isset( $state['lang'] ) && in_array( $state['lang'], self::langs(), true ) ) ? $state['lang'] : self::lang();

		/* Kurulumun geri kalanı, hazırlıkta kilitlenen demoyla devam etmeli. */
		if ( ! empty( $state['demo'] ) ) {
			self::$current_demo = self::demo_id( $state['demo'] );
		} elseif ( '' !== $demo ) {
			self::$current_demo = self::demo_id( $demo );
		}

		switch ( $adim ) {
			case 'gorseller':
				return self::step_gorseller( $state );
			case 'ayarlar':
				return self::step_ayarlar( $state, $state_lang );
			case 'sayfalar':
				return self::step_sayfalar( $state, $state_lang );
			case 'icerikler':
				return self::step_icerikler( $state, $state_lang );
			case 'linkler':
				return self::step_linkler( $state, $state_lang );
			case 'menu':
				return self::step_menu( $state, $state_lang );
			case 'bitis':
				return self::step_bitis( $state );
		}

		return array(
			'ok'      => false,
			'adim'    => $adim,
			'sonraki' => '',
			'yuzde'   => 0,
			'mesaj'   => __( 'Adım yürütülemedi.', 'devxpe-theme' ),
		);
	}

	/**
	 * Başarılı adım yanıtı üretir.
	 *
	 * @param string $adim    Tamamlanan adım.
	 * @param string $sonraki Sıradaki adım ('' = bitti).
	 * @param int    $yuzde   Tamamlanma yüzdesi (0-100).
	 * @param string $mesaj   Kullanıcıya gösterilecek mesaj.
	 * @return array
	 */
	private static function step_don( $adim, $sonraki, $yuzde, $mesaj ) {
		return array(
			'ok'      => true,
			'adim'    => $adim,
			'sonraki' => $sonraki,
			'yuzde'   => (int) $yuzde,
			'mesaj'   => $mesaj,
		);
	}

	/**
	 * Adım: hazırlık (eski demo temizliği + durum iskeleti). 0→5.
	 *
	 * @param string $lang Dil.
	 * @param string $demo Demo kimliği (''=etkin/varsayılan).
	 * @return array
	 */
	private static function step_hazirlik( $lang, $demo = '' ) {
		self::$current_demo = self::demo_id( $demo );

		$lang = in_array( $lang, self::langs(), true ) ? $lang : self::lang();

		/* Zaten kuruluysa önce temizle — çift kayıt oluşmasın. */
		if ( self::is_installed() ) {
			self::remove();
		}

		$state = array(
			'lang'     => $lang,
			'demo'     => self::$current_demo,
			'ids'      => array(
				'pages'       => array(),
				'posts'       => array(),
				'cpt'         => array(),
				'attachments' => array(),
				'menu'        => 0,
			),
			'backup'   => array(
				'options'         => get_option( 'devxpe_theme_options', array() ),
				'show_on_front'   => get_option( 'show_on_front' ),
				'page_on_front'   => get_option( 'page_on_front' ),
				'page_for_posts'  => get_option( 'page_for_posts' ),
				'blogname'        => get_option( 'blogname' ),
				'blogdescription' => get_option( 'blogdescription' ),
			),
			'progress' => array( 'img_index' => 0 ),
			'img_urls' => array(),
			'page_ids' => array(),
			'options'  => array(),
			'adimlar'  => array( 'hazirlik' ),
		);

		update_option( self::STATE_KEY, $state, false );

		return self::step_don( 'hazirlik', 'gorseller', 5, __( 'Kurulum için hazırlık yapıldı.', 'devxpe-theme' ) );
	}

	/**
	 * Adım: görseller (her çağrıda bir görsel). 5→45.
	 *
	 * @param array $state Durum (referans).
	 * @return array
	 */
	private static function step_gorseller( &$state ) {
		$urls = self::import_images_partial( $state, 1 );
		update_option( self::STATE_KEY, $state, false );

		$total = count( self::demo_assets() );
		$index = isset( $state['progress']['img_index'] ) ? (int) $state['progress']['img_index'] : $total;
		$yuzde = ( $total > 0 ) ? 5 + (int) round( 40 * ( $index / $total ) ) : 45;

		if ( $index >= $total ) {
			return self::step_don(
				'gorseller',
				'ayarlar',
				45,
				sprintf(
					/* translators: %d: indirilen görsel sayısı. */
					__( '%d görsel indirildi.', 'devxpe-theme' ),
					count( $urls )
				)
			);
		}

		return self::step_don(
			'gorseller',
			'gorseller',
			$yuzde,
			sprintf(
				/* translators: 1: işlenen, 2: toplam görsel. */
				__( 'Görseller indiriliyor… (%1$d/%2$d)', 'devxpe-theme' ),
				$index,
				$total
			)
		);
	}

	/**
	 * Adım: tema ayarları + içerik tipleri. 45→55.
	 *
	 * @param array  $state Durum (referans).
	 * @param string $lang  Dil.
	 * @return array
	 */
	private static function step_ayarlar( &$state, $lang ) {
		$d   = self::data( $lang );
		$img = isset( $state['img_urls'] ) && is_array( $state['img_urls'] ) ? $state['img_urls'] : array();

		$options = isset( $state['backup']['options'] ) ? $state['backup']['options'] : array();
		if ( ! is_array( $options ) ) {
			$options = array();
		}
		$options = array_merge( $options, self::options( $d, $img ) );

		$options['custom_post_types'] = array(
			array( 'name' => $d['cpt_services'], 'slug' => 'services', 'icon' => 'dashicons-hammer', 'archive' => '1', 'template' => 'layout_1' ),
			array( 'name' => $d['cpt_areas'], 'slug' => 'areas', 'icon' => 'dashicons-location-alt', 'archive' => '0', 'template' => 'layout_2' ),
		);

		update_option( 'devxpe_theme_options', $options, false );

		if ( function_exists( 'devxpe_register_custom_post_types' ) ) {
			devxpe_register_custom_post_types();
		}

		$state['options'] = $options;
		update_option( self::STATE_KEY, $state, false );

		return self::step_don( 'ayarlar', 'sayfalar', 55, __( 'Tema ayarları ve içerik tipleri kaydedildi.', 'devxpe-theme' ) );
	}

	/**
	 * Adım: sayfalar (meta + widget tohumlama). 55→70.
	 *
	 * @param array  $state Durum (referans).
	 * @param string $lang  Dil.
	 * @return array
	 */
	private static function step_sayfalar( &$state, $lang ) {
		$d = self::data( $lang );

		if ( ! isset( $state['page_ids'] ) || ! is_array( $state['page_ids'] ) ) {
			$state['page_ids'] = array();
		}

		foreach ( $d['pages'] as $key => $page ) {
			$id = wp_insert_post(
				array(
					'post_type'    => 'page',
					'post_status'  => 'publish',
					'post_title'   => $page['title'],
					'post_name'    => $page['slug'],
					'post_content' => $page['content'],
				)
			);
			if ( ! $id || is_wp_error( $id ) ) {
				continue;
			}

			$state['page_ids'][ $key ] = $id;
			$state['ids']['pages'][]   = $id;
			update_post_meta( $id, '_dxp_demo', '1' );

			/* Şablon seçimi: WordPress şablon listesi yerine metabox alanı. */
			$dxp_tpl = isset( $page['template'] ) ? $page['template'] : '';
			if ( 'page-about.php' === $dxp_tpl ) {
				update_post_meta( $id, '_dxp_page_type', 'about' );
			} elseif ( 'page-contact.php' === $dxp_tpl ) {
				update_post_meta( $id, '_dxp_page_type', 'contact' );
			}

			/*
			 * Hakkımızda istatistikleri: varsayilan_liste() bu satırları
			 * `_dxp_about_stats` meta'sından okur; widget listesi ÜRETİLMEDEN
			 * önce yazılmalıdır.
			 */
			if ( ! empty( $page['about_stats'] ) ) {
				update_post_meta( $id, '_dxp_about_cols', '3' );
				update_post_meta( $id, '_dxp_about_stats', $page['about_stats'] );
			}

			/* Sayfa düzeni hazır gelsin: varsayılan widget listesi. */
			if ( in_array( $dxp_tpl, array( 'page-about.php', 'page-contact.php' ), true ) && class_exists( 'DEVXPE_Page_Widgets' ) ) {
				$dxp_baglam = ( 'page-contact.php' === $dxp_tpl ) ? 'contact' : 'about';
				$dxp_liste  = DEVXPE_Page_Widgets::varsayilan_liste( $dxp_baglam, $id );
				$dxp_sag    = ( 'contact' === $dxp_baglam ) ? array( 'form' ) : array();

				foreach ( $dxp_liste as $dxp_i => $dxp_w ) {
					if ( in_array( $dxp_w['tip'], $dxp_sag, true ) ) {
						$dxp_liste[ $dxp_i ]['yer'] = 'sag';
					}
				}

				if ( $dxp_liste ) {
					update_post_meta( $id, DEVXPE_Page_Widgets::META_KEY, wp_slash( wp_json_encode( $dxp_liste ) ) );
					update_post_meta( $id, DEVXPE_Page_Widgets::DUZEN_KEY, 'nested' );
				}
			}
		}

		update_option( self::STATE_KEY, $state, false );

		return self::step_don(
			'sayfalar',
			'icerikler',
			70,
			sprintf(
				/* translators: %d: sayfa sayısı. */
				__( '%d sayfa oluşturuldu.', 'devxpe-theme' ),
				count( $state['page_ids'] )
			)
		);
	}

	/**
	 * Adım: hizmet/bölge kayıtları + blog yazıları. 70→85.
	 *
	 * @param array  $state Durum (referans).
	 * @param string $lang  Dil.
	 * @return array
	 */
	private static function step_icerikler( &$state, $lang ) {
		$d   = self::data( $lang );
		$img = isset( $state['img_urls'] ) && is_array( $state['img_urls'] ) ? $state['img_urls'] : array();

		/* 1) Özel içerik kayıtları. */
		foreach ( $d['cpt_items'] as $type => $items ) {
			foreach ( $items as $item ) {
				$id = wp_insert_post(
					array(
						'post_type'    => $type,
						'post_status'  => 'publish',
						'post_title'   => $item['title'],
						'post_name'    => $item['slug'],
						'post_content' => isset( $item['content'] ) ? $item['content'] : '',
					)
				);
				if ( ! $id || is_wp_error( $id ) ) {
					continue;
				}
				$state['ids']['cpt'][] = $id;
				update_post_meta( $id, '_dxp_demo', '1' );

				$item_meta = isset( $item['meta'] ) && is_array( $item['meta'] ) ? $item['meta'] : array();
				$item_meta = array_merge( self::cpt_default_meta( $type, $item, $d, $img ), $item_meta );
				foreach ( $item_meta as $meta_key => $meta_value ) {
					update_post_meta( $id, $meta_key, $meta_value );
				}
			}
		}

		/* 2) Yazılar. */
		foreach ( $d['posts'] as $post ) {
			$id = wp_insert_post(
				array(
					'post_type'    => 'post',
					'post_status'  => 'publish',
					'post_title'   => $post['title'],
					'post_content' => $post['content'],
				)
			);
			if ( $id && ! is_wp_error( $id ) ) {
				$state['ids']['posts'][] = $id;
				update_post_meta( $id, '_dxp_demo', '1' );
			}
		}

		update_option( self::STATE_KEY, $state, false );

		return self::step_don( 'icerikler', 'linkler', 85, __( 'Hizmet, bölge ve blog kayıtları eklendi.', 'devxpe-theme' ) );
	}

	/**
	 * Adım: yasal linkler + header/hero buton bağlantıları. 85→90.
	 *
	 * @param array  $state Durum (referans).
	 * @param string $lang  Dil.
	 * @return array
	 */
	private static function step_linkler( &$state, $lang ) {
		$pages   = isset( $state['page_ids'] ) && is_array( $state['page_ids'] ) ? $state['page_ids'] : array();
		$options = isset( $state['options'] ) && is_array( $state['options'] ) ? $state['options'] : get_option( 'devxpe_theme_options', array() );
		if ( ! is_array( $options ) ) {
			$options = array();
		}

		$legal = array();
		foreach ( array( 'privacy', 'cookies', 'terms' ) as $legal_key ) {
			if ( ! empty( $pages[ $legal_key ] ) ) {
				$legal[] = (int) $pages[ $legal_key ];
			}
		}
		if ( $legal ) {
			$options['footer_legal_pages']  = $legal;
			$options['footer_legal_source'] = 'none';
		}
		if ( ! empty( $pages['contact'] ) ) {
			$contact_url               = get_permalink( $pages['contact'] );
			$options['header_btn_url'] = $contact_url;
			$options['hero_btn_url']   = $contact_url;
		}

		update_option( 'devxpe_theme_options', $options, false );

		$state['options'] = $options;
		update_option( self::STATE_KEY, $state, false );

		return self::step_don( 'linkler', 'menu', 90, __( 'Menü ve buton bağlantıları ayarlandı.', 'devxpe-theme' ) );
	}

	/**
	 * Adım: menü + ön sayfa/blog. 90→95.
	 *
	 * @param array  $state Durum (referans).
	 * @param string $lang  Dil.
	 * @return array
	 */
	private static function step_menu( &$state, $lang ) {
		$d     = self::data( $lang );
		$pages = isset( $state['page_ids'] ) && is_array( $state['page_ids'] ) ? $state['page_ids'] : array();

		$state['ids']['menu'] = self::build_menu( $d, $pages );

		if ( isset( $pages['home'] ) ) {
			update_option( 'show_on_front', 'page' );
			update_option( 'page_on_front', $pages['home'] );
		}
		if ( isset( $pages['blog'] ) ) {
			update_option( 'page_for_posts', $pages['blog'] );
		}

		devxpe_safe_update_blog_option( 'blogname', $d['site_title'] );
		devxpe_safe_update_blog_option( 'blogdescription', $d['tagline'] );

		update_option( self::STATE_KEY, $state, false );

		return self::step_don( 'menu', 'bitis', 95, __( 'Menü ve ön sayfa ayarları kuruldu.', 'devxpe-theme' ) );
	}

	/**
	 * Adım: bitiş (rewrite + son durum). 95→100.
	 *
	 * @param array $state Durum (referans).
	 * @return array
	 */
	private static function step_bitis( &$state ) {
		flush_rewrite_rules( false );

		if ( ! isset( $state['adimlar'] ) || ! is_array( $state['adimlar'] ) ) {
			$state['adimlar'] = array();
		}
		$state['adimlar'][] = 'bitis';

		update_option( self::STATE_KEY, $state, false );

		return self::step_don( 'bitis', '', 100, __( 'Demo kurulumu tamamlandı.', 'devxpe-theme' ) );
	}

	/**
	 * Kurulan demo içeriğini siler ve ayarları geri yükler.
	 *
	 * @return void
	 */
	public static function remove() {
		$state = get_option( self::STATE_KEY, array() );
		$ids   = ( is_array( $state ) && ! empty( $state['ids'] ) ) ? $state['ids'] : array();

		/* 1) Bilinen ID'ler (state varsa). */
		if ( $ids ) {
			foreach ( array( 'cpt', 'posts', 'pages' ) as $group ) {
				foreach ( (array) ( isset( $ids[ $group ] ) ? $ids[ $group ] : array() ) as $id ) {
					wp_delete_post( (int) $id, true );
				}
			}
			foreach ( (array) ( isset( $ids['attachments'] ) ? $ids['attachments'] : array() ) as $id ) {
				wp_delete_attachment( (int) $id, true );
			}
		}

		/*
		 * 2) Emniyet kemeri: state kaybolsa bile `_dxp_demo` ile işaretli tüm
		 *    demo içeriğini (sayfa, yazı, içerik tipi, görsel) sil. Böylece
		 *    yarıda kalan/eski kurulumların artığı kalmaz.
		 */
		$dxp_flagged = get_posts(
			array(
				'post_type'      => 'any',
				'post_status'    => 'any',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'meta_key'       => '_dxp_demo',
			)
		);
		foreach ( $dxp_flagged as $dxp_id ) {
			if ( 'attachment' === get_post_type( $dxp_id ) ) {
				wp_delete_attachment( (int) $dxp_id, true );
			} else {
				wp_delete_post( (int) $dxp_id, true );
			}
		}

		if ( ! empty( $ids['menu'] ) ) {
			wp_delete_nav_menu( (int) $ids['menu'] );
		}

		/* Ayarları geri yükle */
		$backup = isset( $state['backup'] ) ? $state['backup'] : array();

		if ( isset( $backup['options'] ) ) {
			update_option( 'devxpe_theme_options', $backup['options'], false );
		}
		if ( isset( $backup['show_on_front'], $backup['page_on_front'], $backup['page_for_posts'] ) ) {
			update_option( 'show_on_front', $backup['show_on_front'] );
			update_option( 'page_on_front', $backup['page_on_front'] );
			update_option( 'page_for_posts', $backup['page_for_posts'] );
		}
		if ( isset( $backup['blogname'] ) ) {
			devxpe_safe_update_blog_option( 'blogname', $backup['blogname'] );
		}
		if ( isset( $backup['blogdescription'] ) ) {
			devxpe_safe_update_blog_option( 'blogdescription', $backup['blogdescription'] );
		}

		if ( function_exists( 'devxpe_register_custom_post_types' ) ) {
			devxpe_register_custom_post_types();
		}

		delete_option( self::STATE_KEY );
		flush_rewrite_rules( false );
	}

	/* ══════════════════════════════════════════════════════════
	   Kurulum yardımcıları
	   ══════════════════════════════════════════════════════════ */

	/**
	 * Demo görsellerini medya kitaplığına aktarır.
	 *
	 * @param array $state Durum (ID'ler buraya yazılır).
	 * @return array dosya adı => URL
	 */
	private static function import_images( &$state ) {
		return self::import_images_partial( $state, -1 );
	}

	/**
	 * Demo görsellerinin bir kısmını (veya tamamını) medya kitaplığına aktarır.
	 *
	 * Adım adım (AJAX) kurulum için `$state['progress']['img_index']`
	 * sayacından devam eder; `$state['img_urls']` birikimlidir. Böylece her
	 * çağrı tek görsel indirip ilerleme çubuğunu güncelleyebilir.
	 *
	 * @param array $state Durum (sayaç/ID'ler buraya yazılır).
	 * @param int   $adet  İşlenecek en fazla görsel sayısı; -1 = tamamı.
	 * @return array dosya adı => URL
	 */
	private static function import_images_partial( &$state, $adet = 1 ) {
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$assets = self::demo_assets();
		$names  = array_keys( $assets );
		$total  = count( $names );

		if ( ! isset( $state['progress'] ) || ! is_array( $state['progress'] ) ) {
			$state['progress'] = array();
		}
		$index = isset( $state['progress']['img_index'] ) ? (int) $state['progress']['img_index'] : 0;

		if ( ! isset( $state['img_urls'] ) || ! is_array( $state['img_urls'] ) ) {
			$state['img_urls'] = array();
		}

		$done = 0;

		while ( $index < $total && ( $adet < 0 || $done < $adet ) ) {
			$name = $names[ $index ];
			$src  = $assets[ $name ];
			$index++;
			$done++;

			$data = self::fetch_demo_file( $src );
			if ( '' === $data ) {
				continue;
			}

			$bits = wp_upload_bits( $name . '.' . self::demo_ext( $src ), null, $data );
			if ( ! empty( $bits['error'] ) ) {
				continue;
			}

			$type = wp_check_filetype( $bits['file'] );
			$id   = wp_insert_attachment(
				array(
					'post_mime_type' => $type['type'] ? $type['type'] : 'image/jpeg',
					'post_title'     => $name,
					'post_status'    => 'inherit',
				),
				$bits['file']
			);

			if ( ! $id || is_wp_error( $id ) ) {
				continue;
			}

			wp_update_attachment_metadata( $id, wp_generate_attachment_metadata( $id, $bits['file'] ) );
			/* Demo paketine ait olduğunu işaretle: kaldırmada kesin silinsin. */
			update_post_meta( $id, '_dxp_demo', '1' );
			$state['ids']['attachments'][] = $id;
			$state['img_urls'][ $name ]    = wp_get_attachment_url( $id );
		}

		$state['progress']['img_index'] = $index;

		return $state['img_urls'];
	}

	/**
	 * Ön yüz menüsünü kurar.
	 *
	 * @param array $d     Demo verisi.
	 * @param array $pages Sayfa ID'leri (anahtar => ID).
	 * @return int Menü ID'si.
	 */
	private static function build_menu( $d, $pages ) {
		$menu_id = wp_create_nav_menu( $d['menu_name'] );
		if ( is_wp_error( $menu_id ) ) {
			return 0;
		}

		$order = 0;
		foreach ( $d['menu'] as $item ) {
			$order++;

			$args = array(
				'menu-item-title'     => $item['title'],
				'menu-item-position'  => $order,
				'menu-item-status'    => 'publish',
				'menu-item-type'      => 'post_type',
				'menu-item-object'    => 'page',
				'menu-item-object-id' => ( isset( $item['page'] ) && isset( $pages[ $item['page'] ] ) ) ? $pages[ $item['page'] ] : 0,
			);

			if ( ! empty( $item['archive'] ) ) {
				$args['menu-item-type']   = 'custom';
				$args['menu-item-object'] = 'custom';
				$args['menu-item-url']    = get_post_type_archive_link( $item['archive'] );
			}

			if ( $args['menu-item-object-id'] || ! empty( $item['archive'] ) ) {
				wp_update_nav_menu_item( $menu_id, 0, $args );
			}
		}

		$locations            = get_theme_mod( 'nav_menu_locations', array() );
		$locations['primary'] = $menu_id;
		set_theme_mod( 'nav_menu_locations', $locations );

		return $menu_id;
	}

	/**
	 * İçerik tipi kayıtları için varsayılan meta (şablon bölümleri dolsun).
	 *
	 * @param string $type Kayıt tipi (services|areas).
	 * @param array  $item Kayıt verisi.
	 * @param array  $d    Demo verisi.
	 * @param array  $img  Görsel URL'leri.
	 * @return array
	 */
	private static function cpt_default_meta( $type, $item, $d, $img ) {
		$project = function ( $index ) use ( $d, $img ) {
			$num = ( $index % 9 ) + 1;
			$key = 'demo-' . $num;

			return array(
				'image' => isset( $img[ $key ] ) ? $img[ $key ] : '',
				'title' => isset( $d['project_titles'][ $index ] ) ? $d['project_titles'][ $index ] : '',
				'text'  => $d['project_caption'],
			);
		};

		if ( 'services' === $type ) {
			return array(
				'_dxp_template'        => 'layout_1',
				'_dxp_hero_badge'      => $d['hero_badge'],
				'_dxp_hero_subtitle'   => isset( $item['content'] ) ? $item['content'] : '',
				'_dxp_includes_title'  => $d['includes_title'],
				'_dxp_includes'        => $d['includes_list'],
				'_dxp_faq'             => $d['faq_items'],
				'_dxp_related_source'  => 'cpt:services',
				'_dxp_services_source' => 'cpt:services',
				'_dxp_services_limit'  => '3',
			);
		}

		if ( 'areas' === $type ) {
			return array(
				'_dxp_template'        => 'layout_2',
				'_dxp_hero_subtitle'   => $d['areas_subtitle'],
				'_dxp_area_name'       => $item['title'],
				'_dxp_includes_title'  => $d['includes_title'],
				'_dxp_includes'        => $d['includes_list'],
				'_dxp_faq'             => $d['faq_items'],
				'_dxp_services_source' => 'cpt:services',
				'_dxp_services_limit'  => '6',
				'_dxp_related_source'  => 'cpt:services',
				'_dxp_projects'        => array( $project( 0 ), $project( 1 ), $project( 2 ) ),
			);
		}

		return array();
	}

	/**
	 * Demo verisini (metinler + listeler) dile göre döndürür.
	 *
	 * Yapı TEK yerde burada tanımlıdır; dile özel metinler `strings()`
	 * haritasından gelir.
	 *
	 * @param string $lang 'tr' | 'en'
	 * @return array
	 */
	public static function data( $lang ) {
		if ( class_exists( 'DEVXPE_Theme_Demos' ) ) {
			$ozel = DEVXPE_Theme_Demos::data( self::demo_id(), $lang );
			if ( is_array( $ozel ) && $ozel ) {
				return $ozel;
			}
		}

		return self::data_default( $lang );
	}

	/**
	 * Yerleşik demo verisi (demo kendi `data` sağlayıcısını vermezse).
	 *
	 * @param string $lang 'tr' | 'en'
	 * @return array
	 */
	private static function data_default( $lang ) {
		$s = self::strings( $lang );

		return array(
			'lang'                  => $s['lang'],
			'site_title'            => $s['site_title'],
			'tagline'               => $s['tagline'],
			'site_description'      => $s['site_description'],
			'quote_btn'             => $s['quote_btn'],
			'phone'                 => $s['phone'],
			'whatsapp'              => $s['whatsapp'],
			'email'                 => $s['email'],
			'address'               => $s['address'],
			'hours'                 => $s['hours'],
			'wa_text'               => $s['wa_text'],
			'more_text'             => $s['more_text'],
			'send_btn'              => $s['send_btn'],
			'contact_form_name'     => $s['contact_form_name'],
			'consent'               => $s['consent'],
			'form_success'          => $s['form_success'],
			'cpt_services'          => $s['cpt_services'],
			'cpt_areas'             => $s['cpt_areas'],
			'menu_name'             => $s['menu_name'],
			'hero_badge'            => $s['hero_badge'],
			'hero_title'            => $s['hero_title'],
			'hero_subtitle'         => $s['hero_subtitle'],
			'services_eyebrow'      => $s['services_eyebrow'],
			'services_title'        => $s['services_title'],
			'services_subtitle'     => $s['services_subtitle'],
			'features_eyebrow'      => $s['features_eyebrow'],
			'features_title'        => $s['features_title'],
			'features_items'        => $s['features_items'],
			'steps_eyebrow'         => $s['steps_eyebrow'],
			'steps_title'           => $s['steps_title'],
			'steps_subtitle'        => $s['steps_subtitle'],
			'steps_items'           => $s['steps_items'],
			'projects_eyebrow'      => $s['projects_eyebrow'],
			'projects_title'        => $s['projects_title'],
			'projects_subtitle'     => $s['projects_subtitle'],
			'projects_limit'        => $s['projects_limit'],
			'project_titles'        => $s['project_titles'],
			'project_caption'       => $s['project_caption'],
			'reviews_eyebrow'       => $s['reviews_eyebrow'],
			'reviews_title'         => $s['reviews_title'],
			'reviews_items'         => $s['reviews_items'],
			'reviews_note'          => $s['reviews_note'],
			'areas_eyebrow'         => $s['areas_eyebrow'],
			'areas_title'           => $s['areas_title'],
			'areas_subtitle'        => $s['areas_subtitle'],
			'faq_eyebrow'           => $s['faq_eyebrow'],
			'faq_title'             => $s['faq_title'],
			'faq_items'             => $s['faq_items'],
			'includes_title'        => $s['includes_title'],
			'includes_list'         => $s['includes_list'],
			'form_eyebrow'          => $s['form_eyebrow'],
			'form_title'            => $s['form_title'],
			'form_subtitle'         => $s['form_subtitle'],
			'form_benefits'         => $s['form_benefits'],
			'form_phone_text'       => $s['form_phone_text'],
			'form_step1'            => $s['form_step1'],
			'form_step2'            => $s['form_step2'],
			'form_step3'            => $s['form_step3'],
			'form_step4'            => $s['form_step4'],
			'form_note'             => $s['form_note'],
			'form_services'         => $s['form_services'],
			'footer_about'          => $s['footer_about'],
			'footer_note'           => $s['footer_note'],
			'copyright'             => $s['copyright'],
			'service_cards'         => $s['service_cards'],
			'pages'                 => $s['pages'],
			'cpt_items'             => $s['cpt_items'],
			'posts'                 => $s['posts'],
			'menu'                  => $s['menu'],
		);
	}

	/**
	 * Demo metin haritası: dile özel değerler.
	 *
	 * Yapı `data()` içindedir; bu metot yalnızca değerleri tutar.
	 *
	 * @param string $lang 'tr' | 'en'
	 * @return array
	 */
	/**
	 * Tema ayarlarını (metin + kart + iletişim) üretir.
	 *
	 * @param array $d   Demo verisi.
	 * @param array $img Görsel URL'leri.
	 * @return array
	 */
	private static function options( $d, $img ) {
		if ( class_exists( 'DEVXPE_Theme_Demos' ) ) {
			$ozel = DEVXPE_Theme_Demos::options( self::demo_id(), $d, $img );
			if ( is_array( $ozel ) && $ozel ) {
				return $ozel;
			}
		}

		return self::options_default( $d, $img );
	}

	/**
	 * Yerleşik tema ayarları (demo kendi `options` sağlayıcısını vermezse).
	 *
	 * @param array $d   Demo verisi.
	 * @param array $img Görsel URL'leri.
	 * @return array
	 */
	private static function options_default( $d, $img ) {
		$im = function ( $n ) use ( $img ) {
			$key = 'demo-' . $n;
			return isset( $img[ $key ] ) ? $img[ $key ] : '';
		};

		$o = array(
			'site_title'          => $d['site_title'],
			'tagline'             => $d['tagline'],
			'site_description'    => $d['site_description'],
			'show_site_title'     => '1',
			'show_site_tagline'   => '1',
			'logo'                => isset( $img['logo'] ) ? $img['logo'] : '',

			'phone'               => $d['phone'],
			'whatsapp'            => $d['whatsapp'],
			'email'               => $d['email'],
			'address'             => $d['address'],
			'working_hours'       => $d['hours'],

			'topbar_enabled'      => '1',
			'sticky_header'       => '1',
			'breadcrumb_enabled'  => '1',
			'rounded_image'       => '1',
			'layout'              => 'boxed',
			'header_btn_enable'   => '1',
			'header_btn_text'     => $d['quote_btn'],
			'header_btn_url'      => '',

			'float_enable'        => '1',
			'float_style'         => 'classic',
			'float_whatsapp_enable' => '1',
			'float_whatsapp_number' => $d['whatsapp'],
			'float_whatsapp_text' => $d['wa_text'],
			'float_phone_enable'  => '1',
			'float_phone_number'  => $d['phone'],
			'float_top_enable'    => '1',

			'hero_enable'         => '1',
			'hero_badge'          => $d['hero_badge'],
			'hero_title'          => $d['hero_title'],
			'hero_subtitle'       => $d['hero_subtitle'],
			'hero_btn_text'       => $d['quote_btn'],
			'hero_btn_url'        => '',
			'hero_image'          => $im( 1 ),

			'services_enable'        => '1',
			'services_eyebrow'       => $d['services_eyebrow'],
			'services_title'         => $d['services_title'],
			'services_subtitle'      => $d['services_subtitle'],
			'services_more_text'     => $d['more_text'],
			'services_cards_source'  => 'manual',
			'services_terms_source'  => 'none',

			'features_enable'        => '1',
			'features_eyebrow'       => $d['features_eyebrow'],
			'features_title'         => $d['features_title'],
			'features_items'         => $d['features_items'],

			'steps_enable'           => '1',
			'steps_eyebrow'          => $d['steps_eyebrow'],
			'steps_title'            => $d['steps_title'],
			'steps_subtitle'         => $d['steps_subtitle'],
			'steps_items'            => $d['steps_items'],

			'projects_enable'        => '1',
			'projects_eyebrow'       => $d['projects_eyebrow'],
			'projects_title'         => $d['projects_title'],
			'projects_subtitle'      => $d['projects_subtitle'],
			'projects_source'        => 'manual',
			'projects_terms_source'  => 'none',
			'projects_limit'         => '6',

			'reviews_enable'         => '1',
			'reviews_eyebrow'        => $d['reviews_eyebrow'],
			'reviews_title'          => $d['reviews_title'],
			'reviews_rating'         => '5',
			'reviews_items'          => $d['reviews_items'],
			'reviews_note'           => $d['reviews_note'],

			'areas_enable'           => '1',
			'areas_eyebrow'          => $d['areas_eyebrow'],
			'areas_title'            => $d['areas_title'],
			'areas_subtitle'         => $d['areas_subtitle'],
			'areas_terms_source'     => 'cpt:areas',
			'areas_terms_limit'      => '12',

			'faq_enable'             => '1',
			'faq_eyebrow'            => $d['faq_eyebrow'],
			'faq_title'              => $d['faq_title'],
			'faq_items'              => $d['faq_items'],

			'form_enable'            => '1',
			'form_eyebrow'           => $d['form_eyebrow'],
			'form_title'             => $d['form_title'],
			'form_subtitle'          => $d['form_subtitle'],
			'form_benefits'          => $d['form_benefits'],
			'form_phone_text'        => $d['form_phone_text'],
			'form_step1_title'       => $d['form_step1'],
			'form_step2_title'       => $d['form_step2'],
			'form_step3_title'       => $d['form_step3'],
			'form_step4_title'       => $d['form_step4'],
			'form_note'              => $d['form_note'],
			'form_recipient'         => $d['email'],
			'form_success'           => $d['form_success'],
			'contact_btn_text'       => $d['send_btn'],
			'contact_consent_enable' => '1',
			'contact_consent_text'   => $d['consent'],
			'home_form_choice'       => 'quote',

			'footer_style'           => 'full',
			'footer_about_text'      => $d['footer_about'],
			'footer_copyright'       => $d['copyright'],
			'footer_note'            => $d['footer_note'],
			'footer_col2_title'      => $d['cpt_services'],
			'footer_col2_source'     => 'cpt:services',
			'footer_col2_limit'      => '8',
			'footer_col3_title'      => $d['cpt_areas'],
			'footer_col3_source'     => 'cpt:areas',
			'footer_col3_limit'      => '8',
			'footer_legal_source'    => 'none',

			'custom_forms'           => array(
				array( 'name' => $d['contact_form_name'], 'slug' => 'iletisim', 'btn' => $d['send_btn'] ),
			),
			'contact_form_choice'    => 'iletisim',

			/* Demo menüsünde arşiv linki var; içerik tipi arşivleri açık olsun. */
			'cpt_archive_action'     => 'normal',
			'category_archive_action' => 'normal',
		);

		/*
		 * Hizmet kartları — görsel, kartın KONUSUYLA eşleşir (demo görselleri:
		 * 1-2 parke taş zemin, 3-6 ahşap çit, 7-9 doğal taş teras/çim).
		 */
		$dxp_svc_img = array( 3, 6, 1, 7, 9, 8 );

		$o['services_cards'] = array();
		foreach ( $d['service_cards'] as $i => $card ) {
			$o['services_cards'][] = array(
				'image' => $im( isset( $dxp_svc_img[ $i ] ) ? $dxp_svc_img[ $i ] : ( $i + 1 ) ),
				'title' => $card[0],
				'text'  => $card[1],
				'url'   => '',
			);
		}

		/* Projeler — her başlık kendi konusuna uygun görselle eşleşir. */
		$dxp_prj_img = array( 3, 1, 7, 4, 9, 5 );

		$o['projects_items'] = array();
		foreach ( $d['project_titles'] as $i => $title ) {
			$num = isset( $dxp_prj_img[ $i ] ) ? $dxp_prj_img[ $i ] : ( ( $i % 9 ) + 1 );
			$o['projects_items'][] = array(
				'image' => $im( $num ),
				'title' => $title,
				'text'  => $d['project_caption'],
				'url'   => '',
			);
		}

		$o['form_services'] = array();
		foreach ( $d['form_services'] as $group ) {
			$o['form_services'][] = array(
				'icon'  => '',
				'title' => $group[0],
				'text'  => implode( "\n", $group[1] ),
				'url'   => '',
			);
		}

		return $o;
	}

	/**
	 * Demo metin haritası: dile özel değerler.
	 *
	 * Yapı `data()` içindedir; bu metot yalnızca değerleri tutar.
	 *
	 * @param string $lang 'tr' | 'en'
	 * @return array
	 */
	private static function strings( $lang ) {
		$temel = self::strings_default( $lang );

		if ( ! class_exists( 'DEVXPE_Theme_Demos' ) ) {
			return $temel;
		}

		/*
		 * Demo kendi metinlerini sağlıyorsa üzerine bindir: eksik anahtarlar
		 * yerleşik içerikten (aynı dilde) gelir, böylece kısmi tanım da güvenli.
		 */
		$ozel = DEVXPE_Theme_Demos::strings( self::demo_id(), $lang );

		return ( is_array( $ozel ) && $ozel ) ? array_merge( $temel, $ozel ) : $temel;
	}

	/**
	 * Yerleşik demo metin haritası (dile özel).
	 *
	 * @param string $lang 'tr' | 'en'
	 * @return array
	 */
	private static function strings_default( $lang ) {
		if ( 'en' === $lang ) {
			return self::strings_en();
		}

		return array(
			'lang'                => 'tr',
			'site_title'          => 'Örnek Yapı & Peyzaj',
			'tagline'             => 'Çit, kaplama ve peyzaj işleri',
			'site_description'    => 'Yerel ekibimizle bahçe çiti, kaplama ve peyzaj işlerinizi zamanında ve temiz teslim ediyoruz.',
			'quote_btn'           => 'Ücretsiz Teklif',
			'phone'               => '0850 000 00 00',
			'whatsapp'            => '905000000000',
			'email'               => 'info@orneksite.com',
			'address'             => 'Merkez Mah. Örnek Cad. No:1',
			'hours'               => 'Pazartesi–Cumartesi 08:00–18:00',
			'wa_text'             => 'Merhaba, ücretsiz teklif almak istiyorum.',
			'more_text'           => 'Detaylar',
			'send_btn'            => 'Gönder',
			'contact_form_name'   => 'İletişim Formu',
			'consent'             => 'Gizlilik politikasını okudum ve kişisel verilerimin işlenmesini onaylıyorum.',
			'form_success'        => 'Teşekkürler! En kısa sürede size döneceğiz.',
			'cpt_services'        => 'Hizmetler',
			'cpt_areas'           => 'Bölgeler',
			'menu_name'           => 'Ana Menü',

			'hero_badge'          => '24 saatte ücretsiz keşif',
			'hero_title'          => 'Bahçenizi baştan aşağı yeniliyoruz',
			'hero_subtitle'       => 'Çit, kaplama, teras ve peyzaj işlerini tek ekip, tek fiyat ve temiz işçilikle yapıyoruz.',

			'services_eyebrow'    => 'Neler yapıyoruz',
			'services_title'      => 'Bahçe ve zemin işlerinde tek adres',
			'services_subtitle'   => 'Küçük tamirattan komple peyzaja kadar tüm işleri kendi ekibimizle yapıyoruz.',

			'features_eyebrow'    => 'Neden biz',
			'features_title'      => 'İşi baştan sona kendimiz yapıyoruz',
			'features_items'      => array(
				array( 'icon' => 'hammer', 'title' => '15 yılı aşkın deneyim', 'text' => 'Sadece bu işi yapıyoruz; her gün, tüm yıl.' ),
				array( 'icon' => 'shield-check', 'title' => 'Tam sigortalı', 'text' => 'Her proje için mesleki sorumluluk sigortası.' ),
				array( 'icon' => 'badge-check', 'title' => 'Temiz işçilik', 'text' => 'İşi kendi evimizde isteyeceğimiz kalitede bitiriyoruz.' ),
				array( 'icon' => 'users', 'title' => 'Kendi ekibimiz', 'text' => 'Tek ekip, tek muhatap; taşerona iş vermiyoruz.' ),
			),

			'steps_eyebrow'       => 'Nasıl çalışır',
			'steps_title'         => 'İlk görüşmeden teslime kadar',
			'steps_subtitle'      => 'Beş net adım; süpriz yok.',
			'steps_items'         => array(
				array( 'icon' => '', 'title' => 'İhtiyacınızı anlatın', 'text' => 'Formdan birkaç detay ve fotoğraf gönderin ya da bizi arayın. Aynı gün dönüş yaparız.' ),
				array( 'icon' => '', 'title' => 'Ücretsiz yerinde keşif', 'text' => 'Ölçü alır, zemin ve malzeme seçeneklerini konuşuruz.' ),
				array( 'icon' => '', 'title' => 'Yazılı sabit fiyat', 'text' => 'Keşiften sonra 24 saat içinde kalem kalem net fiyat.' ),
				array( 'icon' => '', 'title' => 'Uygulama', 'text' => 'İşi kendi ekibimiz yapar, çevreyi korur ve her gün atığı toplarız.' ),
				array( 'icon' => '', 'title' => 'Teslim', 'text' => 'Bitmiş işi birlikte gezer, kontrol eder ve temiz teslim ederiz.' ),
			),

			'projects_eyebrow'    => 'Son işler',
			'projects_title'      => 'Tamamladığımız işlerden bir seçki',
			'projects_subtitle'   => 'Gerçek müşteri işlerimizden birkaç örnek.',
			'projects_limit'      => '6',
			'project_titles'      => array( 'Bahçe çiti yenileme', 'Betonarme araç yolu', 'Doğal taş teras', 'Kompozit çit uygulaması', 'Çim ve peyzaj düzenlemesi', 'Panel çit montajı' ),
			'project_caption'     => 'Yerel ekibimiz tarafından tamamlandı.',

			'reviews_eyebrow'     => 'Yorumlar',
			'reviews_title'       => 'Müşterilerimiz ne diyor',
			'reviews_items'       => array(
				array( 'icon' => '', 'title' => 'Ayşe K. — Merkez', 'text' => 'Bahçe çitimizi iki günde yenilediler. Tertemiz teslim ettiler, fiyat da baştan netti.' ),
				array( 'icon' => '', 'title' => 'Mehmet D. — Sahil', 'text' => 'Yeni araç yolumuz tam istediğimiz gibi oldu. Zemin hazırlığı çok özenliydi.' ),
				array( 'icon' => '', 'title' => 'Elif T. — Çamlık', 'text' => 'Teras ve çim işini birlikte yaptılar. Tek ekiple çalışmak çok kolaydı.' ),
			),
			'reviews_note'        => 'Yorumlar memnun müşterilerimizden alınmıştır.',

			'areas_eyebrow'       => 'Hizmet bölgeleri',
			'areas_title'         => 'Hizmet verdiğimiz bölgeler',
			'areas_subtitle'      => 'Şehir merkezinden çevre mahallelere kadar hizmet veriyoruz.',

			'faq_eyebrow'         => 'SSS',
			'faq_title'           => 'Sık sorulan sorular',
			'faq_items'           => array(
				array( 'icon' => '', 'title' => 'Teklifi ne kadar sürede alırım?', 'text' => 'Formu doldurduktan sonra 24 saat içinde net fiyatla dönüyoruz.' ),
				array( 'icon' => '', 'title' => 'Sigortalı mısınız?', 'text' => 'Evet, her proje için mesleki sorumluluk sigortamız var.' ),
				array( 'icon' => '', 'title' => 'İş bitince temizlik yapıyor musunuz?', 'text' => 'Evet, atıkları toplar ve alanı temiz teslim ederiz.' ),
				array( 'icon' => '', 'title' => 'Hangi bölgelere hizmet veriyorsunuz?', 'text' => 'Şehir merkezi ve çevresindeki tüm mahallelere hizmet veriyoruz.' ),
			),

			'includes_title'      => 'Neler dahil',
			'includes_list'       => "Ücretsiz keşif ve yazılı sabit fiyat\nEski yapı sökülür, atık bizden\nZemin hazırlığı ve doğru eğim\nİş bitiminde temiz teslim\n1 yıl işçilik garantisi",

			'form_eyebrow'        => 'Ücretsiz keşif',
			'form_title'          => 'Projeniz için teklif alın',
			'form_subtitle'       => 'Birkaç detay bırakın, 24 saat içinde net fiyatla dönelim.',
			'form_benefits'       => "Yükümlülük yok\nÜcretsiz yerinde keşif\nYazılı sabit fiyat",
			'form_phone_text'     => 'Ya da arayın',
			'form_step1'          => 'Hizmet',
			'form_step2'          => 'Projeniz',
			'form_step3'          => 'Bilgileriniz',
			'form_step4'          => 'Kontrol & gönder',
			'form_note'           => 'Emin değilseniz en yakın seçeneği işaretleyin; keşifte birlikte netleştiririz.',
			'form_services'       => array(
				array( 'Çit', array( 'Bahçe çiti', 'Panel çit', 'Kompozit çit', 'Kapı' ) ),
				array( 'Kaplama', array( 'Beton kaplama', 'Araç yolu', 'Teras' ) ),
				array( 'Peyzaj', array( 'Çim', 'Bahçe düzenleme' ) ),
			),

			'footer_about'        => 'Bölgenizde çit, kaplama ve peyzaj işleri yapan sigortalı yerel ekibiz. Ücretsiz keşif ve yazılı sabit fiyat.',
			'footer_note'         => 'Yerinde hizmet veriyoruz; ofis yerine hizmet bölgemizi paylaşıyoruz.',
			'copyright'           => 'Tüm hakları saklıdır.',

			'service_cards'       => array(
				array( 'Bahçe çiti', 'Panel, kompozit ve tel çit uygulama ile tamir.' ),
				array( 'Beton kaplama', 'Araç yolu, patika ve teras için beton kaplama.' ),
				array( 'Araç yolu', 'Blok taş ve doğal taş ile yeni araç yolu.' ),
				array( 'Teras', 'Porselen ve doğal taş teras uygulamaları.' ),
				array( 'Çim', 'Hazır çim serimi ve zemin hazırlığı.' ),
				array( 'Peyzaj', 'Bahçe tasarımı ve komple düzenleme.' ),
			),

			'pages'               => array(
				'home'    => array( 'title' => 'Anasayfa', 'slug' => 'anasayfa', 'content' => '', 'template' => '' ),
				'blog'    => array( 'title' => 'Blog', 'slug' => 'blog', 'content' => '', 'template' => '' ),
				'about'   => array(
					'title'   => 'Hakkımızda',
					'slug'    => 'hakkimizda',
					'template' => 'page-about.php',
					'content' => "<!-- wp:paragraph -->\n<p>Bölgenizde çit, kaplama ve peyzaj işlerini 15 yılı aşkın süredir yapan yerel bir ekibiz. Keşiften teslime kadar aynı ekip çalışır; işi baştan sona kendimiz yapar, taşerona bırakmayız.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Çit, blok kaplama, araç yolu, teras, peyzaj ve çim uygulamaları konusunda uzmanız. Her proje doğru zemin hazırlığı ve doğru eğimle yapılır; kendi evimizde isteyeceğimiz kalitede teslim ederiz.</p>\n<!-- /wp:paragraph -->",
					'about_stats' => array(
						array( 'icon' => 'hammer', 'title' => '15+', 'text' => 'Yıllık deneyim' ),
						array( 'icon' => 'shield-check', 'title' => '2M ₺', 'text' => 'Sigorta güvencesi' ),
						array( 'icon' => 'clock', 'title' => 'Zamanında', 'text' => 'Teslim garantisi' ),
					),
				),
				'contact' => array( 'title' => 'İletişim', 'slug' => 'iletisim', 'template' => 'page-contact.php', 'content' => "<!-- wp:paragraph -->\n<p>Projenizi anlatın; en kısa sürede dönüş yapalım.</p>\n<!-- /wp:paragraph -->" ),
				'privacy' => array( 'title' => 'Gizlilik Politikası', 'slug' => 'gizlilik-politikasi', 'content' => "<!-- wp:paragraph -->\n<p>Bu sayfa gizlilik politikası için örnek içeriktir.</p>\n<!-- /wp:paragraph -->" ),
				'cookies' => array( 'title' => 'Çerez Politikası', 'slug' => 'cerez-politikasi', 'content' => "<!-- wp:paragraph -->\n<p>Bu sayfa çerez politikası için örnek içeriktir.</p>\n<!-- /wp:paragraph -->" ),
				'terms'   => array( 'title' => 'Kullanım Şartları', 'slug' => 'kullanim-sartlari', 'content' => "<!-- wp:paragraph -->\n<p>Bu sayfa kullanım şartları için örnek içeriktir.</p>\n<!-- /wp:paragraph -->" ),
			),

			'cpt_items'           => array(
				'services' => array(
					array( 'title' => 'Bahçe Çiti', 'slug' => 'bahce-citi', 'content' => 'Bahçe çitinizi ölçüyor, malzemeyi seçiyor ve kısa sürede monte ediyoruz.', 'meta' => array() ),
					array( 'title' => 'Panel Çit', 'slug' => 'panel-cit', 'content' => 'Hazır panel çitlerle hızlı ve dayanıklı çevreleme.', 'meta' => array() ),
					array( 'title' => 'Kompozit Çit', 'slug' => 'kompozit-cit', 'content' => 'Bakım gerektirmeyen kompozit çit uygulaması.', 'meta' => array() ),
					array( 'title' => 'Beton Kaplama', 'slug' => 'beton-kaplama', 'content' => 'Araç yolu ve patikalar için beton kaplama.', 'meta' => array() ),
					array( 'title' => 'Araç Yolu', 'slug' => 'arac-yolu', 'content' => 'Blok taş ve doğal taş ile yeni araç yolu.', 'meta' => array() ),
					array( 'title' => 'Teras', 'slug' => 'teras', 'content' => 'Porselen ve doğal taş teras uygulamaları.', 'meta' => array() ),
					array( 'title' => 'Çim', 'slug' => 'cim', 'content' => 'Zemin hazırlığı ve hazır çim serimi.', 'meta' => array() ),
					array( 'title' => 'Peyzaj', 'slug' => 'peyzaj', 'content' => 'Bahçe tasarımı ve komple peyzaj düzenlemesi.', 'meta' => array() ),
				),
				'areas'    => array(
					array( 'title' => 'Merkez', 'slug' => 'merkez' ),
					array( 'title' => 'Sahil', 'slug' => 'sahil' ),
					array( 'title' => 'Çamlık', 'slug' => 'camlik' ),
					array( 'title' => 'Bağlıca', 'slug' => 'baglica' ),
					array( 'title' => 'Yeşiltepe', 'slug' => 'yesiltepe' ),
					array( 'title' => 'Gölbaşı', 'slug' => 'golbasi' ),
					array( 'title' => 'Kavaklı', 'slug' => 'kavakli' ),
					array( 'title' => 'Pınarbaşı', 'slug' => 'pinarbasi' ),
					array( 'title' => 'Dereboyu', 'slug' => 'dereboyu' ),
					array( 'title' => 'Karşıyaka', 'slug' => 'karsiyaka' ),
					array( 'title' => 'Yenişehir', 'slug' => 'yenisehir' ),
					array( 'title' => 'Bahçelievler', 'slug' => 'bahcelievler' ),
				),
			),

			'posts'               => array(
				array( 'title' => 'Bahçe çiti seçerken nelere dikkat edilmeli?', 'content' => "<p>Malzeme, yükseklik ve zemin koşulları doğru çit seçimini belirler.</p>" ),
				array( 'title' => 'Araç yolu için hangi kaplama?', 'content' => "<p>Blok taş mı beton mu? Kullanım yoğunluğuna göre karar verilir.</p>" ),
				array( 'title' => 'Teras bakımı için basit ipuçları', 'content' => "<p>Doğal taş terasların ömrünü uzatan birkaç basit yöntem.</p>" ),
			),

			'menu'                => array(
				array( 'title' => 'Anasayfa', 'page' => 'home' ),
				array( 'title' => 'Hakkımızda', 'page' => 'about' ),
				array( 'title' => 'Hizmetler', 'archive' => 'services' ),
				array( 'title' => 'Blog', 'page' => 'blog' ),
				array( 'title' => 'İletişim', 'page' => 'contact' ),
			),
		);
	}

	/**
	 * İngilizce demo metin haritası.
	 *
	 * @return array
	 */
	private static function strings_en() {
		return array(
			'lang'                => 'en',
			'site_title'          => 'Sample Build & Landscape',
			'tagline'             => 'Fencing, paving and landscaping',
			'site_description'    => 'A local team for fencing, paving and landscaping — finished on time and left clean.',
			'quote_btn'           => 'Free Quote',
			'phone'               => '0000 000 0000',
			'whatsapp'            => '10000000000',
			'email'               => 'info@example.com',
			'address'             => '1 Sample Street, Sample Town',
			'hours'               => 'Monday–Saturday 08:00–18:00',
			'wa_text'             => 'Hi, I would like a free quote please.',
			'more_text'           => 'Learn more',
			'send_btn'            => 'Send',
			'contact_form_name'   => 'Contact Form',
			'consent'             => 'I have read the privacy policy and agree to my data being processed.',
			'form_success'        => 'Thank you! We will get back to you shortly.',
			'cpt_services'        => 'Services',
			'cpt_areas'           => 'Areas',
			'menu_name'           => 'Primary Menu',

			'hero_badge'          => 'Free site visit within 24 hours',
			'hero_title'          => 'We renew your garden from top to bottom',
			'hero_subtitle'       => 'Fencing, paving, patios and landscaping by one team, one price and a clean finish.',

			'services_eyebrow'    => 'What we do',
			'services_title'      => 'One team for every hard-landscaping job',
			'services_subtitle'   => 'From small repairs to a full landscaping build, we do the work ourselves.',

			'features_eyebrow'    => 'Why choose us',
			'features_title'      => 'We do the whole job ourselves',
			'features_items'      => array(
				array( 'icon' => 'hammer', 'title' => '15+ years on the tools', 'text' => 'This is all we do — every day, all year.' ),
				array( 'icon' => 'shield-check', 'title' => 'Fully insured', 'text' => 'Public liability insurance on every project.' ),
				array( 'icon' => 'badge-check', 'title' => 'Quality finish', 'text' => 'Built to a standard we would want at home.' ),
				array( 'icon' => 'users', 'title' => 'In-house team', 'text' => 'One team, one point of contact, no subcontractors.' ),
			),

			'steps_eyebrow'       => 'How it works',
			'steps_title'         => 'From first call to finished job',
			'steps_subtitle'      => 'Five clear stages, no surprises.',
			'steps_items'         => array(
				array( 'icon' => '', 'title' => 'Tell us about the job', 'text' => 'Send a few details and photos, or call us. We reply the same day.' ),
				array( 'icon' => '', 'title' => 'Free site visit', 'text' => 'We measure up and talk through levels, access and materials.' ),
				array( 'icon' => '', 'title' => 'Fixed written quote', 'text' => 'An itemised price in writing within 24 hours.' ),
				array( 'icon' => '', 'title' => 'Installation', 'text' => 'Our own team does the work, protects your property and clears waste daily.' ),
				array( 'icon' => '', 'title' => 'Sign-off', 'text' => 'We walk the finished job with you and hand over a clean site.' ),
			),

			'projects_eyebrow'    => 'Recent projects',
			'projects_title'      => 'A selection of our recent work',
			'projects_subtitle'   => 'A few examples of real customer jobs.',
			'projects_limit'      => '6',
			'project_titles'      => array( 'Garden fence replacement', 'Block paved driveway', 'Natural stone patio', 'Composite fence build', 'Turf and landscaping', 'Panel fence installation' ),
			'project_caption'     => 'Completed by our local team.',

			'reviews_eyebrow'     => 'Reviews',
			'reviews_title'       => 'What our customers say',
			'reviews_items'       => array(
				array( 'icon' => '', 'title' => 'Sarah W. — Sample Town', 'text' => 'They replaced our whole fence in two days. Tidy, immaculate finish and a fair price.' ),
				array( 'icon' => '', 'title' => 'David M. — Riverside', 'text' => 'Our new driveway looks great — properly excavated and laid to a true fall.' ),
				array( 'icon' => '', 'title' => 'Emma T. — Hilltop', 'text' => 'Patio, turf and fencing in one go. One team from start to finish.' ),
			),
			'reviews_note'        => 'Feedback from our customers.',

			'areas_eyebrow'       => 'Local specialists',
			'areas_title'         => 'Areas we cover',
			'areas_subtitle'      => 'From the town centre to the surrounding neighbourhoods.',

			'faq_eyebrow'         => 'FAQ',
			'faq_title'           => 'Answers to common questions',
			'faq_items'           => array(
				array( 'icon' => '', 'title' => 'How quickly can I get a quote?', 'text' => 'Send the form and we reply with a fixed price within 24 hours.' ),
				array( 'icon' => '', 'title' => 'Are you insured?', 'text' => 'Yes — public liability insurance on every project.' ),
				array( 'icon' => '', 'title' => 'Do you clean up after the job?', 'text' => 'Yes, we clear all waste and leave the site clean.' ),
				array( 'icon' => '', 'title' => 'Which areas do you cover?', 'text' => 'We cover the town centre and all surrounding neighbourhoods.' ),
			),

			'includes_title'      => "What's included",
			'includes_list'       => "Free site survey and a fixed written quote\nOld structure removed and waste taken away\nGround preparation and correct levels\nClean handover when the job is finished\n1 year workmanship guarantee",

			'form_eyebrow'        => 'Free quote',
			'form_title'          => 'Get your free written quote',
			'form_subtitle'       => 'Leave a few details and we will reply within 24 hours.',
			'form_benefits'       => "No obligation\nFree site visit\nFixed written price",
			'form_phone_text'     => 'Or call us on',
			'form_step1'          => 'Service',
			'form_step2'          => 'Your project',
			'form_step3'          => 'Your details',
			'form_step4'          => 'Review & send',
			'form_note'           => 'Not sure which one? Pick the closest — we will confirm at the site visit.',
			'form_services'       => array(
				array( 'Fencing', array( 'Garden fencing', 'Panel fencing', 'Composite fencing', 'Gates' ) ),
				array( 'Paving', array( 'Block paving', 'Driveways', 'Patios' ) ),
				array( 'Landscaping', array( 'Turfing', 'Garden design' ) ),
			),

			'footer_about'        => 'A local, insured team for fencing, paving and landscaping. Free site visits and a fixed written price.',
			'footer_note'         => 'We work on site, so we publish our service area instead of a shop address.',
			'copyright'           => 'All rights reserved.',

			'service_cards'       => array(
				array( 'Garden Fencing', 'Panel, composite and mesh fencing, installed and repaired.' ),
				array( 'Block Paving', 'Block paving for driveways, paths and patios.' ),
				array( 'Driveways', 'New driveways in block paving and natural stone.' ),
				array( 'Patios', 'Porcelain and natural stone patios.' ),
				array( 'Turfing', 'Ground preparation and fresh turf.' ),
				array( 'Landscaping', 'Garden design and a full landscaping build.' ),
			),

			'pages'               => array(
				'home'    => array( 'title' => 'Home', 'slug' => 'home', 'content' => '', 'template' => '' ),
				'blog'    => array( 'title' => 'Blog', 'slug' => 'blog', 'content' => '', 'template' => '' ),
				'about'   => array(
					'title'   => 'About',
					'slug'    => 'about',
					'template' => 'page-about.php',
					'content' => "<!-- wp:paragraph -->\n<p>We are a local team that has been fencing, paving and landscaping for 15+ years. The same team handles the job from the first visit to handover — we do the work ourselves, not through subcontractors.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>We specialise in fencing, block paving, driveways, patios, landscaping and turfing. Every project is properly prepped and laid to the correct falls, and finished to a standard we would want at home.</p>\n<!-- /wp:paragraph -->",
					'about_stats' => array(
						array( 'icon' => 'hammer', 'title' => '15+', 'text' => 'Years experience' ),
						array( 'icon' => 'shield-check', 'title' => '£2m', 'text' => 'Public liability' ),
						array( 'icon' => 'clock', 'title' => 'On time', 'text' => 'Delivery guarantee' ),
					),
				),
				'contact' => array( 'title' => 'Contact', 'slug' => 'contact', 'template' => 'page-contact.php', 'content' => "<!-- wp:paragraph -->\n<p>Tell us about your project and we will get back to you.</p>\n<!-- /wp:paragraph -->" ),
				'privacy' => array( 'title' => 'Privacy Policy', 'slug' => 'privacy', 'content' => "<!-- wp:paragraph -->\n<p>This is sample content for a privacy policy page.</p>\n<!-- /wp:paragraph -->" ),
				'cookies' => array( 'title' => 'Cookie Policy', 'slug' => 'cookies', 'content' => "<!-- wp:paragraph -->\n<p>This is sample content for a cookie policy page.</p>\n<!-- /wp:paragraph -->" ),
				'terms'   => array( 'title' => 'Terms', 'slug' => 'terms', 'content' => "<!-- wp:paragraph -->\n<p>This is sample content for a terms page.</p>\n<!-- /wp:paragraph -->" ),
			),

			'cpt_items'           => array(
				'services' => array(
					array( 'title' => 'Garden Fencing', 'slug' => 'garden-fencing', 'content' => 'We measure, supply and install garden fencing.' ),
					array( 'title' => 'Panel Fencing', 'slug' => 'panel-fencing', 'content' => 'Fast, durable panel fencing.' ),
					array( 'title' => 'Composite Fencing', 'slug' => 'composite-fencing', 'content' => 'Low-maintenance composite fencing.' ),
					array( 'title' => 'Block Paving', 'slug' => 'block-paving', 'content' => 'Block paving for driveways and paths.' ),
					array( 'title' => 'Driveways', 'slug' => 'driveways', 'content' => 'New block paving and natural stone driveways.' ),
					array( 'title' => 'Patios', 'slug' => 'patios', 'content' => 'Porcelain and natural stone patios.' ),
					array( 'title' => 'Turfing', 'slug' => 'turfing', 'content' => 'Ground preparation and fresh turf.' ),
					array( 'title' => 'Landscaping', 'slug' => 'landscaping', 'content' => 'Garden design and a full build.' ),
				),
				'areas'    => array(
					array( 'title' => 'Central', 'slug' => 'central' ),
					array( 'title' => 'Riverside', 'slug' => 'riverside' ),
					array( 'title' => 'Hilltop', 'slug' => 'hilltop' ),
					array( 'title' => 'Oakwood', 'slug' => 'oakwood' ),
					array( 'title' => 'Greenfield', 'slug' => 'greenfield' ),
					array( 'title' => 'Lakeside', 'slug' => 'lakeside' ),
					array( 'title' => 'Poplar', 'slug' => 'poplar' ),
					array( 'title' => 'Springfield', 'slug' => 'springfield' ),
					array( 'title' => 'Brookside', 'slug' => 'brookside' ),
					array( 'title' => 'Eastfield', 'slug' => 'eastfield' ),
					array( 'title' => 'Newtown', 'slug' => 'newtown' ),
					array( 'title' => 'Gardens', 'slug' => 'gardens' ),
				),
			),

			'posts'               => array(
				array( 'title' => 'Choosing the right garden fence', 'content' => '<p>Material, height and ground conditions decide the best fence for you.</p>' ),
				array( 'title' => 'Which paving is best for a driveway?', 'content' => '<p>Block paving or concrete? It depends on how the driveway is used.</p>' ),
				array( 'title' => 'Simple patio care tips', 'content' => '<p>A few easy steps to extend the life of a natural stone patio.</p>' ),
			),

			'menu'                => array(
				array( 'title' => 'Home', 'page' => 'home' ),
				array( 'title' => 'About', 'page' => 'about' ),
				array( 'title' => 'Services', 'archive' => 'services' ),
				array( 'title' => 'Blog', 'page' => 'blog' ),
				array( 'title' => 'Contact', 'page' => 'contact' ),
			),
		);
	}

	/**
	 * Eski kurulumlardaki İngilizce demo metinlerini Türkçe karşılıklarına taşır.
	 *
	 * Yalnızca saklanan değer İngilizce demo metniyle BİREBİR aynıysa değiştirir;
	 * kullanıcının düzenlediği (farklı) değere dokunmaz. Bir kez çalışır.
	 *
	 * @return int Değişen alan sayısı.
	 */
	public static function migrate_en_texts() {
		if ( '1' === get_option( 'devxpe_demo_lang_migrated', '' ) ) {
			return 0;
		}

		$tr   = self::strings( 'tr' );
		$en   = self::strings( 'en' );
		$opts = get_option( 'devxpe_theme_options', array() );
		if ( ! is_array( $opts ) ) {
			$opts = array();
		}

		$degisen = 0;
		foreach ( $tr as $k => $tr_val ) {
			if ( ! isset( $en[ $k ], $opts[ $k ] ) ) {
				continue;
			}
			if ( $opts[ $k ] === $en[ $k ] ) {
				$opts[ $k ] = $tr_val;
				$degisen++;
			}
		}

		if ( $degisen > 0 ) {
			update_option( 'devxpe_theme_options', $opts, false );
		}

		/* Site adı/açıklaması ayrı option'da tutulur; onları da taşı. */
		if ( function_exists( 'devxpe_safe_update_blog_option' ) ) {
			if ( isset( $en['site_title'], $tr['site_title'] ) && get_option( 'blogname' ) === $en['site_title'] ) {
				devxpe_safe_update_blog_option( 'blogname', $tr['site_title'] );
				$degisen++;
			}
			if ( isset( $en['tagline'], $tr['tagline'] ) && get_option( 'blogdescription' ) === $en['tagline'] ) {
				devxpe_safe_update_blog_option( 'blogdescription', $tr['tagline'] );
				$degisen++;
			}
		}

		update_option( 'devxpe_demo_lang_migrated', '1', false );

		return $degisen;
	}

	/**
	 * Eski sürümden kalan "Lorem ipsum" yer tutucu satırlarını temizler.
	 *
	 * Yalnızca içinde "lorem ipsum" geçen kart/satırları atar; kullanıcının
	 * gerçek (lorem olmayan) içeriğine dokunmaz. Bir kez çalışır.
	 *
	 * @return int Değişen alan sayısı.
	 */
	public static function cleanup_legacy_cards() {
		if ( '1' === get_option( 'devxpe_demo_cards_cleaned', '' ) ) {
			return 0;
		}

		$o = get_option( 'devxpe_theme_options', array() );
		if ( ! is_array( $o ) ) {
			$o = array();
		}

		$keys = array(
			'services_cards',
			'projects_items',
			'features_items',
			'steps_items',
			'reviews_items',
			'faq_items',
			'form_services',
			'about_sections',
		);

		$deg = 0;

		foreach ( $keys as $key ) {
			if ( empty( $o[ $key ] ) || ! is_array( $o[ $key ] ) ) {
				continue;
			}

			$before = count( $o[ $key ] );
			$o[ $key ] = array_values(
				array_filter(
					$o[ $key ],
					array( __CLASS__, 'row_has_content' )
				)
			);

			if ( count( $o[ $key ] ) !== $before ) {
				$deg++;
			}
		}

		if ( $deg > 0 ) {
			update_option( 'devxpe_theme_options', $o, false );
		}
		update_option( 'devxpe_demo_cards_cleaned', '1', false );

		return $deg;
	}

	/**
	 * Bir satır gerçek içerik mi? (İçinde "lorem ipsum" geçmeyen.)
	 *
	 * @param mixed $row Kart/satır dizisi.
	 * @return bool
	 */
	private static function row_has_content( $row ) {
		if ( ! is_array( $row ) ) {
			return false;
		}
		foreach ( $row as $val ) {
			if ( is_string( $val ) && false !== stripos( $val, 'lorem ipsum' ) ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * "Yetim demo" ayarlarını temizler.
	 *
	 * Durum (state) kaybolmuş ama options'ta demo değerleri kalmışsa çalışır:
	 * demo kartları demo setiyle birebir eşleşiyorsa, demo metinlerini,
	 * kartları ve otomatik etiket kaynaklarını sıfırlar. Güncelleme sonrası
	 * bir kez çalışır; demo KURULUYSA veya içerik gerçekse dokunmaz.
	 *
	 * @return int Değişen alan sayısı.
	 */
	public static function cleanup_orphan_demo() {
		if ( self::is_installed() ) {
			return 0;
		}
		if ( '1' === get_option( 'devxpe_demo_orphan_cleaned', '' ) ) {
			return 0;
		}

		$o = get_option( 'devxpe_theme_options', array() );
		if ( ! is_array( $o ) ) {
			$o = array();
		}

		$tr = self::strings( 'tr' );
		$en = self::strings( 'en' );

		/* Yetim demo mu? Kartlar demo setiyle birebir eşleşiyorsa evet. */
		$orphan = self::stored_matches_demo( $o, 'services_cards', $tr )
			|| self::stored_matches_demo( $o, 'services_cards', $en )
			|| self::stored_matches_demo( $o, 'projects_items', $tr )
			|| self::stored_matches_demo( $o, 'projects_items', $en );

		if ( ! $orphan ) {
			update_option( 'devxpe_demo_orphan_cleaned', '1', false );
			return 0;
		}

		$deg = 0;

		/* 1) Skalar demo metinleri (hero, bölüm başlıkları, footer vb.). */
		foreach ( $tr as $key => $val ) {
			if ( ! is_string( $val ) || ! array_key_exists( $key, $o ) ) {
				continue;
			}
			$en_val = ( isset( $en[ $key ] ) && is_string( $en[ $key ] ) ) ? $en[ $key ] : null;
			if ( $o[ $key ] === $val || ( null !== $en_val && $o[ $key ] === $en_val ) ) {
				$o[ $key ] = '';
				$deg++;
			}
		}

		/* 2) Dizi alanları demo setiyle eşleşiyorsa boşalt. */
		foreach ( array( 'services_cards', 'projects_items', 'features_items', 'steps_items', 'reviews_items', 'faq_items', 'form_services' ) as $key ) {
			if ( empty( $o[ $key ] ) || ! is_array( $o[ $key ] ) ) {
				continue;
			}
			if ( self::stored_matches_demo( $o, $key, $tr ) || self::stored_matches_demo( $o, $key, $en ) ) {
				$o[ $key ] = array();
				$deg++;
			}
		}

		/* 3) Otomatik etiket şeritleri: demo artığında kapatılmalı. */
		foreach ( array( 'services_terms_source', 'projects_terms_source', 'areas_terms_source' ) as $key ) {
			if ( isset( $o[ $key ] ) && 'none' !== $o[ $key ] ) {
				$o[ $key ] = 'none';
				$deg++;
			}
		}

		/* 4) İşaretli kalmış demo içeriği varsa sil. */
		$flag = get_posts(
			array(
				'post_type'      => 'any',
				'post_status'    => 'any',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'meta_key'       => '_dxp_demo',
			)
		);
		foreach ( $flag as $id ) {
			if ( 'attachment' === get_post_type( $id ) ) {
				wp_delete_attachment( (int) $id, true );
			} else {
				wp_delete_post( (int) $id, true );
			}
		}

		if ( $deg > 0 ) {
			update_option( 'devxpe_theme_options', $o, false );
		}
		update_option( 'devxpe_demo_orphan_cleaned', '1', false );

		return $deg;
	}

	/**
	 * Saklanan bir dizi alanı demo setiyle birebir mi?
	 *
	 * @param array  $opts Saklanan option dizisi.
	 * @param string $key  Alan anahtarı (services_cards vb.).
	 * @param array  $s    Demo strings haritası (tr/en).
	 * @return bool
	 */
	private static function stored_matches_demo( $opts, $key, $s ) {
		if ( empty( $opts[ $key ] ) || ! is_array( $opts[ $key ] ) ) {
			return false;
		}
		$map = self::demo_rows_map( $key, $s );
		if ( empty( $map ) ) {
			return false;
		}
		return self::rows_match_map( $opts[ $key ], $map );
	}

	/**
	 * Bir demo alanının başlık=>metin eşlemesini üretir.
	 *
	 * @param string $key Alan anahtarı.
	 * @param array  $s   Demo strings haritası.
	 * @return array
	 */
	private static function demo_rows_map( $key, $s ) {
		$map = array();

		switch ( $key ) {
			case 'services_cards':
				if ( empty( $s['service_cards'] ) ) {
					return array();
				}
				foreach ( $s['service_cards'] as $c ) {
					$map[ (string) $c[0] ] = (string) $c[1];
				}
				break;
			case 'projects_items':
				if ( empty( $s['project_titles'] ) ) {
					return array();
				}
				$cap = isset( $s['project_caption'] ) ? (string) $s['project_caption'] : '';
				foreach ( $s['project_titles'] as $t ) {
					$map[ (string) $t ] = $cap;
				}
				break;
			case 'form_services':
				if ( empty( $s['form_services'] ) ) {
					return array();
				}
				foreach ( $s['form_services'] as $g ) {
					$map[ (string) $g[0] ] = implode( "\n", (array) $g[1] );
				}
				break;
			default:
				if ( empty( $s[ $key ] ) || ! is_array( $s[ $key ] ) ) {
					return array();
				}
				foreach ( $s[ $key ] as $row ) {
					if ( is_array( $row ) && isset( $row['title'], $row['text'] ) ) {
						$map[ (string) $row['title'] ] = (string) $row['text'];
					}
				}
		}

		return $map;
	}

	/**
	 * Satırlar başlık=>metin eşlemesiyle birebir mi?
	 *
	 * @param array $rows Saklanan satırlar.
	 * @param array $map  Başlık=>metin.
	 * @return bool
	 */
	private static function rows_match_map( $rows, $map ) {
		$rows = array_values( (array) $rows );
		if ( count( $rows ) !== count( $map ) ) {
			return false;
		}
		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				return false;
			}
			$title = isset( $row['title'] ) ? (string) $row['title'] : '';
			$text  = isset( $row['text'] ) ? (string) $row['text'] : '';
			if ( ! isset( $map[ $title ] ) || (string) $map[ $title ] !== $text ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Hero rozetlerindeki (chips) "Lorem ipsum" yer tutucularını temizler.
	 *
	 * Eski varsayılanlardan kaydedilmiş olabilir (demo ile ilgisiz). Bir kez çalışır.
	 *
	 * @return int Değişen alan sayısı.
	 */
	public static function cleanup_placeholder_chips() {
		if ( '1' === get_option( 'devxpe_hero_chips_cleaned', '' ) ) {
			return 0;
		}

		$o = get_option( 'devxpe_theme_options', array() );
		if ( ! is_array( $o ) ) {
			$o = array();
		}

		$ph = array(
			'lorem', 'ipsum', 'dolor', 'sit', 'amet', 'consectetur', 'adipiscing',
			'elit', 'sed', 'eiusmod', 'tempor', 'incididunt', 'labore', 'dolore',
			'magna', 'aliqua',
		);

		$deg = 0;

		for ( $i = 1; $i <= 4; $i++ ) {
			$vkey = 'hero_stat_' . $i . '_value';
			$lkey = 'hero_stat_' . $i . '_label';
			$ikey = 'hero_stat_' . $i . '_icon';

			$val = isset( $o[ $vkey ] ) ? strtolower( trim( (string) $o[ $vkey ] ) ) : '';
			$lab = isset( $o[ $lkey ] ) ? strtolower( trim( (string) $o[ $lkey ] ) ) : '';

			$is_ph = ( '' !== $val && in_array( $val, $ph, true ) )
				|| ( '' !== $lab && in_array( $lab, $ph, true ) )
				|| false !== strpos( $val, 'lorem' )
				|| false !== strpos( $lab, 'lorem' );

			if ( $is_ph ) {
				foreach ( array( $vkey, $lkey, $ikey ) as $k ) {
					if ( isset( $o[ $k ] ) && '' !== $o[ $k ] ) {
						$o[ $k ] = '';
						$deg++;
					}
				}
			}
		}

		if ( $deg > 0 ) {
			update_option( 'devxpe_theme_options', $o, false );
		}
		update_option( 'devxpe_hero_chips_cleaned', '1', false );

		return $deg;
	}

	/**
	 * Türkçe demo verisi (geriye dönük uyumluluk için korunur).
	 *
	 * @return array
	 */
	private static function data_tr() {
		return self::data( 'tr' );
	}

	/**
	 * İngilizce demo verisi (geriye dönük uyumluluk için korunur).
	 *
	 * @return array
	 */
	private static function data_en() {
		return self::data( 'en' );
	}
}
