<?php
/**
 * KVKK/GDPR gizlilik araçları: form kayıtlarını dışa aktarma ve silme.
 *
 * WordPress'in "Kişisel Verileri Dışa Aktar / Sil" araçlarına katılır; ayrıca
 * gizlilik politikası sayfasına tema veri işleme metnini ekler.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Kaydın herhangi bir alanındaki e-posta adresi.
 *
 * @param array $entry Form kaydı.
 * @return string Küçük harfli e-posta; yoksa ''.
 */
function devxpe_privacy_entry_email( $entry ) {
	if ( ! is_array( $entry ) ) {
		return '';
	}

	foreach ( $entry as $deger ) {
		if ( ! is_string( $deger ) || '' === trim( $deger ) ) {
			continue;
		}

		$deger = strtolower( trim( $deger ) );

		if ( false !== filter_var( $deger, FILTER_VALIDATE_EMAIL ) ) {
			return $deger;
		}
	}

	return '';
}

/**
 * Verilen e-postaya ait kayıtları döndürür.
 *
 * @param array  $entries Kayıtlar.
 * @param string $email   E-posta.
 * @return array
 */
function devxpe_privacy_find_entries( $entries, $email ) {
	$email = strtolower( trim( (string) $email ) );
	$out   = array();

	if ( '' === $email || ! is_array( $entries ) ) {
		return $out;
	}

	foreach ( $entries as $entry ) {
		if ( devxpe_privacy_entry_email( $entry ) === $email ) {
			$out[] = $entry;
		}
	}

	return $out;
}

/**
 * Verilen e-postaya ait kayıtları siler (yan etkisiz; test edilebilir).
 *
 * @param array  $entries Kayıtlar.
 * @param string $email   E-posta.
 * @return array { kalan: array, silinen: int }
 */
function devxpe_privacy_erase_entries( $entries, $email ) {
	$email   = strtolower( trim( (string) $email ) );
	$kalan   = array();
	$silinen = 0;

	foreach ( (array) $entries as $entry ) {
		if ( '' !== $email && devxpe_privacy_entry_email( $entry ) === $email ) {
			$silinen++;
			continue;
		}

		$kalan[] = $entry;
	}

	return array( 'kalan' => $kalan, 'silinen' => $silinen );
}

/**
 * Dışa aktarma: e-postaya ait form mesajları.
 *
 * @param string $email E-posta.
 * @param int    $page  Sayfa (kullanılmıyor).
 * @return array
 */
function devxpe_privacy_export_data( $email, $page = 1 ) {
	$items = array();

	$etiketler = array(
		'time'    => 'Tarih',
		'date'    => 'Tarih',
		'type'    => 'Tür',
		'name'    => 'Ad',
		'email'   => 'E-posta',
		'phone'   => 'Telefon',
		'service' => 'Hizmet',
		'message' => 'Mesaj',
		'ip'      => 'IP',
	);

	foreach ( devxpe_privacy_find_entries( (array) get_option( DEVXPE_FORM_OPTION, array() ), $email ) as $entry ) {
		$veri = array();

		foreach ( (array) $entry as $anahtar => $deger ) {
			/* Özel form alanları da dışa aktarılır; teknik alanlar atlanır. */
			if ( ! is_scalar( $deger ) || '' === trim( (string) $deger ) ) {
				continue;
			}

			if ( in_array( (string) $anahtar, array( 'id', 'read', 'subject', 'body' ), true ) ) {
				continue;
			}

			$veri[] = array(
				'name'  => $etiketler[ $anahtar ] ?? ucfirst( str_replace( '_', ' ', (string) $anahtar ) ),
				'value' => wp_strip_all_tags( (string) $deger ),
			);
		}

		$items[] = array(
			'group_id'    => 'devxpe-form-entries',
			'group_label' => __( 'İletişim formu mesajları', 'devxpe-theme' ),
			'item_id'     => 'devxpe-form-' . (string) ( $entry['id'] ?? md5( (string) ( $entry['time'] ?? '' ) ) ),
			'data'        => $veri,
		);
	}

	return array( 'data' => $items, 'done' => true );
}

/**
 * Silme: e-postaya ait form mesajları.
 *
 * @param string $email E-posta.
 * @param int    $page  Sayfa (kullanılmıyor).
 * @return array
 */
function devxpe_privacy_erase_data( $email, $page = 1 ) {
	$sonuc = devxpe_privacy_erase_entries( (array) get_option( DEVXPE_FORM_OPTION, array() ), $email );

	if ( $sonuc['silinen'] > 0 ) {
		update_option( DEVXPE_FORM_OPTION, array_values( $sonuc['kalan'] ), false );
	}

	return array(
		'items_removed'  => $sonuc['silinen'] > 0,
		'items_retained' => false,
		'messages'       => array(),
		'done'           => true,
	);
}

/**
 * WordPress gizlilik araçlarına dışa aktarıcı ekler.
 *
 * @param array $exporters Dışa aktarıcılar.
 * @return array
 */
function devxpe_privacy_register_exporter( $exporters ) {
	$exporters['devxpe-form-entries'] = array(
		'exporter_friendly_name' => __( 'DEVXPE form mesajları', 'devxpe-theme' ),
		'callback'               => 'devxpe_privacy_export_data',
	);

	return $exporters;
}

/**
 * WordPress gizlilik araçlarına silici ekler.
 *
 * @param array $erasers Siliciler.
 * @return array
 */
function devxpe_privacy_register_eraser( $erasers ) {
	$erasers['devxpe-form-entries'] = array(
		'eraser_friendly_name' => __( 'DEVXPE form mesajları', 'devxpe-theme' ),
		'callback'             => 'devxpe_privacy_erase_data',
	);

	return $erasers;
}

/**
 * Gizlilik politikası sayfasına veri işleme metnini ekler.
 *
 * @return void
 */
function devxpe_privacy_policy_metni() {
	if ( ! function_exists( 'wp_add_privacy_policy_content' ) ) {
		return;
	}

	$gun = devxpe_form_retention_days();

	$metin  = '<p>' . esc_html__( 'İletişim ve teklif formlarından gönderilen ad, e-posta, telefon, mesaj ve IP adresi, talebinize yanıt vermek amacıyla saklanır ve site yöneticisine e-posta ile iletilir.', 'devxpe-theme' ) . '</p>';
	$metin .= '<p>' . sprintf(
		esc_html__( 'Form kayıtları en fazla %s gün saklanır; süre sonunda otomatik olarak silinir.', 'devxpe-theme' ),
		$gun > 0 ? (int) $gun : esc_html__( 'sınırsız', 'devxpe-theme' )
	) . '</p>';

	if ( '1' === (string) devxpe_theme_get( 'report_enable', '1' ) ) {
		$metin .= '<p>' . esc_html__( 'Site adresi, WordPress/PHP sürümü ve tema sürümü, güncelleme ve destek amacıyla geliştiriciye iletilir. Bu paylaşım panelden kapatılabilir.', 'devxpe-theme' ) . '</p>';
	}

	if ( '1' === (string) devxpe_theme_get( 'recaptcha_enable' ) ) {
		$metin .= '<p>' . esc_html__( 'Formlarda Google reCAPTCHA kullanılır; bu hizmet Google gizlilik politikasına tabidir.', 'devxpe-theme' ) . '</p>';
	}

	wp_add_privacy_policy_content( 'DEVXPE', $metin );
}

add_filter( 'wp_privacy_personal_data_exporters', 'devxpe_privacy_register_exporter' );
add_filter( 'wp_privacy_personal_data_erasers', 'devxpe_privacy_register_eraser' );
add_action( 'admin_init', 'devxpe_privacy_policy_metni' );
