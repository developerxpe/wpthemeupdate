<?php
/**
 * Tema boot, widget alanları, bakım modu ve genel yardımcılar.
 *
 * functions.php'den ayrıldı.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Elementor çakışmasını önleyerek site adı/açıklaması yazar.
 *
 * `update_option('blogname')` çağrısı `update_option_blogname` kancasını
 * tetikler; Elementor bu kancada kendi kit ayarını güncellemeye çalışır ve
 * yetki/oturum bağlamına göre "Access denied" fırlatır. Demo kur/kaldır ve
 * kurulum sihirbazı sırasında bu kancayı geçici olarak askıya alırız.
 *
 * @param string $option 'blogname' | 'blogdescription'.
 * @param string $value  Yeni değer.
 * @return void
 */
function devxpe_safe_update_blog_option( $option, $value ) {
	global $wp_filter;

	$kanca  = 'update_option_' . $option;
	$gecici = null;

	if ( isset( $wp_filter[ $kanca ] ) ) {
		$gecici = $wp_filter[ $kanca ];
		unset( $wp_filter[ $kanca ] );
	}

	update_option( $option, $value );

	if ( null !== $gecici ) {
		$wp_filter[ $kanca ] = $gecici;
	}
}

/**
 * Çok satırlı / virgüllü metni temiz parçalara ayırır.
 *
 * Her parça trim edilir, boş parçalar atılır ve dizi yeniden indekslenir:
 * `array_filter( array_map( 'trim', explode( ... ) ) )` deseninin
 * yeniden indekslenmiş hâli.
 *
 * @param mixed  $text Ham metin (dizi de olabilir, string'e çevrilir).
 * @param string $sep  Ayırıcı (varsayılan: yeni satır).
 * @return array
 */
function devxpe_lines( $text, $sep = "\n" ) {
	return array_values( array_filter( array_map( 'trim', explode( $sep, (string) $text ) ) ) );
}

/**
 * Bölüm sırası/kapalılar satırını ortak biçimde ayrıştırır.
 *
 * `order` kayıtlı sıraya göre dizilir, eksik id'ler sona eklenir; `off` yalnızca
 * geçerli id'lerle sınırlanır. Çıktı: array( 'order' => array, 'off' => array ).
 *
 * @param mixed $row Bölüm iskeleti satırı (order/off alanları).
 * @param array $ids Geçerli bölüm id'leri.
 * @return array
 */
function devxpe_parse_order_off( $row, $ids ) {
	$row = is_array( $row ) ? $row : array();

	$order = isset( $row['order'] ) ? devxpe_lines( $row['order'], ',' ) : array();
	$order = array_values( array_intersect( $order, $ids ) );
	$order = array_merge( $order, array_values( array_diff( $ids, $order ) ) );

	$off = isset( $row['off'] ) ? devxpe_lines( $row['off'], ',' ) : array();
	$off = array_values( array_intersect( $off, $ids ) );

	return array( 'order' => $order, 'off' => $off );
}

/**
 * Tema kurulumu: çeviri, destekler, menüler.
 *
 * @return void
 */
function devxpe_theme_setup() {
	load_theme_textdomain( 'devxpe-theme', DEVXPE_THEME_PATH . 'languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'custom-logo' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );

	register_nav_menus(
		array(
			'primary' => __( 'Primary Menu', 'devxpe-theme' ),
			'footer'  => __( 'Footer Menu', 'devxpe-theme' ),
		)
	);
}
add_action( 'after_setup_theme', 'devxpe_theme_setup' );

/**
 * Widget alanı (sidebar).
 *
 * @return void
 */
function devxpe_theme_widgets() {
	register_sidebar(
		array(
			'name'          => __( 'Sidebar', 'devxpe-theme' ),
			'id'            => 'sidebar-1',
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		)
	);
}
add_action( 'widgets_init', 'devxpe_theme_widgets' );

/**
 * Bakım modu: etkinse ve giriş yapan yönetici değilse sayfayı durdurur.
 *
 * @return void
 */
function devxpe_theme_maintenance() {
	if ( '1' !== devxpe_theme_get( 'maintenance_enable' ) ) {
		return;
	}

	if ( is_user_logged_in() && current_user_can( 'manage_options' ) ) {
		return;
	}

	$title   = devxpe_theme_get( 'maintenance_title', __( 'Bakımdayız', 'devxpe-theme' ) );
	$message = devxpe_theme_get( 'maintenance_message', __( 'Sitemiz şu anda güncellenmektedir. Lütfen daha sonra tekrar deneyin.', 'devxpe-theme' ) );
	$image   = devxpe_theme_get( 'maintenance_image' );
	$date    = devxpe_theme_get( 'maintenance_date' ); // Format: 2026-12-31 23:59
	$primary = devxpe_theme_get( 'primary_color', '#c29525' );
	$text    = devxpe_theme_get( 'text_color', '#033216' );
	$font_css = DEVXPE_THEME_PATH . 'assets/css/public-sans.css';
	
	/*
	 * Yalnızca içerik döndürülür; charset/viewport/title'ı wp_die() üretir.
	 * Önceden tam HTML dokümanı gönderiliyordu: iç içe doküman oluşuyor ve
	 * WP'nin #error-page kuralları (ID özgüllüğü) düzeni bozuyordu.
	 */
	$html = '';

	/* Tema fontu (kendi sunucumuzdan); dosya yoksa sistem fontuna düşer. */
	if ( file_exists( $font_css ) ) {
		$html .= '<link rel="stylesheet" href="' . esc_url( DEVXPE_THEME_URL . 'assets/css/public-sans.css?ver=' . filemtime( $font_css ) ) . '" />';
	}

	$html .= '<style>
		html { background: #f6fcf7; -webkit-text-size-adjust: 100%; }

		body {
			margin         : 0;
			padding        : 20px;
			box-sizing     : border-box;
			min-height     : 100vh;
			min-height     : 100svh;
			background     : #f6fcf7;
			background     : radial-gradient(900px 420px at 50% -10%, color-mix(in srgb, ' . esc_attr( $primary ) . ', transparent 85%), transparent 70%), #f6fcf7;
			border         : 0;
			box-shadow     : none;
			max-width      : none;
			color          : ' . esc_attr( $text ) . ';
			font-family    : "Public Sans", ui-sans-serif, system-ui, -apple-system, "Segoe UI", Arial, sans-serif;
			text-align     : center;
			display        : flex;
			align-items    : center;
			justify-content: center;
		}

		/* WP varsayılan wp_die kurallarını sıfırla */
		#error-page { margin: 0; }
		#error-page .wp-die-message { margin: 0; width: 100%; font-size: inherit; line-height: inherit; }

		.mnt-container {
			width        : 100%;
			max-width    : 600px;
			margin       : 0 auto;
			padding      : 40px 24px;
			box-sizing   : border-box;
			background   : #fff;
			border       : 1px solid #dae4dc;
			border-radius: 14px;
			box-shadow   : 0 1px 2px rgba(0,0,0,.04), 0 10px 30px rgba(3,50,22,.06);
		}

		.mnt-image {
			display      : block;
			width        : 100%;
			max-width    : 100%;
			height       : auto;
			max-height   : 300px;
			object-fit   : cover;
			border-radius: 10px;
			margin       : 0 auto 24px;
		}

		.mnt-container h1 {
			margin     : 0 0 12px;
			padding    : 0;
			border     : 0;
			font-size  : 28px;
			font-weight: 700;
			line-height: 1.25;
			letter-spacing: -.01em;
			color      : ' . esc_attr( $text ) . ';
		}

		.mnt-container p {
			margin     : 0 0 24px;
			font-size  : 16px;
			line-height: 1.6;
			color      : #57685b;
		}

		.mnt-timer {
			display        : flex;
			flex-wrap      : nowrap;
			justify-content: center;
			gap            : 12px;
			margin-top     : 28px;
		}

		.mnt-timer-box {
			flex         : 1 1 0;
			min-width    : 0;
			background   : color-mix(in srgb, ' . esc_attr( $primary ) . ', transparent 90%);
			border       : 1px solid color-mix(in srgb, ' . esc_attr( $primary ) . ', transparent 78%);
			box-shadow   : inset 0 3px 0 ' . esc_attr( $primary ) . ';
			color        : ' . esc_attr( $text ) . ';
			padding      : 14px 6px 12px;
			border-radius: 12px;
		}

		.mnt-timer-box span {
			display    : block;
			font-size  : 28px;
			font-weight: 800;
			line-height: 1.1;
			color      : ' . esc_attr( $primary ) . ';
			font-variant-numeric: tabular-nums;
		}
		.mnt-timer-box small {
			display       : block;
			margin-top    : 4px;
			font-size     : 11px;
			font-weight   : 600;
			letter-spacing: .06em;
			text-transform: uppercase;
			color         : #57685b;
		}

		.mnt-done { display: block; padding: 14px; font-weight: 700; color: ' . esc_attr( $primary ) . '; }

		/* Tablet */
		@media (max-width: 991px) {
			.mnt-container { max-width: 560px; padding: 34px 22px; }
			.mnt-container h1 { font-size: 25px; }
			.mnt-container p { font-size: 15.5px; }
			.mnt-image { max-height: 260px; }
		}

		/* Büyük telefon / küçük tablet */
		@media (max-width: 767px) {
			body { padding: 16px; }
			.mnt-container { max-width: 100%; padding: 30px 20px; border-radius: 10px; }
			.mnt-container h1 { font-size: 23px; }
			.mnt-container p { font-size: 15px; }
			.mnt-image { max-height: 220px; }
			.mnt-timer { gap: 10px; margin-top: 24px; }
			.mnt-timer-box { padding: 12px 4px; }
			.mnt-timer-box span { font-size: 24px; }
		}

		/* Telefon */
		@media (max-width: 480px) {
			body { padding: 12px; }
			.mnt-container { padding: 26px 16px; }
			.mnt-container h1 { font-size: 21px; margin-bottom: 12px; }
			.mnt-container p { font-size: 14.5px; margin-bottom: 20px; }
			.mnt-image { max-height: 180px; margin-bottom: 18px; }
			.mnt-timer { gap: 8px; margin-top: 20px; }
			.mnt-timer-box { padding: 10px 3px; }
			.mnt-timer-box span { font-size: 21px; }
			.mnt-timer-box small { font-size: 9.5px; letter-spacing: .03em; }
		}

		/* Çok dar ekran */
		@media (max-width: 360px) {
			.mnt-container h1 { font-size: 19px; }
			.mnt-timer-box span { font-size: 18px; }
			.mnt-timer-box small { font-size: 8.5px; letter-spacing: 0; }
		}
	</style>';

	$html .= '<div class="mnt-container">';
	
	if ( $image ) {
		$html .= '<img src="' . esc_url( $image ) . '" alt="' . esc_attr__( 'Bakım', 'devxpe-theme' ) . '" class="mnt-image" />';
	}
	
	$html .= '<h1>' . esc_html( $title ) . '</h1>';
	$html .= '<p>' . nl2br( esc_html( $message ) ) . '</p>';
	
	if ( $date ) {
		$html .= '<div class="mnt-timer" id="mntTimer">
			<div class="mnt-timer-box"><span id="mntDays">00</span><small>' . esc_html__( 'Gün', 'devxpe-theme' ) . '</small></div>
			<div class="mnt-timer-box"><span id="mntHours">00</span><small>' . esc_html__( 'Saat', 'devxpe-theme' ) . '</small></div>
			<div class="mnt-timer-box"><span id="mntMinutes">00</span><small>' . esc_html__( 'Dakika', 'devxpe-theme' ) . '</small></div>
			<div class="mnt-timer-box"><span id="mntSeconds">00</span><small>' . esc_html__( 'Saniye', 'devxpe-theme' ) . '</small></div>
		</div>';
		$html .= '<script>
			var countDownDate = new Date("' . esc_js( devxpe_theme_sanitize_datetime( $date ) ) . '").getTime();
			var x = setInterval(function() {
				var now = new Date().getTime();
				var distance = countDownDate - now;
				if (distance < 0) {
					clearInterval(x);
					document.getElementById("mntTimer").innerHTML = "<strong class=\"mnt-done\">' . esc_js( __( 'Süre doldu, yeniden yükleniyor…', 'devxpe-theme' ) ) . '</strong>";
					setTimeout(function(){ window.location.reload(); }, 3000);
					return;
				}
				var days = Math.floor(distance / (1000 * 60 * 60 * 24));
				var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
				var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
				var seconds = Math.floor((distance % (1000 * 60)) / 1000);
				
				document.getElementById("mntDays").innerHTML = days < 10 ? "0"+days : days;
				document.getElementById("mntHours").innerHTML = hours < 10 ? "0"+hours : hours;
				document.getElementById("mntMinutes").innerHTML = minutes < 10 ? "0"+minutes : minutes;
				document.getElementById("mntSeconds").innerHTML = seconds < 10 ? "0"+seconds : seconds;
			}, 1000);
		</script>';
	}
	
	$html .= '</div>';

	wp_die( $html, $title, array( 'response' => 503 ) );
}
add_action( 'template_redirect', 'devxpe_theme_maintenance' );

add_action( 'wp_enqueue_scripts', 'devxpe_theme_assets' );

/**
 * Ön yüzün tarayıcıda bayat kalmasını engeller.
 *
 * Panelde yapılan değişikliklerin (renk, logo, ticker vb.) normal sekmede
 * hemen görünmesi için HTML yanıtına no-cache başlıkları ekler.
 *
 * @param array $headers WP yanıt başlıkları.
 * @return array
 */
function devxpe_theme_no_cache_headers( $headers ) {
	if ( is_admin() ) {
		return $headers;
	}
	$headers['Cache-Control'] = 'no-cache, must-revalidate, max-age=0';
	$headers['Pragma']        = 'no-cache';
	$headers['Expires']       = '0';
	return $headers;
}
add_filter( 'wp_headers', 'devxpe_theme_no_cache_headers' );

/*
 * Arşiv başlığı önekini kaldırır.
 *
 * WP çekirdeği (get_the_archive_title) post type arşivlerine "Arşivler:"
 * öneki ekler ve önek varken başlığı '<span>...</span>' ile sarar. Bu önek
 * hem H1'de hem breadcrumb'da görünüyordu; breadcrumb'da esc_html()
 * yüzünden etiket düz metin olarak basılıyordu. Önek boş döndürülünce
 * hem "Arşivler:" hem de <span> sarması kalkar.
 */
add_filter( 'get_the_archive_title_prefix', '__return_empty_string' );

/**
 * Yönetim panelini başlatır (admin_menu / admin_init hook'larını kurar).
 *
 * @return void
 */
function devxpe_theme_boot_panel() {
	DEVXPE_Theme_Panel::init();
}
add_action( 'after_setup_theme', 'devxpe_theme_boot_panel' );

/**
 * Panelin bulunduğu yönetim sayfasının adresini döndürür.
 *
 * Sınıf yüklenmemişse adres ana yönetim sayfasına (admin.php) düşer;
 * böylece var olmayan bir sayfaya yönlendirme yapılmaz.
 *
 * @param string $ek Opsiyonel ek sorgu/çapa (ör. '&demo=installed#settings--demo').
 * @return string
 */
function devxpe_panel_url( $ek = '' ) {
	if ( class_exists( 'DEVXPE_Theme_Panel' ) ) {
		return admin_url( 'admin.php?page=' . DEVXPE_Theme_Panel::MENU_SLUG ) . $ek;
	}

	return admin_url( 'admin.php' );
}

/**
 * Ticker'ı panelden seçilen kancaya bağlar.
 */
function devxpe_theme_hook_ticker() {
	if ( '1' !== devxpe_theme_get( 'ticker_enabled' ) ) {
		return;
	}
	$pos = devxpe_theme_get( 'ticker_position', 'header_bottom' );
	$hook = 'devxpe_after_header'; // Varsayılan

	if ( 'header_top' === $pos ) {
		$hook = 'devxpe_before_header';
	} elseif ( 'footer_top' === $pos ) {
		$hook = 'devxpe_before_footer';
	} elseif ( 'footer_bottom' === $pos ) {
		$hook = 'devxpe_after_footer';
	}

	add_action( $hook, function() {
		get_template_part( 'template-parts/ticker' );
	} );
}
add_action( 'wp', 'devxpe_theme_hook_ticker' );

/**
 * Panel ayarına göre Bootstrap container sınıfını döndürür.
 *
 * Kutulu/Tam genişlik ayrımı artık CSS değişkenleriyle yapılıyor
 * (--dxp-wrap-max / --dxp-wrap-pad): container-fluid kenarlara yakın durur,
 * container yanlarda boşluk bırakır.
 *
 * @return string
 */
function devxpe_get_container_class() {
	$layout = devxpe_theme_get( 'layout', 'boxed' );
	return ( 'full' === $layout ) ? 'container-fluid' : 'container';
}

/**
 * Reklam alanlarını frontend'de gösterir.
 *
 * @param string $type Reklam tipi (header, sidebar, post_top vb.)
 */
function devxpe_render_ad( $type ) {
	if ( '1' === devxpe_theme_get( $type . '_enable' ) ) {
		$code = devxpe_theme_get( $type . '_code' );
		if ( ! empty( $code ) ) {
			echo '<div class="dxp-ad dxp-ad-' . esc_attr( str_replace( '_ad', '', $type ) ) . '">' . $code . '</div>';
		}
	}
}

