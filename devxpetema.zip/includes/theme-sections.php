<?php
/**
 * Anasayfa/CPT/hakkımızda bölümleri, şablonlar ve arşiv kuralları.
 *
 * functions.php'den ayrıldı.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Tema option dizisinde bir anahtar kayıtlı mı? (Varsayılan değil, gerçek kayıt.)
 *
 * Taze kurulumda hiçbir şey kayıtlı değildir; bölümlerin "ayar yapılmadıysa
 * çizme" kararı buna dayanır. Mevcut kayıtlı değerler etkilenmez.
 *
 * @param string $key Alan id'si.
 * @return bool
 */
function devxpe_option_stored( $key ) {
	$opts = get_option( 'devxpe_theme_options', array() );
	return is_array( $opts ) && array_key_exists( $key, $opts );
}

/**
 * Kayıtlı bir checkbox alanı açık ('1') mı? Kayıt yoksa false.
 *
 * @param string $key Alan id'si.
 * @return bool
 */
function devxpe_option_stored_on( $key ) {
	return devxpe_option_stored( $key ) && ( '1' === devxpe_theme_get( $key ) );
}

/**
 * Bir anasayfa bölümü açık mı? (Sadece "Bölüm Aktif" anahtarı.)
 *
 * @param string $id Bölüm id'si.
 * @return bool
 */
function devxpe_section_enabled( $id ) {
	return ( '1' === devxpe_theme_get( $id . '_enable', '1' ) );
}

/**
 * Bölümün mevcut istekte çizilip çizilmeyeceğini döndürür.
 *
 * Otomatik akışta bölümler yalnızca anasayfada çizilir; başka sayfalarda
 * yerleştirmek için [devxpe_section id="..."] kısa kodu kullanılır.
 *
 * @param string $id Bölüm id'si.
 * @return bool
 */
function devxpe_section_visible( $id ) {
	if ( ! devxpe_section_enabled( $id ) ) {
		return false;
	}

	/* Kısa kod bağlamı: yalnızca istenen bölüm çizilir (sayfa şartı yok). */
	if ( ! empty( $GLOBALS['dxp_render_section'] ) ) {
		return ( $GLOBALS['dxp_render_section'] === $id );
	}

	return is_front_page();
}

/**
 * Tek bir anasayfa bölümünü kısa kodla çizer: [devxpe_section id="services"]
 *
 * @param array $atts Kısa kod öznitelikleri.
 * @return string
 */
function devxpe_section_shortcode( $atts = array() ) {
	$atts = shortcode_atts( array( 'id' => '' ), $atts, 'devxpe_section' );
	$id   = sanitize_key( $atts['id'] );

	if ( '' === $id || ! in_array( $id, devxpe_home_section_ids(), true ) ) {
		return '';
	}

	$GLOBALS['dxp_render_section'] = $id;
	ob_start();
	get_template_part( 'template-parts/home-sections' );
	$html = ob_get_clean();
	unset( $GLOBALS['dxp_render_section'] );

	return $html;
}
add_shortcode( 'devxpe_section', 'devxpe_section_shortcode' );

/**
 * CPT detay sayfasında kullanılabilen bölümler (varsayılan sıra).
 *
 * @return array
 */
function devxpe_cpt_section_ids() {
	return array( 'hero', 'includes', 'content', 'projects', 'services', 'faq', 'related', 'quote' );
}

/**
 * Bir içerik tipi için kayıtlı bölüm iskeletini döndürür.
 *
 * Kayıtlı olmayan (yeni eklenen) bölümler sona eklenir; hiçbir bölüm kaybolmaz.
 *
 * @param string $cpt İçerik tipi slug'ı.
 * @return array array( 'order' => array, 'off' => array )
 */
function devxpe_cpt_sections( $cpt ) {
	$all = devxpe_theme_get( 'cpt_sections' );
	$row = ( is_array( $all ) && isset( $all[ $cpt ] ) && is_array( $all[ $cpt ] ) ) ? $all[ $cpt ] : array();

	$ids = devxpe_cpt_section_ids();

	return devxpe_parse_order_off( $row, $ids );
}

/**
 * Bir CPT bölümünün gösterilip gösterilmeyeceğini döndürür.
 *
 * @param string $cpt     İçerik tipi slug'ı.
 * @param string $section Bölüm id'si.
 * @return bool
 */
function devxpe_cpt_section_visible( $cpt, $section ) {
	$sections = devxpe_cpt_sections( $cpt );
	if ( in_array( $section, $sections['off'], true ) ) {
		return false;
	}

	/*
	 * İçerik bazlı geçersiz kılma: tekil içerik düzenleyicisindeki
	 * "Bölüm İskeleti" kutusundan gizlenen bölümler ön yüzde çizilmez.
	 *
	 * NOT: Bu meta anahtarı eski kurulumlar için korunuyor; yazan arayüz
	 * kaldırıldı ama kayıtlı veri hâlâ okunuyor.
	 */
	if ( is_singular() ) {
		$post_id = (int) get_queried_object_id();
		if ( $post_id ) {
			$off = get_post_meta( $post_id, '_dxp_sections_off', true );
			if ( is_array( $off ) && in_array( $section, $off, true ) ) {
				return false;
			}
		}
	}

	return true;
}

/**
 * Hakkımızda sayfasında sıralanabilen bölümler (varsayılan sıra).
 *
 * @return array
 */
function devxpe_about_section_ids() {
	return array( 'hero', 'content', 'stats' );
}

/**
 * Hakkımızda bölüm iskeletini (sıra + kapalılar) döndürür.
 *
 * Kayıtlı olmayan (yeni eklenen) bölümler sona eklenir.
 *
 * @return array array( 'order' => array, 'off' => array )
 */
function devxpe_about_sections() {
	$row = devxpe_theme_get( 'about_sections' );
	$row = is_array( $row ) ? $row : array();
	$ids = devxpe_about_section_ids();

	return devxpe_parse_order_off( $row, $ids );
}

/**
 * Hakkımızda bölümünün gösterilip gösterilmeyeceği.
 *
 * @param string $section Bölüm id'si.
 * @return bool
 */
function devxpe_about_section_visible( $section ) {
	$sections = devxpe_about_sections();
	return ! in_array( $section, $sections['off'], true );
}

/**
 * Anasayfada sıralanabilen bölümlerin sabit listesi (varsayılan sıra).
 *
 * @return array
 */
function devxpe_home_section_ids() {
	return array( 'hero', 'services', 'features', 'steps', 'projects', 'reviews', 'areas', 'faq', 'form' );
}

/**
 * Bölümlerin panelde/skeleton listesinde görünen adları.
 *
 * @return array
 */
function devxpe_home_section_labels() {
	$defaults = array(
		'hero'       => __( 'Manşet', 'devxpe-theme' ),
		'services'   => __( 'Hizmetler', 'devxpe-theme' ),
		'features'   => __( 'Neden Biz', 'devxpe-theme' ),
		'steps'      => __( 'Nasıl Çalışır', 'devxpe-theme' ),
		'projects'   => __( 'Projeler', 'devxpe-theme' ),
		'reviews'    => __( 'Yorumlar', 'devxpe-theme' ),
		'areas'      => __( 'Bölgeler', 'devxpe-theme' ),
		'faq'        => __( 'SSS', 'devxpe-theme' ),
		'form'       => __( 'Teklif Formu', 'devxpe-theme' ),
	);

	/* Panelden "Bölüm Adı" girildiyse onu kullan (müşteri kendi adını yazabilir). */
	$out = array();
	foreach ( $defaults as $id => $label ) {
		$custom      = trim( (string) devxpe_theme_get( 'home_label_' . $id ) );
		$out[ $id ] = ( '' !== $custom ) ? $custom : $label;
	}

	return $out;
}

/**
 * Panelde kaydedilen bölüm sırasını döndürür.
 *
 * Kayıtlı olmayan (yeni eklenen) bölümler listenin sonuna eklenir, böylece
 * hiçbir bölüm kaybolmaz.
 *
 * @return array
 */
function devxpe_home_sections_order() {
	$all   = devxpe_home_section_ids();
	$saved = devxpe_theme_get( 'home_sections_order' );

	if ( is_array( $saved ) ) {
		$saved = implode( ',', $saved );
	}

	$saved = devxpe_lines( $saved, ',' );
	$saved = array_values( array_intersect( $saved, $all ) );

	return array_merge( $saved, array_values( array_diff( $all, $saved ) ) );
}

/**
 * "Yan yana" işaretlenmiş bölümlerin id listesi.
 *
 * İşaretli bölüm, kendisinden sonra gelen ilk görünür bölümle aynı satırı
 * paylaşır (anasayfada 2 sütun).
 *
 * @return array
 */
function devxpe_home_section_splits() {
	$all   = devxpe_home_section_ids();
	$saved = devxpe_theme_get( 'home_sections_split' );

	if ( is_array( $saved ) ) {
		$saved = implode( ',', $saved );
	}

	$saved = devxpe_lines( $saved, ',' );

	return array_values( array_intersect( $saved, $all ) );
}

/**
 * Detay sayfası şablon (layout) kimlikleri.
 *
 * İçerikten bağımsız global isimler: hangi içerik tipi olursa olsun aynı iki
 * düzen kullanılır.
 *
 * @return array
 */
function devxpe_template_ids() {
	return array( 'layout_1', 'layout_2' );
}

/**
 * Şablonların görünen adları.
 *
 * @return array id => label
 */
function devxpe_template_labels() {
	return array(
		'layout_1' => __( 'Şablon 1 — İki sütun (yapışkan teklif formu)', 'devxpe-theme' ),
		'layout_2' => __( 'Şablon 2 — Tam genişlik bantlar', 'devxpe-theme' ),
	);
}

/**
 * Eski şablon anahtarlarını ('service'/'area') yeni global anahtarlara çevirir.
 *
 * @param string $tpl Şablon anahtarı.
 * @return string
 */
function devxpe_normalize_template( $tpl ) {
	$legacy = array( 'service' => 'layout_1', 'area' => 'layout_2' );
	$tpl    = isset( $legacy[ $tpl ] ) ? $legacy[ $tpl ] : $tpl;
	return in_array( $tpl, devxpe_template_ids(), true ) ? $tpl : 'layout_1';
}

/**
 * Şablon "tam genişlik bantlar" düzeni mi?
 *
 * @param string $tpl Şablon anahtarı.
 * @return bool
 */
function devxpe_template_is_banded( $tpl ) {
	return 'layout_2' === devxpe_normalize_template( $tpl );
}

/**
 * Kaynaktaki içerikleri kart verisine dönüştürür.
 *
 * Kaynak biçimi:
 *   - "manual"     → boş dizi döner (manuel listeye düşülür)
 *   - "category:5" → o terime ait yazılar (taxonomy:term_id)
 *   - "post"       → son yazılar
 *   - "page"       → sayfalar
 *
 * @param string $source Kaynak değeri.
 * @param int    $limit  En fazla kaç kart.
 * @return array array( array( 'image' =>, 'title' =>, 'text' =>, 'url' => ), ... )
 */
function devxpe_cards_from_source( $source, $limit = 6 ) {
	$limit = absint( $limit );
	if ( $limit < 1 ) {
		$limit = 6;
	}

	if ( ! $source || 'manual' === $source ) {
		return array();
	}

	$args = array(
		'numberposts' => $limit,
		'post_status' => 'publish',
	);

	if ( false !== strpos( $source, ':' ) ) {
		list( $prefix, $rest ) = explode( ':', $source, 2 );

		if ( 'cpt' === $prefix ) {
			/* Panelden tanımlı özel içerik tipi. */
			$args['post_type'] = $rest;
		} else {
			$args['post_type'] = 'any';
			$args['tax_query'] = array(
				array(
					'taxonomy' => $prefix,
					'field'    => 'term_id',
					'terms'    => absint( $rest ),
				),
			);
		}
	} elseif ( 'page' === $source ) {
		$args['post_type'] = 'page';
	} elseif ( 'post' === $source ) {
		$args['post_type'] = 'post';
	} else {
		return array();
	}

	$out = array();

	foreach ( get_posts( $args ) as $item ) {
		$out[] = array(
			'image' => (string) get_the_post_thumbnail_url( $item, 'large' ),
			'title' => get_the_title( $item ),
			'text'  => wp_strip_all_tags( get_the_excerpt( $item ) ),
			'url'   => get_permalink( $item ),
		);
	}

	return $out;
}

/**
 * Kaynaktan öge (etiket/kategori/sayfa/yazı) listesi üretir.
 *
 * Fallback altyapısı: panelde bir kaynak seçilir ve liste otomatik doldurulur.
 * Yeni yazı/sayfa/terim eklendiğinde kendiliğinden listeye girer.
 *
 * @param string $source category | post_tag | page | post.
 * @param int    $limit  En fazla kaç öge. 0 → sınırsız.
 * @return array array( array( 'title' => ..., 'url' => ... ), ... )
 */
function devxpe_items_list( $source, $limit = 10 ) {
	$limit = absint( $limit );
	if ( $limit < 1 ) {
		$limit = -1; /* 0 veya boş → sınırsız (panelde limit alanı olmayan listeler için) */
	}

	$out = array();

	/* Kategori arşivleri kapalıysa ölü link üretmemek için url boş bırakılır. */
	$link_off = ( 'category' === $source && 'normal' !== devxpe_theme_get( 'category_archive_action', 'normal' ) );

	switch ( $source ) {
		case 'category':
		case 'post_tag':
			$terms = get_terms(
				array(
					'taxonomy'   => $source,
					'hide_empty' => true,
					'number'     => $limit > 0 ? $limit : 0,
					'orderby'    => 'count',
					'order'      => 'DESC',
				)
			);

			if ( ! is_wp_error( $terms ) ) {
				foreach ( $terms as $term ) {
					$link = get_term_link( $term );
					if ( is_wp_error( $link ) ) {
						continue;
					}
					$out[] = array(
						'title' => $term->name,
						'url'   => $link_off ? '' : $link,
					);
				}
			}
			break;

		case 'page':
			foreach ( get_pages( array( 'number' => $limit > 0 ? $limit : 0, 'sort_column' => 'menu_order,post_title' ) ) as $page ) {				$out[] = array( 'title' => $page->post_title, 'url' => get_permalink( $page->ID ) );
			}
			break;

		case 'post':
			foreach ( get_posts( array( 'numberposts' => $limit > 0 ? $limit : -1, 'post_status' => 'publish' ) ) as $post ) {				$out[] = array( 'title' => get_the_title( $post ), 'url' => get_permalink( $post ) );
			}
			break;

		default:
			$parts  = array_pad( explode( ':', $source, 2 ), 2, '' );
			$prefix = $parts[0];
			$rest   = $parts[1];

			if ( 'cpt' === $prefix && '' !== $rest ) {
				/* Panelden tanımlı özel içerik tipi: cpt:<slug> */
				foreach ( get_posts( array( 'numberposts' => $limit > 0 ? $limit : -1, 'post_type' => $rest, 'post_status' => 'publish' ) ) as $item ) {
					$out[] = array( 'title' => get_the_title( $item ), 'url' => get_permalink( $item ) );
				}
			} elseif ( '' !== $prefix && '' !== $rest && taxonomy_exists( $prefix ) ) {
				/* Taksonomi terimi: <taxonomy>:<term_id> */
				$term_id  = absint( $rest );
				$link_off = ( 'category' === $prefix && 'normal' !== devxpe_theme_get( 'category_archive_action', 'normal' ) );

				if ( $term_id ) {
					$items = get_posts(
						array(
							'numberposts' => $limit > 0 ? $limit : -1,
							'post_status' => 'publish',
							'post_type'   => 'any',
							'tax_query'   => array(
								array(
									'taxonomy' => $prefix,
									'field'    => 'term_id',
									'terms'    => $term_id,
								),
							),
						)
					);

					foreach ( $items as $item ) {
						$out[] = array(
							'title' => get_the_title( $item ),
							'url'   => $link_off ? '' : get_permalink( $item ),
						);
					}
				}
			}
			break;
	}

	return $out;
}


/*
 * NOT: "Sayfa Manşeti" metabox'ı KALDIRILDI.
 *
 * Manşet artık sayfa düzenleyicideki "Sayfa Şablonu ve İçeriği" kutusundaki
 * WIDGET sisteminden eklenir (widget tipi: 'manset' → DEVXPE_Page_Widgets).
 * Eski _dxp_hero_title / _dxp_hero_subtitle değerleri veritabanında kalır ve
 * şablonlar (page-about.php / page-contact.php) onları okumaya devam eder;
 * yeni sayfalarda başlık yoksa sayfa adına düşer.
 */

/* ══════════════════════════════════════════════════════════
   Google reCAPTCHA v3
   ══════════════════════════════════════════════════════════ */

/**
 * Öge listesi girdisini link olarak döndürür; link yoksa düz metin olarak.
 *
 * @param array  $item  title/url anahtarları.
 * @param string $class CSS sınıfı.
 * @return string
 */
function devxpe_item_link( $item, $class = 'dxp-tag' ) {
	$title = isset( $item['title'] ) ? $item['title'] : '';
	$attr  = $class ? ' class="' . esc_attr( $class ) . '"' : '';

	if ( empty( $item['url'] ) ) {
		return '<span' . $attr . '>' . esc_html( $title ) . '</span>';
	}

	return '<a' . $attr . ' href="' . esc_url( $item['url'] ) . '">' . esc_html( $title ) . '</a>';
}

/**
 * "Neler dahil" bölümünün görünür adını döndürür.
 *
 * Panelde global bir ad tanımlanmışsa onu, aksi hâlde çevrilmiş
 * varsayılanı ("Neler dahil") kullanır. İçerikteki meta alanı yine
 * üzerine yazabilir.
 *
 * @return string
 */
function devxpe_includes_heading() {
	$global = trim( (string) devxpe_theme_get( 'includes_heading' ) );

	return '' !== $global ? $global : __( 'Neler dahil', 'devxpe-theme' );
}

/**
 * Arşivi kapatır: anasayfaya yönlendirir ya da 404 verir.
 *
 * @param string $action 'home' | '404'.
 * @return void
 */
function devxpe_archive_close( $action ) {
	if ( 'home' === $action ) {
		/* 302: ayar geri alındığında tarayıcıda kalıcı 301 önbelleği kalmaz. */
		wp_safe_redirect( home_url( '/' ), 302 );
		exit;
	}

	global $wp_query;
	$wp_query->set_404();
	status_header( 404 );
	nocache_headers();
}

/**
 * WordPress kategori arşivlerini kapatır (panel ayarına göre).
 *
 * Kategoriler yalnızca bölümlerde kaynak olarak kullanılıyorsa arşiv
 * sayfaları gereksizdir: anasayfaya yönlendirilir ya da 404 verilir.
 *
 * @return void
 */
function devxpe_category_archive_guard() {
	if ( is_admin() || ! is_category() ) {
		return;
	}

	$action = devxpe_theme_get( 'category_archive_action', 'normal' );

	if ( 'normal' !== $action ) {
		devxpe_archive_close( $action );
	}
}
add_action( 'template_redirect', 'devxpe_category_archive_guard' );

/**
 * Devxpe panelinde tanımlı içerik tiplerinin arşiv sayfalarını kapatır.
 *
 * WordPress kategorilerinden bağımsızdır; yalnızca panelde tanımlı
 * içerik tiplerinin (services, areas…) arşivleri için geçerlidir.
 *
 * @return void
 */
function devxpe_cpt_archive_guard() {
	if ( is_admin() || ! is_post_type_archive() ) {
		return;
	}

	$object = get_queried_object();
	if ( ! $object || ! in_array( $object->name, wp_list_pluck( devxpe_custom_post_types(), 'slug' ), true ) ) {
		return;
	}

	$action = devxpe_theme_get( 'cpt_archive_action', 'normal' );

	if ( 'normal' !== $action ) {
		devxpe_archive_close( $action );
	}
}
add_action( 'template_redirect', 'devxpe_cpt_archive_guard' );

/**
 * Sayfanın "Hakkımızda" / "İletişim" şablonuyla render edilmesini sağlar.
 *
 * Şablon seçimi sayfa düzenleyicisindeki metabox'tan yapılır
 * (`_dxp_page_type` = about | contact). WordPress şablon listesinde
 * görünmesin diye bu şablonların "Template Name" başlığı kaldırılmıştır.
 * Eski kurulumlar için panel seçicileri (about_page_pick/contact_page_pick)
 * yedek olarak korunur.
 *
 * @param string $template Mevcut şablon yolu.
 * @return string
 */
function devxpe_page_pick_template( $template ) {
	global $wp_query;
	if ( empty( $wp_query->is_page ) || empty( $wp_query->get_queried_object_id() ) ) {
		return $template;
	}

	$dxp_page_id = (int) $wp_query->get_queried_object_id();
	$tpl         = '';

	/* 1) Metabox seçimi (asıl yol). */
	if ( 'page' === get_post_type( $dxp_page_id ) ) {
		$dxp_type = (string) get_post_meta( $dxp_page_id, '_dxp_page_type', true );
		if ( 'about' === $dxp_type ) {
			$tpl = 'page-about.php';
		} elseif ( 'contact' === $dxp_type ) {
			$tpl = 'page-contact.php';
		}
	}

	/* 2) Eski panel seçicileri (geriye dönük uyumluluk). */
	if ( '' === $tpl ) {
		$picked = (int) devxpe_theme_get( 'about_page_pick' );
		$tpl    = 'page-about.php';
		if ( ! $picked ) {
			$picked = (int) devxpe_theme_get( 'contact_page_pick' );
			$tpl    = 'page-contact.php';
		}
		if ( ! $picked || $picked !== $dxp_page_id ) {
			return $template;
		}
	}

	$located = locate_template( $tpl );

	return $located ? $located : $template;
}
add_filter( 'template_include', 'devxpe_page_pick_template', 99 );

