<?php
/**
 * Anasayfa/CPT/hakkımızda bölümleri, şablonlar ve arşiv kuralları.
 *
 * functions.php'den ayrıldı.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Tema option dizisinde bir anahtar kayıtlı mı? (Varsayılan değil, gerçek kayıt.)
 *
 * Taze kurulumda hiçbir şey kayıtlı değildir; bölümlerin "ayar yapılmadıysa
 * çizme" kararı buna dayanır. Mevcut kayıtlı değerler etkilenmez.
 *
 * @param string $key Alan id'si.
 * @return bool
 */
function devxpe_option_stored( $key ) {
	$opts = get_option( 'devxpe_theme_options', array() );
	return is_array( $opts ) && array_key_exists( $key, $opts );
}

/**
 * Kayıtlı bir checkbox alanı açık ('1') mı? Kayıt yoksa false.
 *
 * @param string $key Alan id'si.
 * @return bool
 */
function devxpe_option_stored_on( $key ) {
	return devxpe_option_stored( $key ) && ( '1' === devxpe_theme_get( $key ) );
}

/**
 * Bir anasayfa bölümü açık mı? (Sadece "Bölüm Aktif" anahtarı.)
 *
 * @param string $id Bölüm id'si.
 * @return bool
 */
function devxpe_section_enabled( $id ) {
	return ( '1' === devxpe_theme_get( $id . '_enable', '1' ) );
}

/**
 * Bölümün mevcut istekte çizilip çizilmeyeceğini döndürür.
 *
 * Otomatik akışta bölümler yalnızca anasayfada çizilir; başka sayfalarda
 * yerleştirmek için [devxpe_section id="..."] kısa kodu kullanılır.
 *
 * @param string $id Bölüm id'si.
 * @return bool
 */
function devxpe_section_visible( $id ) {
	if ( ! devxpe_section_enabled( $id ) ) {
		return false;
	}

	/* Kısa kod bağlamı: yalnızca istenen bölüm çizilir (sayfa şartı yok). */
	if ( ! empty( $GLOBALS['dxp_render_section'] ) ) {
		return ( $GLOBALS['dxp_render_section'] === $id );
	}

	return is_front_page();
}

/**
 * Tek bir anasayfa bölümünü kısa kodla çizer: [devxpe_section id="services"]
 *
 * @param array $atts Kısa kod öznitelikleri.
 * @return string
 */
function devxpe_section_shortcode( $atts = array() ) {
	$atts = shortcode_atts( array( 'id' => '' ), $atts, 'devxpe_section' );
	$id   = sanitize_key( $atts['id'] );

	if ( '' === $id || ! in_array( $id, devxpe_home_section_ids(), true ) ) {
		return '';
	}

	$GLOBALS['dxp_render_section'] = $id;
	ob_start();
	get_template_part( 'template-parts/home-sections' );
	$html = ob_get_clean();
	unset( $GLOBALS['dxp_render_section'] );

	return $html;
}
add_shortcode( 'devxpe_section', 'devxpe_section_shortcode' );

/**
 * CPT detay sayfasında kullanılabilen bölümler (varsayılan sıra).
 *
 * @return array
 */
function devxpe_cpt_section_ids() {
	return array( 'hero', 'includes', 'content', 'projects', 'services', 'faq', 'related', 'quote' );
}

/**
 * Bir içerik tipi için kayıtlı bölüm iskeletini döndürür.
 *
 * Kayıtlı olmayan (yeni eklenen) bölümler sona eklenir; hiçbir bölüm kaybolmaz.
 *
 * @param string $cpt İçerik tipi slug'ı.
 * @return array array( 'order' => array, 'off' => array )
 */
function devxpe_cpt_sections( $cpt ) {
	$all = devxpe_theme_get( 'cpt_sections' );
	$row = ( is_array( $all ) && isset( $all[ $cpt ] ) && is_array( $all[ $cpt ] ) ) ? $all[ $cpt ] : array();

	$ids = devxpe_cpt_section_ids();

	return devxpe_parse_order_off( $row, $ids );
}

/**
 * Bir CPT bölümünün gösterilip gösterilmeyeceğini döndürür.
 *
 * @param string $cpt     İçerik tipi slug'ı.
 * @param string $section Bölüm id'si.
 * @return bool
 */
function devxpe_cpt_section_visible( $cpt, $section ) {
	$sections = devxpe_cpt_sections( $cpt );
	if ( in_array( $section, $sections['off'], true ) ) {
		return false;
	}

	/*
	 * İçerik bazlı geçersiz kılma: tekil içerik düzenleyicisindeki
	 * "Bölüm İskeleti" kutusundan gizlenen bölümler ön yüzde çizilmez.
	 *
	 * NOT: Bu meta anahtarı eski kurulumlar için korunuyor; yazan arayüz
	 * kaldırıldı ama kayıtlı veri hâlâ okunuyor.
	 */
	if ( is_singular() ) {
		$post_id = (int) get_queried_object_id();
		if ( $post_id ) {
			$off = get_post_meta( $post_id, '_dxp_sections_off', true );
			if ( is_array( $off ) && in_array( $section, $off, true ) ) {
				return false;
			}
		}
	}

	return true;
}

/**
 * Hakkımızda sayfasında sıralanabilen bölümler (varsayılan sıra).
 *
 * @return array
 */
function devxpe_about_section_ids() {
	return array( 'hero', 'content', 'stats' );
}

/**
 * Hakkımızda bölüm iskeletini (sıra + kapalılar) döndürür.
 *
 * Kayıtlı olmayan (yeni eklenen) bölümler sona eklenir.
 *
 * @return array array( 'order' => array, 'off' => array )
 */
function devxpe_about_sections() {
	$row = devxpe_theme_get( 'about_sections' );
	$row = is_array( $row ) ? $row : array();
	$ids = devxpe_about_section_ids();

	return devxpe_parse_order_off( $row, $ids );
}

/**
 * Hakkımızda bölümünün gösterilip gösterilmeyeceği.
 *
 * @param string $section Bölüm id'si.
 * @return bool
 */
function devxpe_about_section_visible( $section ) {
	$sections = devxpe_about_sections();
	return ! in_array( $section, $sections['off'], true );
}

/**
 * Anasayfada sıralanabilen bölümlerin sabit listesi (varsayılan sıra).
 *
 * @return array
 */
function devxpe_home_section_ids() {
	return array( 'hero', 'services', 'features', 'steps', 'projects', 'reviews', 'areas', 'faq', 'form' );
}

/**
 * Bölümlerin panelde/skeleton listesinde görünen adları.
 *
 * @return array
 */
function devxpe_home_section_labels() {
	$defaults = array(
		'hero'       => __( 'Manşet', 'devxpe-theme' ),
		'services'   => __( 'Hizmetler', 'devxpe-theme' ),
		'features'   => __( 'Neden Biz', 'devxpe-theme' ),
		'steps'      => __( 'Nasıl Çalışır', 'devxpe-theme' ),
		'projects'   => __( 'Projeler', 'devxpe-theme' ),
		'reviews'    => __( 'Yorumlar', 'devxpe-theme' ),
		'areas'      => __( 'Bölgeler', 'devxpe-theme' ),
		'faq'        => __( 'SSS', 'devxpe-theme' ),
		'form'       => __( 'Teklif Formu', 'devxpe-theme' ),
	);

	/* Panelden "Bölüm Adı" girildiyse onu kullan (müşteri kendi adını yazabilir). */
	$out = array();
	foreach ( $defaults as $id => $label ) {
		$custom      = trim( (string) devxpe_theme_get( 'home_label_' . $id ) );
		$out[ $id ] = ( '' !== $custom ) ? $custom : $label;
	}

	return $out;
}

/**
 * Panelde kaydedilen bölüm sırasını döndürür.
 *
 * Kayıtlı olmayan (yeni eklenen) bölümler listenin sonuna eklenir, böylece
 * hiçbir bölüm kaybolmaz.
 *
 * @return array
 */
function devxpe_home_sections_order() {
	$all   = devxpe_home_section_ids();
	$saved = devxpe_theme_get( 'home_sections_order' );

	if ( is_array( $saved ) ) {
		$saved = implode( ',', $saved );
	}

	$saved = devxpe_lines( $saved, ',' );
	$saved = array_values( array_intersect( $saved, $all ) );

	return array_merge( $saved, array_values( array_diff( $all, $saved ) ) );
}

/**
 * "Yan yana" işaretlenmiş bölümlerin id listesi.
 *
 * İşaretli bölüm, kendisinden sonra gelen ilk görünür bölümle aynı satırı
 * paylaşır (anasayfada 2 sütun).
 *
 * @return array
 */
function devxpe_home_section_splits() {
	$all   = devxpe_home_section_ids();
	$saved = devxpe_theme_get( 'home_sections_split' );

	if ( is_array( $saved ) ) {
		$saved = implode( ',', $saved );
	}

	$saved = devxpe_lines( $saved, ',' );

	return array_values( array_intersect( $saved, $all ) );
}

/**
 * Detay sayfası şablon (layout) kimlikleri.
 *
 * İçerikten bağımsız global isimler: hangi içerik tipi olursa olsun aynı iki
 * düzen kullanılır.
 *
 * @return array
 */
function devxpe_template_ids() {
	return array( 'layout_1', 'layout_2' );
}

/**
 * Şablonların görünen adları.
 *
 * @return array id => label
 */
function devxpe_template_labels() {
	return array(
		'layout_1' => __( 'Şablon 1 — İki sütun', 'devxpe-theme' ),
		'layout_2' => __( 'Şablon 2 — Tam genişlik bantlar', 'devxpe-theme' ),
	);
}

/**
 * Eski şablon anahtarlarını ('service'/'area') yeni global anahtarlara çevirir.
 *
 * @param string $tpl Şablon anahtarı.
 * @return string
 */
function devxpe_normalize_template( $tpl ) {
	$legacy = array( 'service' => 'layout_1', 'area' => 'layout_2' );
	$tpl    = isset( $legacy[ $tpl ] ) ? $legacy[ $tpl ] : $tpl;
	return in_array( $tpl, devxpe_template_ids(), true ) ? $tpl : 'layout_1';
}

/**
 * Şablon "tam genişlik bantlar" düzeni mi?
 *
 * @param string $tpl Şablon anahtarı.
 * @return bool
 */
function devxpe_template_is_banded( $tpl ) {
	return 'layout_2' === devxpe_normalize_template( $tpl );
}

/**
 * Kaynaktaki içerikleri kart verisine dönüştürür.
 *
 * Kaynak biçimi:
 *   - "manual"     → boş dizi döner (manuel listeye düşülür)
 *   - "category:5" → o terime ait yazılar (taxonomy:term_id)
 *   - "post"       → son yazılar
 *   - "page"       → sayfalar
 *
 * @param string $source Kaynak değeri.
 * @param int    $limit  En fazla kaç kart.
 * @return array array( array( 'image' =>, 'title' =>, 'text' =>, 'url' => ), ... )
 */
function devxpe_cards_from_source( $source, $limit = 6 ) {
	$limit = absint( $limit );
	if ( $limit < 1 ) {
		$limit = 6;
	}

	if ( ! $source || 'manual' === $source ) {
		return array();
	}

	$args = array(
		'numberposts' => $limit,
		'post_status' => 'publish',
	);

	if ( false !== strpos( $source, ':' ) ) {
		list( $prefix, $rest ) = explode( ':', $source, 2 );

		if ( 'cpt' === $prefix ) {
			/* Panelden tanımlı özel içerik tipi. */
			$args['post_type'] = $rest;
		} else {
			$args['post_type'] = 'any';
			$args['tax_query'] = array(
				array(
					'taxonomy' => $prefix,
					'field'    => 'term_id',
					'terms'    => absint( $rest ),
				),
			);
		}
	} elseif ( 'page' === $source ) {
		$args['post_type'] = 'page';
	} elseif ( 'post' === $source ) {
		$args['post_type'] = 'post';
	} else {
		return array();
	}

	$out = array();

	foreach ( get_posts( $args ) as $item ) {
		$out[] = array(
			'image' => (string) get_the_post_thumbnail_url( $item, 'large' ),
			'title' => get_the_title( $item ),
			'text'  => wp_strip_all_tags( get_the_excerpt( $item ) ),
			'url'   => get_permalink( $item ),
		);
	}

	return $out;
}

/**
 * Kaynaktan öge (etiket/kategori/sayfa/yazı) listesi üretir.
 *
 * Fallback altyapısı: panelde bir kaynak seçilir ve liste otomatik doldurulur.
 * Yeni yazı/sayfa/terim eklendiğinde kendiliğinden listeye girer.
 *
 * @param string $source category | post_tag | page | post.
 * @param int    $limit  En fazla kaç öge. 0 → sınırsız.
 * @return array array( array( 'title' => ..., 'url' => ... ), ... )
 */
function devxpe_items_list( $source, $limit = 10 ) {
	$limit = absint( $limit );
	if ( $limit < 1 ) {
		$limit = -1; /* 0 veya boş → sınırsız (panelde limit alanı olmayan listeler için) */
	}

	$out = array();

	/* Kategori arşivleri kapalıysa ölü link üretmemek için url boş bırakılır. */
	$link_off = ( 'category' === $source && 'normal' !== devxpe_theme_get( 'category_archive_action', 'normal' ) );

	switch ( $source ) {
		case 'category':
		case 'post_tag':
			$terms = get_terms(
				array(
					'taxonomy'   => $source,
					'hide_empty' => true,
					'number'     => $limit > 0 ? $limit : 0,
					'orderby'    => 'count',
					'order'      => 'DESC',
				)
			);

			if ( ! is_wp_error( $terms ) ) {
				foreach ( $terms as $term ) {
					$link = get_term_link( $term );
					if ( is_wp_error( $link ) ) {
						continue;
					}
					$out[] = array(
						'id'    => $source . '|' . $term->term_id,
						'title' => $term->name,
						'url'   => $link_off ? '' : $link,
					);
				}
			}
			break;

		case 'page':
			foreach ( get_pages( array( 'number' => $limit > 0 ? $limit : 0, 'sort_column' => 'menu_order,post_title' ) ) as $page ) {
				$out[] = array( 'id' => 'page|' . $page->ID, 'title' => $page->post_title, 'url' => get_permalink( $page->ID ) );
			}
			break;

		case 'post':
			foreach ( get_posts( array( 'numberposts' => $limit > 0 ? $limit : -1, 'post_status' => 'publish' ) ) as $post ) {
				$out[] = array( 'id' => 'post|' . $post->ID, 'title' => get_the_title( $post ), 'url' => get_permalink( $post ) );
			}
			break;

		default:
			$parts  = array_pad( explode( ':', $source, 2 ), 2, '' );
			$prefix = $parts[0];
			$rest   = $parts[1];

			if ( 'cpt' === $prefix && '' !== $rest ) {
				/* Panelden tanımlı özel içerik tipi: cpt:<slug> */
				foreach ( get_posts( array( 'numberposts' => $limit > 0 ? $limit : -1, 'post_type' => $rest, 'post_status' => 'publish' ) ) as $item ) {
					$out[] = array( 'id' => 'cpt:' . $rest . '|' . $item->ID, 'title' => get_the_title( $item ), 'url' => get_permalink( $item ) );
				}
			} elseif ( 'menu' === $prefix && '' !== $rest ) {
				/* WordPress menüsü: menu:<menu_id> */
				$items = wp_get_nav_menu_items( absint( $rest ) );
				if ( is_array( $items ) ) {
					if ( $limit > 0 ) {
						$items = array_slice( $items, 0, $limit );
					}

					$by_id = array();
					foreach ( $items as $item ) {
						$by_id[ (int) $item->ID ] = $item;
					}

					foreach ( $items as $item ) {
						/* Alt öğeler panelde girintili görünür. */
						$derinlik = 0;
						$ust      = (int) $item->menu_item_parent;
						while ( $ust && isset( $by_id[ $ust ] ) && $derinlik < 10 ) {
							$derinlik++;
							$ust = (int) $by_id[ $ust ]->menu_item_parent;
						}

						$out[] = array(
							'id'    => 'menu:' . absint( $rest ) . '|' . $item->ID,
							'title' => str_repeat( '— ', $derinlik ) . $item->title,
							'url'   => $item->url,
						);
					}
				}
			} elseif ( '' !== $prefix && '' !== $rest && taxonomy_exists( $prefix ) ) {
				/* Taksonomi terimi: <taxonomy>:<term_id> */
				$term_id  = absint( $rest );
				$link_off = ( 'category' === $prefix && 'normal' !== devxpe_theme_get( 'category_archive_action', 'normal' ) );

				if ( $term_id ) {
					$items = get_posts(
						array(
							'numberposts' => $limit > 0 ? $limit : -1,
							'post_status' => 'publish',
							'post_type'   => 'any',
							'tax_query'   => array(
								array(
									'taxonomy' => $prefix,
									'field'    => 'term_id',
									'terms'    => $term_id,
								),
							),
						)
					);

					foreach ( $items as $item ) {
						$out[] = array(
							'id'    => $prefix . '|' . $item->ID,
							'title' => get_the_title( $item ),
							'url'   => $link_off ? '' : get_permalink( $item ),
						);
					}
				}
			}
			break;
	}

	return $out;
}

/**
 * Panel için WordPress menüsü seçenekleri: `menu:<id>` => "Ad (konum)".
 *
 * Menü bir konuma atanmışsa (primary, footer …) etikette parantez içinde
 * gösterilir; kullanıcı hangi menünün nerede kullanıldığını görür.
 *
 * @return array
 */
function devxpe_menu_options() {
	$out       = array();
	$locations = get_nav_menu_locations();
	$konumlar  = array();

	foreach ( $locations as $konum => $menu_id ) {
		if ( $menu_id ) {
			$konumlar[ (int) $menu_id ][] = $konum;
		}
	}

	foreach ( wp_get_nav_menus() as $menu ) {
		$etiket = $menu->name;
		if ( ! empty( $konumlar[ (int) $menu->term_id ] ) ) {
			$etiket .= ' (' . implode( ', ', $konumlar[ (int) $menu->term_id ] ) . ')';
		}
		$out[ 'menu:' . $menu->term_id ] = $etiket;
	}

	return $out;
}

/**
 * `auto` kaynağını primary konumundaki menüye çevirir.
 *
 * Eski kayıtlarda `header_menu_source` = `auto` olabilir; panelde menü adı
 * görünsün diye gerçek menüye çözülür.
 *
 * @param string $source Kaynak değeri.
 * @return string
 */
function devxpe_resolve_menu_source( $source ) {
	$source = (string) $source;

	if ( 'auto' !== $source && '' !== $source ) {
		return $source;
	}

	$locations = get_nav_menu_locations();
	if ( ! empty( $locations['primary'] ) ) {
		return 'menu:' . (int) $locations['primary'];
	}

	return 'none';
}

/**
 * Kaynak değerinin panelde görünen etiketi.
 *
 * @param string $source Kaynak değeri.
 * @return string
 */
function devxpe_source_label( $source ) {
	$source = (string) $source;

	if ( 0 === strpos( $source, 'menu:' ) ) {
		$menus = devxpe_menu_options();
		return isset( $menus[ $source ] ) ? $menus[ $source ] : $source;
	}

	$etiketler = array(
		'page'     => __( 'Sayfalar', 'devxpe-theme' ),
		'post'     => __( 'Son yazılar', 'devxpe-theme' ),
		'category' => __( 'Kategoriler', 'devxpe-theme' ),
		'post_tag' => __( 'Etiketler', 'devxpe-theme' ),
		'none'     => __( 'Gizle', 'devxpe-theme' ),
	);

	if ( isset( $etiketler[ $source ] ) ) {
		return $etiketler[ $source ];
	}

	return $source;
}

/**
 * Kaynak listesini panelde yapılan seçime göre süzer.
 *
 * `$selected` null ise seçim hiç yapılmamıştır: tüm liste (limit varsa
 * limitlenmiş) döner. Dizi ise yalnız seçilenler, panelde verilen sırayla
 * döner; limit uygulanmaz.
 *
 * @param string     $source   Kaynak (page, menu:5, cpt:services …).
 * @param int|string $limit    Seçim yokken en fazla öge.
 * @param array|null $selected Seçili öge kimlikleri.
 * @return array
 */
function devxpe_items_list_selected( $source, $limit, $selected ) {
	$all = devxpe_items_list( $source, 0 );

	if ( ! is_array( $selected ) ) {
		$limit = absint( $limit );
		return ( $limit > 0 ) ? array_slice( $all, 0, $limit ) : $all;
	}

	$harita = array();
	foreach ( $all as $item ) {
		if ( isset( $item['id'] ) ) {
			$harita[ (string) $item['id'] ] = $item;
		}
	}

	$out = array();
	foreach ( $selected as $id ) {
		$id = (string) $id;
		if ( isset( $harita[ $id ] ) ) {
			$out[] = $harita[ $id ];
			unset( $harita[ $id ] );
		}
	}

	return $out;
}

/**
 * Header menüsünü seçilen kaynağa göre çizer.
 *
 * @param string     $source   auto | menu:<id> | page | none.
 * @param array|null $selected Görünecek öge kimlikleri (null → hepsi).
 * @param string     $class    UL sınıfı (dxp-nav-list | dxp-mobile-list).
 * @return void
 */
function devxpe_render_header_nav( $source, $selected, $class ) {
	if ( 'none' === $source ) {
		return;
	}

	if ( 0 === strpos( $source, 'menu:' ) ) {
		$menu_id = absint( substr( $source, 5 ) );
		if ( $menu_id ) {
			wp_nav_menu(
				array(
					'menu'        => $menu_id,
					'container'   => false,
					'menu_class'  => $class,
					'depth'       => 2,
					'fallback_cb' => false,
				)
			);
		}
		return;
	}

	if ( 'page' === $source ) {
		$sayfalar = get_pages( array( 'sort_column' => 'menu_order,post_title' ) );
		$secili   = array();

		foreach ( $sayfalar as $sayfa ) {
			$secili[ (int) $sayfa->ID ] = $sayfa;
		}

		$liste = array();
		if ( is_array( $selected ) ) {
			foreach ( $selected as $id ) {
				$parca = explode( '|', (string) $id, 2 );
				if ( 'page' === $parca[0] && isset( $secili[ (int) $parca[1] ] ) ) {
					$pid           = (int) $parca[1];
					$liste[ $pid ] = $secili[ $pid ];
				}
			}
		} else {
			$liste = $secili;
		}

		if ( ! $liste ) {
			return;
		}

		$ust = array();
		$alt = array();
		foreach ( $liste as $pid => $sayfa ) {
			$parent = (int) $sayfa->post_parent;
			if ( $parent && isset( $liste[ $parent ] ) ) {
				$alt[ $parent ][] = $sayfa;
			} else {
				$ust[] = $sayfa;
			}
		}

		echo '<ul class="' . esc_attr( $class ) . '">';
		foreach ( $ust as $sayfa ) {
			$cocuklar = isset( $alt[ $sayfa->ID ] ) ? $alt[ $sayfa->ID ] : array();
			$aktif    = is_page( $sayfa->ID ) ? ' current_page_item' : '';
			echo '<li class="menu-item' . ( $cocuklar ? ' menu-item-has-children' : '' ) . esc_attr( $aktif ) . '">';
			echo '<a href="' . esc_url( get_permalink( $sayfa->ID ) ) . '"' . ( $aktif ? ' aria-current="page"' : '' ) . '>' . esc_html( get_the_title( $sayfa ) ) . '</a>';

			if ( $cocuklar ) {
				echo '<ul class="sub-menu">';
				foreach ( $cocuklar as $cocuk ) {
					$caktif = is_page( $cocuk->ID ) ? ' current_page_item' : '';
					echo '<li class="menu-item' . esc_attr( $caktif ) . '"><a href="' . esc_url( get_permalink( $cocuk->ID ) ) . '"' . ( $caktif ? ' aria-current="page"' : '' ) . '>' . esc_html( get_the_title( $cocuk ) ) . '</a></li>';
				}
				echo '</ul>';
			}

			echo '</li>';
		}
		echo '</ul>';
		return;
	}

	/* auto: WordPress "primary" menü konumu (eski davranış). */
	if ( has_nav_menu( 'primary' ) ) {
		wp_nav_menu(
			array(
				'theme_location' => 'primary',
				'container'      => false,
				'menu_class'     => $class,
				'depth'          => 2,
				'fallback_cb'    => false,
			)
		);
	}
}

/**
 * Header menüsünde panelde işaretlenmeyen ögeleri çıkarır.
 *
 * Yalnız `menu:<id>` kaynağında ve yalnız o menüye uygulanır; footer ve
 * diğer menü çağrıları etkilenmez.
 *
 * @param array    $items Menü ögeleri.
 * @param stdClass $args  wp_nav_menu argümanları.
 * @return array
 */
function devxpe_filter_header_menu_items( $items, $args ) {
	$source = (string) devxpe_theme_get( 'header_menu_source', 'auto' );

	if ( 0 !== strpos( $source, 'menu:' ) ) {
		return $items;
	}

	$menu_id  = absint( substr( $source, 5 ) );
	$arg_menu = ( isset( $args->menu ) && is_object( $args->menu ) ) ? (int) $args->menu->term_id : (int) ( isset( $args->menu ) ? $args->menu : 0 );

	if ( ! $menu_id || $arg_menu !== $menu_id ) {
		return $items;
	}

	$selected = devxpe_theme_get( 'header_menu_items', null );
	if ( ! is_array( $selected ) ) {
		return $items;
	}

	$secili = array();
	foreach ( $selected as $id ) {
		$parca = explode( '|', (string) $id, 2 );
		if ( 'menu:' . $menu_id === $parca[0] ) {
			$secili[ (int) $parca[1] ] = true;
		}
	}

	$out = array();
	foreach ( (array) $items as $item ) {
		if ( ! isset( $secili[ (int) $item->ID ] ) ) {
			continue;
		}

		/* Üst öge gizliyse alt öge de gizlenir. */
		$parent = (int) $item->menu_item_parent;
		if ( $parent && ! isset( $secili[ $parent ] ) ) {
			continue;
		}

		$out[] = $item;
	}

	return $out;
}
add_filter( 'wp_nav_menu_objects', 'devxpe_filter_header_menu_items', 10, 2 );

/**
 * Paneldeki "Yeni sayfaları otomatik ekle" seçimlerini WordPress menü
 * ayarına (`nav_menu_options.auto_add`) yansıtır.
 *
 * @return void
 */
function devxpe_sync_menu_auto_add() {
	$opts = get_option( DEVXPE_Theme_Fields::OPTION_KEY, array() );
	if ( ! is_array( $opts ) ) {
		return;
	}

	$nav = get_option( 'nav_menu_options', array() );
	if ( ! is_array( $nav ) ) {
		$nav = array();
	}

	$auto = isset( $nav['auto_add'] ) ? array_map( 'intval', (array) $nav['auto_add'] ) : array();

	$harita = array(
		'header_menu_source'    => 'header_menu_auto_add',
		'footer_col2_source'    => 'footer_col2_auto_add',
		'footer_col3_source'    => 'footer_col3_auto_add',
		'footer_legal_source'   => 'footer_legal_auto_add',
	);

	foreach ( $harita as $kaynak => $anahtar ) {
		$source = isset( $opts[ $kaynak ] ) ? devxpe_resolve_menu_source( $opts[ $kaynak ] ) : '';
		if ( 0 !== strpos( (string) $source, 'menu:' ) ) {
			continue;
		}

		$menu_id = absint( substr( $source, 5 ) );
		if ( ! $menu_id ) {
			continue;
		}

		$acik = ! empty( $opts[ $anahtar ] );
		$idx  = array_search( $menu_id, $auto, true );

		if ( $acik && false === $idx ) {
			$auto[] = $menu_id;
		} elseif ( ! $acik && false !== $idx ) {
			unset( $auto[ $idx ] );
		}
	}

	$nav['auto_add'] = array_values( array_unique( $auto ) );
	update_option( 'nav_menu_options', $nav );
}
add_action( 'update_option_' . DEVXPE_Theme_Fields::OPTION_KEY, 'devxpe_sync_menu_auto_add', 20 );


/*
 * NOT: "Sayfa Manşeti" metabox'ı KALDIRILDI.
 *
 * Manşet artık sayfa düzenleyicideki "Sayfa Şablonu ve İçeriği" kutusundaki
 * WIDGET sisteminden eklenir (widget tipi: 'manset' → DEVXPE_Page_Widgets).
 * Eski _dxp_hero_title / _dxp_hero_subtitle değerleri veritabanında kalır ve
 * şablonlar (page-about.php / page-contact.php) onları okumaya devam eder;
 * yeni sayfalarda başlık yoksa sayfa adına düşer.
 */

/* ══════════════════════════════════════════════════════════
   Google reCAPTCHA v3
   ══════════════════════════════════════════════════════════ */

/**
 * Öge listesi girdisini link olarak döndürür; link yoksa düz metin olarak.
 *
 * @param array  $item  title/url anahtarları.
 * @param string $class CSS sınıfı.
 * @return string
 */
function devxpe_item_link( $item, $class = 'dxp-tag' ) {
	$title = isset( $item['title'] ) ? $item['title'] : '';
	$attr  = $class ? ' class="' . esc_attr( $class ) . '"' : '';

	if ( empty( $item['url'] ) ) {
		return '<span' . $attr . '>' . esc_html( $title ) . '</span>';
	}

	return '<a' . $attr . ' href="' . esc_url( $item['url'] ) . '">' . esc_html( $title ) . '</a>';
}

/**
 * "Neler dahil" bölümünün görünür adını döndürür.
 *
 * Panelde global bir ad tanımlanmışsa onu, aksi hâlde çevrilmiş
 * varsayılanı ("Neler dahil") kullanır. İçerikteki meta alanı yine
 * üzerine yazabilir.
 *
 * @return string
 */
function devxpe_includes_heading() {
	$global = trim( (string) devxpe_theme_get( 'includes_heading' ) );

	return '' !== $global ? $global : __( 'Neler dahil', 'devxpe-theme' );
}

/**
 * Arşivi kapatır: anasayfaya yönlendirir ya da 404 verir.
 *
 * @param string $action 'home' | '404'.
 * @return void
 */
function devxpe_archive_close( $action ) {
	if ( 'home' === $action ) {
		/* 302: ayar geri alındığında tarayıcıda kalıcı 301 önbelleği kalmaz. */
		wp_safe_redirect( home_url( '/' ), 302 );
		exit;
	}

	global $wp_query;
	$wp_query->set_404();
	status_header( 404 );
	nocache_headers();
}

/**
 * WordPress kategori arşivlerini kapatır (panel ayarına göre).
 *
 * Kategoriler yalnızca bölümlerde kaynak olarak kullanılıyorsa arşiv
 * sayfaları gereksizdir: anasayfaya yönlendirilir ya da 404 verilir.
 *
 * @return void
 */
function devxpe_category_archive_guard() {
	if ( is_admin() || ! is_category() ) {
		return;
	}

	$action = devxpe_theme_get( 'category_archive_action', 'normal' );

	if ( 'normal' !== $action ) {
		devxpe_archive_close( $action );
	}
}
add_action( 'template_redirect', 'devxpe_category_archive_guard' );

/**
 * Devxpe panelinde tanımlı içerik tiplerinin arşiv sayfalarını kapatır.
 *
 * WordPress kategorilerinden bağımsızdır; yalnızca panelde tanımlı
 * içerik tiplerinin (services, areas…) arşivleri için geçerlidir.
 *
 * @return void
 */
function devxpe_cpt_archive_guard() {
	if ( is_admin() || ! is_post_type_archive() ) {
		return;
	}

	$object = get_queried_object();
	if ( ! $object || ! in_array( $object->name, wp_list_pluck( devxpe_custom_post_types(), 'slug' ), true ) ) {
		return;
	}

	$action = devxpe_theme_get( 'cpt_archive_action', 'normal' );

	if ( 'normal' !== $action ) {
		devxpe_archive_close( $action );
	}
}
add_action( 'template_redirect', 'devxpe_cpt_archive_guard' );

/**
 * Sayfanın "Hakkımızda" / "İletişim" şablonuyla render edilmesini sağlar.
 *
 * Şablon seçimi sayfa düzenleyicisindeki metabox'tan yapılır
 * (`_dxp_page_type` = about | contact). WordPress şablon listesinde
 * görünmesin diye bu şablonların "Template Name" başlığı kaldırılmıştır.
 * Eski kurulumlar için panel seçicileri (about_page_pick/contact_page_pick)
 * yedek olarak korunur.
 *
 * @param string $template Mevcut şablon yolu.
 * @return string
 */
function devxpe_page_pick_template( $template ) {
	global $wp_query;
	if ( empty( $wp_query->is_page ) || empty( $wp_query->get_queried_object_id() ) ) {
		return $template;
	}

	$dxp_page_id = (int) $wp_query->get_queried_object_id();
	$tpl         = '';

	/* 1) Metabox seçimi (asıl yol). */
	if ( 'page' === get_post_type( $dxp_page_id ) ) {
		$dxp_type = (string) get_post_meta( $dxp_page_id, '_dxp_page_type', true );
		if ( 'about' === $dxp_type ) {
			$tpl = 'page-about.php';
		} elseif ( 'contact' === $dxp_type ) {
			$tpl = 'page-contact.php';
		}
	}

	/* 2) Eski panel seçicileri (geriye dönük uyumluluk). */
	if ( '' === $tpl ) {
		$picked = (int) devxpe_theme_get( 'about_page_pick' );
		$tpl    = 'page-about.php';
		if ( ! $picked ) {
			$picked = (int) devxpe_theme_get( 'contact_page_pick' );
			$tpl    = 'page-contact.php';
		}
		if ( ! $picked || $picked !== $dxp_page_id ) {
			return $template;
		}
	}

	$located = locate_template( $tpl );

	return $located ? $located : $template;
}
add_filter( 'template_include', 'devxpe_page_pick_template', 99 );

