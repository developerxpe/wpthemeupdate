<?php
/**
 * WebP dönüştürme ve sunumu.
 *
 * Yükleme anında JPEG/PNG görseller için aynı klasöre bir `.webp` kardeş dosya
 * üretir (ör. `resim.jpg.webp`); silinen eklerde bu dosyaları da temizler.
 * Ön yüzde, WebP kardeşi bulunan <img> etiketlerini <picture> ile sarar.
 *
 * Dönüştürme motoru: rosell-dk/webp-convert (MIT) — sistemde bulunan en iyi
 * yöntemi (cwebp/imagick/vips/gd…) otomatik seçer. Gömülü kopya:
 * includes/vendor/webp-convert/webp-convert.inc
 *
 * Filtreler:
 *   devxpe_webp_enabled  (bool, varsayılan true)  — tümünü kapatır.
 *   devxpe_webp_picture  (bool, varsayılan true)  — <picture> sunumunu kapatır.
 *   devxpe_webp_quality  (int,  varsayılan 82)    — dönüştürme kalitesi.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WebP özelliği açık mı?
 *
 * @return bool
 */
function devxpe_webp_enabled() {
	return (bool) apply_filters( 'devxpe_webp_enabled', true );
}

/**
 * Kütüphaneyi (tek dosya) yükler.
 *
 * @return bool Yüklendiyse true.
 */
function devxpe_webp_lib() {
	if ( class_exists( '\WebPConvert\WebPConvert' ) ) {
		return true;
	}

	$file = DEVXPE_THEME_PATH . 'includes/vendor/webp-convert/webp-convert.inc';
	if ( ! is_readable( $file ) ) {
		return false;
	}

	require_once $file;

	return class_exists( '\WebPConvert\WebPConvert' );
}

/**
 * Sunucuda kullanılabilir bir WebP dönüştürücüsü var mı?
 *
 * Önce GD/Imagick (güvenli, kabuksuz); sonra PATH'te cwebp ikilisi aranır.
 * Hiçbiri yoksa kütüphane hiç çağrılmaz (gereksiz exec denemesi/çıktı olmaz).
 *
 * @return string 'gd' | 'imagick' | 'cwebp' | ''
 */
function devxpe_webp_available_converter() {
	static $c = null;
	if ( null !== $c ) {
		return $c;
	}

	if ( function_exists( 'imagewebp' ) ) {
		$c = 'gd';
		return $c;
	}

	if ( class_exists( 'Imagick' ) && defined( 'Imagick::IMAGEFORMAT_WEBP' ) ) {
		$c = 'imagick';
		return $c;
	}

	$ext  = ( DIRECTORY_SEPARATOR === '\\' ) ? '.exe' : '';
	$dirs = array_filter( array_map( 'trim', explode( PATH_SEPARATOR, (string) getenv( 'PATH' ) ) ) );
	$dirs = array_merge( $dirs, array( '/usr/bin', '/usr/local/bin', '/usr/gnu/bin', '/usr/syno/bin' ) );

	foreach ( $dirs as $dir ) {
		$dir = rtrim( $dir, '/\\' );
		if ( '' !== $dir && is_file( $dir . DIRECTORY_SEPARATOR . 'cwebp' . $ext ) ) {
			$c = 'cwebp';
			return $c;
		}
	}

	$c = '';
	return $c;
}

/**
 * Tek bir görsel dosyasını `.webp` kardeşine dönüştürür (gerekmiyorsa atlar).
 *
 * @param string $path Kaynak dosyanın tam yolu (jpg/jpeg/png).
 * @return bool Başarılıysa/değişiklik yoksa true; hata olursa false.
 */
function devxpe_webp_convert_file( $path ) {
	if ( ! devxpe_webp_enabled() || ! is_string( $path ) || '' === $path ) {
		return false;
	}
	if ( ! preg_match( '/\.(jpe?g|png)$/i', $path ) ) {
		return false;
	}
	if ( ! is_readable( $path ) ) {
		return false;
	}

	$dest = $path . '.webp';

	/* Zaten güncel bir .webp varsa dokunma. */
	if ( file_exists( $dest ) && filemtime( $dest ) >= filemtime( $path ) ) {
		return true;
	}

	if ( ! devxpe_webp_lib() ) {
		return false;
	}

	/* Sunucuda çalışan bir dönüştürücü yoksa hiç denemeyelim. */
	if ( '' === devxpe_webp_available_converter() ) {
		return false;
	}

	/*
	 * Dönüştürücü denemeleri (özellikle binary yollar) nadiren de olsa
	 * ekrana çıktı sızdırabilir; tamponlayıp atarız ki yükleme yanıtı bozulmasın.
	 */
	ob_start();
	try {
		$opts = array(
			'quality'     => (int) apply_filters( 'devxpe_webp_quality', 82 ),
			'max-quality' => 88,
		);

		$conv = (array) apply_filters( 'devxpe_webp_converters', array() );
		if ( empty( $conv ) ) {
			/* Yalnızca tespit edilen dönüştürücüyü kullan: gereksiz exec denemesi olmasın. */
			$avail = devxpe_webp_available_converter();
			if ( '' !== $avail ) {
				$conv = array( $avail );
			}
		}
		if ( ! empty( $conv ) ) {
			$opts['converters'] = $conv;
		}

		\WebPConvert\WebPConvert::convert( $path, $dest, $opts );
	} catch ( \Throwable $e ) {
		/* Sunucuda uygun dönüştürücü yoksa sessizce vazgeç. */
		ob_end_clean();
		return false;
	}
	if ( ob_get_level() > 0 ) {
		ob_end_clean();
	}

	return file_exists( $dest );
}

/**
 * Bir ek (attachment) için orijinal + tüm boyutların `.webp` kardeşlerini üretir.
 *
 * @param int   $attachment_id Ek kimliği.
 * @param array $metadata      Ek meta verisi.
 * @return void
 */
function devxpe_webp_convert_attachment( $attachment_id, $metadata ) {
	if ( ! devxpe_webp_enabled() ) {
		return;
	}

	$uploads = wp_get_upload_dir();
	if ( empty( $uploads['basedir'] ) || empty( $metadata['file'] ) ) {
		return;
	}

	$basedir = $uploads['basedir'];
	$main    = $basedir . '/' . $metadata['file'];

	devxpe_webp_convert_file( $main );

	if ( ! empty( $metadata['sizes'] ) && is_array( $metadata['sizes'] ) ) {
		$dir = dirname( $main );
		foreach ( $metadata['sizes'] as $size ) {
			if ( ! empty( $size['file'] ) ) {
				devxpe_webp_convert_file( $dir . '/' . $size['file'] );
			}
		}
	}
}

/**
 * Ek yüklendiğinde (boyutlar üretildikten sonra) WebP kardeşleri üretir.
 *
 * @param array $metadata Ek meta verisi.
 * @param int   $id       Ek kimliği.
 * @return array
 */
function devxpe_webp_on_upload( $metadata, $id ) {
	devxpe_webp_convert_attachment( $id, $metadata );
	return $metadata;
}
add_filter( 'wp_generate_attachment_metadata', 'devxpe_webp_on_upload', 20, 2 );

/**
 * Ek silinince üretilmiş `.webp` kardeşlerini de siler.
 *
 * @param int $attachment_id Ek kimliği.
 * @return void
 */
function devxpe_webp_on_delete( $attachment_id ) {
	$metadata = wp_get_attachment_metadata( $attachment_id );
	if ( empty( $metadata['file'] ) ) {
		return;
	}

	$uploads = wp_get_upload_dir();
	if ( empty( $uploads['basedir'] ) ) {
		return;
	}

	$main  = $uploads['basedir'] . '/' . $metadata['file'];
	$files = array( $main );

	if ( ! empty( $metadata['sizes'] ) && is_array( $metadata['sizes'] ) ) {
		$dir = dirname( $main );
		foreach ( $metadata['sizes'] as $size ) {
			if ( ! empty( $size['file'] ) ) {
				$files[] = $dir . '/' . $size['file'];
			}
		}
	}

	foreach ( $files as $file ) {
		$webp = $file . '.webp';
		if ( file_exists( $webp ) ) {
			@unlink( $webp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		}
	}
}
add_action( 'delete_attachment', 'devxpe_webp_on_delete' );

/**
 * Bir görsel URL'si için WebP kardeşinin URL'sini döndürür (yoksa '').
 *
 * @param string $url Görsel URL'si (uploads içinde olmalı).
 * @return string
 */
function devxpe_webp_url( $url ) {
	if ( ! is_string( $url ) || '' === $url ) {
		return '';
	}

	$url = preg_replace( '/\?.*$/', '', $url );
	if ( ! preg_match( '/\.(jpe?g|png)$/i', $url ) ) {
		return '';
	}

	$uploads = wp_get_upload_dir();
	if ( empty( $uploads['baseurl'] ) || empty( $uploads['basedir'] ) ) {
		return '';
	}

	/* Yalnızca bu sitenin uploads klasöründeki görseller. */
	if ( 0 !== strpos( $url, $uploads['baseurl'] ) ) {
		return '';
	}

	$relative = substr( $url, strlen( $uploads['baseurl'] ) );
	$path     = $uploads['basedir'] . $relative;
	$webp     = $path . '.webp';

	if ( file_exists( $webp ) && filesize( $webp ) > 0 ) {
		return $uploads['baseurl'] . $relative . '.webp';
	}

	return '';
}

/**
 * HTML'deki <img> etiketlerini, WebP kardeşi varsa <picture> ile sarar.
 *
 * @param string $html Sayfa HTML'i.
 * @return string
 */
function devxpe_webp_rewrite_html( $html ) {
	if ( ! is_string( $html ) || false === stripos( $html, '<img' ) ) {
		return $html;
	}

	return preg_replace_callback(
		'#<img\b[^>]*>#i',
		function ( $m ) {
			$tag = $m[0];

			if ( false !== stripos( $tag, 'data-no-webp' ) ) {
				return $tag;
			}

			if ( ! preg_match( '#\bsrc\s*=\s*(["\'])(.*?)\1#i', $tag, $sm ) ) {
				return $tag;
			}

			$webp = devxpe_webp_url( $sm[2] );
			if ( '' === $webp ) {
				return $tag;
			}

			return '<picture><source type="image/webp" srcset="' . esc_url( $webp ) . '">' . $tag . '</picture>';
		},
		$html
	);
}

/**
 * Ön yüz çıktısını tamponlar ve <picture> dönüşümünü uygular.
 *
 * @return void
 */
function devxpe_webp_start_buffer() {
	if ( ! devxpe_webp_enabled() || ! apply_filters( 'devxpe_webp_picture', true ) ) {
		return;
	}
	if ( is_admin() || wp_doing_ajax() || is_feed() || is_robots() ) {
		return;
	}
	if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
		return;
	}
	if ( function_exists( 'wp_is_json_request' ) && wp_is_json_request() ) {
		return;
	}

	ob_start( 'devxpe_webp_rewrite_html' );
}
add_action( 'template_redirect', 'devxpe_webp_start_buffer', 20 );

/**
 * Panel için: sunucuda hangi WebP dönüştürücü çalışıyor? (bilgi amaçlı)
 *
 * @return array Desteklenen yöntem adları.
 */
function devxpe_webp_supported_methods() {
	$method = devxpe_webp_available_converter();
	return ( '' === $method ) ? array() : array( $method );
}

/**
 * Panelden toplu dönüştürme (AJAX, 10'arlı parti).
 *
 * @return void
 */
function devxpe_webp_ajax_bulk() {
	check_ajax_referer( 'devxpe_webp_bulk', 'nonce' );

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => 'cap' ) );
	}
	if ( '' === devxpe_webp_available_converter() ) {
		wp_send_json_error( array( 'message' => 'no_converter' ) );
	}

	$offset = isset( $_POST['offset'] ) ? absint( $_POST['offset'] ) : 0;
	$batch  = 10;

	global $wpdb;
	$total = (int) $wpdb->get_var(
		"SELECT COUNT(*) FROM {$wpdb->posts}
		WHERE post_type = 'attachment' AND post_status = 'inherit'
		AND post_mime_type IN ('image/jpeg','image/png')"
	);

	$ids = get_posts(
		array(
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'post_mime_type' => array( 'image/jpeg', 'image/png' ),
			'posts_per_page' => $batch,
			'offset'         => $offset,
			'fields'         => 'ids',
			'orderby'        => 'ID',
			'order'          => 'ASC',
		)
	);

	$done = 0;
	foreach ( $ids as $id ) {
		$meta = wp_get_attachment_metadata( $id );
		if ( is_array( $meta ) ) {
			devxpe_webp_convert_attachment( $id, $meta );
			$done++;
		}
	}

	$next = $offset + count( $ids );

	wp_send_json_success(
		array(
			'processed' => $done,
			'next'      => $next,
			'total'     => $total,
			'finished'  => ( count( $ids ) < $batch ),
		)
	);
}
add_action( 'wp_ajax_devxpe_webp_bulk', 'devxpe_webp_ajax_bulk' );
