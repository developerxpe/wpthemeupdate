<?php
/**
 * DEVXPE demo kataloğu (çoklu demo altyapısı).
 *
 * Mimari: "motor" bu üst temadır (sabit kalır); her görünüm ayrı bir CHILD
 * temadır (bkz. DEVXPE_Theme_Library). Demo içeriği de bu yüzden görünüme
 * (child temaya) bağlıdır: gelecekte eklenecek her tasarım kendi demo
 * içeriğini getirebilir.
 *
 * Bir demo şu alanlarla tanımlanır:
 *   - label       : Panelde görünen ad (çevrilebilir metin).
 *   - description : Kısa açıklama.
 *   - design      : Demo GÖRSELLERİNİN bulunduğu uzak klasör (`main/<design>/demo/`).
 *   - images      : Görsel sayısı (demo-1.jpg … demo-N.jpg + logo.png).
 *   - preview     : (opsiyonel) Önizleme görseli URL'i.
 *   - strings     : İçerik metinleri. callable($lang):array  VEYA
 *                   array( 'tr' => [...], 'en' => [...] ). Verilmezse motorun
 *                   yerleşik içeriği kullanılır.
 *   - data        : (opsiyonel) callable($lang):array  — yapıyı tamamen ezmek için.
 *   - options     : (opsiyonel) callable(array $d, array $img):array — tema
 *                   ayarlarını ezmek için.
 *
 * Yeni bir demo eklemenin İKİ yolu vardır:
 *   1) Filtre:  add_filter( 'devxpe_demos', fn( $d ) => $d + array( 'slug' => [...] ) );
 *   2) Tema içi dosya: child tema dizininde `demo/demo.php` (bir dizi döndürür).
 *      Bu dosya kurulu her child tema için OTOMATİK taranır; kod gerekmez.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DEVXPE_Theme_Demos {

	/**
	 * Kullanıcının seçtiği demo kimliğinin saklandığı option (opsiyonel).
	 * Boşsa/geçersizse etkin görünüme ve nihayetinde varsayılana düşülür.
	 */
	const OPTION_KEY = 'devxpe_demo_package';

	/**
	 * Motorun yerleşik demo kimliği (görsel klasörü de 'arc').
	 */
	const DEFAULT_ID = 'arc';

	/**
	 * Varsayılan görsel sayısı.
	 */
	const DEFAULT_IMAGES = 9;

	/**
	 * Kayıtlı demolar (tembel yüklenir).
	 *
	 * @var array|null
	 */
	private static $demos = null;

	/**
	 * Tüm demoları döndürür (yerleşik + filtre + otomatik keşif).
	 *
	 * @return array id => tanım.
	 */
	public static function all() {
		if ( null !== self::$demos ) {
			return self::$demos;
		}

		$demos = array(
			self::DEFAULT_ID => array(
				'label'       => __( 'Klasik (Yapı & Peyzaj)', 'devxpe-theme' ),
				'description' => __( 'Motora gömülü hazır yapı ve peyzaj içeriği. Tüm kurulumlarda çalışır.', 'devxpe-theme' ),
				'design'      => 'arc',
				'images'      => self::DEFAULT_IMAGES,
				'preview'     => '',
			),
		);

		/* 1) Kurulu child temaların `demo/demo.php` dosyalarını tara. */
		$demos = array_merge( $demos, self::discover_from_themes() );

		/* 2) Filtre ile kayıt/ezme (en son söz). */
		$demos = apply_filters( 'devxpe_demos', $demos );

		if ( ! is_array( $demos ) ) {
			$demos = array();
		}

		/* Normalleştir: eksik alanlar için makul varsayılan. */
		foreach ( $demos as $id => $tanim ) {
			if ( ! is_array( $tanim ) ) {
				unset( $demos[ $id ] );
				continue;
			}
			$demos[ $id ] = wp_parse_args(
				$tanim,
				array(
					'label'       => (string) $id,
					'description' => '',
					'design'      => (string) $id,
					'images'      => self::DEFAULT_IMAGES,
					'preview'     => '',
					'strings'     => null,
					'data'        => null,
					'options'     => null,
				)
			);
		}

		self::$demos = $demos;

		return self::$demos;
	}

	/**
	 * Kurulu child temaları tarayıp `demo/demo.php` tanımını yükler.
	 *
	 * Dosya bir dizi döndürmelidir (yukarıdaki tanım alanları). Kod yazmadan
	 * yeni tema demo eklenebilsin diye otomatik keşif yapılır.
	 *
	 * @return array slug => tanım.
	 */
	private static function discover_from_themes() {
		$out = array();

		if ( ! class_exists( 'DEVXPE_Theme_Library' ) ) {
			return $out;
		}

		foreach ( DEVXPE_Theme_Library::installed_designs() as $slug => $theme ) {
			$dosya = $theme->get_stylesheet_directory() . '/demo/demo.php';
			if ( ! file_exists( $dosya ) ) {
				continue;
			}

			$tanim = include $dosya;
			if ( is_array( $tanim ) ) {
				$tanim['design'] = isset( $tanim['design'] ) ? $tanim['design'] : $slug;
				$out[ $slug ]    = $tanim;
			}
		}

		return $out;
	}

	/**
	 * Tek bir demoyu döndürür.
	 *
	 * @param string $id Demo kimliği.
	 * @return array|null
	 */
	public static function get( $id ) {
		$all = self::all();
		$id  = (string) $id;

		return isset( $all[ $id ] ) ? $all[ $id ] : null;
	}

	/**
	 * Demo kayıtlı mı?
	 *
	 * @param string $id Demo kimliği.
	 * @return bool
	 */
	public static function exists( $id ) {
		return null !== self::get( $id );
	}

	/**
	 * Kayıtlı demo kimlikleri.
	 *
	 * @return array
	 */
	public static function ids() {
		return array_keys( self::all() );
	}

	/**
	 * Varsayılan demo kimliği.
	 *
	 * @return string
	 */
	public static function default_id() {
		$id = (string) apply_filters( 'devxpe_default_demo', self::DEFAULT_ID );

		return self::exists( $id ) ? $id : self::DEFAULT_ID;
	}

	/**
	 * Kurulum sırasında kullanılacak demo kimliği.
	 *
	 * Öncelik: kayıtlı kullanıcı seçimi → etkin child tasarımın slug'ı →
	 * varsayılan. Böylece bir tasarım etkin olduğunda onun demosu gelir;
	 * tanım yoksa motorun yerleşik içeriği kullanılır.
	 *
	 * @param string $istenen Zorlanmak istenen kimlik (opsiyonel).
	 * @return string
	 */
	public static function active_id( $istenen = '' ) {
		$istenen = sanitize_key( (string) $istenen );
		if ( '' !== $istenen && self::exists( $istenen ) ) {
			return $istenen;
		}

		$secili = sanitize_key( (string) get_option( self::OPTION_KEY, '' ) );
		if ( '' !== $secili && self::exists( $secili ) ) {
			return $secili;
		}

		if ( class_exists( 'DEVXPE_Theme_Library' ) ) {
			$slug = DEVXPE_Theme_Library::active_slug();
			if ( $slug !== DEVXPE_Theme_Library::parent_slug() && self::exists( $slug ) ) {
				return $slug;
			}
		}

		return self::default_id();
	}

	/**
	 * Kullanıcı seçimini kaydeder (geçersizse temizler).
	 *
	 * @param string $id Demo kimliği.
	 * @return void
	 */
	public static function set_active( $id ) {
		$id = sanitize_key( (string) $id );
		update_option( self::OPTION_KEY, self::exists( $id ) ? $id : '', false );
	}

	/**
	 * Bir demonun görsel klasörü (design slug).
	 *
	 * @param string $id Demo kimliği.
	 * @return string
	 */
	public static function design( $id ) {
		$d = self::get( $id );

		return ( $d && ! empty( $d['design'] ) ) ? (string) $d['design'] : (string) $id;
	}

	/**
	 * Bir demonun görsel sayısı.
	 *
	 * @param string $id Demo kimliği.
	 * @return int
	 */
	public static function images( $id ) {
		$d = self::get( $id );
		$n = ( $d && isset( $d['images'] ) ) ? (int) $d['images'] : self::DEFAULT_IMAGES;

		return $n > 0 ? $n : self::DEFAULT_IMAGES;
	}

	/**
	 * Demonun içerik metin haritası (varsa).
	 *
	 * @param string $id   Demo kimliği.
	 * @param string $lang 'tr' | 'en'.
	 * @return array|null Eşleme yoksa null (motor yerleşik içeriği kullanır).
	 */
	public static function strings( $id, $lang ) {
		$d = self::get( $id );
		if ( ! $d || empty( $d['strings'] ) ) {
			return null;
		}

		$s = $d['strings'];

		if ( is_callable( $s ) ) {
			$out = call_user_func( $s, $lang );
			return is_array( $out ) ? $out : null;
		}

		if ( is_array( $s ) ) {
			if ( isset( $s[ $lang ] ) && is_array( $s[ $lang ] ) ) {
				return $s[ $lang ];
			}
			if ( isset( $s['tr'] ) || isset( $s['en'] ) ) {
				$fallback = isset( $s['tr'] ) ? $s['tr'] : $s['en'];
				return is_array( $fallback ) ? $fallback : null;
			}
		}

		return null;
	}

	/**
	 * Demonun tam veri yapısı (varsa; gelişmiş demolar için).
	 *
	 * @param string $id   Demo kimliği.
	 * @param string $lang Dil.
	 * @return array|null
	 */
	public static function data( $id, $lang ) {
		$d = self::get( $id );
		if ( ! $d || empty( $d['data'] ) || ! is_callable( $d['data'] ) ) {
			return null;
		}

		$out = call_user_func( $d['data'], $lang );

		return is_array( $out ) ? $out : null;
	}

	/**
	 * Demonun tema ayarları (varsa; gelişmiş demolar için).
	 *
	 * @param string $id  Demo kimliği.
	 * @param array  $d   Demo verisi.
	 * @param array  $img Görsel URL'leri.
	 * @return array|null
	 */
	public static function options( $id, $d, $img ) {
		$demo = self::get( $id );
		if ( ! $demo || empty( $demo['options'] ) || ! is_callable( $demo['options'] ) ) {
			return null;
		}

		$out = call_user_func( $demo['options'], $d, $img );

		return is_array( $out ) ? $out : null;
	}

	/**
	 * Test/önbellek sıfırlama için kayıtlıları unutur.
	 *
	 * @return void
	 */
	public static function flush() {
		self::$demos = null;
	}
}
