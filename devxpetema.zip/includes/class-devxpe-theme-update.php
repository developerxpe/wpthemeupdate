<?php
/**
 * DEVXPE tema güncelleme alıcısı — GitHub tabanlı güncelleme kanalı.
 *
 * Tema, PUBLIC güncelleme deposundaki update.json dosyasını okur; yeni sürüm
 * varsa WordPress'in güncelleme listesine ekler. Kanal temanın kendi parçasıdır
 * ve her kopyada kalıcıdır.
 *
 * KURALLAR:
 *   - Güncelleme kontrolü ÖNBELLEKLİ (15 dk) → siteyi yavaşlatmaz.
 *   - Manifest, GitHub API "contents" adresinden okunur (`Accept: application/vnd.github.raw`);
 *     API'ye erişilemezse raw adresine düşülür (fail-open).
 *   - Paket adresi manifest'ten gelir (commit SHA'sına sabit olabilir).
 *   - GitHub'a erişilemezse hiçbir şey olmaz (fail-open).
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DEVXPE_Theme_Update {

	/**
	 * Varsayılan güncelleme manifest adresi (GitHub API, taze içerik).
	 */
	const DEFAULT_URL = 'https://api.github.com/repos/developerxpe/wpthemeupdate/contents/update.json?ref=main';

	/**
	 * Manifest önbellek anahtarı (panel de aynı anahtarı temizler).
	 */
	const TRANSIENT = 'dxpe_update_manifest';

	/**
	 * Panelden kaydedilen özel kanal adresinin option anahtarı.
	 */
	const OPTION_URL = 'devxpe_update_url';

	/**
	 * "Yeni sürüm var" uyarısının kullanıcı bazında gizlendiği meta anahtarı.
	 *
	 * Değer olarak gizlenen sürüm numarası saklanır; daha yeni bir sürüm
	 * yayınlanınca uyarı yeniden görünür.
	 */
	const NOTICE_META = 'devxpe_update_notice_hidden';

	/**
	 * Güncelleme sonrası "Hakkımızda" bölümüne yönlendirme bayrağı.
	 *
	 * Güncelleme BİTİNCE kurulur, bir sonraki yönetim isteğinde bir kez
	 * kullanılıp silinir (kullanıcı doğrudan sürüm notlarını görsün).
	 */
	const UPDATED_TRANSIENT = 'dxpe_updated_redirect';

	/**
	 * Kancaları bağlar.
	 *
	 * @return void
	 */
	public static function init() {
		add_filter( 'pre_set_site_transient_update_themes', array( __CLASS__, 'register' ) );
		add_filter( 'upgrader_source_selection', array( __CLASS__, 'source_name' ), 10, 4 );
		add_action( 'upgrader_process_complete', array( __CLASS__, 'after_upgrade' ), 10, 2 );

		/* "Yeni sürüm var" uyarısı ve kullanıcı bazlı kapatma işleyicisi. */
		add_action( 'admin_notices', array( __CLASS__, 'notice' ) );
		add_action( 'admin_init', array( __CLASS__, 'dismiss' ) );

		/* Güncelleme ekranında "önce yedek al" uyarısı. */
		add_action( 'admin_notices', array( __CLASS__, 'backup_warning' ) );

		/* Sürüm notları kartındaki "Yenile": önbelleği atlayıp tazeler. */
		add_action( 'admin_post_devxpe_changelog_refresh', array( __CLASS__, 'handle_refresh' ) );

		/* Güncelleme sonrası bir kez "Hakkımızda" bölümüne yönlendir. */
		add_action( 'admin_init', array( __CLASS__, 'maybe_redirect_after_update' ) );
	}

	/**
	 * Güncelleme bittiyse, bir sonraki yönetim isteğinde Hakkımızda'ya yönlendirir.
	 *
	 * Bayrak `upgrader_process_complete` sırasında kurulur (o istekte admin_init
	 * çoktan geçmiştir) → yönlendirme bir SONRAKİ sayfa yüklemesinde olur.
	 * Böylece güncelleme sonrası ekran/başarı mesajı bozulmaz.
	 *
	 * @return void
	 */
	public static function maybe_redirect_after_update() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( ! get_transient( self::UPDATED_TRANSIENT ) ) {
			return;
		}

		if ( wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return;
		}

		global $pagenow;
		/*
		 * WordPress'in kendi güncelleme ekranlarında yönlendirme YAPMA:
		 * themes.php / update-core.php "Tema güncellendi" başarı mesajını
		 * gösterir; burada yönlendirirsek mesaj kaybolur. Panel yönlendirmesi
		 * yalnızca bu ekranların DIŞINDAKİ admin sayfalarında olur.
		 */
		if ( in_array( $pagenow, array( 'admin-post.php', 'admin-ajax.php', 'async-upload.php', 'update.php', 'themes.php', 'update-core.php' ), true ) ) {
			return;
		}

		/* Panel sınıfı yoksa (adres admin.php'ye düşüyorsa) yönlendirme anlamsız. */
		if ( ! class_exists( 'DEVXPE_Theme_Panel' ) ) {
			return;
		}

		/* Tek kullanımlık: bayrağı sil ve yönlendir. */
		delete_transient( self::UPDATED_TRANSIENT );

		wp_safe_redirect( devxpe_panel_url( '#about--about' ) );
		exit;
	}

	/**
	 * Sürüm notlarını tazeler (manifest önbelleğini atlar).
	 *
	 * @return void
	 */
	public static function handle_refresh() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Yetkiniz yok.', 'devxpe-theme' ) );
		}

		check_admin_referer( 'devxpe_changelog_refresh' );

		delete_transient( self::TRANSIENT );
		self::manifest( true );

		wp_safe_redirect( devxpe_panel_url( '#about--about' ) );
		exit;
	}

	/**
	 * Güncelleme manifest adresini döndürür.
	 *
	 * Öncelik: DXPE_UPDATE_URL sabiti (test için) → panelden kaydedilen adres
	 * (set_url) → varsayılan adres. Her durumda 'dxpe_update_url' filtresiyle
	 * değiştirilebilir.
	 *
	 * @return string
	 */
	public static function url() {
		if ( defined( 'DXPE_UPDATE_URL' ) ) {
			$url = (string) DXPE_UPDATE_URL;
		} else {
			$ayar = (string) get_option( self::OPTION_URL, '' );
			$url  = '' !== $ayar ? $ayar : self::DEFAULT_URL;
		}

		return (string) apply_filters( 'dxpe_update_url', $url );
	}

	/**
	 * Panelden girilen güncelleme adresini kaydeder ve önbelleği temizler.
	 *
	 * Boş ya da varsayılan adres verilirse özel ayar silinir (varsayılana döner).
	 *
	 * NOT: Panelde bu alan yok; değer `update_url` option'ı veya
	 * `dxpe_update_url` filtresi ile ayarlanır.
	 *
	 * @param string $url Yeni manifest adresi.
	 * @return void
	 */
	public static function set_url( $url ) {
		$url = esc_url_raw( trim( (string) $url ) );

		if ( '' === $url || self::DEFAULT_URL === $url ) {
			delete_option( self::OPTION_URL );
		} else {
			update_option( self::OPTION_URL, $url, false );
		}

		delete_transient( self::TRANSIENT );
	}

	/**
	 * Güncelleme bilgisini getirir (15 dk önbellek).
	 *
	 * Öncelik GitHub API "contents" (taze içerik); başarısızsa raw yedek okunur.
	 * Hata / geçersiz veri durumunda boş dizi döner (asla fatal atmaz).
	 *
	 * @param bool $zorla Önbelleği atla.
	 * @return array
	 */
	public static function manifest( $zorla = false ) {
		$url = self::url();

		if ( '' === $url ) {
			return array();
		}

		if ( ! $zorla ) {
			$onbellek = get_transient( self::TRANSIENT );
			if ( is_array( $onbellek ) ) {
				/*
				 * Önbellekteki sürüm kurulu sürümden KÜÇÜKse (yayından hemen
				 * sonraki CDN gecikmesi) önbelleği yok say ve tazele. Böylece
				 * paneldeki "Sürüm Notları" hiçbir zaman kurulu sürümden geri
				 * kalmaz. Normal durumda (uzak >= kurulu) önbellek korunur.
				 */
				$bayat = ! empty( $onbellek['version'] )
					&& version_compare( (string) $onbellek['version'], DEVXPE_THEME_VERSION, '<' );

				if ( ! $bayat ) {
					return $onbellek;
				}
			}
		}

		/*
		 * TEK DENEME: manifest zaman aşımında yedek adres denenmez. Üst sınır
		 * 4 sn; başarısızlık 15 dk negatif önbelleğe yazıldığı için tekrar
		 * deneme olmaz.
		 */
		$veri = self::manifest_uzaktan( $url );

		if ( $veri ) {
			/*
			 * Manifest sürümü kurulu sürümden KÜÇÜKse bu, büyük olasılıkla
			 * yayından hemen sonraki CDN gecikmesidir (eski kopya). 15 dk
			 * kilitlememek için kısa önbellekle → kendi kendine düzelir.
			 */
			$sure = version_compare( (string) $veri['version'], DEVXPE_THEME_VERSION, '<' )
				? MINUTE_IN_SECONDS
				: 15 * MINUTE_IN_SECONDS;

			set_transient( self::TRANSIENT, $veri, $sure );

			return $veri;
		}

		set_transient( self::TRANSIENT, array(), 15 * MINUTE_IN_SECONDS );

		return array();
	}

	/**
	 * Manifesti verilen adresten getirir; geçersiz/hata durumunda boş dizi.
	 *
	 * @param string $url Manifest adresi.
	 * @return array
	 */
	private static function manifest_uzaktan( $url ) {
		$r = wp_remote_get(
			$url,
			array(
				/*
				 * 4 sn: admin ekranını uzun süre bekletmemek için. Başarısız
				 * istek 15 dk negatif önbelleğe yazılır, ağ isteği tekrarlanmaz.
				 */
				'timeout'    => 4,
				'user-agent' => 'DEVXPE/' . DEVXPE_THEME_VERSION,
				/* GitHub API "contents" adresinde HAM içerik için gerekli. */
				'headers'    => array( 'Accept' => 'application/vnd.github.raw' ),
			)
		);

		if ( is_wp_error( $r ) || 200 !== (int) wp_remote_retrieve_response_code( $r ) ) {
			return array();
		}

		$veri = json_decode( (string) wp_remote_retrieve_body( $r ), true );

		if ( ! is_array( $veri ) || empty( $veri['version'] ) || empty( $veri['package'] ) ) {
			return array();
		}

		return $veri;
	}

	/**
	 * Yeni sürüm var mı? Varsa bilgiyi döndürür.
	 *
	 * @return array
	 */
	public static function available() {
		$m = self::manifest();

		if ( empty( $m['version'] ) ) {
			return array();
		}

		if ( ! version_compare( (string) $m['version'], self::kurulu_surum(), '>' ) ) {
			return array();
		}

		return $m;
	}

	/**
	 * Child tema paket bilgisini manifest'ten döndürür.
	 *
	 * Child tema OPSİYONELDİR. Manifest'te `child_package` yoksa (eski
	 * update.json) boş dizi döner → panel child bölümünde indirme bağlantısı
	 * gösterilmez, hiçbir şey bozulmaz.
	 *
	 * @return array array( 'package' => string, 'version' => string ) ya da boş dizi.
	 */
	public static function child_paket() {
		$m = self::manifest();

		if ( empty( $m['child_package'] ) ) {
			return array();
		}

		return array(
			'package' => (string) $m['child_package'],
			'version' => isset( $m['child_version'] ) ? (string) $m['child_version'] : '',
		);
	}

	/**
	 * DİSKTEKİ gerçek kurulu sürümü döndürür (sabit yerine).
	 *
	 * @return string
	 */
	private static function kurulu_surum() {
		$surum = (string) wp_get_theme( get_template() )->get( 'Version' );

		return ( '' !== $surum ) ? $surum : (string) DEVXPE_THEME_VERSION;
	}

	/**
	 * Sürüm notları geçmişini döndürür (yeni → eski, EN FAZLA 2 sürüm).
	 *
	 * KURALLAR:
	 *  - Yalnızca YAYINLANMIŞ sürümler gösterilir (manifest sürümüne kadar).
	 *    Yayında olmayan daha yeni bir sürümün notu kayıtta olsa bile gösterilmez.
	 *  - KURULU sürümün üstündeki notlar da gösterilmez. Sürüm düşürüldüğünde
	 *    (ör. 0.3.3 → 0.1.0) manifest güncellenene kadar eski yüksek sürümlerin
	 *    notları hayalet olarak görünmesin.
	 *  - Yalnızca son 2 sürümün notu tutulur (kurulu sürüm + bir altı).
	 *  - `changelog_history` yoksa manifest'in `changelog` alanı tek kayıt olur.
	 *  - Metinler wp_strip_all_tags ile temizlenir; çevrimdışı/geçersiz veride boş dizi.
	 *
	 * @return array
	 */
	public static function history() {
		$m      = self::manifest();
		$gecmis = array();

		$yayin_surum = (string) ( $m['version'] ?? '' );
		$kurulu      = self::kurulu_surum();

		if ( ! empty( $m['changelog_history'] ) && is_array( $m['changelog_history'] ) ) {
			foreach ( $m['changelog_history'] as $surum => $kayit ) {
				if ( ! is_array( $kayit ) ) {
					continue;
				}

				$surum = (string) $surum;

				/*
				 * YAYINLANMAMIŞ sürümün notu gösterilmez: yalnızca yayındaki en
				 * yeni sürüme (manifest version) kadar olanlar. Böylece "yeni
				 * sürüm yokken yeni not" görünmez.
				 */
				if ( '' !== $yayin_surum && version_compare( $surum, $yayin_surum, '>' ) ) {
					continue;
				}

				/*
				 * KURULU sürümden daha yeni notlar da gösterilmez. Sürüm
				 * düşürülünce (kurulu 0.1.0, manifest hâlâ 0.3.3) eski yüksek
				 * sürümlerin notları görünmesin.
				 */
				if ( version_compare( $surum, $kurulu, '>' ) ) {
					continue;
				}

				$gecmis[ $surum ] = array(
					'tarih' => self::tarih_kisalt( isset( $kayit['tarih'] ) ? $kayit['tarih'] : '' ),
					'not'   => isset( $kayit['not'] ) ? wp_strip_all_tags( (string) $kayit['not'] ) : '',
				);
			}
		}

		/* Geçmiş alanı yoksa: manifest'in changelog'unu tek kayıt yap. */
		if ( empty( $gecmis ) && ! empty( $m['version'] ) && ! empty( $m['changelog'] )
			&& version_compare( (string) $m['version'], $kurulu, '<=' ) ) {
			$gecmis[ (string) $m['version'] ] = array(
				'tarih' => self::tarih_kisalt( isset( $m['published'] ) ? $m['published'] : '' ),
				'not'   => wp_strip_all_tags( (string) $m['changelog'] ),
			);
		}

		/* Yeni → eski sırala, sonra yalnızca SON 2 sürümü bırak. */
		uksort(
			$gecmis,
			static function ( $a, $b ) {
				return version_compare( (string) $b, (string) $a );
			}
		);

		return array_slice( $gecmis, 0, 2, true );
	}

	/**
	 * Not tarihinden SAATİ atar, yalnızca tarihi bırakır.
	 *
	 * Kaynak biçimler: "01.10.2026 21:22" (changelog.json) veya
	 * "2026-10-01T19:22:27+00:00" (published). Çıktı: tarih kısmı.
	 *
	 * @param mixed $tarih Ham tarih.
	 * @return string
	 */
	private static function tarih_kisalt( $tarih ) {
		$t = wp_strip_all_tags( (string) $tarih );

		if ( '' === $t ) {
			return '';
		}

		/* ISO 8601 (published): "T"den önceki kısım. */
		$t_pos = strpos( $t, 'T' );
		if ( false !== $t_pos ) {
			return substr( $t, 0, $t_pos );
		}

		/* "d.m.Y H:i": ilk boşluktan önceki kısım. */
		$bosluk = strpos( $t, ' ' );
		return ( false !== $bosluk ) ? substr( $t, 0, $bosluk ) : $t;
	}

	/**
	 * Bu kullanıcı için verilen sürümün uyarısı gizlenmiş mi?
	 *
	 * Gizlenen sürümden daha yeni bir sürüm varsa false döner → uyarı tekrar çıkar.
	 * Çevrimdışı/hata durumunda karar vermez; yalnızca saklanan meta okunur.
	 *
	 * @param string $surum Yeni sürüm numarası.
	 * @return bool
	 */
	public static function notice_hidden( $surum ) {
		$gizli = (string) get_user_meta( get_current_user_id(), self::NOTICE_META, true );

		/* Gizlenen sürüm, mevcut yeni sürümden eski/eşitse uyarıyı gösterme. */
		return ( '' !== $gizli && version_compare( (string) $surum, $gizli, '<=' ) );
	}

	/**
	 * "Yeni sürüm var" uyarısını wp-admin'de basar.
	 *
	 * YALNIZCA yönetim yetkisi olan kullanıcıya gösterilir. Kontrol başarısızsa
	 * (çevrimdışı / geçersiz veri) hiçbir şey basılmaz; PHP uyarısı üretilmez.
	 * Otomatik yönlendirme YAPILMAZ — yalnızca bağlantı sunulur.
	 *
	 * @return void
	 */
	public static function notice() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$m = self::available();
		if ( empty( $m['version'] ) ) {
			return;
		}

		$surum = (string) $m['version'];

		if ( self::notice_hidden( $surum ) ) {
			return;
		}

		/* Kullanıcı bazlı kalıcı kapatma bağlantısı (nonce'lu). */
		$kapat = wp_nonce_url(
			add_query_arg( 'dxpe_dismiss', $surum, admin_url( 'index.php' ) ),
			'dxpe_dismiss_' . $surum
		);
		?>
		<div class="notice notice-warning">
			<p>
				<strong>DEVXPE:</strong>
				<?php
				echo esc_html(
					sprintf(
						/* translators: %s: yeni sürüm numarası */
						__( 'Tema için yeni sürüm var (%s).', 'devxpe-theme' ),
						$surum
					)
				);
				?>
				<br>
				<?php echo esc_html__( 'Güncellemeden önce sitenizin ve veritabanınızın yedeğini alın.', 'devxpe-theme' ); ?>
				<a href="<?php echo esc_url( admin_url( 'update-core.php' ) ); ?>"><?php echo esc_html__( 'Güncellemeye git', 'devxpe-theme' ); ?></a>
				&nbsp;|&nbsp;
				<a href="<?php echo esc_url( $kapat ); ?>"><?php echo esc_html__( 'Bu sürümü gizle', 'devxpe-theme' ); ?></a>
			</p>
		</div>
		<?php
	}

	/**
	 * Güncelleme ekranında "önce yedek al" uyarısı basar.
	 *
	 * YALNIZCA bir DEVXPE güncellemesi beklerken ve yalnızca güncelleme
	 * ekranlarında (update-core.php / themes.php) görünür. Böylece uyarı,
	 * "Şimdi güncelle" düğmesinin hemen yanında okunur. "Yeni sürüm var"
	 * uyarısı gizlenmiş olsa bile bu uyarı görünmeye devam eder.
	 *
	 * @return void
	 */
	public static function backup_warning() {
		if ( ! current_user_can( 'update_themes' ) ) {
			return;
		}

		global $pagenow;
		if ( ! in_array( $pagenow, array( 'update-core.php', 'themes.php' ), true ) ) {
			return;
		}

		if ( ! self::available() ) {
			return;
		}

		?>
		<div class="notice notice-warning">
			<p>
				<strong>DEVXPE:</strong>
				<?php esc_html_e( 'Tema güncellemesinden önce sitenizin ve veritabanınızın yedeğini alın. Güncelleme yalnızca tema dosyalarını değiştirir; geri dönmek isterseniz yedeğe ihtiyacınız olur.', 'devxpe-theme' ); ?>
			</p>
		</div>
		<?php
	}

	/**
	 * Uyarıyı bu kullanıcı ve bu sürüm için kalıcı olarak gizler.
	 *
	 * admin_init'te çalışır; nonce doğrulanır, yetki kontrol edilir.
	 * Geçersiz/eksik istek sessizce yok sayılır.
	 *
	 * @return void
	 */
	public static function dismiss() {
		if ( empty( $_GET['dxpe_dismiss'] ) ) {
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$surum = sanitize_text_field( wp_unslash( (string) $_GET['dxpe_dismiss'] ) );

		check_admin_referer( 'dxpe_dismiss_' . $surum );

		if ( '' !== $surum ) {
			update_user_meta( get_current_user_id(), self::NOTICE_META, $surum );
		}
	}

	/**
	 * WordPress güncelleme listesine ekler → "Güncelleme var" görünür.
	 *
	 * Manifest sürümü kuruludan YENİYSE response; aksi halde no_update doldurulur.
	 *
	 * @param object $transient Tema güncelleme geçici verisi.
	 * @return object
	 */
	public static function register( $transient ) {
		if ( ! is_object( $transient ) ) {
			return $transient;
		}

		if ( ! isset( $transient->response ) || ! is_array( $transient->response ) ) {
			$transient->response = array();
		}
		if ( ! isset( $transient->no_update ) || ! is_array( $transient->no_update ) ) {
			$transient->no_update = array();
		}

		$m = self::manifest();
		if ( empty( $m['version'] ) || empty( $m['package'] ) ) {
			return $transient;
		}

		$slug = get_template(); /* kurulu klasör adı */

		/* WordPress 'response' içinde requires/tested bekler (kurulu WordPress sürümü). */
		$gereksinim = isset( $m['requires'] ) ? (string) $m['requires'] : '';
		$tested     = isset( $m['tested'] ) ? (string) $m['tested'] : '';

		$kayit = array(
			'theme'       => $slug,
			'new_version' => (string) $m['version'],
			'package'     => (string) $m['package'],
			'url'         => isset( $m['url'] ) ? (string) $m['url'] : '',
			'requires'    => $gereksinim,
			'tested'      => $tested,
		);

		/*
		 * ÖNCE eski kaydı İKİ diziden de sil. Aksi hâlde tema güncellenip
		 * artık güncelleme olmadığında eski `response` kaydı yerinde kalır;
		 * WP `wp_update_themes()` erken döndüğü için "Güncelle" rozeti saatlerce
		 * ekranda takılı kalır. Çekirdek de aynı deseni kullanır (unset → set).
		 */
		unset( $transient->response[ $slug ], $transient->no_update[ $slug ] );

		if ( version_compare( (string) $m['version'], self::kurulu_surum(), '>' ) ) {
			$transient->response[ $slug ] = $kayit;
		} else {
			$transient->no_update[ $slug ] = $kayit;
		}

		return $transient;
	}

	/**
	 * Güncellemede klasör adını GARANTİ eder (düz zip güvenliği).
	 *
	 * @param string $source        Çıkarılan kaynak klasör yolu.
	 * @param string $remote_source Geçici çalışma klasörü.
	 * @param object $upgrader      Yükseltici.
	 * @param array  $hook_extra    İşlem bilgisi.
	 * @return string
	 */
	public static function source_name( $source, $remote_source, $upgrader, $hook_extra = array() ) {
		/* Yalnızca BİZİM tema. */
		$hedef = get_template();

		if ( empty( $hook_extra['theme'] ) ) {
			return $source;
		}

		/*
		 * `type` alanı TÜM güncelleme yollarında gelmez:
		 *   - Theme_Upgrader::upgrade()      → 'type' => 'theme' gönderir.
		 *   - Theme_Upgrader::bulk_upgrade() → (tema listesindeki/AJAX
		 *     "Hemen güncelle" bu yolu kullanır) 'type' GÖNDERMEZ.
		 * `type` VARSA 'theme' olmalı, YOKSA da 'theme' alanının bu temaya
		 * eşit olması yeterlidir.
		 */
		if ( isset( $hook_extra['type'] ) && '' !== (string) $hook_extra['type'] && 'theme' !== $hook_extra['type'] ) {
			return $source;
		}

		if ( '' === $hedef || (string) $hook_extra['theme'] !== $hedef ) {
			return $source;
		}

		$kaynak = basename( rtrim( (string) $source, '/' ) );

		/* Ad zaten doğruysa dokunma. */
		if ( $kaynak === $hedef ) {
			return $source;
		}

		/*
		 * Hedef: kaynağın YANINDA (kardeş) istenen ad.
		 * DİKKAT: Düz zip'te $source ile $remote_source AYNI klasördür; hedefi
		 * $source içine koymak rename()'i başarısız kılar (içine taşınamaz).
		 */
		$yeni = trailingslashit( dirname( rtrim( (string) $source, '/' ) ) ) . $hedef;

		if ( rtrim( $yeni, '/' ) === rtrim( (string) $source, '/' ) ) {
			return $source;
		}

		if ( @rename( rtrim( (string) $source, '/' ), $yeni ) ) {
			/*
			 * Sondaki eğik çizgi ŞART: WordPress, dönen yolu `$kaynak . 'style.css'`
			 * gibi birleştirir (check_package). Çizgisiz dönersek dosya bulunamaz
			 * ve toplu/AJAX güncelleme "style.css eksik" ile başarısız olur.
			 */
			return trailingslashit( $yeni );
		}

		return $source;
	}

	/**
	 * Güncelleme BİTİNCE önbellekleri temizler.
	 *
	 * Aksi hâlde tema güncellendiği hâlde "güncelleme var" demeye devam eder
	 * ve tekrar güncelleyince aynı sürüm kurulur (eski hâline döner gibi görünür).
	 *
	 * @param WP_Upgrader $upgrader Yükseltici.
	 * @param array       $data     İşlem bilgisi.
	 * @return void
	 */
	public static function after_upgrade( $upgrader, $data ) {
		if ( ! is_array( $data ) ) {
			return;
		}

		$tur     = isset( $data['type'] ) ? (string) $data['type'] : '';
		$eylem   = isset( $data['action'] ) ? (string) $data['action'] : '';
		$temalar = isset( $data['themes'] ) ? (array) $data['themes'] : array();

		$bizim = ( 'theme' === $tur && 'update' === $eylem );

		/* Tek tema güncellemesinde 'theme' alanı gelir. */
		if ( isset( $data['theme'] ) && get_template() === $data['theme'] ) {
			$bizim = true;
		}
		if ( $temalar && in_array( get_template(), $temalar, true ) ) {
			$bizim = true;
		}

		if ( $bizim ) {
			delete_transient( self::TRANSIENT );
			delete_site_transient( 'update_themes' );

			/* Bir sonraki yönetim isteğinde Hakkımızda'ya yönlendir (tek kez). */
			set_transient( self::UPDATED_TRANSIENT, '1', 5 * MINUTE_IN_SECONDS );
		}
	}
}

DEVXPE_Theme_Update::init();
