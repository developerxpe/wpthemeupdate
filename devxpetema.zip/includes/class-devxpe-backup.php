<?php
/**
 * DEVXPE — Ayarlar yedekleme (JSON / fotoğraflı ZIP) + otomatik yedek.
 *
 * Panelin "İçe / Dışa Aktar" bölümünden:
 *   - Elle yedek alınır (indirilebilir),
 *   - Otomatik yedek açılır (günlük / haftalık / aylık),
 *   - En fazla 2 yedek saklanır (eskisi silinir).
 *
 * "Fotoğrafları dahil et" açıkken yedek .zip olur: `ayarlar.json` + `uploads/`
 * içindeki görseller. Kapalıyken yalnızca ayarlar (.json) saklanır.
 *
 * Yedekler `wp-content/uploads/devxpe-yedek/` altında tutulur (index.html +
 * .htaccess ile korunur). İndirme, yetki + nonce denetimli bir uçtan yapılır.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DEVXPE_Backup {

	/** Yedek klasörü (uploads altında). */
	const DIR     = 'devxpe-yedek';
	/** Cron kancası. */
	const CRON    = 'devxpe_auto_backup';
	/** En fazla saklanan yedek sayısı. */
	const MAX     = 2;
	/** Yedek dosyası ön eki. */
	const PREFIX  = 'yedek-';

	/** Görsel uzantıları (fotoğraflı yedek). */
	private static function image_ext() {
		return array( 'jpg', 'jpeg', 'png', 'webp', 'gif', 'svg', 'avif' );
	}

	/**
	 * Kancaları bağlar.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( self::CRON, array( __CLASS__, 'run_cron' ) );
		add_action( 'init', array( __CLASS__, 'schedule' ) );
		add_filter( 'cron_schedules', array( __CLASS__, 'cron_schedules' ) );
		add_action( 'admin_post_devxpe_backup_download', array( __CLASS__, 'handle_download' ) );
		add_action( 'admin_post_devxpe_backup_upload', array( __CLASS__, 'handle_upload' ) );
	}

	public static function handle_upload() {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Yetkiniz yok.', '', array( 'response' => 403 ) ); }
		check_admin_referer( 'devxpe_backup_upload' );
		$file = $_FILES['backup_file'] ?? array();
		if ( ! isset( $file['error'], $file['tmp_name'], $file['name'] ) || UPLOAD_ERR_OK !== $file['error'] || ! is_uploaded_file( $file['tmp_name'] ) ) { wp_die( 'Yedek dosyası yüklenemedi.' ); }
		$ext = strtolower( pathinfo( $file['name'], PATHINFO_EXTENSION ) );
		$json = '';
		if ( 'json' === $ext ) {
			$json = file_get_contents( $file['tmp_name'] );
		} elseif ( 'zip' === $ext && class_exists( 'ZipArchive' ) ) {
			$zip = new ZipArchive();
			if ( true !== $zip->open( $file['tmp_name'] ) ) { wp_die( 'ZIP okunamadı.' ); }
			$total = 0;
			for ( $i = 0; $i < $zip->numFiles; $i++ ) {
				$stat = $zip->statIndex( $i );
				$name = $stat['name'];
				$zip->getExternalAttributesIndex( $i, $opsys, $attributes );
				if ( ( ( $attributes >> 16 ) & 0170000 ) === 0120000 || false !== strpos( $name, '\\' ) ) { $zip->close(); wp_die( 'ZIP bağlantı veya geçersiz yol içeriyor.' ); }
				$total += $stat['size'];
				$valid = 'ayarlar.json' === $name || ( 0 === strpos( $name, 'uploads/' ) && ( '/' === substr( $name, -1 ) || in_array( strtolower( pathinfo( $name, PATHINFO_EXTENSION ) ), self::image_ext(), true ) ) );
				if ( ! $valid || preg_match( '~(^|/)\.\.(/|$)|[\\\\:]~', $name ) || $total > 512 * 1024 * 1024 || $zip->numFiles > 10000 ) { $zip->close(); wp_die( 'Yedek güvenli dosya/sınır kontrolünden geçemedi.' ); }
			}
			$json = $zip->getFromName( 'ayarlar.json' );
			$zip->close();
		} else { wp_die( 'JSON veya ZIP seçin. ZIP yüklemek için ZipArchive gereklidir.' ); }
		$data = json_decode( (string) $json, true );
		if ( ! is_array( $data ) || ! isset( $data['options'] ) || ! is_array( $data['options'] ) ) { wp_die( 'Geçerli bir DEVXPE yedeği seçin.' ); }
		$name = self::PREFIX . 'import-' . uniqid() . '.' . $ext;
		$path = self::dir() . '/' . $name;
		if ( ! move_uploaded_file( $file['tmp_name'], $path ) ) { wp_die( 'Yedek kaydedilemedi.' ); }
		try { $result = self::restore( $name ); } finally { @unlink( $path ); }
		if ( ! $result['ok'] ) { wp_die( esc_html( $result['mesaj'] ) ); }
		wp_safe_redirect( devxpe_panel_url( '#settings--importexport' ) );
		exit;
	}

	/**
	 * Özel cron aralığını kaydeder (ayardan hesaplanır).
	 *
	 * @param array $sched Mevcut aralıklar.
	 * @return array
	 */
	public static function cron_schedules( $sched ) {
		$sec = self::interval_seconds();
		if ( $sec > 0 ) {
			$sched['dxp_backup_interval'] = array(
				'interval' => $sec,
				'display'  => __( 'DEVXPE yedek aralığı', 'devxpe-theme' ),
			);
		}
		return $sched;
	}

	/**
	 * İndirme ucunu işler (yetki + nonce denetimi burada).
	 *
	 * @return void
	 */
	public static function handle_download() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Bu işlem için yetkiniz yok.', 'devxpe-theme' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'devxpe_theme_save', 'devxpe_theme_nonce' );

		$ad = isset( $_GET['dosya'] ) ? sanitize_text_field( wp_unslash( (string) $_GET['dosya'] ) ) : '';
		self::download( $ad );
	}

	/**
	 * Panel alanlarından yedek ayarlarını okur.
	 *
	 * @return array { auto: string, images: bool }
	 */
	public static function settings() {
		return array(
			'auto'   => (string) devxpe_theme_get( 'backup_auto', 'off' ),
			'every'  => max( 1, absint( devxpe_theme_get( 'backup_every', '1' ) ) ),
			'images' => ( '1' === (string) devxpe_theme_get( 'backup_images', '' ) ),
		);
	}

	/**
	 * Otomatik yedek aralığı (saniye). Kapalıysa/geçersizse 0.
	 *
	 * @return int
	 */
	public static function interval_seconds() {
		$s    = self::settings();
		$unit = array(
			'minute' => MINUTE_IN_SECONDS,
			'hour'   => HOUR_IN_SECONDS,
			'day'    => DAY_IN_SECONDS,
			'week'   => WEEK_IN_SECONDS,
			'month'  => MONTH_IN_SECONDS,
		);

		if ( ! isset( $unit[ $s['auto'] ] ) ) {
			return 0;
		}

		return max( 60, (int) $s['every'] * (int) $unit[ $s['auto'] ] );
	}

	/**
	 * Yedek klasörünü döndürür (gerekirse oluşturur ve korur).
	 *
	 * @return string
	 */
	public static function dir() {
		$u = wp_get_upload_dir();
		$d = trailingslashit( $u['basedir'] ) . self::DIR;

		if ( ! is_dir( $d ) ) {
			wp_mkdir_p( $d );
		}
		if ( is_dir( $d ) ) {
			if ( ! file_exists( $d . '/index.html' ) ) {
				@file_put_contents( $d . '/index.html', '' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
			}
			if ( ! file_exists( $d . '/.htaccess' ) ) {
				@file_put_contents( $d . '/.htaccess', "Order deny,allow\nDeny from all\n" ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
			}
		}

		return $d;
	}

	/**
	 * Otomatik yedeği ayara göre zamanlar/günceller.
	 *
	 * @return void
	 */
	public static function schedule() {
		$sec  = self::interval_seconds();
		$key  = 'dxp_backup_interval';
		$next = wp_next_scheduled( self::CRON );

		if ( $sec <= 0 ) {
			if ( $next ) {
				wp_unschedule_event( $next, self::CRON );
			}
			return;
		}

		/* Aralık değiştiyse eski zamanlamayı bırak ve yeniden kur. */
		if ( $next && wp_get_schedule( self::CRON ) !== $key ) {
			wp_unschedule_event( $next, self::CRON );
			$next = false;
		}

		if ( ! $next ) {
			wp_schedule_event( time() + $sec, $key, self::CRON );
		}
	}

	/**
	 * Cron çalışınca yedek üretir.
	 *
	 * @return void
	 */
	public static function run_cron() {
		self::create( self::settings()['images'] );
	}

	/**
	 * Yedek üretir. ZipArchive yoksa (veya fotoğraf istenmiyorsa) JSON üretir.
	 *
	 * @param bool $images Görselleri dahil et.
	 * @return string Üretilen dosya adı (başarısızsa '').
	 */
	public static function create( $images = false ) {
		$dir   = self::dir();
		$stamp = gmdate( 'Ymd-His' );

		$payload = array(
			'version' => ( defined( 'DEVXPE_THEME_VERSION' ) ? DEVXPE_THEME_VERSION : '' ),
			'time'    => gmdate( 'c' ),
			'options' => get_option( DEVXPE_Theme_Fields::OPTION_KEY, array() ),
			/*
			 * Site adı/açıklaması ayrı WP option'ında tutulur, tema option'ında
			 * değildir; yedeğe ayrıca eklenir. Kayıt sırasında çekirdek tekrar
			 * kaçışladığı için burada düz metin saklanır.
			 */
			'site'    => array(
				'name'        => wp_specialchars_decode( (string) get_option( 'blogname' ), ENT_QUOTES ),
				'description' => wp_specialchars_decode( (string) get_option( 'blogdescription' ), ENT_QUOTES ),
			),
			'uploads_url' => wp_get_upload_dir()['baseurl'],
			'home_url' => home_url(),
			'site_url' => site_url(),
			/* Panelde üretilen içerik: sayfalar, içerik tipleri, menüler, front-page. */
			'content' => self::export_content(),
			'front'   => self::export_front(),
			'menus'   => self::export_menus(),
		);
		$json = wp_json_encode( $payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE );

		if ( $images ) {
			$zip_path = $dir . '/' . self::PREFIX . $stamp . '.zip';

			if ( self::zip_create( $zip_path, (string) $json, self::upload_files() ) ) {
				self::prune();
				return basename( $zip_path );
			}
		}

		$file = $dir . '/' . self::PREFIX . $stamp . '.json';
		if ( false === @file_put_contents( $file, (string) $json ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
			return '';
		}

		self::prune();
		return basename( $file );
	}

	/**
	 * uploads içindeki TÜM dosyaların tam yollarını döndürür (görsel dahil her
	 * şey). Yedek klasörü ve geçici dosyalar atlanır.
	 *
	 * @return array
	 */
	private static function upload_files() {
		$u    = wp_get_upload_dir();
		$base = rtrim( str_replace( '\\', '/', $u['basedir'] ), '/' );
		if ( ! is_dir( $base ) ) {
			return array();
		}

		$out = array();
		$root = realpath( $base );
		$collect = static function ( $value ) use ( &$collect, &$out, $u, $root ) {
			if ( is_array( $value ) ) {
				foreach ( $value as $child ) { $collect( $child ); }
				return;
			}
			if ( ! is_string( $value ) ) { return; }
			preg_match_all( '~https?://[^\s"<>\']+~u', html_entity_decode( $value, ENT_QUOTES, 'UTF-8' ), $matches );
			foreach ( $matches[0] as $url ) {
				$prefix = trailingslashit( $u['baseurl'] );
				if ( 0 !== strpos( $url, $prefix ) ) { continue; }
				$relative = rawurldecode( strtok( substr( $url, strlen( $prefix ) ), '?#' ) );
				$file = realpath( $root . '/' . $relative );
				if ( ! $file || ! is_file( $file ) || 0 !== strpos( $file, $root . DIRECTORY_SEPARATOR ) ) { continue; }
				if ( ! in_array( strtolower( pathinfo( $file, PATHINFO_EXTENSION ) ), self::image_ext(), true ) ) { continue; }
				$out[ $file ] = str_replace( '\\', '/', $file );
			}
		};
		$collect( get_option( DEVXPE_Theme_Fields::OPTION_KEY, array() ) );
		global $wpdb;
		foreach ( $wpdb->get_col( "SELECT post_content FROM {$wpdb->posts} WHERE post_type NOT IN ('attachment','revision') AND post_status NOT IN ('trash','auto-draft')" ) as $content ) {
			$collect( $content );
		}
		foreach ( $wpdb->get_results( "SELECT meta_key, meta_value FROM {$wpdb->postmeta} WHERE meta_key LIKE '\\_dxp\\_%' OR meta_key = '_thumbnail_id'" ) as $meta ) {
			$collect( '_thumbnail_id' === $meta->meta_key ? (string) wp_get_attachment_url( (int) $meta->meta_value ) : maybe_unserialize( $meta->meta_value ) );
		}
		return array_values( $out );
	}

	/**
	 * Yedek zip'i üretir (ayarlar.json + uploads görselleri).
	 * ZipArchive yoksa WordPress ile gelen PclZip kullanılır.
	 *
	 * @param string $zip_path Hedef zip.
	 * @param string $json     ayarlar.json içeriği.
	 * @param array  $files    Görsellerin tam yolları.
	 * @return bool
	 */
	private static function zip_create( $zip_path, $json, array $files ) {
		$u    = wp_get_upload_dir();
		$base = rtrim( str_replace( '\\', '/', $u['basedir'] ), '/' );

		if ( class_exists( 'ZipArchive' ) ) {
			$zip = new ZipArchive();
			if ( true !== $zip->open( $zip_path, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) {
				return false;
			}
			$zip->addFromString( 'ayarlar.json', (string) $json );
			foreach ( $files as $f ) {
				$rel = ltrim( substr( str_replace( '\\', '/', $f ), strlen( $base ) ), '/' );
				$zip->addFile( $f, 'uploads/' . $rel );
			}
			return (bool) $zip->close();
		}

		$pcl = ABSPATH . 'wp-admin/includes/class-pclzip.php';
		if ( ! is_file( $pcl ) ) {
			return false;
		}
		require_once $pcl;

		$tmp = trailingslashit( get_temp_dir() ) . 'dxp-bk-' . uniqid();
		wp_mkdir_p( $tmp );
		file_put_contents( $tmp . '/ayarlar.json', (string) $json );

		$zip = new PclZip( $zip_path );
		$ok  = ( 0 !== $zip->create( $tmp . '/ayarlar.json', PCLZIP_OPT_REMOVE_PATH, $tmp ) );
		if ( $ok && $files ) {
			$zip->add( $files, PCLZIP_OPT_REMOVE_PATH, $base, PCLZIP_OPT_ADD_PATH, 'uploads' );
		}

		@unlink( $tmp . '/ayarlar.json' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		@rmdir( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors

		return (bool) $ok;
	}

	/**
	 * Zip'i bir dizine çıkarır (ZipArchive yoksa PclZip).
	 *
	 * @param string $zip_path Zip.
	 * @param string $dest     Hedef dizin.
	 * @return bool
	 */
	private static function zip_extract_to( $zip_path, $dest ) {
		if ( class_exists( 'ZipArchive' ) ) {
			$zip = new ZipArchive();
			if ( true !== $zip->open( $zip_path ) ) {
				return false;
			}
			$ok = $zip->extractTo( $dest );
			$zip->close();
			return (bool) $ok;
		}

		$pcl = ABSPATH . 'wp-admin/includes/class-pclzip.php';
		if ( ! is_file( $pcl ) ) {
			return false;
		}
		require_once $pcl;

		$zip = new PclZip( $zip_path );
		return ( 0 !== $zip->extract( PCLZIP_OPT_PATH, $dest ) );
	}

	/**
	 * Dizini içeriğiyle siler.
	 *
	 * @param string $dir Dizin.
	 * @return void
	 */
	private static function rrmdir( $dir ) {
		if ( ! is_dir( $dir ) ) {
			return;
		}
		foreach ( (array) scandir( $dir ) as $ad ) {
			if ( '.' === $ad || '..' === $ad ) {
				continue;
			}
			$yol = $dir . '/' . $ad;
			is_dir( $yol ) ? self::rrmdir( $yol ) : @unlink( $yol ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		}
		@rmdir( $dir ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
	}

	/**
	 * Yedekleri (yeni → eski) listeler.
	 *
	 * @return array array( array( 'ad', 'zaman', 'boyut', 'foto' ), ... )
	 */
	public static function list_files() {
		$dir  = self::dir();
		$out  = array();
		$glob = glob( $dir . '/' . self::PREFIX . '*.{json,zip}', GLOB_BRACE );

		foreach ( (array) $glob as $f ) {
			$out[] = array(
				'ad'    => basename( $f ),
				'zaman' => (int) filemtime( $f ),
				'boyut' => (int) filesize( $f ),
				'foto'  => ( 'zip' === strtolower( (string) pathinfo( $f, PATHINFO_EXTENSION ) ) ),
			);
		}

		usort(
			$out,
			static function ( $a, $b ) {
				return $b['zaman'] <=> $a['zaman'];
			}
		);

		return $out;
	}

	/**
	 * En fazla MAX yedek bırakır; eskilerini siler.
	 *
	 * @return void
	 */
	public static function prune() {
		$liste = self::list_files();
		if ( count( $liste ) <= self::MAX ) {
			return;
		}

		$dir = self::dir();
		foreach ( array_slice( $liste, self::MAX ) as $yedek ) {
			@unlink( $dir . '/' . $yedek['ad'] ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		}
	}

	/**
	 * Güvenli yedek dosya yolu (ad doğrulanır).
	 *
	 * @param string $ad Dosya adı.
	 * @return string Yol ya da ''.
	 */
	public static function path( $ad ) {
		$ad = basename( (string) $ad );
		if ( '' === $ad || 0 !== strpos( $ad, self::PREFIX ) ) {
			return '';
		}
		/*
		 * Adlar: zaman damgalı yedek (yedek-20261017-123456) ve içe aktarma
		 * kopyası (yedek-import-68f…). İkisi de bu klasörde üretilir.
		 */
		if ( ! preg_match( '/^' . preg_quote( self::PREFIX, '/' ) . '[a-z0-9\-]+\.(json|zip)$/i', $ad ) ) {
			return '';
		}

		$yol = self::dir() . '/' . $ad;
		return is_file( $yol ) ? $yol : '';
	}

	/**
	 * Yedeği siler.
	 *
	 * @param string $ad Dosya adı.
	 * @return bool
	 */
	public static function delete( $ad ) {
		$yol = self::path( $ad );
		return ( '' !== $yol ) ? (bool) @unlink( $yol ) : false; // phpcs:ignore WordPress.PHP.NoSilencedErrors
	}

	/**
	 * Yedeği indirir (yetki + nonce dispatcher tarafından doğrulanır).
	 *
	 * @param string $ad Dosya adı.
	 * @return void
	 */
	public static function download( $ad ) {
		$yol = self::path( $ad );
		if ( '' === $yol ) {
			wp_die( esc_html__( 'Yedek bulunamadı.', 'devxpe-theme' ), '', array( 'response' => 404 ) );
		}

		nocache_headers();
		header( 'Content-Type: application/octet-stream' );
		header( 'Content-Disposition: attachment; filename="' . basename( $yol ) . '"' );
		header( 'Content-Length: ' . filesize( $yol ) );
		readfile( $yol );
		exit;
	}

	/**
	 * Yedekteki adresleri hedef sitenin adreslerine çevirir.
	 *
	 * @param array $options Ayar dizisi.
	 * @param array $source  Yedek verisi (site_url, home_url, uploads_url).
	 * @param array $target  Hedef adresler.
	 * @return array
	 */
	private static function adapt_urls( array $options, array $source, array $target ) {
		// Eski yedeklerde kaynak adresi yalnızca standart uploads yolundan çıkarılabilir.
		if ( empty( $source['site_url'] ) && ! empty( $source['uploads_url'] ) && is_string( $source['uploads_url'] ) ) {
			if ( preg_match( '~^(https?://.+)/wp-content/uploads$~', rtrim( $source['uploads_url'], '/' ), $match ) ) {
				$source['site_url'] = $match[1];
				$source['home_url'] = $match[1];
			}
		}
		$map = array();
		foreach ( $target as $key => $url ) {
			if ( empty( $source[$key] ) || ! is_string( $source[$key] ) || ! preg_match( '~^https?://~', $source[$key] ) ) { continue; }
			$old = rtrim( $source[$key], '/' );
			if ( ! isset( $map[$old] ) ) { $map[$old] = rtrim( $url, '/' ); }
		}
		return self::rewrite_urls( $options, $map );
	}

	/**
	 * URL eşlemesini ayar değerlerine uygular (uzun URL önce denenir).
	 *
	 * @param array $options Ayar dizisi.
	 * @param array $map     eski URL => yeni URL.
	 * @return array
	 */
	private static function rewrite_urls( array $options, array $map ) {
		if ( ! $map ) {
			return $options;
		}

		uksort( $map, static function ( $a, $b ) { return strlen( $b ) <=> strlen( $a ); } );
		$pattern = '~(?<![a-zA-Z0-9_./?=&%\-])(?:' . implode( '|', array_map( static function ( $url ) { return preg_quote( $url, '~' ); }, array_keys( $map ) ) ) . ')(?=$|[/\s?#"\'<>])~';

		array_walk_recursive( $options, static function ( &$value ) use ( $pattern, $map ) {
			if ( is_string( $value ) ) {
				$value = preg_replace_callback( $pattern, static function ( $match ) use ( $map ) { return $map[ $match[0] ]; }, $value );
			}
		} );

		return $options;
	}

	/**
	 * Yedekteki uploads yolunu hedef sitenin klasör düzenine uyarlar.
	 *
	 * Hedef yıl/ay klasörü kullanıyorsa tarihli yollar korunur, tarihsiz
	 * dosyalar geçerli yıl/ay klasörüne girer. Hedef düz yapıdaysa tarih
	 * klasörleri kaldırılır.
	 *
	 * @param string $rel   Yedekteki göreli yol ("2026/06/a.jpg" ya da "a.jpg").
	 * @param string $ymdir Hedefin yıl/ay alt klasörü ('' ise düz yapı).
	 * @return string
	 */
	private static function hedef_yol( $rel, $ymdir ) {
		$tarihli = (bool) preg_match( '~^\d{4}/\d{2}/~', $rel );

		if ( '' !== $ymdir ) {
			return $tarihli ? $rel : $ymdir . '/' . $rel;
		}

		return $tarihli ? (string) preg_replace( '~^\d{4}/\d{2}/~', '', $rel ) : $rel;
	}

	/**
	 * Yedekteki uploads klasörünü hedefe kopyalar, adres eşlemesini döndürür.
	 *
	 * Var olan dosyaların üzerine YAZILMAZ.
	 *
	 * @param string $kaynak    Yedekteki uploads dizini.
	 * @param string $eski_base Yedeğin uploads adresi (yoksa '').
	 * @param bool   $hata      Kopyalama hatası (referans).
	 * @return array eski URL => yeni URL
	 */
	private static function import_uploads( $kaynak, $eski_base, &$hata ) {
		$hata = false;

		$u      = wp_get_upload_dir();
		$ymdir  = trim( (string) $u['subdir'], '/' );
		$kbase  = rtrim( str_replace( '\\', '/', $kaynak ), '/' );
		$taban  = trailingslashit( $u['basedir'] );
		$tbase  = rtrim( (string) $u['baseurl'], '/' );
		$eski   = rtrim( (string) $eski_base, '/' );
		$map    = array();
		$kullan = array();

		$rip = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $kaynak, FilesystemIterator::SKIP_DOTS ) );

		foreach ( $rip as $f ) {
			if ( ! $f->isFile() ) {
				continue;
			}

			$tam = str_replace( '\\', '/', $f->getPathname() );
			$rel = ltrim( substr( $tam, strlen( $kbase ) ), '/' );

			$hedef_rel = self::hedef_yol( $rel, $ymdir );

			/* Düz yapıya indirgerken ada çakışırsa özgün (yıl/ay) yol korunur. */
			if ( $hedef_rel !== $rel && isset( $kullan[ $hedef_rel ] ) && $kullan[ $hedef_rel ] !== $rel ) {
				$hedef_rel = $rel;
			}
			$kullan[ $hedef_rel ] = $rel;

			$hedef = $taban . $hedef_rel;
			if ( ! file_exists( $hedef ) ) {
				wp_mkdir_p( dirname( $hedef ) );
				if ( ! copy( $tam, $hedef ) ) {
					$hata = true;
					return array();
				}
			}

			/* Medya kütüphanesi kaydı: dosya zaten kayıtlıysa tekrar eklenmez. */
			self::register_attachment( $hedef, $hedef_rel, $tbase );

			if ( '' !== $eski ) {
				$map[ $eski . '/' . $rel ] = $tbase . '/' . $hedef_rel;
			}
		}

		return $map;
	}

	/**
	 * Bir dosyayı medya kütüphanesine kaydeder (zaten kayıtlıysa var olanı döndürür).
	 *
	 * @param string $file    Dosyanın tam yolu.
	 * @param string $rel     uploads'a göreli yol.
	 * @param string $baseurl uploads adresi (GUID için).
	 * @return int Ek kimliği; oluşturulamazsa 0.
	 */
	private static function register_attachment( $file, $rel, $baseurl ) {
		if ( ! function_exists( 'wp_insert_attachment' ) || ! is_file( $file ) ) {
			return 0;
		}

		$rel = ltrim( str_replace( '\\', '/', (string) $rel ), '/' );

		/* Aynı göreli yol daha önce kaydedilmişse yeniden eklenmez. */
		$mevcut = get_posts(
			array(
				'post_type'      => 'attachment',
				'post_status'    => 'inherit',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'meta_key'       => '_wp_attached_file',
				'meta_value'     => $rel,
			)
		);
		if ( $mevcut ) {
			return (int) $mevcut[0];
		}

		$tip = wp_check_filetype( $file, null );
		if ( empty( $tip['type'] ) ) {
			return 0;
		}

		$id = wp_insert_attachment(
			array(
				'post_mime_type' => $tip['type'],
				'post_title'     => sanitize_text_field( pathinfo( $file, PATHINFO_FILENAME ) ),
				'post_content'   => '',
				'post_status'    => 'inherit',
				'guid'           => rtrim( (string) $baseurl, '/' ) . '/' . $rel,
			),
			$file
		);

		if ( is_wp_error( $id ) || ! $id ) {
			return 0;
		}

		$id = (int) $id;

		/* Küçük boyutları üret (SVG gibi boyutsuz biçimlerde atlanır). */
		if ( 'image/svg+xml' !== $tip['type'] && file_exists( ABSPATH . 'wp-admin/includes/image.php' ) ) {
			require_once ABSPATH . 'wp-admin/includes/image.php';
			$meta = wp_generate_attachment_metadata( $id, $file );
			if ( is_array( $meta ) && $meta ) {
				wp_update_attachment_metadata( $id, $meta );
			}
		}

		return $id;
	}

	/**
	 * Yedekteki site adı/açıklamasını uygular (eski yedeklerde options içinde).
	 *
	 * @param array $veri Yedek verisi.
	 * @return void
	 */
	private static function apply_site( array $veri ) {
		$opts = ( isset( $veri['options'] ) && is_array( $veri['options'] ) ) ? $veri['options'] : $veri;
		$site = ( isset( $veri['site'] ) && is_array( $veri['site'] ) ) ? $veri['site'] : array();

		$ad = null;
		if ( isset( $site['name'] ) ) {
			$ad = (string) $site['name'];
		} elseif ( isset( $opts['site_title'] ) ) {
			$ad = (string) $opts['site_title'];
		}

		$aciklama = null;
		if ( isset( $site['description'] ) ) {
			$aciklama = (string) $site['description'];
		} elseif ( isset( $opts['tagline'] ) ) {
			$aciklama = (string) $opts['tagline'];
		}

		$yaz = static function ( $option, $value ) {
			$value = sanitize_text_field( wp_specialchars_decode( $value, ENT_QUOTES ) );

			if ( function_exists( 'devxpe_safe_update_blog_option' ) ) {
				devxpe_safe_update_blog_option( $option, $value );
			} else {
				update_option( $option, $value );
			}
		};

		if ( null !== $ad && '' !== trim( $ad ) ) {
			$yaz( 'blogname', $ad );
		}
		if ( null !== $aciklama ) {
			$yaz( 'blogdescription', $aciklama );
		}
	}

	/**
	 * Yedeğin uploads adresini döndürür (yoksa site adresinden türetilir).
	 *
	 * @param array $veri Yedek verisi.
	 * @return string
	 */
	private static function source_uploads_url( array $veri ) {
		if ( ! empty( $veri['uploads_url'] ) && is_string( $veri['uploads_url'] ) ) {
			return rtrim( $veri['uploads_url'], '/' );
		}

		if ( ! empty( $veri['site_url'] ) && is_string( $veri['site_url'] ) ) {
			return rtrim( $veri['site_url'], '/' ) . '/wp-content/uploads';
		}

		return '';
	}

	/**
	 * Panelde üretilen içerikte adresleri hedef siteye çevirir.
	 *
	 * @param mixed $value   Dizi ya da metin.
	 * @param array $filemap Dosya adresi eşlemesi.
	 * @param array $veri    Yedek verisi.
	 * @return mixed
	 */
	private static function fix_urls( $value, array $filemap, array $veri ) {
		$wrap = array( 'v' => $value );
		$wrap = self::rewrite_urls( $wrap, $filemap );
		$wrap = self::adapt_urls(
			$wrap,
			$veri,
			array(
				'home_url'    => home_url(),
				'site_url'    => site_url(),
				'uploads_url' => wp_get_upload_dir()['baseurl'],
			)
		);

		return $wrap['v'];
	}

	/**
	 * Sayfaları, içerik tipi kayıtlarını ve demo yazılarını dışa aktarır.
	 *
	 * @return array
	 */
	private static function export_content() {
		$types = array( 'page' );

		if ( function_exists( 'devxpe_custom_post_types' ) ) {
			foreach ( devxpe_custom_post_types() as $cpt ) {
				if ( ! empty( $cpt['slug'] ) ) {
					$types[] = $cpt['slug'];
				}
			}
		}

		$rows = array();

		foreach ( get_posts(
			array(
				'post_type'        => array_values( array_unique( $types ) ),
				'post_status'      => array( 'publish', 'draft', 'private', 'pending', 'future' ),
				'numberposts'      => -1,
				'orderby'          => 'ID',
				'order'            => 'ASC',
				'suppress_filters' => true,
			)
		) as $post ) {
			$rows[ $post->ID ] = self::export_post( $post );
		}

		/* Demo yazıları (panelden kurulan demo); normal yazılar taşınmaz. */
		foreach ( get_posts(
			array(
				'post_type'        => 'post',
				'post_status'      => array( 'publish', 'draft', 'private', 'pending', 'future' ),
				'numberposts'      => -1,
				'meta_key'         => '_dxp_demo',
				'meta_value'       => '1',
				'suppress_filters' => true,
			)
		) as $post ) {
			$rows[ $post->ID ] = self::export_post( $post );
		}

		return array_values( $rows );
	}

	/**
	 * Tek bir içeriği taşınabilir biçime çevirir.
	 *
	 * @param WP_Post $post İçerik.
	 * @return array
	 */
	private static function export_post( $post ) {
		$meta = array();
		foreach ( (array) get_post_meta( $post->ID ) as $key => $values ) {
			if ( 0 !== strpos( $key, '_dxp_' ) || '_dxp_demo' === $key ) {
				continue;
			}
			$meta[ $key ] = maybe_unserialize( $values[0] );
		}

		$thumb = '';
		$tid   = (int) get_post_thumbnail_id( $post->ID );
		if ( $tid ) {
			$rel = (string) get_post_meta( $tid, '_wp_attached_file', true );
			if ( '' !== $rel ) {
				$thumb = ltrim( str_replace( '\\', '/', $rel ), '/' );
			}
		}

		$parent = $post->post_parent ? get_post( $post->post_parent ) : null;

		return array(
			'type'        => $post->post_type,
			'slug'        => $post->post_name,
			'title'       => $post->post_title,
			'content'     => $post->post_content,
			'excerpt'     => $post->post_excerpt,
			'status'      => $post->post_status,
			'menu_order'  => (int) $post->menu_order,
			'parent_slug' => $parent ? $parent->post_name : '',
			'parent_type' => $parent ? $parent->post_type : '',
			'thumbnail'   => $thumb,
			'meta'        => $meta,
		);
	}

	/**
	 * Front-page / yazılar sayfası ayarını (slug olarak) dışa aktarır.
	 *
	 * @return array
	 */
	private static function export_front() {
		$front = (int) get_option( 'page_on_front' );
		$blog  = (int) get_option( 'page_for_posts' );

		return array(
			'show_on_front'  => (string) get_option( 'show_on_front' ),
			'page_on_front'  => $front ? (string) get_post_field( 'post_name', $front ) : '',
			'page_for_posts' => $blog ? (string) get_post_field( 'post_name', $blog ) : '',
		);
	}

	/**
	 * Menüleri ve konum eşlemesini dışa aktarır.
	 *
	 * @return array
	 */
	private static function export_menus() {
		$out  = array();
		$locs = get_nav_menu_locations();

		foreach ( (array) wp_get_nav_menus() as $menu ) {
			$items  = (array) wp_get_nav_menu_items( $menu->term_id, array( 'post_status' => 'any' ) );
			$index  = array();
			$rows   = array();

			foreach ( $items as $i => $item ) {
				$index[ (int) $item->ID ] = $i;
			}

			foreach ( $items as $item ) {
				$slug = '';
				if ( 'post_type' === $item->type && $item->object_id ) {
					$slug = (string) get_post_field( 'post_name', (int) $item->object_id );
				} elseif ( 'taxonomy' === $item->type && $item->object_id ) {
					$term = get_term( (int) $item->object_id, $item->object );
					if ( $term && ! is_wp_error( $term ) ) {
						$slug = (string) $term->slug;
					}
				}

				$rows[] = array(
					'title'       => $item->title,
					'type'        => $item->type,
					'object'      => $item->object,
					'object_slug' => $slug,
					'url'         => $item->url,
					'parent'      => isset( $index[ (int) $item->menu_item_parent ] ) ? (int) $index[ (int) $item->menu_item_parent ] : -1,
					'order'       => (int) $item->menu_order,
				);
			}

			$out[] = array(
				'name'      => $menu->name,
				'locations' => array_values( array_keys( $locs, (int) $menu->term_id, true ) ),
				'items'     => $rows,
			);
		}

		return $out;
	}

	/**
	 * Bir içeriği tip + slug ile bulur (yoksa 0).
	 *
	 * @param string $type İçerik tipi.
	 * @param string $slug Slug.
	 * @return int
	 */
	private static function find_post( $type, $slug ) {
		$slug = sanitize_title( (string) $slug );
		if ( '' === $slug || '' === $type ) {
			return 0;
		}

		$q = new WP_Query(
			array(
				'post_type'        => $type,
				'name'             => $slug,
				'post_status'      => 'any',
				'posts_per_page'   => 1,
				'fields'           => 'ids',
				'no_found_rows'    => true,
				'suppress_filters' => true,
			)
		);

		return $q->posts ? (int) $q->posts[0] : 0;
	}

	/**
	 * `_wp_attached_file` yolundan ek kimliğini bulur (yoksa 0).
	 *
	 * @param string $rel Göreli yol.
	 * @return int
	 */
	private static function attachment_id_by_file( $rel ) {
		$rel = ltrim( str_replace( '\\', '/', (string) $rel ), '/' );
		if ( '' === $rel ) {
			return 0;
		}

		$ids = get_posts(
			array(
				'post_type'      => 'attachment',
				'post_status'    => 'inherit',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'meta_key'       => '_wp_attached_file',
				'meta_value'     => $rel,
			)
		);

		return $ids ? (int) $ids[0] : 0;
	}

	/**
	 * İçerikleri tip + slug eşleşmesiyle oluşturur/günceller.
	 *
	 * @param array $items Dışa aktarılmış içerik listesi.
	 * @return void
	 */
	private static function import_content( array $items ) {
		$ids = array();

		foreach ( $items as $item ) {
			$type = isset( $item['type'] ) ? sanitize_key( $item['type'] ) : '';
			$slug = isset( $item['slug'] ) ? sanitize_title( $item['slug'] ) : '';

			if ( '' === $type || '' === $slug ) {
				continue;
			}

			$status = isset( $item['status'] ) ? (string) $item['status'] : 'publish';
			if ( ! in_array( $status, array( 'publish', 'draft', 'private', 'pending', 'future' ), true ) ) {
				$status = 'publish';
			}

			$data = array(
				'post_type'    => $type,
				'post_name'    => $slug,
				'post_title'   => wp_strip_all_tags( isset( $item['title'] ) ? (string) $item['title'] : '' ),
				'post_content' => isset( $item['content'] ) ? (string) $item['content'] : '',
				'post_excerpt' => isset( $item['excerpt'] ) ? (string) $item['excerpt'] : '',
				'post_status'  => $status,
				'menu_order'   => isset( $item['menu_order'] ) ? (int) $item['menu_order'] : 0,
			);

			$mevcut = self::find_post( $type, $slug );
			if ( $mevcut ) {
				$data['ID'] = $mevcut;
			}

			$id = wp_insert_post( wp_slash( $data ), true );
			if ( is_wp_error( $id ) || ! $id ) {
				continue;
			}

			$id = (int) $id;
			$ids[ $type . '|' . $slug ] = $id;

			if ( isset( $item['meta'] ) && is_array( $item['meta'] ) ) {
				foreach ( $item['meta'] as $key => $value ) {
					if ( 0 !== strpos( (string) $key, '_dxp_' ) ) {
						continue;
					}
					update_post_meta( $id, $key, $value );
				}
			}
		}

		/* Üst içerik ve öne çıkan görsel: tüm kimlikler oluştuktan sonra. */
		foreach ( $items as $item ) {
			$type = isset( $item['type'] ) ? sanitize_key( $item['type'] ) : '';
			$slug = isset( $item['slug'] ) ? sanitize_title( $item['slug'] ) : '';
			$key  = $type . '|' . $slug;

			if ( '' === $type || '' === $slug || empty( $ids[ $key ] ) ) {
				continue;
			}

			$id = (int) $ids[ $key ];

			if ( ! empty( $item['parent_slug'] ) ) {
				$p_type = isset( $item['parent_type'] ) ? sanitize_key( $item['parent_type'] ) : '';
				$p_slug = sanitize_title( $item['parent_slug'] );
				$p_key  = $p_type . '|' . $p_slug;
				$p_id   = ! empty( $ids[ $p_key ] ) ? (int) $ids[ $p_key ] : self::find_post( $p_type, $p_slug );

				if ( $p_id && $p_id !== $id ) {
					wp_update_post( array( 'ID' => $id, 'post_parent' => $p_id ) );
				}
			}

			if ( ! empty( $item['thumbnail'] ) ) {
				$tid = self::attachment_id_by_file( $item['thumbnail'] );
				if ( $tid ) {
					set_post_thumbnail( $id, $tid );
				}
			}
		}
	}

	/**
	 * Front-page ayarını slug eşleşmesiyle uygular.
	 *
	 * @param array $front Dışa aktarılmış ayar.
	 * @return void
	 */
	private static function import_front( array $front ) {
		$show = isset( $front['show_on_front'] ) ? (string) $front['show_on_front'] : '';

		if ( 'page' !== $show && 'posts' !== $show ) {
			return;
		}

		update_option( 'show_on_front', $show );

		if ( 'page' !== $show ) {
			return;
		}

		$front_id = self::find_post( 'page', isset( $front['page_on_front'] ) ? $front['page_on_front'] : '' );
		if ( $front_id ) {
			update_option( 'page_on_front', $front_id );
		}

		$blog_id = self::find_post( 'page', isset( $front['page_for_posts'] ) ? $front['page_for_posts'] : '' );
		if ( $blog_id ) {
			update_option( 'page_for_posts', $blog_id );
		}
	}

	/**
	 * Menüleri oluşturur/günceller ve konumlara bağlar.
	 *
	 * @param array $menus Dışa aktarılmış menü listesi.
	 * @return void
	 */
	private static function import_menus( array $menus ) {
		foreach ( $menus as $entry ) {
			$name = isset( $entry['name'] ) ? sanitize_text_field( (string) $entry['name'] ) : '';
			if ( '' === $name ) {
				continue;
			}

			$menu    = wp_get_nav_menu_object( $name );
			$menu_id = $menu ? (int) $menu->term_id : (int) wp_create_nav_menu( $name );

			if ( is_wp_error( $menu_id ) || ! $menu_id ) {
				continue;
			}

			/* Yeniden içe aktarmada öğeler çoğalmasın: mevcutlar silinir. */
			foreach ( (array) wp_get_nav_menu_items( $menu_id, array( 'post_status' => 'any' ) ) as $old ) {
				wp_delete_post( (int) $old->ID, true );
			}

			$map   = array();
			$items = isset( $entry['items'] ) && is_array( $entry['items'] ) ? $entry['items'] : array();

			foreach ( $items as $i => $item ) {
				$args = array(
					'menu-item-title'    => isset( $item['title'] ) ? (string) $item['title'] : '',
					'menu-item-status'   => 'publish',
					'menu-item-position' => isset( $item['order'] ) ? (int) $item['order'] : ( $i + 1 ),
				);

				$type = isset( $item['type'] ) ? (string) $item['type'] : '';

				if ( 'post_type' === $type ) {
					$obj  = isset( $item['object'] ) ? (string) $item['object'] : 'page';
					$obj_id = self::find_post( $obj, isset( $item['object_slug'] ) ? $item['object_slug'] : '' );

					if ( ! $obj_id ) {
						continue;
					}

					$args['menu-item-type']      = 'post_type';
					$args['menu-item-object']    = $obj;
					$args['menu-item-object-id'] = $obj_id;
				} elseif ( 'taxonomy' === $type ) {
					$obj  = isset( $item['object'] ) ? (string) $item['object'] : 'category';
					$term = get_term_by( 'slug', isset( $item['object_slug'] ) ? $item['object_slug'] : '', $obj );

					if ( ! $term ) {
						continue;
					}

					$args['menu-item-type']      = 'taxonomy';
					$args['menu-item-object']    = $obj;
					$args['menu-item-object-id'] = (int) $term->term_id;
				} else {
					$args['menu-item-type']   = 'custom';
					$args['menu-item-object'] = 'custom';
					$args['menu-item-url']    = isset( $item['url'] ) ? (string) $item['url'] : '';
				}

				if ( isset( $item['parent'], $map[ (int) $item['parent'] ] ) ) {
					$args['menu-item-parent-id'] = (int) $map[ (int) $item['parent'] ];
				}

				$new = wp_update_nav_menu_item( $menu_id, 0, $args );
				if ( ! is_wp_error( $new ) ) {
					$map[ $i ] = (int) $new;
				}
			}

			if ( ! empty( $entry['locations'] ) && is_array( $entry['locations'] ) ) {
				$locs = get_theme_mod( 'nav_menu_locations', array() );
				foreach ( $entry['locations'] as $loc ) {
					$locs[ sanitize_key( $loc ) ] = $menu_id;
				}
				set_theme_mod( 'nav_menu_locations', $locs );
			}
		}
	}

	/**
	 * Yedeği geri yükler.
	 *
	 * JSON: yalnızca ayarlar. ZIP: ayarlar + görseller. Görseller hedef
	 * sitenin uploads düzenine yerleştirilir (yıl/ay klasörleri varsa oraya,
	 * düz yapıdaysa köke) ve ayarlardaki adresler yeni yollara çevrilir.
	 * Var olan dosyaların üzerine yazılmaz.
	 *
	 * @param string $ad Dosya adı.
	 * @return array { ok, mesaj }
	 */
	public static function restore( $ad ) {
		$yol = self::path( $ad );
		if ( '' === $yol ) {
			return array( 'ok' => false, 'mesaj' => 'Yedek bulunamadı.' );
		}

		$ext  = strtolower( (string) pathinfo( $yol, PATHINFO_EXTENSION ) );
		$json = '';
		$tmp  = '';
		$map  = array();

		if ( 'json' === $ext ) {
			$json = (string) file_get_contents( $yol );
		} elseif ( 'zip' === $ext ) {
			$tmp = trailingslashit( get_temp_dir() ) . 'dxp-bk-r-' . uniqid();
			wp_mkdir_p( $tmp );

			if ( ! self::zip_extract_to( $yol, $tmp ) || ! is_file( $tmp . '/ayarlar.json' ) ) {
				self::rrmdir( $tmp );
				return array( 'ok' => false, 'mesaj' => 'Zip açılamadı (zip desteği olmayabilir).' );
			}

			$json = (string) file_get_contents( $tmp . '/ayarlar.json' );
		} else {
			return array( 'ok' => false, 'mesaj' => 'Desteklenmeyen yedek biçimi.' );
		}

		$veri = json_decode( (string) $json, true );

		if ( ! is_array( $veri ) ) {
			if ( '' !== $tmp ) {
				self::rrmdir( $tmp );
			}
			return array( 'ok' => false, 'mesaj' => 'Yedek okunamadı (geçersiz JSON).' );
		}

		/* Görseller: hedefin klasör düzenine uyarlanmış yollarla kopyalanır. */
		if ( '' !== $tmp && is_dir( $tmp . '/uploads' ) ) {
			$hata = false;
			$map  = self::import_uploads( $tmp . '/uploads', self::source_uploads_url( $veri ), $hata );

			if ( $hata ) {
				self::rrmdir( $tmp );
				return array( 'ok' => false, 'mesaj' => 'Fotoğraf kopyalanamadı; ayarlar uygulanmadı.' );
			}
		}

		if ( '' !== $tmp ) {
			self::rrmdir( $tmp );
		}

		$options = isset( $veri['options'] ) && is_array( $veri['options'] ) ? $veri['options'] : $veri;

		/* Önce dosya bazlı yollar (daha özel), sonra site/uploads adresleri. */
		$options = self::rewrite_urls( $options, $map );
		$options = self::adapt_urls( $options, $veri, array( 'home_url' => home_url(), 'site_url' => site_url(), 'uploads_url' => wp_get_upload_dir()['baseurl'] ) );

		/* İçe aktarımda kullanılan aynı sanitize akışından geçir. */
		$all = DEVXPE_Theme_Fields::all();
		$out = get_option( DEVXPE_Theme_Fields::OPTION_KEY, array() );
		foreach ( $options as $key => $value ) {
			if ( isset( $all[ $key ] ) && empty( $all[ $key ]['wp_option'] ) ) {
				$out[ $key ] = DEVXPE_Theme_Fields::sanitize( $key, $value );
			}
		}
		update_option( DEVXPE_Theme_Fields::OPTION_KEY, $out, false );

		/*
		 * Panelde üretilen içerik: sayfalar, içerik tipi kayıtları ve demo
		 * yazıları. `_dxp_*` meta'ları (widget düzenleri, şablon, bölüm
		 * ayarları) birlikte taşınır. Menü ve front-page ayarları da gelir.
		 */
		if ( isset( $veri['content'] ) && is_array( $veri['content'] ) ) {
			self::import_content( self::fix_urls( $veri['content'], $map, $veri ) );
		}

		if ( isset( $veri['front'] ) && is_array( $veri['front'] ) ) {
			self::import_front( $veri['front'] );
		}

		if ( isset( $veri['menus'] ) && is_array( $veri['menus'] ) ) {
			self::import_menus( self::fix_urls( $veri['menus'], $map, $veri ) );
		}

		/* Site adı/açıklaması (varsa) en son uygulanır. */
		self::apply_site( $veri );

		return array( 'ok' => true, 'mesaj' => 'Yedek geri yüklendi.' );
	}
}

DEVXPE_Backup::init();
