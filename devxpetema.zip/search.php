<?php
/**
 * Arama sonuçları şablonu.
 *
 * Blog/arşiv tarafıyla aynı ortak ızgarayı kullanır.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

get_template_part(
	'template-parts/archive-grid',
	null,
	array(
		'eyebrow'     => __( 'Arama', 'devxpe-theme' ),
		/* translators: %s: arama sorgusu. */
		'title'       => sprintf( __( '"%s" için arama sonuçları', 'devxpe-theme' ), get_search_query() ),
		'description' => '',
	)
);

get_footer();
