<?php
/**
 * Etiket arşivi şablonu — blog tarafı.
 *
 * Yalnızca etikete giren normal yazıları listeler; içerik tipleri dâhil
 * edilmez. Görünüm arşivlerle ortaktır.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

get_template_part(
	'template-parts/archive-grid',
	null,
	array(
		'eyebrow'     => __( 'Etiket', 'devxpe-theme' ),
		'title'       => single_tag_title( '', false ),
		'description' => get_the_archive_description(),
		'filters'     => true,
	)
);

get_footer();
