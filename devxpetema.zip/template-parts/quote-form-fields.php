<?php
/**
 * Teklif formunun gövdesi — tüm varyantlarda ortak (tek yerde yazılır).
 *
 * $args: groups, steps, note
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$f = wp_parse_args(
	isset( $args ) ? (array) $args : array(),
	array(
		'groups' => array(),
		'steps'  => array(),
		'note'   => '',
	)
);

$f_steps = array_values( (array) $f['steps'] );
$f_total = max( 1, count( $f_steps ) );

/* Gizlilik onayı: tüm formlarda geçerli olan global ayar. */
$f_consent     = '1' === devxpe_theme_get( 'contact_consent_enable', '1' );
$f_consent_txt = (string) devxpe_theme_get( 'contact_consent_text' );

/*
 * Form metinleri panelden gelir; sabit yazı yok.
 * Alan etiketleri/yer tutucuları "Proje Adımı Alanları" ve "İletişim Adımı
 * Alanları" listelerinden okunur (aşağıda döngüyle çizilir).
 */
$f_legend1  = devxpe_theme_get( 'form_step1_legend', __( 'Neye ihtiyacınız var?', 'devxpe-theme' ) );
$f_btn_back = devxpe_theme_get( 'form_btn_back', __( 'Geri', 'devxpe-theme' ) );
$f_btn_next = devxpe_theme_get( 'form_btn_next', __( 'Devam Et', 'devxpe-theme' ) );
$f_btn_send = devxpe_theme_get( 'form_btn_send', __( 'Gönder', 'devxpe-theme' ) );
$f_pick_err = __( 'Lütfen bir hizmet seçin.', 'devxpe-theme' );

/*
 * Buton/başlık yazıları boş kalmasın.
 *
 * NEDEN: Panelde alan boşaltılırsa (ya da eski kayıtta boş string saklanmışsa)
 * ön yüzde yazısız buton görünüyordu; `devxpe_theme_get()` kayıtlı boş değeri
 * döndürdüğü için ikinci parametredeki varsayılan devreye girmiyordu.
 */
$f_btn_back = ( '' === trim( (string) $f_btn_back ) ) ? __( 'Geri', 'devxpe-theme' ) : $f_btn_back;
$f_btn_next = ( '' === trim( (string) $f_btn_next ) ) ? __( 'Devam Et', 'devxpe-theme' ) : $f_btn_next;
$f_btn_send = ( '' === trim( (string) $f_btn_send ) ) ? __( 'Gönder', 'devxpe-theme' ) : $f_btn_send;
$f_legend1  = ( '' === trim( (string) $f_legend1 ) ) ? __( 'Neye ihtiyacınız var?', 'devxpe-theme' ) : $f_legend1;
?>
<div class="dxp-quote-box"
     data-ajax="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>"
     data-nonce="<?php echo esc_attr( wp_create_nonce( 'devxpe_form' ) ); ?>"
     data-total="<?php echo absint( $f_total ); ?>"
     data-steps="<?php echo esc_attr( implode( '|', $f_steps ) ); ?>"
     data-consent="<?php esc_attr_e( 'Lütfen onay kutusunu işaretleyin.', 'devxpe-theme' ); ?>">

	<div class="dxp-quote-meta">
		<div class="dxp-quote-step" id="dxp-q-label"></div>
		<div class="dxp-quote-time"><?php esc_html_e( 'Yaklaşık bir dakika sürer', 'devxpe-theme' ); ?></div>
	</div>

	<?php // Numaralı adım çubuğu — salt görsel; JS ilerlemeyi .dxp-quote-progress üzerinden yönetir. ?>
	<ol class="dxp-qsteps" aria-hidden="true">
		<?php for ( $f_i = 1; $f_i <= $f_total; $f_i++ ) : ?>
		<li class="dxp-qstep-item" data-step="<?php echo absint( $f_i ); ?>">
			<span class="dxp-qstep-num">
				<span class="dxp-qstep-n"><?php echo absint( $f_i ); ?></span>
				<span class="dxp-qstep-check"><?php echo devxpe_lucide( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
			</span>
			<span class="dxp-qstep-name"><?php echo esc_html( isset( $f_steps[ $f_i - 1 ] ) ? $f_steps[ $f_i - 1 ] : '' ); ?></span>
		</li>
		<?php endfor; ?>
	</ol>

	<div class="dxp-quote-progress" role="progressbar" aria-valuemin="1" aria-valuemax="<?php echo absint( $f_total ); ?>" aria-valuenow="1">
		<div class="dxp-quote-bar"></div>
	</div>

	<form class="dxp-quote-form" novalidate>
		<fieldset class="dxp-qstep is-active" data-step="1">
			<legend><?php echo esc_html( $f_legend1 ); ?></legend>
			<?php foreach ( (array) $f['groups'] as $f_group ) : ?>
			<div class="dxp-qgroup">
				<div class="dxp-qgroup-title"><?php echo esc_html( $f_group['title'] ); ?></div>
				<div class="dxp-qoptions">
					<?php foreach ( (array) $f_group['options'] as $f_option ) : ?>
					<button type="button" class="dxp-qopt" data-value="<?php echo esc_attr( $f_option ); ?>" aria-pressed="false"><?php echo esc_html( $f_option ); ?></button>
					<?php endforeach; ?>
				</div>
			</div>
			<?php endforeach; ?>
			<?php if ( $f['note'] ) : ?>
			<p class="dxp-qnote"><?php echo esc_html( $f['note'] ); ?></p>
			<?php endif; ?>
			<p class="dxp-field-error" hidden><?php echo esc_html( $f_pick_err ); ?></p>
		</fieldset>

		<fieldset class="dxp-qstep" data-step="2" hidden>
			<legend><?php echo esc_html( isset( $f_steps[1] ) ? $f_steps[1] : '' ); ?></legend>
			<div class="dxp-qgrid">
				<?php foreach ( devxpe_quote_step_fields( 'project' ) as $f_row ) : ?>
					<?php devxpe_render_quote_field( $f_row ); ?>
				<?php endforeach; ?>
			</div>
		</fieldset>

		<fieldset class="dxp-qstep" data-step="3" hidden>
			<legend><?php echo esc_html( isset( $f_steps[2] ) ? $f_steps[2] : '' ); ?></legend>
			<div class="dxp-qgrid">
				<?php foreach ( devxpe_quote_step_fields( 'contact' ) as $f_row ) : ?>
					<?php devxpe_render_quote_field( $f_row ); ?>
				<?php endforeach; ?>
			</div>
		</fieldset>

		<fieldset class="dxp-qstep" data-step="4" hidden>
			<legend><?php echo esc_html( isset( $f_steps[3] ) ? $f_steps[3] : '' ); ?></legend>
			<dl class="dxp-qsummary"></dl>
			<?php if ( $f_consent && $f_consent_txt ) : ?>
			<label class="dxp-consent">
				<input type="checkbox" name="consent" value="1" />
				<span><?php echo devxpe_consent_metni( $f_consent_txt ); // phpcs:ignore WordPress.Security.EscapeOutput -- kaçış yardımcı fonksiyonda ?></span>
			</label>
			<?php endif; ?>
		</fieldset>

		<input type="text" name="website" class="dxp-qhoneypot" tabindex="-1" autocomplete="off" aria-hidden="true" />

		<div class="dxp-qnav">
			<button type="button" class="dxp-qback" hidden><?php echo esc_html( $f_btn_back ); ?></button>
			<button type="button" class="dxp-btn dxp-btn--primary dxp-qnext">
				<?php echo esc_html( $f_btn_next ); ?>
				<?php echo devxpe_lucide( 'arrow-right' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			</button>
			<button type="submit" class="dxp-btn dxp-btn--primary dxp-qsubmit" hidden>
				<?php echo esc_html( $f_btn_send ); ?>
			</button>
		</div>
	</form>

	<div class="dxp-quote-result" hidden></div>
</div>

<script>
( function () {
	var box = document.querySelector( '.dxp-quote-box' );
	if ( ! box ) { return; }

	var steps    = box.getAttribute( 'data-steps' ).split( '|' );
	var total    = parseInt( box.getAttribute( 'data-total' ), 10 ) || steps.length;
	var fields   = box.querySelectorAll( '.dxp-qstep' );
	var label    = box.querySelector( '#dxp-q-label' );
	var bar      = box.querySelector( '.dxp-quote-bar' );
	var progress = box.querySelector( '.dxp-quote-progress' );
	var back     = box.querySelector( '.dxp-qback' );
	var next     = box.querySelector( '.dxp-qnext' );
	var submit   = box.querySelector( '.dxp-qsubmit' );
	var form     = box.querySelector( '.dxp-quote-form' );
	var summary  = box.querySelector( '.dxp-qsummary' );
	var result   = box.querySelector( '.dxp-quote-result' );
	var current  = 1;

	function data() {
		var out = {};
		new FormData( form ).forEach( function ( v, k ) { out[ k ] = v; } );
		return out;
	}

	function buildSummary() {
		var d = data();
		var rows = [];

		/* Hizmet satırı: etiketi 1. adımın başlığından (panelden) gelir. */
		rows.push( [ steps[ 0 ] || '', d.service || '-' ] );

		/* Diğer alanlar: etiket, alan üzerindeki data-label'dan okunur.
		   Dosya alanları özete girmez. */
		Array.prototype.forEach.call( form.querySelectorAll( '[data-label]' ), function ( el ) {
			if ( 'file' === el.type ) { return; }
			rows.push( [ el.getAttribute( 'data-label' ), d[ el.name ] || '-' ] );
		} );

		summary.innerHTML = '';
		rows.forEach( function ( r ) {
			var dt = document.createElement( 'dt' );
			var dd = document.createElement( 'dd' );
			dt.textContent = r[ 0 ];
			dd.textContent = r[ 1 ];
			summary.appendChild( dt );
			summary.appendChild( dd );
		} );
	}

	function pickError( on ) {
		var pe = form.querySelector( '.dxp-qstep[data-step="1"] .dxp-field-error' );
		if ( pe ) { pe.hidden = ! on; }
	}

	function show( n ) {
		current = Math.min( Math.max( n, 1 ), total );
		Array.prototype.forEach.call( fields, function ( f ) {
			var on = parseInt( f.getAttribute( 'data-step' ), 10 ) === current;
			f.classList.toggle( 'is-active', on );
			f.hidden = ! on;
		} );
		label.textContent = 'Adım ' + current + ' / ' + total + ' \u2014 ' + steps[ current - 1 ];
		bar.style.width = ( current / total * 100 ) + '%';
		progress.setAttribute( 'aria-valuenow', current );
		back.hidden = ( current === 1 );
		next.hidden = ( current === total );
		submit.hidden = ( current !== total );
		if ( current === total ) { buildSummary(); }
	}

	box.addEventListener( 'click', function ( e ) {
		var opt = e.target.closest( '.dxp-qopt' );
		if ( ! opt ) { return; }

		Array.prototype.forEach.call( box.querySelectorAll( '.dxp-qopt' ), function ( b ) {
			b.classList.toggle( 'is-on', b === opt );
			b.setAttribute( 'aria-pressed', b === opt ? 'true' : 'false' );
		} );

		var hidden = form.querySelector( '[name="service"]' );
		if ( ! hidden ) {
			hidden = document.createElement( 'input' );
			hidden.type = 'hidden';
			hidden.name = 'service';
			form.appendChild( hidden );
		}
		hidden.value = opt.getAttribute( 'data-value' );
		pickError( false );
	} );

	next.addEventListener( 'click', function () {
		/* 1. adım: hizmet seçilmeden ilerlenmez. */
		if ( current === 1 && ! box.querySelector( '.dxp-qopt.is-on' ) ) {
			pickError( true );
			return;
		}
		/* Adım zorunlu alanları (panel "Doğrulama" ayarından bağımsız). */
		if ( window.dxpStepValidate && ! window.dxpStepValidate( form, current ) ) { return; }
		/* Geçerli adımın alanlarını doğrula (e-posta/telefon formatı vb.). */
		var step = form.querySelector( '.dxp-qstep[data-step="' + current + '"]' );
		if ( window.dxpFormValidate && ! window.dxpFormValidate( form, step ) ) { return; }
		show( current + 1 );
	} );
	back.addEventListener( 'click', function () { show( current - 1 ); } );

	form.addEventListener( 'submit', function ( e ) {
		e.preventDefault();
		if ( window.dxpFormValidate && ! window.dxpFormValidate( form ) ) { return; }

		var ck = form.querySelector( '[name="consent"]' );
		if ( ck && ! ck.checked ) {
			result.hidden = false;
			result.textContent = box.getAttribute( 'data-consent' ) || 'L\u00fctfen onay kutusunu i\u015faretleyin.';
			return;
		}

		submit.disabled = true;

		var fd = new FormData( form );
		fd.append( 'action', 'devxpe_form_submit' );
		fd.append( 'nonce', box.getAttribute( 'data-nonce' ) );

		function send() {
			fetch( box.getAttribute( 'data-ajax' ), { method: 'POST', body: fd, credentials: 'same-origin' } )
				.then( function ( r ) { return r.json(); } )
				.then( function ( res ) {
					var msg = ( res && res.data && res.data.message ) ? res.data.message : 'Bir hata oluştu.';
					form.hidden = true;
					box.querySelector( '.dxp-quote-meta' ).hidden = true;
					box.querySelector( '.dxp-quote-progress' ).hidden = true;
					result.hidden = false;
					result.textContent = msg;
				} )
				.catch( function () {
					submit.disabled = false;
					result.hidden = false;
					result.textContent = 'Bağlantı hatası. Lütfen tekrar deneyin.';
				} );
		}

		/* reCAPTCHA v3 açıksa token alınıp gönderilir. */
		if ( window.dxpRecaptchaKey && window.grecaptcha ) {
			grecaptcha.ready( function () {
				grecaptcha.execute( window.dxpRecaptchaKey, { action: 'dxp_form' } ).then( function ( token ) {
					if ( token ) { fd.append( 'dxp_recaptcha', token ); }
					send();
				} ).catch( send );
			} );
		} else {
			send();
		}
	} );

	show( 1 );
} )();
</script>
