<?php
/**
 * Ortak sayfa yerleşimi.
 *
 * Tüm sayfalarda aynı sıra: breadcrumb → sayfa başlığı (WordPress) → sayfa
 * içeriği → widget'lar. Tek arka plan kullanılır; başlık ve içerik ayrı bir
 * renk bandına taşınmaz. Başlık ve içerik widget değildir, her zaman çizilir.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$dxp_args    = wp_parse_args( $args ?? array(), array( 'context' => '' ) );
$dxp_is_wide = ( 'contact' === $dxp_args['context'] );
?>
<section class="dxp-band dxp-band--paper dxp-page-band">
	<div class="dxp-band-inner <?php echo $dxp_is_wide ? 'dxp-page-inner--wide' : 'dxp-page-inner'; ?>">
		<?php get_template_part( 'template-parts/breadcrumbs' ); ?>
		<?php
		while ( have_posts() ) :
			the_post();

			/*
			 * Başlık ve içerik kilitli widget temsilcileri olarak listenin
			 * içinde çizilir; böylece diğer widget'larla sırası değiştirilebilir.
			 * Değerler her zaman WordPress sayfasından gelir.
			 */
			$dxp_pw_html = class_exists( 'DEVXPE_Page_Widgets' ) ? (string) DEVXPE_Page_Widgets::cikti( get_the_ID() ) : '';

			if ( '' !== trim( $dxp_pw_html ) ) {
				echo '<div class="dxp-page-widgets-wrap">' . $dxp_pw_html . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput -- ciz() kendi kaçışını yapar
			}
		endwhile;
		?>
	</div>
</section>
