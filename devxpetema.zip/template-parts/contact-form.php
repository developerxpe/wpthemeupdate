<?php
/**
 * İletişim formu — panelden tasarlanan alanlarla.
 *
 * Kullanım:
 *   [devxpe_contact_form]              → varsayılan/aktif form
 *   [devxpe_form slug="iletisim"]      → belirli bir form
 *   get_template_part('template-parts/contact-form', null, array('slug'=>'iletisim'))
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$forms = devxpe_custom_forms();
$slug  = isset( $args['slug'] ) ? sanitize_key( $args['slug'] ) : '';
if ( '' === $slug || ! isset( $forms[ $slug ] ) ) {
	$slug = devxpe_active_form_slug();
}

$c_fields = devxpe_form_fields( $slug );
$c_btn    = ! empty( $forms[ $slug ]['btn'] ) ? $forms[ $slug ]['btn'] : (string) devxpe_theme_get( 'contact_btn_text', __( 'Mesaj Gönder', 'devxpe-theme' ) );
$c_consent = '1' === devxpe_theme_get( 'contact_consent_enable', '1' );
$c_ctext   = (string) devxpe_theme_get( 'contact_consent_text' );
$c_types   = (string) devxpe_theme_get( 'contact_upload_types', 'jpg,jpeg,png,webp,pdf' );
$c_accept  = '.' . implode( ',.', devxpe_lines( $c_types, ',' ) );
?>
<div class="dxp-cform"
     data-ajax="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>"
     data-nonce="<?php echo esc_attr( wp_create_nonce( 'devxpe_form' ) ); ?>"
     data-required="<?php esc_attr_e( 'Lütfen zorunlu alanları doldurun.', 'devxpe-theme' ); ?>"
     data-consent="<?php esc_attr_e( 'Lütfen onay kutusunu işaretleyin.', 'devxpe-theme' ); ?>"
     data-error="<?php esc_attr_e( 'Bir hata oluştu, lütfen tekrar deneyin.', 'devxpe-theme' ); ?>">
	<form class="dxp-cform-form" novalidate>
		<input type="hidden" name="dxp_form_slug" value="<?php echo esc_attr( $slug ); ?>" />
		<div class="dxp-cform-grid">
			<?php
			foreach ( $c_fields as $c_index => $c_f ) :
				$c_type  = isset( $c_f['type'] ) ? $c_f['type'] : 'input';
				$c_label = isset( $c_f['label'] ) ? $c_f['label'] : '';
				$c_key   = isset( $c_f['key'] ) ? $c_f['key'] : 'field_' . ( $c_index + 1 );
				$c_req   = ! empty( $c_f['required'] );
				$c_wide  = ( isset( $c_f['width'] ) && 'full' === $c_f['width'] ) ? ' dxp-field--full' : '';
				$c_name  = 'field_' . $c_key;
				$c_id    = 'dxp-cf-' . $slug . '-' . $c_key;
				$c_ph    = isset( $c_f['placeholder'] ) ? $c_f['placeholder'] : '';
				$c_opts  = isset( $c_f['options'] ) ? devxpe_lines( $c_f['options'], ',' ) : array();
				$c_req_attr = $c_req ? ' required' : '';

				if ( 'file' === $c_type ) :
					?>
					<div class="dxp-field<?php echo esc_attr( $c_wide ); ?>">
						<label for="<?php echo esc_attr( $c_id ); ?>"><?php echo esc_html( $c_label ); ?><?php echo $c_req ? ' <span aria-hidden="true">*</span>' : ''; ?></label>
						<input id="<?php echo esc_attr( $c_id ); ?>" type="file" name="dxp_file_<?php echo esc_attr( $c_key ); ?>" accept="<?php echo esc_attr( $c_accept ); ?>" />
						<small class="dxp-field-hint"><?php echo esc_html( sprintf( __( 'İzinli türler: %s', 'devxpe-theme' ), $c_types ) ); ?></small>
					</div>
					<?php
				elseif ( 'checkbox' === $c_type ) :
					?>
					<label class="dxp-consent<?php echo esc_attr( $c_wide ); ?>">
						<input type="checkbox" name="<?php echo esc_attr( $c_name ); ?>" value="1" <?php echo $c_req ? 'data-required="1"' : ''; ?> />
						<span><?php echo esc_html( $c_label ); ?><?php echo $c_req ? ' *' : ''; ?></span>
					</label>
					<?php
				elseif ( 'textarea' === $c_type ) :
					?>
					<div class="dxp-field<?php echo esc_attr( $c_wide ); ?>">
						<label for="<?php echo esc_attr( $c_id ); ?>"><?php echo esc_html( $c_label ); ?><?php echo $c_req ? ' <span aria-hidden="true">*</span>' : ''; ?></label>
						<textarea id="<?php echo esc_attr( $c_id ); ?>" name="<?php echo esc_attr( $c_name ); ?>" rows="4" placeholder="<?php echo esc_attr( $c_ph ); ?>"<?php echo $c_req_attr; ?><?php echo devxpe_field_maxlength_attr( 'textarea' ); ?>></textarea>
						<?php devxpe_render_field_counter( 'textarea' ); ?>
					</div>
					<?php
				elseif ( 'select' === $c_type ) :
					?>
					<div class="dxp-field<?php echo esc_attr( $c_wide ); ?>">
						<label for="<?php echo esc_attr( $c_id ); ?>"><?php echo esc_html( $c_label ); ?><?php echo $c_req ? ' <span aria-hidden="true">*</span>' : ''; ?></label>
						<select id="<?php echo esc_attr( $c_id ); ?>" name="<?php echo esc_attr( $c_name ); ?>"<?php echo $c_req_attr; ?>>
							<option value=""><?php esc_html_e( 'Seçiniz', 'devxpe-theme' ); ?></option>
							<?php foreach ( $c_opts as $c_opt ) : ?>
							<option value="<?php echo esc_attr( $c_opt ); ?>"><?php echo esc_html( $c_opt ); ?></option>
							<?php endforeach; ?>
						</select>
					</div>
					<?php
				else :
					$c_html_type = in_array( $c_type, array( 'input', 'text', 'email', 'tel', 'url', 'number', 'date' ), true ) ? $c_type : 'text';
					if ( 'input' === $c_html_type ) {
						$c_html_type = 'text';
					}
					?>
					<div class="dxp-field<?php echo esc_attr( $c_wide ); ?>">
						<label for="<?php echo esc_attr( $c_id ); ?>"><?php echo esc_html( $c_label ); ?><?php echo $c_req ? ' <span aria-hidden="true">*</span>' : ''; ?></label>
						<?php if ( 'tel' === $c_type ) : ?>
						<div class="dxp-tel-wrap">
							<?php devxpe_form_country_select( $c_key ); ?>
							<input id="<?php echo esc_attr( $c_id ); ?>" type="tel" name="<?php echo esc_attr( $c_name ); ?>" placeholder="<?php echo esc_attr( $c_ph ); ?>"<?php echo $c_req_attr; ?> />
						</div>
						<?php else : ?>
						<input id="<?php echo esc_attr( $c_id ); ?>" type="<?php echo esc_attr( $c_html_type ); ?>" name="<?php echo esc_attr( $c_name ); ?>" placeholder="<?php echo esc_attr( $c_ph ); ?>"<?php echo $c_req_attr; ?><?php echo in_array( $c_html_type, array( 'text', 'email', 'url' ), true ) ? devxpe_field_maxlength_attr( $c_html_type ) : ''; ?> />
						<?php endif; ?>
					</div>
					<?php
				endif;
			endforeach;
			?>
		</div>

		<?php if ( $c_consent && $c_ctext ) : ?>
		<label class="dxp-consent dxp-field--full">
			<input type="checkbox" name="consent" value="1" />
			<span><?php echo devxpe_consent_metni( $c_ctext ); // phpcs:ignore WordPress.Security.EscapeOutput -- kaçış yardımcı fonksiyonda ?></span>
		</label>
		<?php endif; ?>

		<button type="submit" class="dxp-btn dxp-btn--primary dxp-cform-submit"><?php echo esc_html( $c_btn ); ?></button>
		<p class="dxp-cform-msg" role="status" aria-live="polite"></p>
	</form>
</div>
<script>
(function () {
	document.querySelectorAll( '.dxp-cform' ).forEach( function ( box ) {
		if ( box.dataset.bound ) { return; }
		box.dataset.bound = '1';

		var form = box.querySelector( '.dxp-cform-form' );
		var msg  = box.querySelector( '.dxp-cform-msg' );
		var btn  = box.querySelector( '.dxp-cform-submit' );
		if ( ! form ) { return; }

		function fail( text ) {
			msg.textContent = text;
			msg.className = 'dxp-cform-msg is-error';
			if ( btn ) { btn.disabled = false; }
		}

		form.addEventListener( 'submit', function ( e ) {
			e.preventDefault();
			msg.textContent = '';
			msg.className = 'dxp-cform-msg';
			if ( btn ) { btn.disabled = true; }

			/* Ortak doğrulama: zorunlu + e-posta/telefon formatı + uzunluk. */
			if ( window.dxpFormValidate && ! window.dxpFormValidate( form ) ) {
				fail( box.getAttribute( 'data-required' ) );
				return;
			}

			var consent = form.querySelector( '[name="consent"]' );
			if ( consent && ! consent.checked ) { fail( box.getAttribute( 'data-consent' ) ); return; }

			var fd = new FormData( form );
			fd.append( 'action', 'devxpe_contact_submit' );
			fd.append( 'nonce', box.getAttribute( 'data-nonce' ) );

			function send() {
				fetch( box.getAttribute( 'data-ajax' ), { method: 'POST', body: fd } )
					.then( function ( r ) { return r.json(); } )
					.then( function ( d ) {
						if ( d && d.success ) {
							msg.textContent = d.data.message;
							msg.className = 'dxp-cform-msg is-ok';
							form.reset();
							if ( btn ) { btn.disabled = false; }
						} else {
							fail( ( d && d.data && d.data.message ) ? d.data.message : box.getAttribute( 'data-error' ) );
						}
					} )
					.catch( function () { fail( box.getAttribute( 'data-error' ) ); } );
			}

			/* reCAPTCHA v3 açıksa token alınıp gönderilir. */
			if ( window.dxpRecaptchaKey && window.grecaptcha ) {
				grecaptcha.ready( function () {
					grecaptcha.execute( window.dxpRecaptchaKey, { action: 'dxp_form' } ).then( function ( token ) {
						if ( token ) { fd.append( 'dxp_recaptcha', token ); }
						send();
					} ).catch( send );
				} );
			} else {
				send();
			}
		} );
	} );
})();
</script>
