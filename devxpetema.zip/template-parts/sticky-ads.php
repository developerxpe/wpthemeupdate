<?php
/**
 * Sticky Ads (Sabit Sağ/Sol Skin Reklamları)
 */

$left_ad_enable  = devxpe_theme_get( 'left_ad_enable' );
$left_ad_code    = devxpe_theme_get( 'left_ad_code' );
$right_ad_enable = devxpe_theme_get( 'right_ad_enable' );
$right_ad_code   = devxpe_theme_get( 'right_ad_code' );

if ( '1' !== $left_ad_enable && '1' !== $right_ad_enable ) {
	return;
}
?>

<!-- Sol Reklam -->
<?php if ( '1' === $left_ad_enable && ! empty( $left_ad_code ) ) : ?>
<div class="dxp-sticky-ad dxp-sticky-ad-left" id="dxp-ad-left">
	<button class="dxp-sticky-close" onclick="dxpCloseAd('dxp-ad-left')" aria-label="Reklamı Kapat">&times;</button>
	<div class="dxp-sticky-content">
		<?php echo do_shortcode( $left_ad_code ); ?>
	</div>
</div>
<?php endif; ?>

<!-- Sağ Reklam -->
<?php if ( '1' === $right_ad_enable && ! empty( $right_ad_code ) ) : ?>
<div class="dxp-sticky-ad dxp-sticky-ad-right" id="dxp-ad-right">
	<button class="dxp-sticky-close" onclick="dxpCloseAd('dxp-ad-right')" aria-label="Reklamı Kapat">&times;</button>
	<div class="dxp-sticky-content">
		<?php echo do_shortcode( $right_ad_code ); ?>
	</div>
</div>
<?php endif; ?>

<script>
function dxpCloseAd(adId) {
	document.getElementById(adId).style.display = 'none';
	localStorage.setItem('dxp_closed_' + adId, 'true');
}

document.addEventListener('DOMContentLoaded', function() {
	if (localStorage.getItem('dxp_closed_dxp-ad-left') === 'true') {
		var lAd = document.getElementById('dxp-ad-left');
		if(lAd) lAd.style.display = 'none';
	}
	if (localStorage.getItem('dxp_closed_dxp-ad-right') === 'true') {
		var rAd = document.getElementById('dxp-ad-right');
		if(rAd) rAd.style.display = 'none';
	}
});
</script>
