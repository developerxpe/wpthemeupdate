<?php
/**
 * Arşiv ızgarası — blog/kategori/etiket ve içerik tipi (CPT) arşivlerinin
 * ortak gövdesi. Sorgular WordPress'in kendi ana sorgusudur; blog tarafı ile
 * CPT karışmaz. Görünüm ortaktır.
 *
 * $args:
 *   eyebrow     (string) Üst etiket metni.
 *   title       (string) H1 başlığı (düz metin).
 *   description (string) Alt açıklama (HTML'e izin verilir).
 *   filters     (bool)   Sağ sütunda blog yan paneli çizilsin mi (blog/kategori/etiket).
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$a = wp_parse_args(
	isset( $args ) ? (array) $args : array(),
	array(
		'eyebrow'     => '',
		'title'       => '',
		'description' => '',
		'filters'     => false,
	)
);

/*
 * Yan panel YALNIZCA Kategoriler bölümü oluşacaksa çizilir (3+ dolu kategori).
 * Kategori yoksa/azsa sağ sütun hiç açılmaz; blog tek sütun kalır. İçerik tipi
 * arşivlerinde yan panel yoktur.
 */
$dxp_side = false;

if ( $a['filters'] ) {
	$dxp_side = ( count( get_categories( array( 'hide_empty' => true ) ) ) >= 3 );
}

/* Kırıntı şeridi hemen üstte çizilirse bant ek üst boşluk istemez. */
$dxp_after_crumbs = ( '1' === devxpe_theme_get( 'breadcrumb_enabled', '1' ) );
?>
<section class="dxp-band dxp-band--paper dxp-page-band dxp-archive<?php echo $dxp_after_crumbs ? ' dxp-archive--after-crumbs' : ''; ?>">
	<div class="dxp-band-inner">

		<header class="dxp-archive-head">
			<?php if ( '' !== $a['eyebrow'] ) : ?>
			<p class="dxp-eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></p>
			<?php endif; ?>

			<?php if ( '' !== $a['title'] ) : ?>
			<h1 class="dxp-page-title"><?php echo esc_html( $a['title'] ); ?></h1>
			<?php endif; ?>

			<?php if ( '' !== $a['description'] ) : ?>
			<div class="dxp-page-lead dxp-archive-desc"><?php echo wp_kses_post( $a['description'] ); ?></div>
			<?php endif; ?>

		</header>

		<div class="dxp-archive-layout<?php echo $dxp_side ? ' has-sidebar' : ''; ?>">
			<div class="dxp-archive-main">

				<?php if ( have_posts() ) : ?>

					<div class="dxp-cards dxp-archive-grid">
						<?php
						while ( have_posts() ) :
							the_post();

							/* Başlıksız kayıt ızgarada boş kart olarak görünmesin. */
							if ( '' === trim( (string) get_the_title() ) ) {
								continue;
							}

							$dxp_is_post = ( 'post' === get_post_type() );
							?>
							<article id="post-<?php the_ID(); ?>" <?php post_class( 'dxp-archive-item' ); ?>>
								<a class="dxp-card dxp-archive-card" href="<?php the_permalink(); ?>">
									<div class="dxp-archive-media">
										<?php if ( has_post_thumbnail() ) : ?>
											<?php the_post_thumbnail( 'medium_large', array( 'loading' => 'lazy' ) ); ?>
										<?php else : ?>
											<span class="dxp-archive-media-ph" aria-hidden="true">
												<?php echo devxpe_lucide( 'layers' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
											</span>
										<?php endif; ?>
									</div>
									<div class="dxp-archive-card-body">
										<?php if ( $dxp_is_post ) : ?>
										<p class="dxp-archive-card-meta">
											<span class="dashicons dashicons-calendar-alt" aria-hidden="true"></span>
											<?php echo esc_html( get_the_date() ); ?>
										</p>
										<?php endif; ?>

										<h2 class="dxp-archive-card-title"><?php the_title(); ?></h2>

										<p class="dxp-archive-card-excerpt">
											<?php echo esc_html( wp_trim_words( get_the_excerpt(), 22, '…' ) ); ?>
										</p>

										<?php
										if ( $dxp_is_post ) :
											$dxp_cats = get_the_category();
											if ( $dxp_cats ) :
												?>
												<span class="dxp-archive-card-cats">
													<?php foreach ( $dxp_cats as $dxp_cat ) : ?>
													<span class="dxp-archive-cat"><?php echo esc_html( $dxp_cat->name ); ?></span>
													<?php endforeach; ?>
												</span>
												<?php
											endif;
										endif;
										?>

										<span class="dxp-card-link">
											<?php esc_html_e( 'Devamını oku', 'devxpe-theme' ); ?>
											<?php echo devxpe_lucide( 'arrow-right' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
										</span>
									</div>
								</a>
							</article>
							<?php
						endwhile;
						?>
					</div>

					<div class="dxp-archive-pagination">
						<?php
						the_posts_pagination(
							array(
								'mid_size'           => 1,
								'prev_text'          => esc_html__( 'Önceki', 'devxpe-theme' ),
								'next_text'          => esc_html__( 'Sonraki', 'devxpe-theme' ),
								'screen_reader_text' => esc_html__( 'Arşiv sayfaları', 'devxpe-theme' ),
							)
						);
						?>
					</div>

				<?php else : ?>

					<div class="dxp-archive-empty">
						<span class="dxp-archive-empty-icon" aria-hidden="true">
							<?php echo devxpe_lucide( 'layers' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
						</span>
						<h2 class="dxp-archive-empty-title"><?php esc_html_e( 'İçerik bulunamadı', 'devxpe-theme' ); ?></h2>
						<p class="dxp-archive-empty-text">
							<?php esc_html_e( 'Bu sayfada henüz yayınlanmış bir içerik yok. Lütfen daha sonra tekrar kontrol edin.', 'devxpe-theme' ); ?>
						</p>
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="dxp-btn dxp-btn--primary">
							<?php esc_html_e( 'Anasayfaya dön', 'devxpe-theme' ); ?>
						</a>
					</div>

				<?php endif; ?>

			</div><!-- /.dxp-archive-main -->

			<?php if ( $dxp_side ) : ?>
				<?php get_template_part( 'template-parts/blog-sidebar' ); ?>
			<?php endif; ?>
		</div><!-- /.dxp-archive-layout -->

	</div>
</section>
