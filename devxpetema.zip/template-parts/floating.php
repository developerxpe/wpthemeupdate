<?php
/**
 * Yüzen iletişim butonları (WhatsApp / Telefon / Yukarı Çık) ve duyuru popup'ı.
 *
 * Footer'ın sonunda çağrılır. Tüm ayarlar panelden yönetilir.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ── Yüzen butonlar ─────────────────────────────────────── */
if ( '1' === devxpe_theme_get( 'float_enable', '1' ) ) {

	$dxp_wa_number = trim( (string) devxpe_theme_get( 'float_whatsapp_number' ) );
	if ( '' === $dxp_wa_number ) {
		$dxp_wa_number = (string) devxpe_theme_get( 'whatsapp' );
	}
	$dxp_wa_digits = preg_replace( '/\D/', '', $dxp_wa_number );

	$dxp_wa_message = trim( (string) devxpe_theme_get( 'float_whatsapp_text' ) );

	$dxp_tel_number = trim( (string) devxpe_theme_get( 'float_phone_number' ) );
	if ( '' === $dxp_tel_number ) {
		$dxp_tel_number = (string) devxpe_theme_get( 'phone' );
	}
	$dxp_tel_href = preg_replace( '/\s+/', '', $dxp_tel_number );

	$dxp_wa_show  = ( '1' === devxpe_theme_get( 'float_whatsapp_enable', '1' ) && '' !== $dxp_wa_digits );
	$dxp_tel_show = ( '1' === devxpe_theme_get( 'float_phone_enable', '1' ) && '' !== $dxp_tel_href );
	$dxp_top_show = ( '1' === devxpe_theme_get( 'float_top_enable', '1' ) );
	$dxp_style    = (string) devxpe_theme_get( 'float_style', 'classic' );

	$dxp_wa_url = 'https://wa.me/' . $dxp_wa_digits;
	if ( '' !== $dxp_wa_message ) {
		$dxp_wa_url .= '?text=' . rawurlencode( $dxp_wa_message );
	}

	/* Alt bardaki teklif linki: boşsa header butonunun linki kullanılır. */
	$dxp_bar_url = (string) devxpe_theme_get( 'header_btn_url' );
	if ( '' === $dxp_bar_url ) {
		$dxp_bar_url = home_url( '/' );
	}

	/*
	 * Şablon 2 — Mobil Alt Bar: yalnızca telefonda, altta sabit üç buton
	 * (Ara | WhatsApp | Teklif Al). Şablon 1: klasik yüzen butonlar.
	 */
	if ( 'bar' === $dxp_style ) :
		/* Alt bar butonları panelden: ikon + yazı + link. Boş alanlar varsayılana düşer. */
		$dxp_mbar_tel_icon = (string) devxpe_theme_get( 'mbar_tel_icon', 'phone' );
		$dxp_mbar_tel_text = (string) devxpe_theme_get( 'mbar_tel_text' );
		$dxp_mbar_tel_url  = (string) devxpe_theme_get( 'mbar_tel_url' );
		$dxp_mbar_wa_icon  = (string) devxpe_theme_get( 'mbar_wa_icon' );
		$dxp_mbar_wa_text  = (string) devxpe_theme_get( 'mbar_wa_text' );
		$dxp_mbar_wa_url   = (string) devxpe_theme_get( 'mbar_wa_url' );
		$dxp_mbar_q_icon   = (string) devxpe_theme_get( 'mbar_quote_icon', 'file-text' );
		$dxp_mbar_q_text   = (string) devxpe_theme_get( 'mbar_quote_text' );
		$dxp_mbar_q_url    = (string) devxpe_theme_get( 'mbar_quote_url' );

		if ( '' === $dxp_mbar_tel_text ) { $dxp_mbar_tel_text = __( 'Ara', 'devxpe-theme' ); }
		if ( '' === $dxp_mbar_wa_text ) { $dxp_mbar_wa_text = 'WhatsApp'; }
		if ( '' === $dxp_mbar_q_text ) { $dxp_mbar_q_text = __( 'Teklif Al', 'devxpe-theme' ); }
		if ( '' === $dxp_mbar_q_url ) { $dxp_mbar_q_url = $dxp_bar_url; }

		$dxp_mbar_wa_svg = '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413Z"/></svg>';
		?>
	<div class="dxp-mbar">
		<?php if ( $dxp_tel_show ) : ?>
		<a class="dxp-mbar-item" href="<?php echo esc_url( $dxp_mbar_tel_url ? $dxp_mbar_tel_url : 'tel:' . $dxp_tel_href ); ?>">
			<?php echo devxpe_lucide( $dxp_mbar_tel_icon ? $dxp_mbar_tel_icon : 'phone' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<span><?php echo esc_html( $dxp_mbar_tel_text ); ?></span>
		</a>
		<?php endif; ?>

		<?php if ( $dxp_wa_show ) : ?>
		<a class="dxp-mbar-item dxp-mbar-main" href="<?php echo esc_url( $dxp_mbar_wa_url ? $dxp_mbar_wa_url : $dxp_wa_url ); ?>" target="_blank" rel="noopener noreferrer">
			<?php echo $dxp_mbar_wa_icon ? devxpe_lucide( $dxp_mbar_wa_icon ) : $dxp_mbar_wa_svg; // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<span><?php echo esc_html( $dxp_mbar_wa_text ); ?></span>
		</a>
		<?php endif; ?>

		<a class="dxp-mbar-item" href="<?php echo esc_url( $dxp_mbar_q_url ); ?>">
			<?php echo devxpe_lucide( $dxp_mbar_q_icon ? $dxp_mbar_q_icon : 'file-text' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<span><?php echo esc_html( $dxp_mbar_q_text ); ?></span>
		</a>
	</div>
		<?php
	endif;

	/*
	 * WhatsApp butonu: Şablon 1'de her boyutta; Şablon 2'de yalnızca masaüstünde
	 * (mobilde alt barda zaten var).
	 */
	if ( $dxp_wa_show ) :
		?>
	<a class="dxp-float dxp-float--wa<?php echo ( 'bar' === $dxp_style ) ? ' dxp-desktop-only' : ''; ?>" href="<?php echo esc_url( $dxp_wa_url ); ?>" target="_blank" rel="noopener noreferrer"
		aria-label="<?php esc_attr_e( 'WhatsApp ile yaz', 'devxpe-theme' ); ?>" title="WhatsApp">
		<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413Z"/></svg>
	</a>
		<?php
	endif;

	/* Klasik yüzen telefon butonu: yalnızca Şablon 1'de (bar modunda bar içinde). */
	if ( $dxp_tel_show && 'bar' !== $dxp_style ) :
		?>
	<a class="dxp-float dxp-float--tel" href="tel:<?php echo esc_attr( $dxp_tel_href ); ?>"
		aria-label="<?php esc_attr_e( 'Telefonla ara', 'devxpe-theme' ); ?>" title="<?php echo esc_attr( $dxp_tel_number ); ?>">
		<?php echo devxpe_lucide( 'phone' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
	</a>
		<?php
	endif;

	if ( $dxp_top_show ) :
		?>
	<button type="button" class="dxp-float dxp-float--top"
		aria-label="<?php esc_attr_e( 'Yukarı çık', 'devxpe-theme' ); ?>" title="<?php esc_attr_e( 'Yukarı çık', 'devxpe-theme' ); ?>">
		<?php echo devxpe_lucide( 'chevron-down' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
	</button>
		<?php
	endif;
}

/* ── Popup / duyuru ─────────────────────────────────────── */
if ( '1' !== devxpe_theme_get( 'popup_enable' ) ) {
	return;
}

$dxp_popup_trigger = (string) devxpe_theme_get( 'popup_trigger', 'both' );
$dxp_popup_scope   = (string) devxpe_theme_get( 'popup_scope', 'home' );
$dxp_popup_freq    = (string) devxpe_theme_get( 'popup_frequency', 'day' );
$dxp_popup_delay   = (int) devxpe_theme_get( 'popup_delay', '1' );

$dxp_popup_auto = ( 'auto' === $dxp_popup_trigger || 'both' === $dxp_popup_trigger );
if ( 'all' !== $dxp_popup_scope ) {
	$dxp_popup_auto = ( $dxp_popup_auto && is_front_page() );
}

$dxp_popup_title   = (string) devxpe_theme_get( 'popup_title' );
$dxp_popup_text    = (string) devxpe_theme_get( 'popup_text' );
$dxp_popup_image   = (string) devxpe_theme_get( 'popup_image' );
$dxp_popup_btn_txt = (string) devxpe_theme_get( 'popup_btn_text' );
$dxp_popup_btn_url = (string) devxpe_theme_get( 'popup_btn_url' );
?>
<div class="dxp-popup" id="dxp-popup" role="dialog" aria-modal="true" aria-labelledby="dxp-popup-title"
	data-auto="<?php echo $dxp_popup_auto ? '1' : '0'; ?>"
	data-frequency="<?php echo esc_attr( $dxp_popup_freq ); ?>"
	data-delay="<?php echo esc_attr( (string) $dxp_popup_delay ); ?>">
	<div class="dxp-popup-backdrop" data-dxp-popup-close></div>
	<div class="dxp-popup-box">
		<button type="button" class="dxp-popup-x" data-dxp-popup-close
			aria-label="<?php esc_attr_e( 'Kapat', 'devxpe-theme' ); ?>">&times;</button>

		<?php if ( $dxp_popup_image ) : ?>
		<div class="dxp-popup-img">
			<img src="<?php echo esc_url( $dxp_popup_image ); ?>" alt="" loading="lazy">
		</div>
		<?php endif; ?>

		<div class="dxp-popup-body">
			<?php if ( '' !== $dxp_popup_title ) : ?>
			<h3 class="dxp-popup-title" id="dxp-popup-title"><?php echo esc_html( $dxp_popup_title ); ?></h3>
			<?php endif; ?>

			<?php if ( '' !== $dxp_popup_text ) : ?>
			<div class="dxp-popup-text"><?php echo wp_kses_post( wpautop( $dxp_popup_text ) ); ?></div>
			<?php endif; ?>

			<?php if ( '' !== $dxp_popup_btn_txt && '' !== $dxp_popup_btn_url ) : ?>
			<a class="dxp-popup-btn" href="<?php echo esc_url( $dxp_popup_btn_url ); ?>"><?php echo esc_html( $dxp_popup_btn_txt ); ?></a>
			<?php endif; ?>
		</div>
	</div>
</div>
