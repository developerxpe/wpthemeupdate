<?php
/**
 * Anasayfa bölümleri (hero, hizmetler, vb.).
 *
 * Bu şablon header.php'deki 'devxpe_content_top' kancasından çağrılır,
 * böylece her bölüm paneldeki "Gösterileceği Yer" ayarına göre anasayfada,
 * tüm sayfalarda veya seçili sayfalarda görünebilir.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ══ Hero (Manşet) ═════════════════════════════════════ */
$dxp_sections = array();
ob_start();

/* Hero değerleri. */
$hero_badge    = devxpe_theme_get( 'hero_badge' );
$hero_title    = devxpe_theme_get( 'hero_title' );
$hero_subtitle = devxpe_theme_get( 'hero_subtitle' );
$hero_image    = devxpe_theme_get( 'hero_image' );
$hero_btn      = devxpe_theme_get( 'hero_btn_text' );
$hero_btn_url  = devxpe_theme_get( 'hero_btn_url' );
$hero_btn2     = devxpe_theme_get( 'hero_btn2_text' );
$hero_btn2_url = devxpe_theme_get( 'hero_btn2_url' );

/* Rozetler: değeri girilmemiş olanlar çizilmez. */
$hero_chips = array();
for ( $dxp_i = 1; $dxp_i <= 4; $dxp_i++ ) {
	$dxp_value = devxpe_theme_get( 'hero_stat_' . $dxp_i . '_value' );
	if ( '' === $dxp_value ) {
		continue;
	}
	$hero_chips[] = array(
		'icon'  => devxpe_theme_get( 'hero_stat_' . $dxp_i . '_icon', 'hammer' ),
		'value' => $dxp_value,
		'label' => devxpe_theme_get( 'hero_stat_' . $dxp_i . '_label' ),
	);
}

if ( devxpe_section_visible( 'hero' ) ) :

	/* Başlık yoksa site adı gösterilir (özgün, asla boş kalmaz). */
	if ( '' === trim( (string) $hero_title ) ) {
		$hero_title = get_bloginfo( 'name' );
	}

	/* İkinci buton boşsa telefon numarasına bağlanır. */
	$hero_phone = devxpe_theme_get( 'phone' );
	if ( ! $hero_btn2 && $hero_phone ) {
		$hero_btn2 = $hero_phone;
	}
	if ( ! $hero_btn2_url && $hero_phone ) {
		$hero_btn2_url = 'tel:' . preg_replace( '/\s+/', '', $hero_phone );
	}
	?>
<section class="dxp-hero">
	<div class="dxp-hero-inner">
		<div class="dxp-hero-copy">

			<?php if ( $hero_badge ) : ?>
			<span class="dxp-hero-badge">
				<span class="dxp-hero-badge-dot"></span>
				<?php echo esc_html( $hero_badge ); ?>
			</span>
			<?php endif; ?>

			<h1 class="dxp-hero-title"><?php echo esc_html( $hero_title ); ?></h1>

			<?php if ( $hero_subtitle ) : ?>
			<p class="dxp-hero-subtitle"><?php echo esc_html( $hero_subtitle ); ?></p>
			<?php endif; ?>

			<?php if ( $hero_btn || $hero_btn2 ) : ?>
			<div class="dxp-hero-buttons">
				<?php if ( $hero_btn ) : ?>
				<a href="<?php echo esc_url( $hero_btn_url ); ?>" class="dxp-btn dxp-btn--primary">
					<?php echo esc_html( $hero_btn ); ?>
					<?php echo devxpe_lucide( 'arrow-right' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				</a>
				<?php endif; ?>

				<?php if ( $hero_btn2 ) : ?>
				<a href="<?php echo esc_url( $hero_btn2_url ); ?>" class="dxp-btn dxp-btn--outline">
					<?php echo devxpe_lucide( 'phone' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
					<?php echo esc_html( $hero_btn2 ); ?>
				</a>
				<?php endif; ?>
			</div>
			<?php endif; ?>

			<?php if ( $hero_chips ) : ?>
			<div class="dxp-hero-chips">
				<?php foreach ( $hero_chips as $hero_chip ) : ?>
				<div class="dxp-chip">
					<?php echo devxpe_lucide( $hero_chip['icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
					<div class="dxp-chip-value"><?php echo esc_html( $hero_chip['value'] ); ?></div>
					<?php if ( $hero_chip['label'] ) : ?>
					<div class="dxp-chip-label"><?php echo esc_html( $hero_chip['label'] ); ?></div>
					<?php endif; ?>
				</div>
				<?php endforeach; ?>
			</div>
			<?php endif; ?>

		</div>

		<?php if ( $hero_image ) : ?>
		<div class="dxp-hero-media">
			<div class="dxp-hero-media-frame">
				<img src="<?php echo esc_url( $hero_image ); ?>" alt="<?php echo esc_attr( $hero_title ); ?>" fetchpriority="high" decoding="async">
			</div>
		</div>
		<?php endif; ?>
	</div>
</section>
	<?php
endif;

$dxp_sections['hero'] = ob_get_clean();

/* ══ Hizmetler — panel ayarlarına göre (kaynak / limit / etiketler) ══ */
$services_src = devxpe_theme_get( 'services_cards_source', 'cpt:services' );
$services_lim = devxpe_theme_get( 'services_cards_limit', '6' );
$services_items = array();
if ( 'manual' === $services_src ) {
	/* Panelde elle eklenen kartlar (görsel + başlık + metin + link). */
	foreach ( (array) devxpe_theme_get( 'services_cards' ) as $devxpe_row ) {
		if ( ! is_array( $devxpe_row ) || empty( $devxpe_row['title'] ) ) {
			continue;
		}
		$services_items[] = array(
			'image' => isset( $devxpe_row['image'] ) ? (string) $devxpe_row['image'] : '',
			'title' => (string) $devxpe_row['title'],
			'text'  => isset( $devxpe_row['text'] ) ? (string) $devxpe_row['text'] : '',
			'url'   => isset( $devxpe_row['url'] ) ? (string) $devxpe_row['url'] : '',
		);
	}
} elseif ( 'none' !== $services_src ) {
	$services_items = devxpe_cards_from_source( $services_src, $services_lim );
}

$dxp_secs_tag_src = devxpe_theme_get( 'services_terms_source', 'none' );
$services_tags    = ( 'none' !== $dxp_secs_tag_src )
	? devxpe_items_list( $dxp_secs_tag_src, devxpe_theme_get( 'services_terms_limit', '10' ) )
	: array();
ob_start();
if ( devxpe_section_visible( 'services' ) && ( $services_items || $services_tags ) ) :
	$services_eyebrow = devxpe_theme_get( 'services_eyebrow' );
	$services_title   = devxpe_theme_get( 'services_title' );
	$services_sub     = devxpe_theme_get( 'services_subtitle' );
	$services_more    = devxpe_theme_get( 'services_more_text' );
	if ( ! $services_more ) {
		$services_more = __( 'Daha fazla', 'devxpe-theme' );
	}
	?>
<section id="services" class="dxp-services">
	<div class="dxp-services-inner">

		<div class="dxp-section-head">
			<?php if ( $services_eyebrow ) : ?>
			<div class="dxp-eyebrow"><?php echo esc_html( $services_eyebrow ); ?></div>
			<?php endif; ?>
			<?php if ( $services_title ) : ?>
			<h2 class="dxp-section-h2"><?php echo esc_html( $services_title ); ?></h2>
			<?php endif; ?>
			<?php if ( $services_sub ) : ?>
			<p class="dxp-section-sub"><?php echo esc_html( $services_sub ); ?></p>
			<?php endif; ?>
		</div>

		<?php if ( $services_items ) : ?>
		<div class="dxp-cards">
			<?php foreach ( $services_items as $services_card ) : ?>
				<?php if ( ! empty( $services_card['url'] ) ) : ?>
				<a class="dxp-card" href="<?php echo esc_url( $services_card['url'] ); ?>">
					<?php if ( ! empty( $services_card['image'] ) ) : ?>
					<div class="dxp-card-media">
						<img src="<?php echo esc_url( $services_card['image'] ); ?>" alt="<?php echo esc_attr( $services_card['title'] ); ?>" loading="lazy" decoding="async">
					</div>
					<?php endif; ?>
					<div class="dxp-card-body">
						<?php if ( ! empty( $services_card['title'] ) ) : ?>
						<h3><?php echo esc_html( $services_card['title'] ); ?></h3>
						<?php endif; ?>
						<?php if ( ! empty( $services_card['text'] ) ) : ?>
						<p><?php echo esc_html( $services_card['text'] ); ?></p>
						<?php endif; ?>
						<span class="dxp-card-link">
							<?php echo esc_html( $services_more ); ?>
							<?php echo devxpe_lucide( 'arrow-right' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
						</span>
					</div>
				</a>
				<?php else : ?>
				<div class="dxp-card">
					<?php if ( ! empty( $services_card['image'] ) ) : ?>
					<div class="dxp-card-media">
						<img src="<?php echo esc_url( $services_card['image'] ); ?>" alt="<?php echo esc_attr( $services_card['title'] ); ?>" loading="lazy" decoding="async">
					</div>
					<?php endif; ?>
					<div class="dxp-card-body">
						<?php if ( ! empty( $services_card['title'] ) ) : ?>
						<h3><?php echo esc_html( $services_card['title'] ); ?></h3>
						<?php endif; ?>
						<?php if ( ! empty( $services_card['text'] ) ) : ?>
						<p><?php echo esc_html( $services_card['text'] ); ?></p>
						<?php endif; ?>
					</div>
				</div>
				<?php endif; ?>
			<?php endforeach; ?>
		</div>
		<?php endif; ?>

		<?php if ( $services_tags ) : ?>
		<div class="dxp-tagrow">
			<?php foreach ( $services_tags as $services_tag ) : ?>
			<?php echo devxpe_item_link( $services_tag ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<?php endforeach; ?>
		</div>
		<?php endif; ?>

	</div>
</section>
	<?php
endif;

$dxp_sections['services'] = ob_get_clean();
ob_start();

/* ══ Neden Biz ════════════════════════════════════════ */
$features_items = array_values(
	array_filter(
		(array) devxpe_theme_get( 'features_items' ),
		function ( $row ) {
			return is_array( $row ) && ( ! empty( $row['title'] ) || ! empty( $row['text'] ) );
		}
	)
);

if ( devxpe_section_visible( 'features' ) && $features_items ) :
	$features_eyebrow = devxpe_theme_get( 'features_eyebrow' );
	$features_title   = devxpe_theme_get( 'features_title' );
	?>
<section class="dxp-features">
	<div class="dxp-services-inner">
		<div class="dxp-section-head">
			<?php if ( $features_eyebrow ) : ?>
			<div class="dxp-eyebrow"><?php echo esc_html( $features_eyebrow ); ?></div>
			<?php endif; ?>
			<?php if ( $features_title ) : ?>
			<h2 class="dxp-section-h2"><?php echo esc_html( $features_title ); ?></h2>
			<?php endif; ?>
		</div>

		<div class="dxp-features-grid">
			<?php foreach ( $features_items as $features_row ) : ?>
			<div class="dxp-feature">
				<?php echo devxpe_lucide( $features_row['icon'], 'dxp-ic--lg' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				<?php if ( ! empty( $features_row['title'] ) ) : ?>
				<h3><?php echo esc_html( $features_row['title'] ); ?></h3>
				<?php endif; ?>
				<?php if ( ! empty( $features_row['text'] ) ) : ?>
				<p><?php echo esc_html( $features_row['text'] ); ?></p>
				<?php endif; ?>
			</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>
	<?php
endif;

$dxp_sections['features'] = ob_get_clean();
ob_start();

/* ══ Nasıl Çalışır ════════════════════════════════════ */
$steps_items = array_values(
	array_filter(
		(array) devxpe_theme_get( 'steps_items' ),
		function ( $row ) {
			return is_array( $row ) && ( ! empty( $row['title'] ) || ! empty( $row['text'] ) );
		}
	)
);

if ( devxpe_section_visible( 'steps' ) && $steps_items ) :
	$steps_eyebrow = devxpe_theme_get( 'steps_eyebrow' );
	$steps_title   = devxpe_theme_get( 'steps_title' );
	$steps_sub     = devxpe_theme_get( 'steps_subtitle' );
	?>
<section class="dxp-steps">
	<div class="dxp-services-inner">
		<div class="dxp-section-head">
			<?php if ( $steps_eyebrow ) : ?>
			<div class="dxp-eyebrow"><?php echo esc_html( $steps_eyebrow ); ?></div>
			<?php endif; ?>
			<?php if ( $steps_title ) : ?>
			<h2 class="dxp-section-h2"><?php echo esc_html( $steps_title ); ?></h2>
			<?php endif; ?>
			<?php if ( $steps_sub ) : ?>
			<p class="dxp-section-sub"><?php echo esc_html( $steps_sub ); ?></p>
			<?php endif; ?>
		</div>

		<ol class="dxp-steps-grid">
			<?php
			$steps_index = 0;
			foreach ( $steps_items as $steps_row ) :
				$steps_index++;
				?>
			<li class="dxp-step">
				<span class="dxp-step-num"><?php echo absint( $steps_index ); ?></span>
				<?php if ( ! empty( $steps_row['title'] ) ) : ?>
				<h3><?php echo esc_html( $steps_row['title'] ); ?></h3>
				<?php endif; ?>
				<?php if ( ! empty( $steps_row['text'] ) ) : ?>
				<p><?php echo esc_html( $steps_row['text'] ); ?></p>
				<?php endif; ?>
			</li>
			<?php endforeach; ?>
		</ol>
	</div>
</section>
	<?php
endif;

$dxp_sections['steps'] = ob_get_clean();
ob_start();

/* ══ Projeler ═════════════════════════════════════════ */
$projects_source = devxpe_theme_get( 'projects_source', 'manual' );
$projects_items  = devxpe_cards_from_source( $projects_source, devxpe_theme_get( 'projects_limit', '6' ) );

if ( ! $projects_items ) {
	$projects_items = array_values(
		array_filter(
			(array) devxpe_theme_get( 'projects_items' ),
			function ( $row ) {
				return is_array( $row ) && ( ! empty( $row['title'] ) || ! empty( $row['image'] ) );
			}
		)
	);
}

/* Etiket satırı: panelde seçilen kaynaktan otomatik doldurulur. */
$projects_tags      = array();
$projects_terms_src = devxpe_theme_get( 'projects_terms_source', 'none' );
if ( 'none' !== $projects_terms_src ) {
	$projects_tags = devxpe_items_list( $projects_terms_src, devxpe_theme_get( 'projects_terms_limit', '10' ) );
}

if ( devxpe_section_visible( 'projects' ) && ( $projects_items || $projects_tags ) ) :
	$projects_eyebrow = devxpe_theme_get( 'projects_eyebrow' );
	$projects_title   = devxpe_theme_get( 'projects_title' );
	$projects_sub     = devxpe_theme_get( 'projects_subtitle' );
	?>
<section class="dxp-projects">
	<div class="dxp-services-inner">
		<div class="dxp-section-head">
			<?php if ( $projects_eyebrow ) : ?>
			<div class="dxp-eyebrow"><?php echo esc_html( $projects_eyebrow ); ?></div>
			<?php endif; ?>
			<?php if ( $projects_title ) : ?>
			<h2 class="dxp-section-h2"><?php echo esc_html( $projects_title ); ?></h2>
			<?php endif; ?>
			<?php if ( $projects_sub ) : ?>
			<p class="dxp-section-sub"><?php echo esc_html( $projects_sub ); ?></p>
			<?php endif; ?>
		</div>

		<?php if ( $projects_items ) : ?>
		<div class="dxp-projects-grid">
			<?php foreach ( $projects_items as $projects_row ) : ?>
			<figure class="dxp-project">
				<?php if ( ! empty( $projects_row['image'] ) ) : ?>
				<div class="dxp-project-media">
					<img src="<?php echo esc_url( $projects_row['image'] ); ?>" alt="<?php echo esc_attr( $projects_row['title'] ); ?>" loading="lazy" decoding="async">
				</div>
				<?php endif; ?>
				<figcaption>
					<?php if ( ! empty( $projects_row['title'] ) ) : ?>
					<h3><?php echo esc_html( $projects_row['title'] ); ?></h3>
					<?php endif; ?>
					<?php if ( ! empty( $projects_row['text'] ) ) : ?>
					<p><?php echo esc_html( $projects_row['text'] ); ?></p>
					<?php endif; ?>
				</figcaption>
			</figure>
			<?php endforeach; ?>
		</div>
		<?php endif; ?>

		<?php if ( $projects_tags ) : ?>
		<div class="dxp-tagrow">
			<?php foreach ( $projects_tags as $projects_tag ) : ?>
			<?php echo devxpe_item_link( $projects_tag ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<?php endforeach; ?>
		</div>
		<?php endif; ?>

	</div>
</section>
	<?php
endif;

$dxp_sections['projects'] = ob_get_clean();
ob_start();

/* ══ Yorumlar ═════════════════════════════════════════ */
$reviews_items = array_values(
	array_filter(
		(array) devxpe_theme_get( 'reviews_items' ),
		function ( $row ) {
			return is_array( $row ) && ( ! empty( $row['title'] ) || ! empty( $row['text'] ) );
		}
	)
);

if ( devxpe_section_visible( 'reviews' ) && $reviews_items ) :
	$reviews_eyebrow = devxpe_theme_get( 'reviews_eyebrow' );
	$reviews_title   = devxpe_theme_get( 'reviews_title' );
	$reviews_rating  = absint( devxpe_theme_get( 'reviews_rating', '5' ) );
	$reviews_note    = devxpe_theme_get( 'reviews_note' );
	?>
<section class="dxp-reviews">
	<div class="dxp-services-inner">
		<div class="dxp-section-head">
			<?php if ( $reviews_eyebrow ) : ?>
			<div class="dxp-eyebrow"><?php echo esc_html( $reviews_eyebrow ); ?></div>
			<?php endif; ?>
			<?php if ( $reviews_title ) : ?>
			<h2 class="dxp-section-h2"><?php echo esc_html( $reviews_title ); ?></h2>
			<?php endif; ?>
		</div>

		<div class="dxp-reviews-grid">
			<?php foreach ( $reviews_items as $reviews_row ) : ?>
			<figure class="dxp-review">
				<?php if ( $reviews_rating > 0 ) : ?>
				<div class="dxp-stars" role="img" aria-label="<?php echo esc_attr( sprintf( __( '%d yıldız', 'devxpe-theme' ), $reviews_rating ) ); ?>">
					<?php
					for ( $dxp_star = 0; $dxp_star < $reviews_rating; $dxp_star++ ) {
						echo devxpe_lucide( 'star' ); // phpcs:ignore WordPress.Security.EscapeOutput
					}
					?>
				</div>
				<?php endif; ?>
				<?php if ( ! empty( $reviews_row['text'] ) ) : ?>
				<blockquote><?php echo esc_html( $reviews_row['text'] ); ?></blockquote>
				<?php endif; ?>
				<?php if ( ! empty( $reviews_row['title'] ) ) : ?>
				<figcaption><?php echo esc_html( $reviews_row['title'] ); ?></figcaption>
				<?php endif; ?>
			</figure>
			<?php endforeach; ?>
		</div>

		<?php if ( $reviews_note ) : ?>
		<p class="dxp-reviews-note"><?php echo esc_html( $reviews_note ); ?></p>
		<?php endif; ?>
	</div>
</section>
	<?php
endif;

$dxp_sections['reviews'] = ob_get_clean();
ob_start();

/* ══ Bölgeler ═════════════════════════════════════════ */
$areas_tags = array();
$areas_src  = devxpe_theme_get( 'areas_terms_source', 'none' );
if ( 'none' !== $areas_src ) {
	$areas_tags = devxpe_items_list( $areas_src, devxpe_theme_get( 'areas_terms_limit', '12' ) );
}

if ( devxpe_section_visible( 'areas' ) && $areas_tags ) :
	$areas_eyebrow = devxpe_theme_get( 'areas_eyebrow' );
	$areas_title   = devxpe_theme_get( 'areas_title' );
	$areas_sub     = devxpe_theme_get( 'areas_subtitle' );
	?>
<section class="dxp-areas">
	<div class="dxp-services-inner">
		<div class="dxp-section-head">
			<?php if ( $areas_eyebrow ) : ?>
			<div class="dxp-eyebrow"><?php echo esc_html( $areas_eyebrow ); ?></div>
			<?php endif; ?>
			<?php if ( $areas_title ) : ?>
			<h2 class="dxp-section-h2"><?php echo esc_html( $areas_title ); ?></h2>
			<?php endif; ?>
			<?php if ( $areas_sub ) : ?>
			<p class="dxp-section-sub"><?php echo esc_html( $areas_sub ); ?></p>
			<?php endif; ?>
		</div>

		<div class="dxp-tagrow">
			<?php foreach ( $areas_tags as $areas_tag ) : ?>
			<?php echo devxpe_item_link( $areas_tag, 'dxp-tag dxp-tag--lg' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<?php endforeach; ?>
		</div>
	</div>
</section>
	<?php
endif;

$dxp_sections['areas'] = ob_get_clean();
ob_start();

/* ══ SSS ══════════════════════════════════════════════ */
$faq_items = array_values(
	array_filter(
		(array) devxpe_theme_get( 'faq_items' ),
		function ( $row ) {
			return is_array( $row ) && ( ! empty( $row['title'] ) || ! empty( $row['text'] ) );
		}
	)
);

if ( devxpe_section_visible( 'faq' ) && $faq_items ) :
	$faq_eyebrow = devxpe_theme_get( 'faq_eyebrow' );
	$faq_title   = devxpe_theme_get( 'faq_title' );
	?>
<section class="dxp-faq">
	<div class="dxp-services-inner dxp-faq-inner">
		<div class="dxp-section-head">
			<?php if ( $faq_eyebrow ) : ?>
			<div class="dxp-eyebrow"><?php echo esc_html( $faq_eyebrow ); ?></div>
			<?php endif; ?>
			<?php if ( $faq_title ) : ?>
			<h2 class="dxp-section-h2"><?php echo esc_html( $faq_title ); ?></h2>
			<?php endif; ?>
		</div>

		<div class="dxp-accordion">
			<?php foreach ( $faq_items as $faq_row ) : ?>
			<details class="dxp-acc">
				<summary class="dxp-acc-btn">
					<span><?php echo esc_html( $faq_row['title'] ); ?></span>
					<?php echo devxpe_lucide( 'chevron-down', 'dxp-acc-chev' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				</summary>
				<?php if ( ! empty( $faq_row['text'] ) ) : ?>
				<div class="dxp-acc-panel"><p><?php echo esc_html( $faq_row['text'] ); ?></p></div>
				<?php endif; ?>
			</details>
			<?php endforeach; ?>
		</div>
	</div>
</section>
	<?php
endif;

$dxp_sections['faq'] = ob_get_clean();
ob_start();

/* ══ Teklif Formu ═════════════════════════════════════ */
/* Taze kurulumda form ayarı hiç kaydedilmemişse çizilmez (boş anasayfa). */
if ( devxpe_section_visible( 'form' ) && ( devxpe_option_stored( 'form_enable' ) || devxpe_option_stored( 'home_form_choice' ) ) ) {
	devxpe_render_form_choice( devxpe_theme_get( 'home_form_choice', 'quote' ) );
}

$dxp_sections['form'] = ob_get_clean();

/*
 * Bölümler yukarıda tamponlandı; paneldeki "Aktif Olanlar" listesinde
 * belirlenen sıraya göre basılır. Kayıtlı sırada olmayan bölümler
 * devxpe_home_sections_order() tarafından sona eklenir.
 */


/*
 * Yalnızca "yan yana" işaretlenmiş bölümler aynı satırı paylaşır: arka arkaya
 * gelen işaretli bölümler eşit sütunlara bölünür. İşaretsiz bölüm her zaman
 * tam genişlik kalır; işaretli olup komşusu işaretsiz olan bölüm de tek başına
 * tam genişlik çizilir (ön yüzde boşluk bırakılmaz).
 */
$dxp_order = devxpe_home_sections_order();
$dxp_split = devxpe_home_section_splits();
$dxp_count = count( $dxp_order );

for ( $dxp_i = 0; $dxp_i < $dxp_count; $dxp_i++ ) {
	$dxp_id = $dxp_order[ $dxp_i ];

	if ( empty( $dxp_sections[ $dxp_id ] ) ) {
		continue;
	}

	$dxp_group  = array( $dxp_id );
	$dxp_cursor = $dxp_i;

	if ( in_array( $dxp_id, $dxp_split, true ) ) {
		while ( true ) {
			$dxp_next = -1;

			for ( $dxp_j = $dxp_cursor + 1; $dxp_j < $dxp_count; $dxp_j++ ) {
				if ( ! empty( $dxp_sections[ $dxp_order[ $dxp_j ] ] ) ) {
					$dxp_next = $dxp_j;
					break;
				}
			}

			if ( $dxp_next < 0 || ! in_array( $dxp_order[ $dxp_next ], $dxp_split, true ) ) {
				break;
			}

			$dxp_group[] = $dxp_order[ $dxp_next ];
			$dxp_cursor  = $dxp_next;
		}
	}

	$dxp_size = count( $dxp_group );

	if ( $dxp_size > 1 ) {
		echo '<div class="dxp-rows-side" style="--dxp-cols:' . absint( $dxp_size ) . '">';
	}

	foreach ( $dxp_group as $dxp_group_id ) {
		echo $dxp_sections[ $dxp_group_id ]; // phpcs:ignore WordPress.Security.EscapeOutput
		unset( $dxp_sections[ $dxp_group_id ] );
	}

	if ( $dxp_size > 1 ) {
		echo '</div>';
	}
}
