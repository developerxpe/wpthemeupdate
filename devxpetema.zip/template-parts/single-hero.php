<?php
/**
 * Detay sayfası manşeti — hizmet/bölge düzeni.
 *
 * Kırıntı menü ve manşet bandı single.php'de açılır; bu parça yalnızca
 * başlık + lead + CTA'lar + rozet/istatistik şeridi + manşet görseli
 * ızgarasını basar. Tüm alanlar içerik bazında meta ile doldurulur;
 * boş bırakılanlar panel ayarına / özete / öne çıkan görsele düşer
 * (mevcut davranış korunur).
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$dxp_banded = ! empty( $args['banded'] );
$dxp_pid    = get_the_ID();
$dxp_m      = function ( $key ) use ( $dxp_pid ) {
	return (string) get_post_meta( $dxp_pid, $key, true );
};

$dxp_phone = devxpe_theme_get( 'phone' );

/*
 * Bölüm modu (single.php) varsayılanları. Widget ayarı boş bırakılırsa bu
 * değerler kazanır; böylece manşet, widget ile bölüm modunda birebir aynı
 * HTML'i üretir.
 */

/* Rozet: içeriğe özel > panel ayarı */
$dxp_badge = $dxp_m( '_dxp_hero_badge' );
if ( '' === $dxp_badge ) {
	$dxp_badge = devxpe_theme_get( 'hero_badge', __( '24 saat içinde ücretsiz teklif', 'devxpe-theme' ) );
}

/* Lead paragraf: içeriğe özel > özet */
$dxp_subtitle = $dxp_m( '_dxp_hero_subtitle' );
if ( '' === $dxp_subtitle ) {
	$dxp_subtitle = has_excerpt() ? get_the_excerpt() : '';
}

/* Manşet görseli: içeriğe özel > öne çıkan görsel */
$dxp_image = $dxp_m( '_dxp_hero_image' );

/* 1. CTA "Ücretsiz Teklif": içeriğe özel > panel > form çapası */
$dxp_btn = $dxp_m( '_dxp_hero_btn_text' );
if ( '' === $dxp_btn ) {
	$dxp_btn = devxpe_theme_get( 'hero_btn_text' );
}
if ( '' === $dxp_btn ) {
	$dxp_btn = __( 'Ücretsiz Teklif', 'devxpe-theme' );
}
$dxp_btn_url = $dxp_m( '_dxp_hero_btn_url' );
if ( '' === $dxp_btn_url ) {
	$dxp_btn_url = devxpe_theme_get( 'hero_btn_url' );
}
if ( '' === $dxp_btn_url ) {
	$dxp_btn_url = '#quote';
}

/* 2. CTA (telefon): içeriğe özel yazı > panel telefonu */
$dxp_btn2 = $dxp_m( '_dxp_hero_btn2_text' );
if ( '' === $dxp_btn2 ) {
	$dxp_btn2 = $dxp_phone;
}
$dxp_btn2_url = $dxp_m( '_dxp_hero_btn2_url' );
if ( '' === $dxp_btn2_url && $dxp_phone ) {
	$dxp_btn2_url = 'tel:' . preg_replace( '/\s+/', '', $dxp_phone );
}

/* Rozet/istatistik şeridi: içeriğe özel > panel hero_stat_* */
$dxp_chips = array();
$dxp_own   = get_post_meta( $dxp_pid, '_dxp_hero_chips', true );

if ( is_array( $dxp_own ) && $dxp_own ) {
	foreach ( $dxp_own as $dxp_c ) {
		$dxp_chips[] = array(
			'icon'  => isset( $dxp_c['icon'] ) ? $dxp_c['icon'] : '',
			'value' => isset( $dxp_c['title'] ) ? $dxp_c['title'] : '',
			'label' => isset( $dxp_c['text'] ) ? $dxp_c['text'] : '',
		);
	}
} else {
	for ( $dxp_i = 1; $dxp_i <= 4; $dxp_i++ ) {
		$dxp_val = devxpe_theme_get( 'hero_stat_' . $dxp_i . '_value' );
		if ( '' === $dxp_val ) {
			continue;
		}
		$dxp_chips[] = array(
			'icon'  => devxpe_theme_get( 'hero_stat_' . $dxp_i . '_icon', 'hammer' ),
			'value' => $dxp_val,
			'label' => devxpe_theme_get( 'hero_stat_' . $dxp_i . '_label' ),
		);
	}
}

/* Bölge şablonu: görsel yerine konum satırı; rozetler yalnızca hizmet düzeninde. */
$dxp_location = $dxp_m( '_dxp_hero_location' );

$dxp_title = get_the_title();

/*
 * Widget modu: dolu ayarlar bölüm varsayılanlarını geçersiz kılar. Boş
 * bırakılan ayar, bölüm moduyla aynı sonucu verir (fallback).
 */
if ( ! empty( $args['widget'] ) ) {
	$dxp_baslik_k = isset( $args['baslik_kaynak'] ) ? (string) $args['baslik_kaynak'] : 'baslik';
	if ( 'meta' === $dxp_baslik_k ) {
		$dxp_meta_title = $dxp_m( '_dxp_hero_title' );
		if ( '' !== $dxp_meta_title ) {
			$dxp_title = $dxp_meta_title;
		}
	}

	$dxp_w_rozet = isset( $args['rozet'] ) ? trim( (string) $args['rozet'] ) : '';
	if ( '' !== $dxp_w_rozet ) {
		$dxp_badge = $dxp_w_rozet;
	}

	$dxp_w_lead = isset( $args['lead'] ) ? trim( (string) $args['lead'] ) : '';
	if ( '' !== $dxp_w_lead ) {
		$dxp_subtitle = $dxp_w_lead;
	}

	$dxp_w_konum = isset( $args['konum'] ) ? trim( (string) $args['konum'] ) : '';
	if ( '' !== $dxp_w_konum ) {
		$dxp_location = $dxp_w_konum;
	}

	$dxp_w_image = isset( $args['gorsel'] ) ? trim( (string) $args['gorsel'] ) : '';
	if ( '' !== $dxp_w_image ) {
		$dxp_image = $dxp_w_image;
	}

	$dxp_w_btn = isset( $args['btn1_metin'] ) ? trim( (string) $args['btn1_metin'] ) : '';
	if ( '' !== $dxp_w_btn ) {
		$dxp_btn = $dxp_w_btn;
	}
	$dxp_w_btn_url = isset( $args['btn1_link'] ) ? trim( (string) $args['btn1_link'] ) : '';
	if ( '' !== $dxp_w_btn_url ) {
		$dxp_btn_url = $dxp_w_btn_url;
	}

	$dxp_w_btn2 = isset( $args['btn2_metin'] ) ? trim( (string) $args['btn2_metin'] ) : '';
	if ( '' !== $dxp_w_btn2 ) {
		$dxp_btn2 = $dxp_w_btn2;
	}
	$dxp_w_btn2_url = isset( $args['btn2_link'] ) ? trim( (string) $args['btn2_link'] ) : '';
	if ( '' !== $dxp_w_btn2_url ) {
		$dxp_btn2_url = $dxp_w_btn2_url;
	}

	/* Rozetler ayarı doluysa istatistik şeridi ondan kurulur. */
	$dxp_w_rozetler = isset( $args['rozetler'] ) ? trim( (string) $args['rozetler'] ) : '';
	if ( '' !== $dxp_w_rozetler ) {
		$dxp_chips = array();
		foreach ( preg_split( '/\r\n|\r|\n/', $dxp_w_rozetler ) as $dxp_satir ) {
			$dxp_satir = trim( $dxp_satir );
			if ( '' === $dxp_satir ) {
				continue;
			}
			$dxp_p       = array_map( 'trim', explode( '|', $dxp_satir ) );
			$dxp_chips[] = array(
				'icon'  => isset( $dxp_p[0] ) ? $dxp_p[0] : '',
				'value' => isset( $dxp_p[1] ) ? $dxp_p[1] : '',
				'label' => isset( $dxp_p[2] ) ? $dxp_p[2] : '',
			);
		}
	}
}

$dxp_has_media = ( ! $dxp_banded && ( '' !== $dxp_image || has_post_thumbnail() ) );
$dxp_solo      = ( $dxp_banded || ! $dxp_has_media );
?>
<div class="dxp-detail-inner dxp-detail-hero-grid<?php echo $dxp_solo ? ' dxp-detail-hero-grid--solo' : ''; ?>">
	<div class="dxp-hero-copy">
		<?php if ( $dxp_badge ) : ?>
		<span class="dxp-hero-badge"><span class="dxp-hero-badge-dot"></span><?php echo esc_html( $dxp_badge ); ?></span>
		<?php endif; ?>

		<h1 class="dxp-detail-title"><?php echo esc_html( $dxp_title ); ?></h1>

		<?php if ( $dxp_subtitle ) : ?>
		<p class="dxp-detail-sub"><?php echo esc_html( $dxp_subtitle ); ?></p>
		<?php endif; ?>

		<?php if ( $dxp_location ) : ?>
		<p class="dxp-detail-location">
			<?php echo devxpe_lucide( 'map-pin' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<span><?php echo esc_html( $dxp_location ); ?></span>
		</p>
		<?php endif; ?>

		<?php if ( $dxp_btn || $dxp_btn2 ) : ?>
		<div class="dxp-hero-buttons">
			<?php if ( $dxp_btn ) : ?>
			<a href="<?php echo esc_url( $dxp_btn_url ); ?>" class="dxp-btn dxp-btn--primary">
				<?php echo esc_html( $dxp_btn ); ?>
				<?php echo devxpe_lucide( 'arrow-right' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			</a>
			<?php endif; ?>
			<?php if ( $dxp_btn2 ) : ?>
			<a href="<?php echo esc_url( $dxp_btn2_url ); ?>" class="dxp-btn dxp-btn--outline">
				<?php echo devxpe_lucide( 'phone' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				<?php echo esc_html( $dxp_btn2 ); ?>
			</a>
			<?php endif; ?>
		</div>
		<?php endif; ?>

		<?php if ( $dxp_chips && ! $dxp_banded ) : ?>
		<div class="dxp-hero-chips">
			<?php foreach ( $dxp_chips as $dxp_chip ) : ?>
			<div class="dxp-chip">
				<?php echo devxpe_lucide( $dxp_chip['icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				<div class="dxp-chip-value"><?php echo esc_html( $dxp_chip['value'] ); ?></div>
				<?php if ( $dxp_chip['label'] ) : ?>
				<div class="dxp-chip-label"><?php echo esc_html( $dxp_chip['label'] ); ?></div>
				<?php endif; ?>
			</div>
			<?php endforeach; ?>
		</div>
		<?php endif; ?>
	</div>

	<?php if ( $dxp_has_media ) : ?>
	<div class="dxp-hero-media">
		<div class="dxp-hero-media-frame">
			<?php if ( '' !== $dxp_image ) : ?>
			<img src="<?php echo esc_url( $dxp_image ); ?>" alt="<?php echo esc_attr( get_the_title() ); ?>" decoding="async" />
			<?php else : ?>
			<?php the_post_thumbnail( 'large', array( 'fetchpriority' => 'high', 'decoding' => 'async' ) ); ?>
			<?php endif; ?>
		</div>
	</div>
	<?php endif; ?>
</div>
