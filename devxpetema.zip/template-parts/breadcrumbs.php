<?php
/**
 * Kırıntı menü (breadcrumb).
 *
 * Kapsayıcı (container/band) üst şablonda sağlanır; bu parça yalnızca
 * nav + listeyi basar. Böylece hero/bant arkaplanını paylaşır (ARC düzeni).
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * Normal sayfalarda (page) kırıntı menü gösterilmez (ARC düzeni).
 * Yazı/içerik tipi detaylarında ve arşiv/aramada görünür.
 */
if ( '1' !== devxpe_theme_get( 'breadcrumb_enabled', '1' ) || is_front_page() || is_page() ) {
	return;
}
?>
<nav class="dxp-crumbs-wrap" aria-label="<?php esc_attr_e( 'Kırıntı menü', 'devxpe-theme' ); ?>">
	<ol class="dxp-crumbs">
		<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Anasayfa', 'devxpe-theme' ); ?></a></li>
		<li role="presentation" aria-hidden="true"><?php echo devxpe_lucide( 'chevron-right' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></li>
		<li>
			<span aria-current="page">
				<?php
				if ( is_singular() ) {
					echo esc_html( get_the_title( get_queried_object_id() ) );
				} elseif ( is_category() ) {
					echo esc_html( single_cat_title( '', false ) );
				} elseif ( is_search() ) {
					echo esc_html( sprintf( __( '"%s" için arama sonuçları', 'devxpe-theme' ), get_search_query() ) );
				} elseif ( is_archive() ) {
					echo esc_html( get_the_archive_title() );
				}
				?>
			</span>
		</li>
	</ol>
</nav>
