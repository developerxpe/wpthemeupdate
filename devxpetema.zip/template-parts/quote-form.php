<?php
/**
 * Teklif formu bölümü — iki varyant.
 *
 * - 'full'    : Anasayfa bölümü (kömür zemin, solda metin, sağda kart).
 * - 'compact' : Detay sayfası kartı (kömür çerçeve + başlık + iç beyaz kutu).
 *
 * Formun gövdesi tek yerde: template-parts/quote-form-fields.php
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$q = wp_parse_args(
	isset( $args ) ? (array) $args : array(),
	array(
		'variant'       => 'full',
		'groups'        => array(),
		'eyebrow'       => '',
		'title'         => '',
		'subtitle'      => '',
		'benefits'      => array(),
		'phone'         => '',
		'phone_text'    => '',
		'note'          => '',
		'steps'         => array(),
		'mini_title'    => '',
		'mini_subtitle' => '',
	)
);

if ( 'bare' === $q['variant'] ) :
	?>
	<div class="dxp-quote-bare">
		<?php get_template_part( 'template-parts/quote-form-fields', null, $q ); ?>
	</div>
	<?php
	return;
endif;

if ( 'compact' === $q['variant'] ) :
	?>
	<div class="dxp-quote-mini" id="quote">
		<?php if ( $q['mini_title'] ) : ?>
		<h3 class="dxp-quote-mini-title"><?php echo esc_html( $q['mini_title'] ); ?></h3>
		<?php endif; ?>
		<?php if ( $q['mini_subtitle'] ) : ?>
		<p class="dxp-quote-mini-sub"><?php echo esc_html( $q['mini_subtitle'] ); ?></p>
		<?php endif; ?>
		<div class="dxp-quote-mini-box">
			<?php get_template_part( 'template-parts/quote-form-fields', null, $q ); ?>
		</div>
	</div>
	<?php
	return;
endif;
?>
<section id="quote" class="dxp-quote">
	<div class="dxp-quote-inner">

		<div class="dxp-quote-copy">
			<?php if ( $q['eyebrow'] ) : ?>
			<div class="dxp-eyebrow"><?php echo esc_html( $q['eyebrow'] ); ?></div>
			<?php endif; ?>

			<?php if ( $q['title'] ) : ?>
			<h2 class="dxp-quote-title"><?php echo esc_html( $q['title'] ); ?></h2>
			<?php endif; ?>

			<?php if ( $q['subtitle'] ) : ?>
			<p class="dxp-quote-sub"><?php echo esc_html( $q['subtitle'] ); ?></p>
			<?php endif; ?>

			<?php if ( $q['benefits'] ) : ?>
			<ul class="dxp-quote-benefits">
				<?php foreach ( (array) $q['benefits'] as $q_benefit ) : ?>
				<li>
					<?php echo devxpe_lucide( 'circle-check' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
					<span><?php echo esc_html( $q_benefit ); ?></span>
				</li>
				<?php endforeach; ?>
			</ul>
			<?php endif; ?>

			<?php if ( $q['phone'] ) : ?>
			<div class="dxp-quote-call">
				<?php echo esc_html( $q['phone_text'] ); ?>
				<a href="tel:<?php echo esc_attr( preg_replace( '/\s+/', '', $q['phone'] ) ); ?>"><?php echo esc_html( $q['phone'] ); ?></a>
			</div>
			<?php endif; ?>
		</div>

		<div class="dxp-quote-card">
			<?php get_template_part( 'template-parts/quote-form-fields', null, $q ); ?>
		</div>

	</div>
</section>
