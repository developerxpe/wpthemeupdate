<?php
/**
 * Teklif formu bölümü — iki varyant.
 *
 * - 'full'    : Anasayfa bölümü (kömür zemin, solda metin, sağda kart).
 * - 'compact' : Detay sayfası kartı (kömür çerçeve + başlık + iç beyaz kutu).
 *
 * Formun gövdesi tek yerde: template-parts/quote-form-fields.php
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$q = wp_parse_args(
	isset( $args ) ? (array) $args : array(),
	array(
		'variant'       => 'full',
		'groups'        => array(),
		'eyebrow'       => '',
		'title'         => '',
		'subtitle'      => '',
		'benefits'      => array(),
		'phone'         => '',
		'phone_text'    => '',
		'note'          => '',
		'steps'         => array(),
		'form_slug'     => '',
		'mini_title'    => '',
		'mini_subtitle' => '',
	)
);

$dxp_body = function () use ( $q ) {
	/* Seçilen form bir özel form ise onun gövdesini, değilse adımlı teklif formunu çiz. */
	if ( ! empty( $q['form_slug'] ) ) {
		get_template_part( 'template-parts/contact-form', null, array( 'slug' => $q['form_slug'] ) );
		return;
	}
	get_template_part( 'template-parts/quote-form-fields', null, $q );
};

if ( 'bare' === $q['variant'] ) :
	?>
	<div class="dxp-quote-bare">
		<?php $dxp_body(); ?>
	</div>
	<?php
	return;
endif;

if ( 'compact' === $q['variant'] ) :
	?>
	<div class="dxp-quote-mini" id="quote">
		<div class="dxp-quote-mini-box">
			<?php $dxp_body(); ?>
		</div>
	</div>
	<?php
	return;
endif;
?>
<section id="quote" class="dxp-quote">
	<div class="dxp-quote-inner">

		<div class="dxp-quote-copy">
			<?php if ( $q['eyebrow'] ) : ?>
			<div class="dxp-eyebrow"><?php echo esc_html( $q['eyebrow'] ); ?></div>
			<?php endif; ?>

			<?php if ( $q['title'] ) : ?>
			<h2 class="dxp-quote-title"><?php echo esc_html( $q['title'] ); ?></h2>
			<?php endif; ?>

			<?php if ( $q['subtitle'] ) : ?>
			<p class="dxp-quote-sub"><?php echo esc_html( $q['subtitle'] ); ?></p>
			<?php endif; ?>

			<?php if ( $q['benefits'] ) : ?>
			<ul class="dxp-quote-benefits">
				<?php foreach ( (array) $q['benefits'] as $q_benefit ) : ?>
				<li>
					<?php echo devxpe_lucide( 'circle-check' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
					<span><?php echo esc_html( $q_benefit ); ?></span>
				</li>
				<?php endforeach; ?>
			</ul>
			<?php endif; ?>

			<?php if ( $q['phone'] ) : ?>
			<div class="dxp-quote-call">
				<?php echo esc_html( $q['phone_text'] ); ?>
				<a href="tel:<?php echo esc_attr( preg_replace( '/\s+/', '', $q['phone'] ) ); ?>"><?php echo esc_html( $q['phone'] ); ?></a>
			</div>
			<?php endif; ?>
		</div>

		<div class="dxp-quote-card">
			<?php $dxp_body(); ?>
		</div>

	</div>
</section>
