<?php
/**
 * Blog yan paneli — yalnızca tekil blog yazılarında gösterilir.
 *
 * WordPress widget altyapısı (dynamic_sidebar) KULLANILMAZ. Panelde sabit
 * olarak:
 *   - Arama kutusu,
 *   - Yazılar (son yazılar),
 *   - Kategoriler (yalnızca 3 veya daha fazla kategori varsa)
 * bulunur. Yalnızca normal yazıları kapsar; içerik tipleri karışmaz.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$dxp_current = is_singular( 'post' ) ? (int) get_queried_object_id() : 0;
?>
<aside class="dxp-blog-side" aria-label="<?php esc_attr_e( 'Blog yan paneli', 'devxpe-theme' ); ?>">

	<div class="dxp-widget">
		<h2 class="dxp-widget-title"><?php esc_html_e( 'Ara', 'devxpe-theme' ); ?></h2>
		<form role="search" method="get" class="dxp-side-search" action="<?php echo esc_url( home_url( '/' ) ); ?>">
			<label class="screen-reader-text" for="dxp-side-search-input"><?php esc_html_e( 'Ara', 'devxpe-theme' ); ?></label>
			<input type="search" id="dxp-side-search-input" class="dxp-side-search-input" name="s"
				value="<?php echo esc_attr( get_search_query() ); ?>"
				placeholder="<?php esc_attr_e( 'Yazılarda ara…', 'devxpe-theme' ); ?>" autocomplete="off" />
			<button type="submit" class="dxp-side-search-btn">
				<?php echo devxpe_lucide( 'search' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				<span class="screen-reader-text"><?php esc_html_e( 'Ara', 'devxpe-theme' ); ?></span>
			</button>
		</form>
	</div>

	<?php
	$dxp_recent = new WP_Query(
		array(
			'post_type'           => 'post',
			'post_status'         => 'publish',
			'posts_per_page'      => 5,
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
			'post__not_in'        => $dxp_current ? array( $dxp_current ) : array(),
		)
	);

	if ( $dxp_recent->have_posts() ) :
		?>
		<div class="dxp-widget">
			<h2 class="dxp-widget-title"><?php esc_html_e( 'Yazılar', 'devxpe-theme' ); ?></h2>
			<ul class="dxp-widget-posts">
				<?php
				while ( $dxp_recent->have_posts() ) :
					$dxp_recent->the_post();
					?>
					<li>
						<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
						<span class="dxp-widget-date"><?php echo esc_html( get_the_date() ); ?></span>
					</li>
					<?php
				endwhile;
				?>
			</ul>
		</div>
		<?php
		wp_reset_postdata();
	endif;

	/* Kategoriler yalnızca 3 veya daha fazlaysa gösterilir. */
	$dxp_cats = get_categories(
		array(
			'hide_empty' => true,
			'orderby'    => 'count',
			'order'      => 'DESC',
		)
	);

	if ( count( $dxp_cats ) >= 3 ) :
		?>
		<div class="dxp-widget">
			<h2 class="dxp-widget-title"><?php esc_html_e( 'Kategoriler', 'devxpe-theme' ); ?></h2>
			<ul class="dxp-widget-cats">
				<?php foreach ( $dxp_cats as $dxp_cat ) : ?>
					<li>
						<a href="<?php echo esc_url( get_category_link( $dxp_cat ) ); ?>">
							<span><?php echo esc_html( $dxp_cat->name ); ?></span>
							<span class="dxp-widget-count"><?php echo absint( $dxp_cat->count ); ?></span>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	<?php endif; ?>

</aside>
