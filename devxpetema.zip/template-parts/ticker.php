<?php
/**
 * Ticker (Haber Bandı) Bileşeni
 *
 * @package Devxpe_Theme
 */

if ( '1' !== devxpe_theme_get( 'ticker_enabled' ) ) {
	return;
}

$ticker_title = devxpe_theme_get( 'ticker_title', __( 'Son Dakika', 'devxpe-theme' ) );
$ticker_text  = devxpe_theme_get( 'ticker_text' );
$ticker_speed = devxpe_theme_get( 'ticker_speed', 'normal' );
$ticker_bg    = devxpe_theme_get( 'ticker_bg', '#1e73be' );

if ( ! $ticker_text ) {
	return;
}

$lines = devxpe_lines( $ticker_text );
if ( empty( $lines ) ) {
	return;
}

$speed_class = 'dxp-ticker-speed-' . $ticker_speed;
?>
<div class="dxp-ticker-wrap" style="background-color: <?php echo esc_attr( $ticker_bg ); ?>;">
	<div class="<?php echo esc_attr( devxpe_get_container_class() ); ?>">
		<div class="dxp-ticker-inner">
			<div class="dxp-ticker-label">
				<?php echo esc_html( $ticker_title ); ?>
			</div>
			<div class="dxp-ticker-content">
				<div class="dxp-ticker-marquee <?php echo esc_attr( $speed_class ); ?>">
					<?php foreach ( $lines as $line ) : ?>
						<span class="dxp-ticker-item"><?php echo wp_kses_post( $line ); ?></span>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
	</div>
</div>
