<?php
/**
 * Kategori arşivi şablonu — blog tarafı.
 *
 * Yalnızca kategoriye giren normal yazıları listeler; içerik tipleri dâhil
 * edilmez. Görünüm arşivlerle ortaktır.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

get_template_part(
	'template-parts/archive-grid',
	null,
	array(
		'eyebrow'     => __( 'Kategori', 'devxpe-theme' ),
		'title'       => single_cat_title( '', false ),
		'description' => get_the_archive_description(),
		'filters'     => true,
	)
);

get_footer();
