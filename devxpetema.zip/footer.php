<?php
/**
 * Alt bilgi şablonu (tema tasarımı).
 *
 * Yapı: marka sütunu (logo + açıklama + not + iletişim) + iki link sütunu
 * (panelden seçilen kaynaktan otomatik dolar) + telif/yasal alt çubuk.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * Footer TEK düzendir (marka + link sütunları + alt şerit). Eski
 * `footer_style` ("Sade — yalnız telif") düzeni kaldırıldı; kayıtlı
 * değer artık okunmaz.
 */

$site_name = devxpe_theme_get( 'site_title', get_bloginfo( 'name' ) );
$phone     = devxpe_theme_get( 'phone' );
$email     = devxpe_theme_get( 'email' );
$address   = devxpe_theme_get( 'address' );
$year      = gmdate( 'Y' );

$footer_logo = (string) devxpe_theme_get( 'footer_logo' );
$footer_bg   = (string) devxpe_theme_get( 'footer_bg', '#09090b' );
$logo        = $footer_logo;

/*
 * Footer zemini koyuysa footer'a özel "Koyu Zemin Logosu" önceliklidir;
 * yoksa Footer Logosu, o da yoksa zemine uygun site logosu kullanılır.
 * Beyaz plaka eklenmez; logo rengi çevrilmez.
 */
if ( devxpe_bg_is_dark( $footer_bg ) ) {
	$footer_logo_dark = (string) devxpe_theme_get( 'footer_logo_dark' );
	if ( '' !== trim( $footer_logo_dark ) ) {
		$logo = $footer_logo_dark;
	}
}
if ( ! $logo ) {
	$logo = devxpe_brand_logo( $footer_bg );
}

$about = devxpe_theme_get( 'footer_about_text' );
if ( ! $about ) {
	$about = devxpe_theme_get( 'site_description' );
}
if ( ! $about ) {
	$about = get_bloginfo( 'description' );
}

$note = devxpe_theme_get( 'footer_note' );

/* Link sütunları: panelde seçilen kaynaktan + işaretlenen öğelerden doldurulur. */
$col2    = array();
$col2_src = devxpe_theme_get( 'footer_col2_source', 'page' );
if ( 'none' !== $col2_src ) {
	$col2 = devxpe_items_list_selected( $col2_src, devxpe_theme_get( 'footer_col2_limit', '8' ), devxpe_theme_get( 'footer_col2_items', null ) );
}

$col3    = array();
$col3_src = devxpe_theme_get( 'footer_col3_source', 'category' );
if ( 'none' !== $col3_src ) {
	$col3 = devxpe_items_list_selected( $col3_src, devxpe_theme_get( 'footer_col3_limit', '8' ), devxpe_theme_get( 'footer_col3_items', null ) );
}

/* Yasal linkler (telif metninin yanı). Kaynak `legacy` ise eski
   `footer_legal_pages` listesi kullanılır; yeni kaynakta menü/sayfa seçimi. */
$legal        = array();
$legal_source = (string) devxpe_theme_get( 'footer_legal_source', 'legacy' );
$legal_items  = devxpe_theme_get( 'footer_legal_items', null );

/* Eski demo "none" kaydı, dolu yasal pages listesini gizlemesin (ilk kayıta kadar). */
if ( 'none' === $legal_source && ! is_array( $legal_items ) && devxpe_theme_get( 'footer_legal_pages' ) ) {
	$legal_source = 'legacy';
}

if ( '' === $legal_source || 'legacy' === $legal_source ) {
	$legal_pages = devxpe_theme_get( 'footer_legal_pages' );

	if ( is_array( $legal_pages ) && $legal_pages ) {
		$privacy_ozel = trim( (string) devxpe_theme_get( 'privacy_url', '' ) );

		foreach ( $legal_pages as $legal_pid ) {
			$legal_page = get_post( absint( $legal_pid ) );

			if ( ! $legal_page || 'page' !== $legal_page->post_type || 'publish' !== $legal_page->post_status ) {
				continue;
			}

			$legal_url = (string) get_permalink( $legal_page );

			/* Elle verilen gizlilik linki varsa footer'da da o kullanılır. */
			if ( '' !== $privacy_ozel
				&& ( false !== strpos( (string) $legal_page->post_name, 'gizlilik' ) || false !== strpos( (string) $legal_page->post_name, 'privacy' ) ) ) {
				$legal_url = $privacy_ozel;
			}

			$legal[] = array( 'title' => get_the_title( $legal_page ), 'url' => $legal_url );
		}
	}
} elseif ( 'none' !== $legal_source ) {
	$legal = devxpe_items_list_selected( $legal_source, 0, $legal_items );
}

$copyright = devxpe_theme_get( 'footer_copyright', __( 'Tüm hakları saklıdır', 'devxpe-theme' ) );

$footer_attrs = 'background-color: var(--dxp-footer-bg); color: var(--dxp-footer-text);';

/* Mobilde 2. ve 3. sütun yan yana (panel seçeneği). */
$cols_side = ( '1' === devxpe_theme_get( 'footer_cols_mobile_side' ) );
?>

</div><!-- /#content -->

<!-- ══ FOOTER ════════════════════════════════════════════ -->
<?php do_action( 'devxpe_before_footer' ); ?>

<?php devxpe_render_ad( 'footer_ad' ); ?>

<footer class="dxp-footer" role="contentinfo" style="<?php echo esc_attr( $footer_attrs ); ?>">
	<div class="dxp-footer-inner">

		<div class="dxp-footer-grid<?php echo $cols_side ? ' dxp-footer-grid--cols-side' : ''; ?>">

			<!-- Marka sütunu -->
			<div class="dxp-footer-brand">
				<?php if ( $logo ) : ?>
				<div class="dxp-footer-logobox">
					<img src="<?php echo esc_url( $logo ); ?>"<?php echo devxpe_img_dim_attr( $logo ); ?> alt="<?php echo esc_attr( $site_name ); ?>" loading="lazy" decoding="async">
				</div>
				<?php endif; ?>

				<?php if ( $about ) : ?>
				<p class="dxp-footer-about"><?php echo esc_html( $about ); ?></p>
				<?php endif; ?>

				<?php if ( $note ) : ?>
				<p class="dxp-footer-note"><?php echo esc_html( $note ); ?></p>
				<?php endif; ?>

				<?php if ( $phone || $email || $address ) : ?>
				<ul class="dxp-footer-contact">
					<?php if ( $phone ) : ?>
					<li>
						<?php echo devxpe_lucide( 'phone' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
						<a class="dxp-footer-strong" href="tel:<?php echo esc_attr( preg_replace( '/\s+/', '', $phone ) ); ?>"><?php echo esc_html( $phone ); ?></a>
					</li>
					<?php endif; ?>

					<?php if ( $email ) : ?>
					<li>
						<?php echo devxpe_lucide( 'mail' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
						<a href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a>
					</li>
					<?php endif; ?>

					<?php if ( $address ) : ?>
					<li>
						<?php echo devxpe_lucide( 'map-pin' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
						<span><?php echo esc_html( wp_strip_all_tags( $address ) ); ?></span>
					</li>
					<?php endif; ?>
				</ul>
				<?php endif; ?>
			</div>

			<?php if ( $col2 ) : ?>
			<div class="dxp-footer-col">
				<?php if ( devxpe_theme_get( 'footer_col2_title' ) ) : ?>
				<h2><?php echo esc_html( devxpe_theme_get( 'footer_col2_title' ) ); ?></h2>
				<?php endif; ?>
				<ul>
					<?php foreach ( $col2 as $col2_item ) : ?>
					<li><?php echo devxpe_item_link( $col2_item, '' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></li>
					<?php endforeach; ?>
				</ul>
			</div>
			<?php endif; ?>

			<?php if ( $col3 ) : ?>
			<div class="dxp-footer-col">
				<?php if ( devxpe_theme_get( 'footer_col3_title' ) ) : ?>
				<h2><?php echo esc_html( devxpe_theme_get( 'footer_col3_title' ) ); ?></h2>
				<?php endif; ?>
				<ul>
					<?php foreach ( $col3 as $col3_item ) : ?>
					<li><?php echo devxpe_item_link( $col3_item, '' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></li>
					<?php endforeach; ?>
				</ul>
			</div>
			<?php endif; ?>

		</div>

		<!-- Alt çubuk -->
		<div class="dxp-footer-bottom">
			<div class="dxp-footer-bottom-inner">
				<span>&copy; <?php echo esc_html( $year ); ?> <?php echo esc_html( $site_name ); ?>. <?php echo esc_html( $copyright ); ?></span>
				<?php foreach ( $legal as $legal_item ) : ?>
				<?php echo devxpe_item_link( $legal_item, '' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				<?php endforeach; ?>
			</div>
		</div>

	</div>
</footer><!-- /dxp-footer -->

<?php do_action( 'devxpe_after_footer' ); ?>

<?php get_template_part( 'template-parts/sticky-ads' ); ?>

<?php get_template_part( 'template-parts/floating' ); ?>

<?php wp_footer(); ?>
</body>
</html>
