<?php
/**
 * Normal blog yazısı (post) detay şablonu.
 *
 * WordPress'in normal yazı yapısını kullanır: tarih, yazar, başlık, içerik,
 * etiketler, önceki/sonraki yazı ve yorumlar. İçerik tipleri (CPT) buraya
 * karışmaz — onlar `single.php` ile çizilir.
 *
 * Yazıya öne çıkan görsel eklenmişse görsel, başlığın arkasında yarı şeffaf
 * bir katmanla gösterilir; okunabilirlik için üzerine karartma uygulanır.
 *
 * @package Devxpe_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$dxp_has_thumb = has_post_thumbnail();
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'dxp-single dxp-post' ); ?>>

	<?php if ( '1' === devxpe_theme_get( 'breadcrumb_enabled', '1' ) ) : ?>
	<div class="dxp-crumbs-outer">
		<div class="dxp-detail-inner">
			<?php get_template_part( 'template-parts/breadcrumbs' ); ?>
		</div>
	</div>
	<?php endif; ?>

	<?php
	while ( have_posts() ) :
		the_post();
		?>
		<header class="dxp-post-hero<?php echo $dxp_has_thumb ? ' dxp-post-hero--image' : ''; ?>">
			<?php if ( $dxp_has_thumb ) : ?>
				<?php
				the_post_thumbnail(
					'full',
					array(
						'class'   => 'dxp-post-hero-img',
						'loading' => 'eager',
					)
				);
				?>
				<span class="dxp-post-hero-veil" aria-hidden="true"></span>
			<?php endif; ?>

			<div class="dxp-post-hero-inner">
				<div class="dxp-post-meta">
					<span class="dxp-post-meta-item">
						<span class="dashicons dashicons-calendar-alt" aria-hidden="true"></span>
						<?php echo esc_html( get_the_date() ); ?>
					</span>
					<span class="dxp-post-meta-item">
						<span class="dashicons dashicons-admin-users" aria-hidden="true"></span>
						<?php the_author(); ?>
					</span>
					<?php
					$dxp_cats = get_the_category();
					if ( $dxp_cats ) {
						$dxp_links = array();
						foreach ( $dxp_cats as $dxp_cat ) {
							$dxp_links[] = '<a href="' . esc_url( get_category_link( $dxp_cat ) ) . '">' . esc_html( $dxp_cat->name ) . '</a>';
						}
						echo '<span class="dxp-post-meta-item dxp-post-meta-cats">' . implode( ', ', $dxp_links ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput
					}
					?>
				</div>

				<h1 class="dxp-post-title"><?php the_title(); ?></h1>
			</div>
		</header>

		<div class="dxp-post-layout">
			<div class="dxp-post-main">

				<div class="dxp-post-content entry-content">
					<?php the_content(); ?>
					<?php wp_link_pages(); ?>
				</div>

				<?php
				$dxp_tags = get_the_tag_list( '', '' );
				if ( $dxp_tags ) :
					?>
					<div class="dxp-post-tags"><?php echo wp_kses_post( $dxp_tags ); ?></div>
				<?php endif; ?>

				<?php
				the_post_navigation(
					array(
						'prev_text' => '<span class="dxp-post-nav-label">' . esc_html__( 'Önceki yazı', 'devxpe-theme' ) . '</span><span class="dxp-post-nav-title">%title</span>',
						'next_text' => '<span class="dxp-post-nav-label">' . esc_html__( 'Sonraki yazı', 'devxpe-theme' ) . '</span><span class="dxp-post-nav-title">%title</span>',
					)
				);
				?>

				<?php
				if ( comments_open() || get_comments_number() ) {
					comments_template();
				}
				?>
			</div>

			<?php get_template_part( 'template-parts/blog-sidebar' ); ?>
		</div>
		<?php
	endwhile;
	?>
</article>
<?php
get_footer();
